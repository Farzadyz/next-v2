import { Router } from "express";
import crypto from "crypto";
import { bot, i18nL } from "../bot/index.js";
import { SelectNowpeyment, UpdateNowpeyment } from "../controllers/Nowpeyment.js";
import { UpdateUser, selectUser } from "../controllers/Users.js";
import { SelectSetting } from "../controllers/Setting.js";
import { CreateFree } from "../controllers/Free.js";
import { SelectPeyment, UpdatePeyment } from "../controllers/Peyment.js";
import Servise from "../bot/model/servise.js";
import { CreateAlert } from "../controllers/Alert.js";
const router = Router();

// مرتب سازی کلیدهای آبجکت جهت ساخت امضا دقیقا طبق مستندات نوپیمنت
function sortObject(obj) {
  return Object.keys(obj)
    .sort()
    .reduce((result, key) => {
      result[key] = obj[key] && obj[key].constructor === Object ? sortObject(obj[key]) : obj[key];
      return result;
    }, {});
}

router.post("/nowpayments-ipn", async (req, res) => {
  const setting = await SelectSetting();
  if (!setting.nowpayments_enabled) return res.status(200).json({ ok: true });

  const ipnSecret = setting.nowpayments_ipn_secret || process.env.NOWPAYMENTS_IPN_SECRET;
  // در صورتی که ادمین کلید IPN را تنظیم کرده باشد ، امضا الزاما باید معتبر باشد
  if (ipnSecret) {
    const signature = req.headers["x-nowpayments-sig"];
    if (!signature) return res.status(401).json({ ok: false });
    const hmac = crypto.createHmac("sha512", ipnSecret);
    hmac.update(JSON.stringify(sortObject(req.body)));
    const digest = hmac.digest("hex");
    if (digest !== signature) return res.status(401).json({ ok: false });
  }

  const { payment_id, payment_status } = req.body;
  if (!payment_id) return res.status(200).json({ ok: true });

  const paid = ["finished", "confirmed", "partially_paid"].includes(payment_status);
  if (!paid) return res.status(200).json({ ok: true });

  const result = await SelectNowpeyment({ payment_id: String(payment_id) });
  if (!result || result.deposit) return res.status(200).json({ ok: true });

  await UpdateNowpeyment(result.id, { status: true, deposit: true });
  const user = await selectUser({ id: result.chat_id });
  const { log_buy, invite } = await SelectSetting();

  if (!result.idServise) {
    // شارژ کیف پول
    await UpdateUser({ id: result.chat_id }, { price: user.price + Number(result.amount), first_payment: true });
    bot.telegram.sendMessage(result.chat_id, i18nL.t(user.language, "CRYPTO.SUCCESS_CHARGE", { amount: result.amount }), {
      parse_mode: "html",
    });
  } else {
    // فعالسازی سرویس (پرداخت فاکتور کانفیگ)
    await UpdateUser({ id: result.chat_id }, { first_payment: true });
    await UpdatePeyment({ id: result.idServise }, { status: true });
    const { location, types, price, idPlan, traficc, day, name, gift, defaultname } = await SelectPeyment({ id: result.idServise });
    const Servises = new Servise();
    const { result: results, id } = await Servises.createServise({
      id: result.chat_id,
      traficc,
      day,
      name,
      idPlan,
      defaultname,
      location,
      types2: types,
      price,
    });
    if (!results) {
      bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.ERROR_TO_CREATED"));
      return res.status(200).json({ ok: true });
    }
    bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.SECCEFULY_PLAN", { id }), {
      parse_mode: "html",
    });
    try {
      const getServise = await Servises.SelectServise({ id, i18n: i18nL });
      const { panel, time, remaining, traffic, used_traffic, internal, tunel, name: servName, subscription_url } = getServise;
      bot.telegram.sendMessage(
        result.chat_id,
        i18nL.t("fa", panel == "sanae" ? "MY_ESHTERAK.SEE_ESHTERAK_SANAE" : "MY_ESHTERAK.SEE_ESHTERAK_MARZBAN", {
          id,
          location: getServise.location,
          status: i18nL.t("fa", "MY_ESHTERAK.MENU.STATUS_ON"),
          time,
          traffic,
          remaining,
          used_traffic,
          internal,
          tunel,
          name: servName,
          token: subscription_url,
        }),
        { parse_mode: "html" }
      );
    } catch (error) {}
    CreateAlert({ primaryId: id });
    const gifts = JSON.parse(gift);
    bot.telegram.sendMessage(
      log_buy,
      i18nL.t("fa", "ESHTERAK_BUY.NEW_BUY", {
        type: "خرید",
        id: result.chat_id,
        name: "نا مشخص",
        username: "نا مشخص",
        idEshterak: id,
        pelan: name,
        price,
        day,
        traficc,
        gift: gifts ? i18nL.t("fa", "ESHTERAK_BUY.LOG_BUY_GIFT", { code: gifts.code, gift: gifts.gift }) : "",
      }),
      { parse_mode: "html" }
    );
  }

  if (user.inviter) {
    try {
      const { charge } = JSON.parse(invite);
      const percentageAmount = (charge / 100) * Number(result.amount);
      const userInvier = await selectUser({ id: user.inviter });
      await UpdateUser({ id: user.inviter }, { price: userInvier.price + percentageAmount });
      await CreateFree({ chat_id: user.inviter, amount: percentageAmount, type: "charge" });
      await bot.telegram.sendMessage(user.inviter, i18nL.t(user.language, "PRICE.SEND_INVITE", { percentageAmount }), {
        parse_mode: "html",
      });
    } catch (error) {}
  }

  return res.status(200).json({ ok: true });
});

export default router;
