import { Router } from "express";
import cheerio from "cheerio";
import request from "request";
import BingX from "../api/api-bingx.js";

const router = Router();

router.get("/api/prices", async (req, res) => {
  // check switch

  const url = "https://bonbast.com/graph/usd";
  request(url, async (error, response, body) => {
    if (!error && response.statusCode == 200) {
      // get price dollar to irr
      const $ = cheerio.load(body);
      let priceUsd = Number($("td.price").eq(5).text());
      let usdt = new Intl.NumberFormat("us-us", { maximumSignificantDigits: 3 }).format(priceUsd);
      usdt = usdt.replace(/,/g, "");
      usdt = parseInt(usdt);
      // get price dollar trx
      const bing = new BingX();
      const priceTrx = await bing.getPrice("TRX-USDT");
      // errpr to api
      if (!priceTrx) return res.json({ result: false });
      // const dollar trx to irr
      let converTrx = Math.round(Math.round(Number(priceTrx.data.price) * priceUsd));
      converTrx = new Intl.NumberFormat("us-us", { maximumSignificantDigits: 3 }).format(converTrx);
      converTrx = converTrx.replace(/,/g, "");
      converTrx = parseInt(converTrx);
      //   send result
      res.json({ result: true, usdt, trx: converTrx });
    } else {
      // errpr to api
      res.json({ result: false });
    }
  });
});

export default router;
