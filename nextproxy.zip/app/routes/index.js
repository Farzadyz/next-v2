import { Router } from "express";
import Paystar from "./paystar.js";
import Redirect from "./redirect.js";
import Paystarbot from "./paystartbot.js";
import ZarinPal from "./zarinpal.js";
import Novinpal from "./novinpal.js";
import Polam from "./polam.js";
import Zibal from "./zibal.js";
import Zirgozar from "./zirgozar.js";
import Terapay from "./terapay.js";
import Rialit from "./rialit.js";
import Tabapay from "./tabapay.js";
import Sizpay from "./sizpay.js";
import Bot from "./bot.js";
import Price from "./price.js";
import Resultpay from "./resultpay.js";
import Payment from "./payment.js";
import NowPayments from "./nowpayments.js";
import ResellerApi from "../reseller-api/index.js";
import ResellerProxy from "./resellerProxy.js";
import WebappApi from "../webapp/routes.js";
const router = Router();

router.use(Resultpay);
router.use(Payment);
router.use(NowPayments);
router.use(Paystar);
router.use(Paystarbot);
router.use(Zirgozar);
router.use(Terapay);
router.use(Rialit);
router.use(ZarinPal);
router.use(Sizpay);
router.use(Novinpal);
router.use(Polam);
router.use(Zibal);
router.use(Tabapay);
router.use(Price);
router.use(Redirect);

// Intermediary REST API for isolated reseller bots (own key-based auth) and the
// public gateway-callback pass-through to reseller instances.
router.use(ResellerApi);
router.use(ResellerProxy);

// Telegram Mini App REST API (own initData-based auth) - mounted before the
// generic API_TOKEN gate below, since the Mini App never sends that header.
router.use(WebappApi);

router.use((req, res, next) => {
  if (req.headers.authorization != process.env.API_TOKEN) return res.redirect(process.env.ID_BOT);
  return next();
});

router.use(Bot);

export default router;
