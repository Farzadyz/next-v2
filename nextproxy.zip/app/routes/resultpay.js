import { Router } from "express";

const router = Router();

router.get("/successpay", async (req, res) => {
  res.render("success");
});

router.get("/errorpay", async (req, res) => {
  res.render("error");
});

router.get("/pendingpay", async (req, res) => {
  res.render("pending");
});

router.get("/sizpay", async (req, res) => {
  const token = req.query.token; // گرفتن توکن از URL
  if (!token) return res.send("توکن پیدا نشد!");

  res.render("sizpay", { token }); // پاس دادن token به EJS
});

export default router;
