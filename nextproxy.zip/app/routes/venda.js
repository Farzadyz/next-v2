import { Router } from "express";
import { bot, i18nL } from "../bot/index.js";
import { UpdateUser, selectUser } from "../controllers/Users.js";
import { SelectSetting } from "../controllers/Setting.js";
import { CreateFree } from "../controllers/Free.js";
import { SelectVenda, UpdateVenda } from "../controllers/Venda.js";
import Venda from "../pay/venda.js";
import { CreateAlert } from "../controllers/Alert.js";
import Servise from "../bot/model/servise.js";
import { SelectPeyment } from "../controllers/Peyment.js";
const router = Router();

router.get("/venda*", async (req, res) => {
  const Authority = req.query.token;
  const Status = req.query.payment_status;

  if (!Authority || Status == "FAILED") return res.redirect("/errorpay");

  const result = await SelectVenda({ vprescode: Authority });
  if (!result || result.status) return res.redirect("/errorpay");

  // zarinpal
  const vendas = new Venda();
  const verify = await vendas.VerifyPayment({ token: Authority });
  if (!verify || verify.status != 1) return res.redirect("/errorpay");

  await UpdateVenda({ id: result.id }, { status: true });
  const user = await selectUser({ id: result.chat_id });
  const { log_buy } = await SelectSetting();
  if (!result.payment) {
    await UpdateUser({ id: result.chat_id }, { price: user.price + result.amount });
    bot.telegram.sendMessage(
      result.chat_id,
      i18nL.t(user.language, "PAY.SUCCESS_ZARINPAL", { amount: result.amount, RefID: verify.transId }),
      {
        parse_mode: "html",
      }
    );
  } else {
    // enable servise
    await UpdateUser({ id: result.chat_id }, { first_payment: true });
    const { location, types, price, idPlan, traficc, day, name, gift, defaultname, panel } = await SelectPeyment({ id: result.payment });
    // create api servise
    const Servises = new Servise();
    const { result: results, id } = await Servises.createServise({
      id: result.chat_id,
      traficc,
      day,
      name,
      idPlan,
      defaultname,
      location,
      types2: types,
      panel,
    });
    // error to create
    if (!results) {
      bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.ERROR_TO_CREATED"));
      return res.redirect("/errorpay");
    }
    bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.SECCEFULY_PLAN", { id }), {
      parse_mode: "html",
    });
    try {
      const getServise = await Servises.SelectServise({ id, i18n: i18nL });
      const { panel, time, remaining, traffic, used_traffic, internal, tunel, name, subscription_url } = getServise;
      // send status eshterak
      bot.telegram.sendMessage(
        result.chat_id,
        i18nL.t("fa", panel == "sanae" ? "MY_ESHTERAK.SEE_ESHTERAK_SANAE" : "MY_ESHTERAK.SEE_ESHTERAK_MARZBAN", {
          id,
          location: getServise.location,
          status: i18nL.t("fa", "MY_ESHTERAK.MENU.STATUS_ON"),
          time,
          traffic,
          remaining,
          used_traffic,
          internal,
          tunel,
          name,
          token: subscription_url,
        }),
        {
          parse_mode: "html",
        }
      );
    } catch (error) {}
    // insert to alert
    CreateAlert({ primaryId: id });
    // send meesage buy
    const gifts = JSON.parse(gift);
    bot.telegram.sendMessage(
      log_buy,
      i18nL.t("fa", "ESHTERAK_BUY.NEW_BUY", {
        type: "خرید",
        id: result.chat_id,
        name: "نا مشخص",
        username: "نا مشخص",
        idEshterak: id,
        pelan: name,
        price,
        day,
        traficc,
        gift: gifts ? i18nL.t("fa", "ESHTERAK_BUY.LOG_BUY_GIFT", { code: gifts.code, gift: gifts.gift }) : "",
      }),
      {
        parse_mode: "html",
      }
    );
  }
  // send porsant
  if (user.inviter) {
    const setting = await SelectSetting();
    const { charge } = JSON.parse(setting.invite);
    const percentageAmount = (charge / 100) * result.amount;
    const userInvier = await selectUser({ id: user.inviter });
    UpdateUser({ id: user.inviter }, { price: userInvier.price + percentageAmount });
    CreateFree({ chat_id: user.inviter, amount: percentageAmount, type: "charge" });
    bot.telegram.sendMessage(user.inviter, i18nL.t(user.language, "PRICE.SEND_INVITE", { percentageAmount }), {
      parse_mode: "html",
    });
  }
  return res.redirect("/successpay");
});

export default router;
