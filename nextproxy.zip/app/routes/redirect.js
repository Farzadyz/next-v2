import { Router } from "express";
import axios from "axios";

const router = Router();
const TARGET_BASE = "https://versub.vercel.app";

router.use("/link/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // آدرس واقعی مقصد
    const targetUrl = `${TARGET_BASE}/guards/${id}`;

    const response = await axios({
      method: req.method,
      url: targetUrl,
      responseType: "arraybuffer",
      maxRedirects: 0,
      validateStatus: () => true,
      headers: {
        "accept-encoding": "identity", // ⛔ جلوگیری از gzip
        "user-agent": req.headers["user-agent"] || "Mozilla/5.0",
        accept: req.headers["accept"] || "*/*",
        "accept-language": req.headers["accept-language"] || "en",
        host: "versub.vercel.app",
      },
    });

    // اگر سرور مقصد redirect داد → نادیده بگیر
    if (response.status >= 300 && response.status < 400 && response.headers.location) {
      return res.status(200).end();
    }

    let data = response.data;
    const contentType = response.headers["content-type"] || "";

    // اگر HTML بود → base + قفل URL
    if (contentType.includes("text/html")) {
      let html = data.toString("utf-8");

      html = html.replace(
        "<head>",
        `<head>
<base href="${TARGET_BASE}/">
<script>
(function () {
  const cleanPath = "/${id}";

  const lock = () => {
    if (location.pathname !== cleanPath) {
      history.replaceState(null, "", cleanPath);
    }
  };

  history.pushState = function () {};
  history.replaceState = function () {};

  window.addEventListener("popstate", lock);
  setInterval(lock, 100);
  lock();
})();
</script>
`
      );

      data = Buffer.from(html, "utf-8");
    }

    // ست هدرها (بدون هدرهای دردسرساز)
    Object.entries(response.headers).forEach(([key, value]) => {
      const k = key.toLowerCase();
      if (!["content-encoding", "content-length", "transfer-encoding", "connection"].includes(k)) {
        res.setHeader(key, value);
      }
    });

    res.status(response.status).send(data);
  } catch (err) {
    console.error("Proxy error:", err.message);
    res.status(500).send("Proxy failed");
  }
});

export default router;
