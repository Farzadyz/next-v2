import { Router } from "express";
import { SelectRialit, UpdateRialit } from "../controllers/Rialit.js";
import Rialit from "../pay/rialit.js";
import ProcessRialit from "../pay/rialitProcess.js";
const router = Router();

router.get("/rialit*", async (req, res) => {
  const token = req.query.token;

  if (!token) return res.redirect("/errorpay");

  const result = await SelectRialit({ trans_id: token });
  if (!result) return res.redirect("/errorpay");
  // قبلا با موفقیت پردازش شده
  if (result.status) return res.redirect("/successpay");

  // علامت‌گذاری بازگشت کاربر از درگاه تا کرون این رکورد را verify کند
  if (!result.callback) await UpdateRialit({ id: result.id }, { callback: true });

  // تلاش برای تایید آنی
  const rialit = new Rialit();
  const verify = await rialit.VerifyPayment({ token });

  // درگاه هنوز پرداخت را تایید نکرده (مثلا 409) — به کرون واگذار می‌شود
  if (!verify || verify.status != 3) return res.redirect("/pendingpay");

  // پرداخت موفق — پردازش نهایی
  const ok = await ProcessRialit({ result, verify });
  if (!ok) return res.redirect("/errorpay");
  return res.redirect("/successpay");
});

export default router;
