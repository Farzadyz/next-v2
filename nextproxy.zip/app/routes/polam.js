import { Router } from "express";
import { bot, i18nL } from "../bot/index.js";
import { UpdateUser, selectUser } from "../controllers/Users.js";
import { SelectSetting } from "../controllers/Setting.js";
import { CreateFree } from "../controllers/Free.js";
import { SelectPolam, UpdatePolam } from "../controllers/Polam.js";
import Polam from "../pay/polam.js";
const router = Router();

router.get("/polam*", async (req, res) => {
  const Authority = req.query.statusapi_key;

  if (!Authority) return res.redirect("/errorpay");

  const result = await SelectPolam({ trans_id: Authority });
  if (!result || result.status) return res.redirect("/errorpay");

  // zarinpal
  const vendas = new Polam();
  const verify = await vendas.VerifyPayment({ invoice_key: Authority });
  if (!verify || verify.status != 1) return res.redirect("/errorpay");

  await UpdatePolam({ id: result.id }, { status: true });
  const user = await selectUser({ id: result.chat_id });
  await UpdateUser({ id: result.chat_id }, { price: user.price + result.amount });
  bot.telegram.sendMessage(
    result.chat_id,
    i18nL.t(user.language, "PAY.SUCCESS_ZARINPAL", { amount: result.amount, RefID: verify.refNumber }),
    {
      parse_mode: "html",
    }
  );

  // send porsant
  if (user.inviter) {
    const setting = await SelectSetting();
    const { charge } = JSON.parse(setting.invite);
    const percentageAmount = (charge / 100) * result.amount;
    const userInvier = await selectUser({ id: user.inviter });
    UpdateUser({ id: user.inviter }, { price: userInvier.price + percentageAmount });
    CreateFree({ chat_id: user.inviter, amount: percentageAmount, type: "charge" });
    bot.telegram.sendMessage(user.inviter, i18nL.t(user.language, "PRICE.SEND_INVITE", { percentageAmount }), {
      parse_mode: "html",
    });
  }
  return res.redirect("/successpay");
});

export default router;
