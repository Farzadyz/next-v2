import { Router } from "express";
import Bots from "../action/bot.js";
const router = Router();

router.post("/api/bot", async (req, res) => {
  const username = req.body?.username;
  // error usrname
  if (!username) return res.redirect(process.env.ID_BOT);

  switch (req.body?.query) {
    // get data
    case "getbot":
      return EventListener.GETDATA({ res, username });
    // update price
    case "updateprice":
      return EventListener.UPDATEPRICE({ res, username, price: req.body.price });
    // create peymanet
    case "createpayment":
      return EventListener.CREATEPEYMENT({ res, username, amount: req.body.amount, chat_id: req.body.chat_id });
  }
  return res.json({ result: false });
});

export default router;

const EventListener = {
  // Bots
  ...Bots,
};
