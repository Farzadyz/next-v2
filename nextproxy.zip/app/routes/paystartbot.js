import { Router } from "express";
import { bot, i18nL } from "../bot/index.js";
import { SelectPeystar, UpdatePeystar } from "../controllers/Paystar.js";
import Paystar from "../pay/paystar.js";
import { UpdateBot } from "../controllers/Bot.js";
const router = Router();

router.get("/peystar/pricenmd*", async (req, res) => {
  const card_number = req.query?.card_number;
  const tracking_code = req.query?.tracking_code;

  if (!tracking_code || !card_number) return res.redirect("/errorpay");
  const ref_num = req.query?.ref_num;
  const result = await SelectPeystar({ ref_num });
  if (!result || result.status) return res.redirect("/errorpay");

  // // zarinpal
  const pays = new Paystar();
  const verify = await pays.VerifyPayment({ amount: result.amount, card_number, tracking_code, ref_num });
  if (!verify || verify.status != 1) return res.redirect("/errorpay");
  await UpdatePeystar({ ref_num }, { status: true });
  // send paymennt
  await UpdateBot({ username: result.bot, price: result.amount });
  bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "PAY.SUCCESS_BOT", { amount: result.amount, RefID: ref_num, bot: result.bot }), {
    parse_mode: "html",
  });
  return res.redirect("/successpay");
});

export default router;
