import { Router } from "express";
import geoip from "geoip-country";

const router = Router();

router.get("/payment", async (request, res) => {
  // const ip =
  //   request.headers["cf-connecting-ip"] ||
  //   request.headers["x-real-ip"] ||
  //   request.headers["x-forwarded-for"] ||
  //   request.socket.remoteAddress ||
  //   "";

  // // Automatically handles both IPv4 and IPv6
  // const geo = await geoip.lookup(ip);

  // parametr
  const url = request.query?.url;
  return res.redirect(url);

  // // contry iran
  // if (geo?.country == "IR" && geo?.name == "Iran") return res.redirect(url);

  // // none;
  // if (!geo) return res.redirect(url);

  // return res.render("payment");
});

export default router;
