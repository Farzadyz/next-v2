import http from "http";
import { Router } from "express";
import { SelectReseller } from "../controllers/Reseller.js";

// Public gateway callbacks (Zarinpal / Zibal / Paystar / Novinpal) must reach a
// reseller's OWN payment endpoints. Each isolated instance listens only on
// 127.0.0.1, so the main web server passes GET /r/<id>/pay/* straight through
// (no logic, no data of its own - the reseller instance verifies the payment
// with the reseller's own merchant keys).
const router = Router();

router.get(/^\/r\/(\d+)(\/pay\/.*)$/, async (req, res) => {
  const reseller = await SelectReseller({ id: Number(req.params[0]) }).catch(() => null);
  if (!reseller || !reseller.port || reseller.status !== "active") return res.status(404).send("not found");

  const query = req.originalUrl.includes("?") ? req.originalUrl.slice(req.originalUrl.indexOf("?")) : "";
  const upstream = http.request(
    { host: "127.0.0.1", port: reseller.port, path: req.params[1] + query, method: "GET", timeout: 15000, headers: { accept: req.headers.accept || "*/*" } },
    (response) => {
      res.status(response.statusCode || 502);
      if (response.headers["content-type"]) res.set("content-type", response.headers["content-type"]);
      response.pipe(res);
    }
  );
  upstream.on("timeout", () => upstream.destroy());
  upstream.on("error", () => {
    if (!res.headersSent) res.status(502).send("reseller bot unavailable");
  });
  upstream.end();
});

export default router;
