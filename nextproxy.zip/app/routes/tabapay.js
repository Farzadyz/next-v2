import { Router } from "express";
import { bot, i18nL } from "../bot/index.js";
import { UpdateUser, selectUser } from "../controllers/Users.js";
import { SelectSetting } from "../controllers/Setting.js";
import { CreateFree } from "../controllers/Free.js";
import { SelectTabaPay, UpdateTabaPay } from "../controllers/TabaPay.js";
import TabaPay from "../pay/tabapay.js";
import { SelectPeyment, UpdatePeyment } from "../controllers/Peyment.js";
import Servise from "../bot/model/servise.js";
import { CreateAlert } from "../controllers/Alert.js";
const router = Router();

router.get("/tabapay*", async (req, res) => {
  const Authority = req.query.token;

  if (!Authority) return res.redirect("/errorpay");

  const result = await SelectTabaPay({ trans_id: Authority });
  if (!result || result.status) return res.redirect("/errorpay");

  // zarinpal
  const vendas = new TabaPay();
  const verify = await vendas.VerifayPeyment({ token: Authority, amount: result.amount });
  if (!verify || verify.responseCode != 1) return res.redirect("/errorpay");

  await UpdateTabaPay({ id: result.id }, { status: true });
  const user = await selectUser({ id: result.chat_id });
  const { log_buy, invite } = await SelectSetting();

  if (!result.payment) {
    await UpdateUser({ id: result.chat_id }, { price: user.price + result.amount });
    bot.telegram.sendMessage(
      result.chat_id,
      i18nL.t(user.language, "PAY.SUCCESS_ZARINPAL", { amount: result.amount, RefID: verify.trackingCode }),
      {
        parse_mode: "html",
      }
    );
  } else {
    // enable servise
    await UpdateUser({ id: result.chat_id }, { first_payment: true });
    await UpdatePeyment({ id: result.payment }, { status: true });
    const { location, types, price, idPlan, traficc, day, name, gift, defaultname, panel } = await SelectPeyment({ id: result.payment });
    // create api servise
    const Servises = new Servise();
    const { result: results, id } = await Servises.createServise({
      id: result.chat_id,
      traficc,
      day,
      name,
      idPlan,
      defaultname,
      location,
      types2: types,
      panel,
      price,
    });
    // error to create
    if (!results) {
      bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.ERROR_TO_CREATED"));
      return res.redirect("/errorpay");
    }
    bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.SECCEFULY_PLAN", { id }), {
      parse_mode: "html",
    });
    try {
      const getServise = await Servises.SelectServise({ id, i18n: i18nL });
      const { panel, time, remaining, traffic, used_traffic, internal, tunel, name, subscription_url } = getServise;
      // send status eshterak
      bot.telegram.sendMessage(
        result.chat_id,
        i18nL.t("fa", panel == "sanae" ? "MY_ESHTERAK.SEE_ESHTERAK_SANAE" : "MY_ESHTERAK.SEE_ESHTERAK_MARZBAN", {
          id,
          location: getServise.location,
          status: i18nL.t("fa", "MY_ESHTERAK.MENU.STATUS_ON"),
          time,
          traffic,
          remaining,
          used_traffic,
          internal,
          tunel,
          name,
          token: subscription_url,
        }),
        {
          parse_mode: "html",
        }
      );
    } catch (error) {}
    // insert to alert
    CreateAlert({ primaryId: id });
    // send meesage buy
    const gifts = JSON.parse(gift);
    bot.telegram.sendMessage(
      log_buy,
      i18nL.t("fa", "ESHTERAK_BUY.NEW_BUY", {
        type: "خرید",
        id: result.chat_id,
        name: "نا مشخص",
        username: "نا مشخص",
        idEshterak: id,
        pelan: name,
        price,
        day,
        traficc,
        gift: gifts ? i18nL.t("fa", "ESHTERAK_BUY.LOG_BUY_GIFT", { code: gifts.code, gift: gifts.gift }) : "",
      }),
      {
        parse_mode: "html",
      }
    );
  }

  // send porsant
  if (user.inviter) {
    const { charge } = JSON.parse(invite);
    const percentageAmount = (charge / 100) * result.amount;
    const userInvier = await selectUser({ id: user.inviter });
    UpdateUser({ id: user.inviter }, { price: userInvier.price + percentageAmount });
    CreateFree({ chat_id: user.inviter, amount: percentageAmount, type: "charge" });
    bot.telegram.sendMessage(user.inviter, i18nL.t(user.language, "PRICE.SEND_INVITE", { percentageAmount }), {
      parse_mode: "html",
    });
  }
  return res.redirect("/successpay");
});

export default router;
