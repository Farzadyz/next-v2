import Free from "../model/free.js";
import { Op } from "sequelize";
import moment from "moment";

const CreateFree = async ({ chat_id, amount, type }) => {
  await Free.create({ chat_id, amount, type });
};

const SelectFree = (object) => {
  return Free.findOne({ where: object });
};

const countFree = async () => {
  const FreeCount = await Free.sum("amount");
  return FreeCount;
};

const countAddedWeekFree = async () => {
  return Free.sum("amount", {
    where: {
      createdAt: {
        [Op.gte]: moment().startOf("week").toDate(),
        [Op.lte]: moment().endOf("week").toDate(),
      },
    },
  });
};

const countAddedMonthFree = async () => {
  return Free.sum("amount", {
    where: {
      createdAt: {
        [Op.gte]: moment().startOf("month").toDate(),
        [Op.lte]: moment().endOf("month").toDate(),
      },
    },
  });
};

// total referral income a single user has earned - "invite" rows are the
// fixed per-signup bonus, "charge" rows are the ongoing top-up percentage
// (see app/bot/middleware/CommendMiddleware.js and the wallet-topup crediting
// logic mirrored in app/webapp/controllers/shopApi.js checkCryptoTopup)
const sumUserReferralEarnings = async (chat_id) => {
  const total = await Free.sum("amount", { where: { chat_id, type: { [Op.in]: ["invite", "charge"] } } });
  return total || 0;
};

export { CreateFree, SelectFree, countFree, countAddedWeekFree, countAddedMonthFree, sumUserReferralEarnings };
