import Inbound from "../model/inbound.js";
import { PANEL_TYPES } from "../utils/panelTypes.js";

// create a server of the "Sanaei New Versions" panel type
const CreataInboundSanaeiNew = async ({ location, internal, usePort, port, tunel, host, type, damoin, username, password, session, price }) => {
  const { id } = await Inbound.create({
    location,
    usePort,
    port,
    internal,
    tunel,
    host,
    damoin,
    type,
    username,
    password,
    session,
    price,
    panel: PANEL_TYPES.SANAEI_NEW,
  });
  return id;
};

// all servers of the "Sanaei New Versions" panel type
const selectAllInboundSanaeiNew = async () => {
  return Inbound.findAll({ where: { panel: PANEL_TYPES.SANAEI_NEW } });
};

export { CreataInboundSanaeiNew, selectAllInboundSanaeiNew };
