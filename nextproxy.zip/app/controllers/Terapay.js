import Terapay from "../model/terapay.js";

const CreateTerapay = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Terapay.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectTerapay = async (object) => {
  const select = await Terapay.findOne({ where: object });
  return select;
};

const UpdateTerapay = async ({ id }, object) => {
  await Terapay.update(object, { where: { id } });
};

export { CreateTerapay, SelectTerapay, UpdateTerapay };
