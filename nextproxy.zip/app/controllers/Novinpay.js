import Novinpay from "../model/novinpay.js";

const CreateNovinpay = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Novinpay.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectNovinpay = async (object) => {
  const select = await Novinpay.findOne({ where: object });
  return select;
};

const CountNovinpay = async () => {
  return Novinpay.count();
};

const UpdateNovinpay = async ({ id }, object) => {
  await Novinpay.update(object, { where: { id } });
};

export { CreateNovinpay, SelectNovinpay, UpdateNovinpay, CountNovinpay };
