import { Op } from "sequelize";
import Inbound from "../model/inbound.js";
import sequelize from "../utils/database.js";

const CreataInbound = async ({ location, internal, usePort, port, tunel, host, type, damoin, username, password, session, price }) => {
  const { id } = await Inbound.create({ location, usePort, port, internal, tunel, host, damoin, type, username, password, session, price });
  return id;
};

const selectAllInbound = async () => {
  const data = await Inbound.findAll();
  return data;
};

const selectAllInboundType = async (type = "normal") => {
  const data = await Inbound.findAll({
    where: {
      usePort: {
        [Op.ne]: sequelize.literal(`SUBSTRING_INDEX(SUBSTRING_INDEX(port, ',', 2), ',', -1)`), // استفاده از SUBSTRING_INDEX برای گرفتن دومین مقدار
      },
      status: true,
      type,
    },
  });
  return data;
};

const selectInbound = async (object) => {
  const data = await Inbound.findOne({ where: object });
  return data;
};

const selectFirstInbound = async () => {
  const count = await Inbound.count();
  const randomIndex = Math.floor(Math.random() * count);
  return Inbound.findOne({ where: { id: 3 } });
};

const UpdateInbound = async ({ id }, object) => {
  await Inbound.update(object, { where: { id } });
};

const DestoryInbound = async (object) => {
  await Inbound.destroy({
    where: object,
  });
};

const getInboundsByIds = async (ids) => {
  const inbounds = await Inbound.findAll({
    where: {
      id: {
        [Op.in]: ids,
      },
    },
  });

  return {
    success: true,
    data: inbounds,
    message: "Inbounds fetched successfully.",
  };
};

export {
  CreataInbound,
  selectAllInbound,
  selectFirstInbound,
  selectAllInboundType,
  selectInbound,
  DestoryInbound,
  UpdateInbound,
  getInboundsByIds,
};
