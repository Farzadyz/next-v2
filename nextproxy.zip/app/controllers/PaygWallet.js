import { Op, literal } from "sequelize";
import Users from "../model/users.js";

// wallets of many users in one query (id -> user)
const selectUsersByIds = async (ids) => {
  if (!ids.length) return [];
  return Users.findAll({ where: { id: { [Op.in]: ids } } });
};

// Atomic wallet deduction (a single conditional UPDATE - a concurrent top-up / purchase can never be overwritten).
//  - partial = false : all-or-nothing, nothing is taken when the balance is lower than `amount`
//  - partial = true  : takes as much as the wallet has (up to `amount`)
// returns { deducted, balance } - `balance` is the wallet after the deduction
const DeductUserBalance = async ({ id, amount, partial = false }) => {
  const want = Math.floor(Number(amount));
  let balance = 0;
  for (let attempt = 0; attempt < 3; attempt++) {
    const user = await Users.findOne({ where: { id } });
    if (!user) return { deducted: 0, balance: 0 };
    balance = Number(user.price) || 0;
    if (!Number.isFinite(want) || want <= 0) return { deducted: 0, balance };
    const take = partial ? Math.min(want, Math.max(balance, 0)) : want;
    if (take <= 0 || balance < take) return { deducted: 0, balance };
    const [affected] = await Users.update({ price: literal(`price - ${take}`) }, { where: { id, price: { [Op.gte]: take } } });
    if (affected > 0) return { deducted: take, balance: balance - take };
  }
  return { deducted: 0, balance };
};

export { selectUsersByIds, DeductUserBalance };
