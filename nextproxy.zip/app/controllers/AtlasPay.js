import AtlasPay from "../model/atlaspay.js";

const CreateAtlasPay = async ({ payment, chat_id, amount, order_id, tracking_code }) => {
  const { id } = await AtlasPay.create({ payment, chat_id, amount, order_id, tracking_code });
  return id;
};

const SelectAtlasPay = (object) => {
  return AtlasPay.findOne({ where: object });
};

// رکوردهای در انتظار تایید برای کرون verify (هنوز نه موفق و نه بسته شده)
const SelectPendingAtlasPay = () => {
  return AtlasPay.findAll({ where: { status: false, closed: false } });
};

const CountAtlasPay = async () => {
  return AtlasPay.count();
};

const UpdateAtlasPay = async ({ id }, object) => {
  await AtlasPay.update(object, { where: { id } });
};

export { CreateAtlasPay, SelectAtlasPay, SelectPendingAtlasPay, CountAtlasPay, UpdateAtlasPay };
