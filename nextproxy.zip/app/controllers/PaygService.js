import { Op } from "sequelize";
import PaygService from "../model/paygservice.js";
import Servise from "../model/servise.js";

const CreatePaygService = async ({ service_id, telegram_id, initial_traffic, initial_days }) => {
  const { id } = await PaygService.create({ service_id, telegram_id, initial_traffic, initial_days });
  // اثرات جانبی خرید جدید (ثبت هزینه ایجاد در لاگ کسر هزینه + پیام فوری به ادمین) - هرگز خرید را کند یا خراب نمی‌کند
  // (import پویا برای جلوگیری از وابستگی حلقوی با ربات)
  import("../utils/paygPurchase.js")
    .then((module) => module.onPaygPurchased(id))
    .catch((error) => console.error("PAYG purchase hooks failed:", error?.message || error));
  return id;
};

const SelectPaygService = (object) => {
  return PaygService.findOne({ where: object });
};

// سرویس‌های فعال (تعلیق نشده) - برای کرون کسر هزینه بر اساس مصرف/روز
const SelectActivePaygService = () => {
  return PaygService.findAll({ where: { suspended_at: null } });
};

// سرویس‌های تعلیق‌شده - برای کرون فعال‌سازی مجدد یا حذف نهایی بعد از ۱۲ ساعت
const SelectSuspendedPaygService = () => {
  return PaygService.findAll({ where: { suspended_at: { [Op.ne]: null } } });
};

// سرویس‌های تعلیق‌شده یک کاربر - برای فعال‌سازی مجدد فوری بعد از شارژ کیف پول
const SelectSuspendedPaygServiceByUser = ({ telegram_id }) => {
  return PaygService.findAll({ where: { telegram_id, suspended_at: { [Op.ne]: null } }, order: [["id", "ASC"]] });
};

// ردیف سرویس‌های اصلی (جدول servise) چند سرویس PAYG در یک کوئری - برای حلقه لحظه‌ای صورتحساب
const SelectServisesByIds = (ids) => {
  if (!ids.length) return [];
  return Servise.findAll({ where: { id: { [Op.in]: ids } } });
};

// لیست صفحه‌بندی‌شده همه سرویس‌های PAYG - برای صفحه مدیریت پنل ادمین
const SelectAllPaygService = ({ offset, limit }) => {
  return PaygService.findAll({ offset, limit, order: [["id", "DESC"]] });
};

const CountPaygService = () => {
  return PaygService.count();
};

const UpdatePaygService = async ({ id }, object) => {
  await PaygService.update(object, { where: { id } });
};

const DeletePaygServiceRow = async ({ id }) => {
  await PaygService.destroy({ where: { id } });
};

export {
  CreatePaygService,
  SelectPaygService,
  SelectActivePaygService,
  SelectSuspendedPaygService,
  SelectSuspendedPaygServiceByUser,
  SelectServisesByIds,
  SelectAllPaygService,
  CountPaygService,
  UpdatePaygService,
  DeletePaygServiceRow,
};
