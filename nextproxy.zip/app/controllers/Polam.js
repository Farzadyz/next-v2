import Polam from "../model/polam.js";

const CreatePolam = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Polam.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectPolam = async (object) => {
  const select = await Polam.findOne({ where: object });
  return select;
};

const UpdatePolam = async ({ id }, object) => {
  await Polam.update(object, { where: { id } });
};

export { CreatePolam, SelectPolam, UpdatePolam };
