import Servise from "../model/servise.js";
import { PANEL_TYPES } from "../utils/panelTypes.js";

// free (test) services that are active on a "Sanaei New Versions" panel - used by the test-service expire cron
const SelectAllFreeActiveSanaeiNew = async () => {
  return Servise.findAll({ where: { panel: PANEL_TYPES.SANAEI_NEW, free: true, status: true } });
};

export { SelectAllFreeActiveSanaeiNew };
