import Venda from "../model/venda.js";

const CreateVenda = async ({ payment, chat_id, amount, vprescode }) => {
  const { id } = await Venda.create({ payment, chat_id, amount, vprescode });
  return id;
};

const SelectVenda = (object) => {
  return Venda.findOne({ where: object });
};

const CountVenda = async () => {
  return Venda.count();
};

const UpdateVenda = async (id, object) => {
  await Venda.update(object, { where: { id } });
};

export { CreateVenda, SelectVenda, CountVenda, UpdateVenda };
