import Nowpeyment from "../model/nowpeyment.js";

const CreateNowpeyment = async (object) => {
  const { id } = await Nowpeyment.create(object);
  return id;
};

const SelectNowpeyment = async (object) => {
  const select = await Nowpeyment.findOne({ where: object });
  return select;
};

const UpdateNowpeyment = async (id, object) => {
  await Nowpeyment.update(object, { where: { id } });
};

export { CreateNowpeyment, SelectNowpeyment, UpdateNowpeyment };
