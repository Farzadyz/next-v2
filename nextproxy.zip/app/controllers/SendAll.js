import Sendall from "../model/sendAll.js";

const CreateSendall = async () => {
  await Sendall.create();
};

const SelectSendall = async () => {
  const data = await Sendall.findOne({ where: { id: 1 } });
  return data;
};

const UpdateSendall = async (object) => {
  await Sendall.update(object, { where: { id: 1 } });
};

export { UpdateSendall, CreateSendall, SelectSendall };
