import Number from "../model/number.js";

const CreateNumber = async ({ phonenumber }) => {
  await Number.create({ phonenumber });
};

const SelectNumber = async ({ phonenumber }) => {
  const data = await Number.findOne({ where: { phonenumber } });
  return data;
};

export { CreateNumber, SelectNumber };
