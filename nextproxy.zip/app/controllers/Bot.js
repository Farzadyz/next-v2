import Bot from "../model/bot.js";

const SelectBot = ({ username }) => {
  return Bot.findOne({ where: { username } });
};

const UpdateBot = async ({ username, price }) => {
  const select = await SelectBot({ username });
  // check
  if (select) return Bot.update({ price: select.price + Number(price) }, { where: { username } });
  await Bot.create({ username, price });
};

export { SelectBot, UpdateBot };
