import { Op } from "sequelize";
import Servise from "../model/servise.js";

const CreateServise = async ({
  id,
  uuid,
  email,
  name,
  types,
  defaultname,
  location,
  data_limit,
  id_pelan,
  traficc,
  day,
  free,
  key,
  panel,
  price,
}) => {
  const lastItem = await Servise.findOne({
    order: [["id", "DESC"]],
  });
  const username = defaultname ? `Userbot${lastItem ? lastItem.id + 1 : 1}` : name + "-" + key;
  const servise = await Servise.create({
    id_pelan,
    telegram_id: id,
    username: panel == "marzban" ? username : email,
    uuid,
    location,
    types,
    name,
    defaultname,
    data_limit,
    first_data_limit: data_limit,
    traficc,
    time: day,
    free,
    panel,
    price: price || 0,
  });
  return { ids: servise.id, username };
};

const SelectServise = async ({ id }) => {
  return Servise.findOne({ where: { id } });
};

const SelectALLServiseUser = async ({ telegram_id, offset, limit }) => {
  const data = await Servise.findAll({
    where: { telegram_id },
    offset,
    limit,
    order: [["id", "DESC"]],
  });
  return data;
};

const SelectALLServise = async (type) => {
  if (type) {
    return Servise.findAll({ where: { type: { [Op.ne]: type } } });
  } else {
    return Servise.findAll();
  }
};

// سرویس‌های تست (رایگان) فعال روی پنل x-ui/sanae - برای کرون اجرای واقعی تعلیق بعد از انقضا
const SelectAllFreeActiveSanae = async () => {
  return Servise.findAll({ where: { panel: "sanae", free: true, status: true } });
};

const SearchServise = async (telegram_id, searchTerm, admin = false) => {
  const whereClause = {
    [Op.and]: [
      // شرط telegram_id را فقط در صورتی اضافه می‌کنیم که admin برابر با false باشد
      ...(admin ? [] : [{ telegram_id }]),
      {
        [Op.or]: [
          { id: { [Op.like]: `%${searchTerm}%` } },
          { name: { [Op.like]: `%${searchTerm}%` } },
          { username: { [Op.like]: `%${searchTerm}%` } },
          { uuid: { [Op.like]: `%${searchTerm}%` } },
        ],
      },
    ],
  };

  return Servise.findAll({
    where: whereClause,
  });
};

const CountServise = async ({ telegram_id }) => {
  return Servise.count({ where: { telegram_id } });
};

const UpdateServise = async ({ id }, object) => {
  await Servise.update(object, { where: { id } });
};

const DeleteServise = async ({ id }) => {
  await Servise.destroy({ where: { id } });
};

const getServicesByDateRange = async (startDate, endDate, ids) => {
  try {
    const services = await Servise.findAll({
      where: {
        createdAt: {
          [Op.between]: [new Date(startDate), new Date(endDate)],
        },
        location: {
          [Op.in]: ids,
        },
        panel: "sanae",
      },
    });

    return {
      success: true,
      data: services,
      message: "Services fetched successfully.",
    };
  } catch (error) {
    console.error("Error fetching services by date range:", error);

    return {
      success: false,
      data: null,
      message: "An error occurred while fetching services.",
    };
  }
};

export {
  CreateServise,
  SelectALLServise,
  SelectAllFreeActiveSanae,
  SelectALLServiseUser,
  SelectServise,
  SearchServise,
  CountServise,
  UpdateServise,
  DeleteServise,
  getServicesByDateRange,
};
