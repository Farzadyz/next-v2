import { Op } from "sequelize";
import moment from "moment";
import ResellerTopup from "../model/resellertopup.js";

const CreateResellerTopup = async (data) => {
  return ResellerTopup.create(data);
};

const SelectResellerTopup = async (where) => {
  return ResellerTopup.findOne({ where });
};

const SelectResellerTopups = async ({ reseller_id, limit = 10 }) => {
  return ResellerTopup.findAll({ where: { reseller_id }, order: [["id", "DESC"]], limit });
};

const SelectPendingResellerTopups = async () => {
  return ResellerTopup.findAll({ where: { status: "pending" } });
};

// paid invoices the reseller bot has not been told about yet
const SelectUnnotifiedPaidTopups = async () => {
  return ResellerTopup.findAll({ where: { status: "paid", notified: false, updatedAt: { [Op.gte]: moment().subtract(2, "days").toDate() } } });
};

const UpdateResellerTopup = async ({ id }, object) => {
  return ResellerTopup.update(object, { where: { id } });
};

export {
  CreateResellerTopup,
  SelectResellerTopup,
  SelectResellerTopups,
  SelectPendingResellerTopups,
  SelectUnnotifiedPaidTopups,
  UpdateResellerTopup,
};
