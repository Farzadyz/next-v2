import Pelan from "../model/pelan.js";

const CreataPelan = async ({ name, price, traficc, time, panel, type, connection }) => {
  await Pelan.create({ name, price, traficc, time, panel, type, connection });
};

const selectAllPelan = async () => {
  const data = await Pelan.findAll();
  return data;
};

const selectAllPelanLocation = async (object) => {
  const data = await Pelan.findAll({ where: object });
  return data;
};

const selectPelan = async (object) => {
  const data = await Pelan.findOne({ where: object });
  return data;
};

const UpdatePelan = ({ id }, object) => {
  Pelan.update(object, { where: { id } });
};

const DestoryPelan = async ({ name }) => {
  await Pelan.destroy({
    where: { name },
  });
};

export { CreataPelan, selectAllPelan, selectPelan, UpdatePelan, DestoryPelan, selectAllPelanLocation };
