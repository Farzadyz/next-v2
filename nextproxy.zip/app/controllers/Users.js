import { Op } from "sequelize";
import moment from "moment";
import Users from "../model/users.js";
import Servise from "../model/servise.js";

const insertUser = async ({ id, inviter }) => {
  const find = await selectUser({ id });
  if (find) return true;
  Users.create({ id, inviter });
};

const selectUser = async ({ id }) => {
  const data = await Users.findOne({ where: { id } });
  return data;
};

const selectAllUser = async () => {
  return Users.findAll();
};

const selectUserForAll = async ({ offset, limit, type = "ALL" }) => {
  const where = {};

  switch (type) {
    case "BUYS":
      where.first_payment = true;
      break;
    case "NOBUYES":
      where.first_payment = false;
      break;
    case "NOTEST":
      where.first_payment = false;
      where.free = false;
      break;
    case "TEST":
      where.first_payment = false;
      where.free = true;
      break;
  }

  return await Users.findAll({ offset, limit, where, order: [["ids", "ASC"]] });
};

const selectAllAgent = () => {
  return Users.findAll({ where: { agent: true } });
};

const selectLastMessage = async () => {
  // تاریخ 30 روز پیش
  const thirtyDaysAgo = moment().subtract(30, "days").toDate();
  return Users.findAll({
    where: {
      last_Message: {
        [Op.lt]: thirtyDaysAgo, // [Op.lt] برای تاریخ‌های قبل از تاریخ مشخص شده
      },
      status: true, // اضافه کردن شرط برای status
    },
  });
};

const UpdateUser = async ({ id }, object) => {
  await Users.update(object, { where: { id } });
};

const countUser = async () => {
  const usersCount = await Users.count();
  return usersCount;
};

const countAddedToday = async () => {
  return Users.count({
    where: {
      createdAt: {
        [Op.gte]: moment().startOf("day").toDate(),
        [Op.lte]: moment().endOf("day").toDate(),
      },
    },
  });
};

const countAddedWeek = async () => {
  return Users.count({
    where: {
      createdAt: {
        [Op.gte]: moment().startOf("week").toDate(),
        [Op.lte]: moment().endOf("week").toDate(),
      },
    },
  });
};

const countAddedMonth = async () => {
  return Users.count({
    where: {
      createdAt: {
        [Op.gte]: moment().startOf("month").toDate(),
        [Op.lte]: moment().endOf("month").toDate(),
      },
    },
  });
};

const countAddedYear = async () => {
  return Users.count({
    where: {
      createdAt: {
        [Op.gte]: moment().startOf("year").toDate(),
        [Op.lte]: moment().endOf("year").toDate(),
      },
    },
  });
};

const updateFirstPaymentFlag = async () => {
  try {
    // دریافت همه کاربران
    const users = await Users.findAll();

    for (const user of users) {
      // بررسی وجود سرویس با id یا telegram_id مربوط به کاربر
      const hasService = await Servise.findOne({
        where: { telegram_id: user.id },
      });

      // اگر سرویس وجود داشت، first_payment را true کن
      if (hasService) {
        await user.update({ first_payment: true });
      }
    }

    console.log("Update completed.");
  } catch (error) {
    console.error("Error updating first_payment:", error);
  }
};

export {
  insertUser,
  selectUser,
  selectAllUser,
  selectUserForAll,
  selectLastMessage,
  selectAllAgent,
  UpdateUser,
  countUser,
  countAddedToday,
  countAddedWeek,
  countAddedMonth,
  countAddedYear,
  updateFirstPaymentFlag,
};
