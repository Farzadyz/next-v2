import PaygUsageLog from "../model/paygusagelog.js";

const CreatePaygUsageLog = async ({ payg_service_id, used_traffic_bytes, cost }) => {
  await PaygUsageLog.create({ payg_service_id, used_traffic_bytes, cost });
};

// آخرین N رکورد مصرف برای رسم نمودار (صعودی بر اساس زمان)
const SelectPaygUsageLogs = async ({ payg_service_id, limit = 30 }) => {
  const rows = await PaygUsageLog.findAll({
    where: { payg_service_id },
    order: [["id", "DESC"]],
    limit,
  });
  return rows.reverse();
};

export { CreatePaygUsageLog, SelectPaygUsageLogs };
