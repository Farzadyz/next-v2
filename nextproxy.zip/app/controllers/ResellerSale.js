import ResellerSale from "../model/resellersale.js";

const CreateResellerSale = async (data) => {
  return ResellerSale.create(data);
};

const SelectResellerSales = async ({ reseller_id, limit = 50 }) => {
  return ResellerSale.findAll({ where: { reseller_id }, order: [["id", "DESC"]], limit });
};

// idempotency lookup - the same request_id never creates/charges twice
const SelectResellerSaleByRequest = async ({ reseller_id, request_id }) => {
  return ResellerSale.findOne({ where: { reseller_id, request_id } });
};

// the sale that originally created a service (used to authorise + price renewals)
const SelectResellerSaleByService = async ({ reseller_id, servise_id }) => {
  return ResellerSale.findOne({ where: { reseller_id, servise_id: String(servise_id) }, order: [["id", "ASC"]] });
};

const CountResellerFreeByCustomer = async ({ reseller_id, customer_id }) => {
  return ResellerSale.count({ where: { reseller_id, customer_id, kind: "free" } });
};

const CountResellerSales = async ({ reseller_id }) => {
  return ResellerSale.count({ where: { reseller_id } });
};

const SumResellerSales = async ({ reseller_id }) => {
  return (await ResellerSale.sum("cost", { where: { reseller_id } })) || 0;
};

export {
  CreateResellerSale,
  SelectResellerSales,
  SelectResellerSaleByRequest,
  SelectResellerSaleByService,
  CountResellerFreeByCustomer,
  CountResellerSales,
  SumResellerSales,
};
