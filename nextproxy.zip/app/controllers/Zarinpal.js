import Zarinpal from "../model/zarinpal.js";

const CreateZarinpal = async ({ payment, chat_id, amount, authority }) => {
  const { id } = await Zarinpal.create({ payment, chat_id, amount, authority });
  return id;
};

const SelectZarinpal = async (object) => {
  const select = await Zarinpal.findOne({ where: object });
  return select;
};

const UpdateZarinpal = async ({ id }, object) => {
  await Zarinpal.update(object, { where: { id } });
};

export { CreateZarinpal, SelectZarinpal, UpdateZarinpal };
