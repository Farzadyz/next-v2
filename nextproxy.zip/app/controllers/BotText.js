import BotText from "../model/bottext.js";

// Return every override row currently stored in the database.
const SelectAllBotTexts = async () => {
  return BotText.findAll();
};

// Return a single override row by its i18n key (e.g. "MENU.ESHTERAK_BUY").
const SelectBotText = async ({ text_key }) => {
  return BotText.findOne({ where: { text_key } });
};

// Create or update the override for a key in a single call.
const UpsertBotText = async ({ text_key, value }) => {
  const existing = await BotText.findOne({ where: { text_key } });
  if (existing) {
    await BotText.update({ value }, { where: { text_key } });
    return { text_key, value };
  }
  await BotText.create({ text_key, value });
  return { text_key, value };
};

// Remove an override so the key falls back to the locales/fa.yaml default.
const DeleteBotText = async ({ text_key }) => {
  return BotText.destroy({ where: { text_key } });
};

export { SelectAllBotTexts, SelectBotText, UpsertBotText, DeleteBotText };
