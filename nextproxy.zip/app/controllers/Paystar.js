import Peystar from "../model/paystar.js";
import { Op } from "sequelize";

const CreatePeystar = async ({ chat_id, bot, amount, ref_num, payment }) => {
  const { id } = await Peystar.create({ chat_id, bot, amount, ref_num, payment });
  return id;
};

const SelectPeystar = (object) => {
  return Peystar.findOne({ where: object });
};

const SelectHoursPeystar = async () => {
  const twelveHoursAgo = new Date(Date.now() - 12 * 60 * 60 * 1000);

  return Peystar.findAll({
    where: {
      status: true,
      payment: {
        [Op.ne]: null, // شرط برای اینکه payment برابر null نباشد
      },
      createdAt: {
        [Op.gte]: twelveHoursAgo,
      },
    },
  });
};

const CountPeystar = async () => {
  return Peystar.count();
};

const UpdatePeystar = async (wheres, object) => {
  await Peystar.update(object, { where: wheres });
};

export { CreatePeystar, SelectPeystar, CountPeystar, UpdatePeystar, SelectHoursPeystar };
