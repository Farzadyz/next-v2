import Peyment from "../model/peyment.js";
import { Op } from "sequelize";
import moment from "moment";

const CreatePeyment = async ({ location, types, name, price, day, traficc, idPlan, telegram_id, uuid, idServise, panel, connection }) => {
  const { id } = await Peyment.create({
    location,
    types,
    name,
    price,
    priceTamdid: price,
    day,
    traficc,
    idPlan,
    telegram_id,
    uuid,
    idServise,
    panel,
    connection,
  });
  return id;
};

const SelectPeyment = async ({ id }) => {
  const data = await Peyment.findOne({ where: { id } });
  return data;
};

const SelectAllPeyment = async () => {
  return Peyment.findAll({
    where: {
      status: true,
      createdAt: {
        [Op.gte]: moment().startOf("month").toDate(),
        [Op.lte]: moment().endOf("month").toDate(),
      },
    },
  });
};

const CountPeyment = async ({ id }) => {
  const data = await Peyment.count({ where: { belongs: id, status: true } });
  return data;
};

const countAllPeyment = async () => {
  return await Peyment.count({ where: { status: true } });
};

const UpdatePeyment = async ({ id }, object) => {
  await Peyment.update(object, { where: { id } });
};

const countAddedTodayPeyment = async () => {
  return Peyment.count({
    where: {
      status: true,
      createdAt: {
        [Op.gte]: moment().startOf("day").toDate(),
        [Op.lte]: moment().endOf("day").toDate(),
      },
    },
  });
};

const countAddedWeekPeyment = async () => {
  return Peyment.count({
    where: {
      status: true,
      createdAt: {
        [Op.gte]: moment().startOf("week").toDate(),
        [Op.lte]: moment().endOf("week").toDate(),
      },
    },
  });
};

const countAddedMonthPeyment = async () => {
  return Peyment.count({
    where: {
      status: true,
      createdAt: {
        [Op.gte]: moment().startOf("month").toDate(),
        [Op.lte]: moment().endOf("month").toDate(),
      },
    },
  });
};

const countAddedYearPeyment = async () => {
  return Peyment.count({
    where: {
      status: true,
      createdAt: {
        [Op.gte]: moment().startOf("year").toDate(),
        [Op.lte]: moment().endOf("year").toDate(),
      },
    },
  });
};

const SelectRecentPendingPeyments = async () => {
  const oneDayAgo = moment().subtract(24, "hours").toDate();

  // 1️⃣ گرفتن همه فاکتورهای ۲۴ ساعت اخیر که هنوز پیام تخفیف نگرفته‌اند
  const payments = await Peyment.findAll({
    where: {
      createdAt: { [Op.gte]: oneDayAgo },
      alert_gift: false,
    },
    order: [["createdAt", "DESC"]],
  });

  if (!payments.length) return [];

  // 2️⃣ گروه‌بندی براساس telegram_id
  const groups = {};

  payments.forEach((p) => {
    if (!groups[p.telegram_id]) groups[p.telegram_id] = [];
    groups[p.telegram_id].push(p);
  });

  // 3️⃣ پردازش هر کاربر
  const results = [];

  Object.keys(groups).forEach((telegram_id) => {
    const userPayments = groups[telegram_id];

    // اگر حداقل یکی پرداخت کرده → هیچ چیز اضافه نکن
    const anyPaid = userPayments.some((p) => p.status === true);
    if (anyPaid) return;

    // اگر پرداخت نشده → فقط جدیدترین فاکتور
    const latest = userPayments[0]; // چون قبلاً DESC مرتب کردیم
    results.push(latest);
  });

  return results;
};

export {
  CreatePeyment,
  SelectPeyment,
  SelectAllPeyment,
  UpdatePeyment,
  CountPeyment,
  countAllPeyment,
  countAddedTodayPeyment,
  countAddedMonthPeyment,
  countAddedWeekPeyment,
  countAddedYearPeyment,
  SelectRecentPendingPeyments,
};
