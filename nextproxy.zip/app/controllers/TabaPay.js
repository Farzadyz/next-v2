import TabaPay from "../model/tabapay.js";

const CreateTabaPay = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await TabaPay.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectTabaPay = async (object) => {
  const select = await TabaPay.findOne({ where: object });
  return select;
};

const UpdateTabaPay = async ({ id }, object) => {
  await TabaPay.update(object, { where: { id } });
};

export { CreateTabaPay, SelectTabaPay, UpdateTabaPay };
