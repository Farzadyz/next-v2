import Zibal from "../model/zibal.js";

const CreateZibal = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Zibal.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectZibal = async (object) => {
  const select = await Zibal.findOne({ where: object });
  return select;
};

const UpdateZibal = async ({ id }, object) => {
  await Zibal.update(object, { where: { id } });
};

export { CreateZibal, SelectZibal, UpdateZibal };
