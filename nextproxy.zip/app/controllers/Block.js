import Block from "../model/block.js";

const CreateBlock = async ({ id }) => {
  await Block.create({ id });
};

const SelectBlock = async ({ id }) => {
  const data = await Block.findOne({ where: { id } });
  return data;
};

const DestoryBlock = async ({ id }) => {
  await Block.destroy({
    where: { id },
  });
};

export { CreateBlock, SelectBlock, DestoryBlock };
