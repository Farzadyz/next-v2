import Rialit from "../model/rialit.js";

const CreateRialit = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Rialit.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectRialit = async (object) => {
  const select = await Rialit.findOne({ where: object });
  return select;
};

// رکوردهای در انتظار تایید برای کرون verify
// (کاربر از درگاه برگشته، هنوز نه موفق و نه بسته شده)
const SelectPendingRialit = async () => {
  const select = await Rialit.findAll({ where: { callback: true, status: false, closed: false } });
  return select;
};

const CountRialit = async () => {
  return Rialit.count();
};

const UpdateRialit = async ({ id }, object) => {
  await Rialit.update(object, { where: { id } });
};

export { CreateRialit, SelectRialit, SelectPendingRialit, UpdateRialit, CountRialit };
