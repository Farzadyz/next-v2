import Card from "../model/card.js";
import { Op } from "sequelize";
import moment from "moment";

const CreateCard = async ({ chat_id, amount }) => {
  const { id } = await Card.create({ chat_id, amount });
  return id;
};

const SelectCard = (object) => {
  return Card.findOne({ where: object });
};

const SelectAllCard = async () => {
  return Card.findAll({
    where: {
      status: true,
      createdAt: {
        [Op.gte]: moment().startOf("month").toDate(),
        [Op.lte]: moment().endOf("month").toDate(),
      },
    },
  });
};

const UpdateCard = async (id, object) => {
  await Card.update(object, { where: { id } });
};

export { CreateCard, SelectCard, SelectAllCard, UpdateCard };
