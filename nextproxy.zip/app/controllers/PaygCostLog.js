import { fn, col, literal } from "sequelize";
import PaygCostLog from "../model/paygcostlog.js";

// کسرهای مصرف داده‌ای که در این بازه پشت‌سرهم اتفاق می‌افتند در یک ردیف جمع می‌شوند
// (جمع مبلغ و حجم دقیق می‌ماند ولی جدول با هر دور ۵ ثانیه‌ای کرون پر نمی‌شود)
const MERGE_WINDOW_MS = 10 * 60 * 1000;
// payg id -> { id: ردیف آخرین لاگ مصرف داده, at: زمان شروع آن }
const lastDataRow = new Map();

const num = (value) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const CreatePaygCostLog = async ({ payg_service_id, type, amount, requested, traffic_bytes = 0, balance_after = null }) => {
  const deducted = Math.round(num(amount));
  const wanted = Math.round(num(requested ?? amount));
  const bytes = num(traffic_bytes);
  const balance = balance_after === null || balance_after === undefined ? null : Math.round(num(balance_after));

  if (type === "data") {
    const last = lastDataRow.get(payg_service_id);
    if (last && Date.now() - last.at < MERGE_WINDOW_MS) {
      const [affected] = await PaygCostLog.update(
        {
          amount: literal(`amount + ${deducted}`),
          requested: literal(`requested + ${wanted}`),
          traffic_bytes: literal(`traffic_bytes + ${bytes}`),
          balance_after: balance,
        },
        { where: { id: last.id } }
      );
      if (affected > 0) return;
    }
    const row = await PaygCostLog.create({ payg_service_id, type, amount: deducted, requested: wanted, traffic_bytes: bytes, balance_after: balance });
    lastDataRow.set(payg_service_id, { id: row.id, at: Date.now() });
    return;
  }

  await PaygCostLog.create({ payg_service_id, type, amount: deducted, requested: wanted, traffic_bytes: bytes, balance_after: balance });
};

// تاریخچه کسرها - جدیدترین‌ها اول (صفحه‌بندی‌شده)
const SelectPaygCostLogs = ({ payg_service_id, offset = 0, limit = 10 }) => {
  return PaygCostLog.findAll({ where: { payg_service_id }, order: [["id", "DESC"]], offset, limit });
};

const CountPaygCostLogs = ({ payg_service_id }) => {
  return PaygCostLog.count({ where: { payg_service_id } });
};

// جمع کسرها به تفکیک نوع: [{ type, total, requested, bytes, count }]
const SumPaygCostLogsByType = async ({ payg_service_id }) => {
  const rows = await PaygCostLog.findAll({
    where: { payg_service_id },
    attributes: [
      "type",
      [fn("SUM", col("amount")), "total"],
      [fn("SUM", col("requested")), "requested"],
      [fn("SUM", col("traffic_bytes")), "bytes"],
      [fn("COUNT", col("id")), "count"],
    ],
    group: ["type"],
    raw: true,
  });
  return rows.map((row) => ({
    type: row.type,
    total: num(row.total),
    requested: num(row.requested),
    bytes: num(row.bytes),
    count: num(row.count),
  }));
};

export { CreatePaygCostLog, SelectPaygCostLogs, CountPaygCostLogs, SumPaygCostLogsByType };
