import { Op } from "sequelize";
import Reseller from "../model/reseller.js";

const CreateReseller = async ({ owner_id, bot_token, bot_username }) => {
  return Reseller.create({ owner_id, bot_token, bot_username });
};

const SelectReseller = async ({ id }) => {
  return Reseller.findOne({ where: { id } });
};

const SelectResellerByToken = async ({ bot_token }) => {
  return Reseller.findOne({ where: { bot_token } });
};

const SelectResellerByOwner = async ({ owner_id }) => {
  return Reseller.findOne({ where: { owner_id } });
};

const SelectAllResellers = async ({ offset = 0, limit = 10 } = {}) => {
  return Reseller.findAll({ offset, limit, order: [["id", "DESC"]] });
};

// every row with status != 'deleted' - used to relaunch instances on restart
const SelectActiveResellers = async () => {
  return Reseller.findAll({ where: { status: { [Op.ne]: "deleted" } } });
};

// instances that currently expose a local hook port (used for instant sync)
const SelectResellersWithPort = async () => {
  return Reseller.findAll({ where: { port: { [Op.ne]: null }, status: "active" } });
};

const CountResellers = async () => {
  return Reseller.count();
};

const UpdateReseller = async ({ id }, object) => {
  return Reseller.update(object, { where: { id } });
};

const DeleteReseller = async ({ id }) => {
  return Reseller.destroy({ where: { id } });
};

export {
  CreateReseller,
  SelectReseller,
  SelectResellerByToken,
  SelectResellerByOwner,
  SelectAllResellers,
  SelectActiveResellers,
  SelectResellersWithPort,
  CountResellers,
  UpdateReseller,
  DeleteReseller,
};
