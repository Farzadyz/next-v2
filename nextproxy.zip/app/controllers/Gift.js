import Gift from "../model/gift.js";

const insertGift = async ({ code, gift, limit }) => {
  await Gift.create({ code, gift, limit });
};

const SelectGift = async ({ code }) => {
  const select = await Gift.findOne({ where: { code } });
  return select;
};

const selectAllGift = async () => {
  const data = await Gift.findAll();
  return data;
};

const DeleteGift = async ({ code }) => {
  await Gift.destroy({ where: { code } });
};

const UpdateGift = async ({ code }, object) => {
  await Gift.update(object, { where: { code } });
};

export { insertGift, SelectGift, selectAllGift, DeleteGift, UpdateGift };
