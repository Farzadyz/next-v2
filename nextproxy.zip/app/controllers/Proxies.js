import Proxies from "../model/proxies.js";

const CreateProxy = async ({ user_id, type, settings }) => {
  Proxies.create({
    user_id,
    type,
    settings,
  });
};

export { CreateProxy };
