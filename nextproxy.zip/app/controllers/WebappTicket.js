import WebappTicket from "../model/webapp_ticket.js";

const CreateTicket = async ({ telegram_id, subject, message }) => {
  const { id } = await WebappTicket.create({ telegram_id, subject, message });
  return id;
};

const SelectTicketsByUser = ({ telegram_id }) => WebappTicket.findAll({ where: { telegram_id }, order: [["id", "DESC"]] });

const SelectAllTickets = ({ status } = {}) => WebappTicket.findAll({ where: status ? { status } : {}, order: [["id", "DESC"]] });

const SelectTicket = ({ id }) => WebappTicket.findByPk(id);

const ReplyTicket = ({ id }, reply) => WebappTicket.update({ reply, status: "answered" }, { where: { id } });

const CloseTicket = ({ id }) => WebappTicket.update({ status: "closed" }, { where: { id } });

export { CreateTicket, SelectTicketsByUser, SelectAllTickets, SelectTicket, ReplyTicket, CloseTicket };
