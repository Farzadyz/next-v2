import Zirgozar from "../model/zirgozar.js";

const CreateZirgozar = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Zirgozar.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectZirgozar = async (object) => {
  const select = await Zirgozar.findOne({ where: object });
  return select;
};

const UpdateZirgozar = async ({ id }, object) => {
  await Zirgozar.update(object, { where: { id } });
};

export { CreateZirgozar, SelectZirgozar, UpdateZirgozar };
