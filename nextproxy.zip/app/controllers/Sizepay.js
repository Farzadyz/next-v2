import Sizapay from "../model/sizepay.js";

const CreateSizapay = async ({ payment, chat_id, amount, trans_id }) => {
  const { id } = await Sizapay.create({ payment, chat_id, amount, trans_id });
  return id;
};

const SelectSizapay = async (object) => {
  const select = await Sizapay.findOne({ where: object });
  return select;
};

const UpdateSizapay = async ({ id }, object) => {
  await Sizapay.update(object, { where: { id } });
};

export { CreateSizapay, SelectSizapay, UpdateSizapay };
