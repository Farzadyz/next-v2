import Upgrade from "../model/upgrade.js";

const CreataUpgrade = async ({ name, price, traficc }) => {
  await Upgrade.create({ name, price, traficc });
};

const selectAllUpgrade = async () => {
  const data = await Upgrade.findAll();
  return data;
};

const selectUpgrade = async (object) => {
  const data = await Upgrade.findOne({ where: object });
  return data;
};

const DestoryUpgrade = async ({ name }) => {
  await Upgrade.destroy({
    where: { name },
  });
};

export { CreataUpgrade, selectAllUpgrade, selectUpgrade, DestoryUpgrade };
