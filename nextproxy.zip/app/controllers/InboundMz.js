import InboundMz from "../model/inbound_mz.js";
import sequelize from "../utils/database.js";

const CreataInboundMz = async ({ type, tag, protocol, network, tls, port }) => {
  const { id } = await InboundMz.create({ type, tag, protocol, network, tls, port });
  return id;
};

const selectAllInboundMz = async () => {
  const data = await InboundMz.findAll();
  return data;
};

const selectAllInboundMzType = async (object) => {
  return sequelize.transaction(async (t) => {
    // ابتدا رکورد مطابق با شرایط را بیابید
    const InboundMzRecords = await InboundMz.findAll({ where: object });

    // برای هر رکورد count را یک واحد افزایش دهید
    for (const InboundMzRecord of InboundMzRecords) {
      await InboundMzRecord.increment("count", { by: 1, transaction: t });
    }

    // حالا دوباره تمام رکوردهای مطابق با شرایط را با اطلاعات به‌روزشده بخوانید
    const updatedData = await InboundMz.findAll({ where: object, transaction: t });

    // بازگرداندن اطلاعات به‌روزشده
    return updatedData;
  });
};

const selectInboundMz = async (object) => {
  const data = await InboundMz.findOne({ where: object });
  return data;
};

const UpdateInboundMz = async ({ id }, object) => {
  await InboundMz.update(object, { where: { id } });
};

const DestoryInboundMz = async (object) => {
  await InboundMz.destroy({
    where: object,
  });
};

export { CreataInboundMz, selectAllInboundMz, selectAllInboundMzType, selectInboundMz, DestoryInboundMz, UpdateInboundMz };
