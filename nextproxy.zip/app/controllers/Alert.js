import Alert from "../model/alert.js";

const CreateAlert = async ({ primaryId }) => {
  await Alert.create({ primaryId });
};

const SelectAllAlert = async () => {
  const data = await Alert.findAll();
  return data;
};

const SelectAlert = async ({ primaryId }) => {
  const data = await Alert.findOne({ where: { primaryId } });
  return data;
};

const UpdateAlert = async (whr, object) => {
  await Alert.update(object, { where: whr });
};

const DeleteAlert = async ({ id }) => {
  await Alert.destroy({ where: { id } });
};

export { CreateAlert, SelectAllAlert, SelectAlert, UpdateAlert, DeleteAlert };
