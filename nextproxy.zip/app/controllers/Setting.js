import Setting from "../model/setting.js";

const CreateSetting = async () => {
  await Setting.create();
};

const SelectSetting = async () => {
  const data = await Setting.findOne({ where: { id: 1 } });
  return data;
};

const UpdateSetting = async (object) => {
  await Setting.update(object, { where: { id: 1 } });
};

export { SelectSetting, UpdateSetting, CreateSetting };
