import { ApiError, ok, assertActive, assertAllowed } from "../services/http.js";
import { buildCatalog } from "../services/catalog.js";
import { getBalance } from "../services/credit.js";
import { createTopupInvoice, syncTopupStatus, TOPUP_GATEWAY_LABELS } from "../services/topupGateways.js";
import { CreateResellerTopup, SelectResellerTopup, SelectResellerTopups } from "../../controllers/ResellerTopup.js";

const present = (row, status = row.status) => {
  let extra = {};
  try {
    extra = JSON.parse(row.extra || "{}");
  } catch (error) {
    extra = {};
  }
  return {
    id: row.id,
    amount: row.amount,
    gateway: row.gateway,
    gateway_label: TOPUP_GATEWAY_LABELS[row.gateway] || row.gateway,
    status,
    pay_url: row.pay_url,
    extra,
    created_at: row.createdAt,
  };
};

const CreditController = {
  balance: async (req, res) => {
    ok(res, { balance: await getBalance(req.reseller) });
  },

  // "Recharge Account": creates an invoice on the MAIN bot's gateways
  createTopup: async (req, res) => {
    const { reseller } = req;
    assertActive(reseller);
    const catalog = await buildCatalog();
    assertAllowed(catalog.permissions, "allow_panel_recharge");

    const amount = Math.round(Number(req.body?.amount));
    const gateway = String(req.body?.gateway || "");
    if (!Number.isFinite(amount) || amount < catalog.topup.min || amount > catalog.topup.max) {
      throw new ApiError(400, "invalid_amount", `amount must be between ${catalog.topup.min} and ${catalog.topup.max}`, catalog.topup);
    }
    if (!catalog.topup.gateways.some((item) => item.key === gateway)) throw new ApiError(400, "gateway_unavailable", "this gateway is not available");

    const created = await createTopupInvoice({ gateway, amount, chatId: reseller.owner_id });
    if (!created) throw new ApiError(502, "gateway_error", "could not create the invoice, try another gateway");

    const row = await CreateResellerTopup({
      reseller_id: reseller.id,
      amount,
      gateway,
      ref: created.ref,
      pay_url: created.url || null,
      extra: JSON.stringify(created.extra || {}),
    });
    ok(res, present(row));
  },

  listTopups: async (req, res) => {
    const rows = await SelectResellerTopups({ reseller_id: req.reseller.id, limit: 10 });
    ok(res, { items: rows.map((row) => present(row)) });
  },

  // polled by the reseller bot ("check payment" button)
  getTopup: async (req, res) => {
    const row = await SelectResellerTopup({ id: Number(req.params.id), reseller_id: req.reseller.id });
    if (!row) throw new ApiError(404, "not_found", "invoice not found");
    const status = await syncTopupStatus(row);
    ok(res, { ...present(row, status), balance: await getBalance(req.reseller) });
  },
};

export default CreditController;
