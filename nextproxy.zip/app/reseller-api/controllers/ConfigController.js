import { ok } from "../services/http.js";
import { buildCatalog } from "../services/catalog.js";
import { getBalance } from "../services/credit.js";

// Everything a reseller bot needs to render itself: identity, credit balance,
// servers, plans, pricing rules and the permission matrices (features + admin panel).
const ConfigController = {
  bootstrap: async (req, res) => {
    const { reseller } = req;
    const catalog = await buildCatalog();
    ok(res, {
      reseller: { id: reseller.id, username: reseller.bot_username, status: reseller.status, owner_id: String(reseller.owner_id) },
      credit: { balance: await getBalance(reseller) },
      ...catalog,
    });
  },
  permissions: async (req, res) => {
    const { rev, permissions, admin_permissions } = await buildCatalog();
    ok(res, { rev, permissions, admin_permissions });
  },
  servers: async (req, res) => {
    const { rev, servers } = await buildCatalog();
    ok(res, { rev, servers });
  },
  plans: async (req, res) => {
    const { rev, plans, custom, payg } = await buildCatalog();
    ok(res, { rev, plans, custom, payg });
  },
};

export default ConfigController;
