import { ApiError, ok, assertActive, assertAllowed } from "../services/http.js";
import { buildCatalog } from "../services/catalog.js";
import { debit, refund, getBalance } from "../services/credit.js";
import Servise from "../../bot/model/servise.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectPelan } from "../../controllers/Pelan.js";
import { selectInbound, selectAllInboundType } from "../../controllers/Inbound.js";
import { SelectServise as SelectServiseRow } from "../../controllers/Servise.js";
import { CreatePaygService } from "../../controllers/PaygService.js";
import {
  CreateResellerSale,
  SelectResellerSaleByRequest,
  SelectResellerSaleByService,
  CountResellerFreeByCustomer,
  CountResellerSales,
  SumResellerSales,
} from "../../controllers/ResellerSale.js";

const I18N = { t: (key) => (key === "MY_ESHTERAK.MENU.STATUS_ON" ? "فعال ✅" : "غیر فعال ❌") };
const inflight = new Map(); // "<reseller>:<request>" -> Promise (parallel duplicate protection)

// ------------------------------------------------------------ resolvers ---

// picks an active server that still has free capacity (optionally the customer's choice)
const pickServer = async (serverId, permissions) => {
  const pool = await selectAllInboundType("normal");
  if (serverId && permissions.allow_server_choice) {
    const row = await selectInbound({ id: Number(serverId) });
    if (!row || !row.status) throw new ApiError(400, "server_unavailable", "selected server is not available");
    const all = await selectAllInboundType(row.type);
    if (!all.some((item) => item.id === row.id)) throw new ApiError(400, "server_full", "selected server has no free capacity");
    return row;
  }
  if (!pool.length) throw new ApiError(503, "no_server", "no server available right now");
  return pool[Math.floor(Math.random() * pool.length)];
};

const resolveOrder = async (kind, body, catalog) => {
  const perms = catalog.permissions;
  switch (kind) {
    case "plan": {
      const pelan = await selectPelan({ id: Number(body.plan_id) });
      if (!pelan) throw new ApiError(404, "plan_not_found", "plan not found");
      assertAllowed(perms, pelan.connection === "multi" ? "allow_multi_location" : "allow_single_location");
      let location = "0";
      let extra = 0;
      let serverId = null;
      if (pelan.panel === "sanae") {
        const inbound = await pickServer(body.server_id, perms);
        location = String(inbound.id);
        extra = Number(inbound.price || 0);
        serverId = inbound.id;
      }
      return {
        cost: pelan.price + extra,
        spec: { traficc: pelan.traficc, day: pelan.time, name: pelan.name, idPlan: pelan.id, location, types2: "select", panel: pelan.panel },
        sale: { pelan_id: pelan.id, days: pelan.time, traffic: pelan.traficc, server_id: serverId ? String(serverId) : null },
      };
    }
    case "custom": {
      assertAllowed(perms, "allow_custom_plan");
      const traffic = Number(body.traffic);
      const days = Number(body.days);
      if (!catalog.custom.traffic_values.includes(traffic) || !catalog.custom.days_values.includes(days)) {
        throw new ApiError(400, "invalid_custom", "traffic/days are not in the allowed lists");
      }
      const inbound = await pickServer(body.server_id, perms);
      const cost = Math.round(days * catalog.custom.price_per_day + traffic * catalog.custom.price_per_gb) + Number(inbound.price || 0);
      return {
        cost,
        spec: { traficc: traffic, day: days, name: "🎛 پلن سفارشی", idPlan: null, location: String(inbound.id), types2: "select-sefareshi", panel: "sanae" },
        sale: { pelan_id: null, days, traffic, server_id: String(inbound.id) },
      };
    }
    case "payg": {
      const multi = body.connection === "multi";
      assertAllowed(perms, multi ? "allow_payg_multi" : "allow_payg_single");
      if (!(multi ? catalog.payg.enabled_multi : catalog.payg.enabled_single)) throw new ApiError(403, "not_permitted", "PAYG is disabled");
      if (catalog.payg.base_amount <= 0) throw new ApiError(400, "not_configured", "PAYG is not configured");
      let location = "payg";
      if (!multi) location = String((await pickServer(body.server_id, perms)).id);
      return {
        cost: catalog.payg.base_amount,
        payg: true,
        spec: { name: "⚡️ اشتراک اشتراکی (PAYG)", idPlan: null, location, types2: "payg", panel: multi ? "wiguard" : "sanae" },
        sale: { pelan_id: null, server_id: multi ? null : location },
      };
    }
    case "free": {
      assertAllowed(perms, "allow_test_service");
      const inbound = await pickServer(null, perms);
      return {
        cost: 0,
        spec: { traficc: catalog.free_traffic_gb, day: 1, name: "🎁 اشتراک تست", idPlan: null, location: String(inbound.id), types2: "free", panel: "sanae", free: true },
        sale: { pelan_id: null, days: 1, traffic: catalog.free_traffic_gb, server_id: String(inbound.id) },
      };
    }
  }
  throw new ApiError(400, "invalid_kind", "kind must be plan | custom | payg | free");
};

const paygInitial = async (panel, remaining) => {
  const setting = await SelectSetting();
  if (setting.payg_initial_mode === "auto") {
    const multi = panel === "wiguard";
    const daily = Number((multi ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0);
    const data = Number((multi ? setting.payg_data_rate_multi : setting.payg_data_rate_single) || 0);
    return {
      traficc: data > 0 ? Math.max(1, Math.floor(remaining / data)) : 1,
      day: daily > 0 ? Math.max(1, Math.floor(remaining / daily)) : 1,
    };
  }
  return { traficc: Math.max(1, Number(setting.payg_initial_traffic || 1)), day: Math.max(1, Number(setting.payg_initial_days || 1)) };
};

// ------------------------------------------------------------- creation ---

const createOnce = async (reseller, body) => {
  const catalog = await buildCatalog({ fresh: true });
  const kind = String(body.kind || "");
  const customerId = Number(body.customer_id);
  const requestId = String(body.request_id);

  if (kind === "free" && (await CountResellerFreeByCustomer({ reseller_id: reseller.id, customer_id: customerId }))) {
    throw new ApiError(409, "free_used", "this customer already received a test service");
  }
  const order = await resolveOrder(kind, body, catalog);

  if (!(await debit(reseller, order.cost))) {
    throw new ApiError(402, "insufficient_credit", "insufficient credit balance", { required: order.cost, balance: await getBalance(reseller) });
  }

  const spec = { ...order.spec };
  if (order.payg) Object.assign(spec, await paygInitial(spec.panel, await getBalance(reseller)));

  let created = null;
  try {
    created = await new Servise().createServise({ id: reseller.owner_id, defaultname: true, free: Boolean(spec.free), price: order.cost, ...spec });
  } catch (error) {
    console.error("[reseller-api] createServise", error?.message || error);
  }
  if (!created || !created.result) {
    await refund(reseller, order.cost);
    throw new ApiError(502, "create_failed", "could not create the config, nothing was charged");
  }

  if (order.payg) {
    await CreatePaygService({ service_id: created.id, telegram_id: reseller.owner_id, initial_traffic: spec.traficc, initial_days: spec.day });
  }
  await CreateResellerSale({
    reseller_id: reseller.id,
    customer_id: customerId,
    cost: order.cost,
    display_price: Number(body.display_price) || null,
    servise_id: String(created.id),
    kind,
    request_id: requestId,
    ...order.sale,
  });
  return { service_id: created.id, kind, cost: order.cost, balance: await getBalance(reseller), replayed: false };
};

// ----------------------------------------------------------------- info ---

const loadOwned = async (req) => {
  const sale = await SelectResellerSaleByService({ reseller_id: req.reseller.id, servise_id: req.params.id });
  if (!sale) throw new ApiError(404, "service_not_found", "service not found");
  const customer = req.query.customer_id ?? req.body?.customer_id;
  if (customer && Number(customer) !== Number(sale.customer_id)) throw new ApiError(403, "forbidden", "service belongs to another customer");
  const row = await SelectServiseRow({ id: req.params.id });
  if (!row) throw new ApiError(404, "service_not_found", "service not found");
  return { sale, row };
};

const describe = async (row) => {
  const raw = await new Servise().SelectServise({ id: row.id, i18n: I18N });
  if (!raw || raw.status === false) throw new ApiError(502, "upstream_unavailable", "could not read the service from its panel");
  const links = raw.panel === "sanae"
    ? [
        { label: "لینک اتصال مستقیم", url: raw.tunel },
        { label: "لینک اتصال داخلی", url: raw.internal },
      ]
    : [{ label: "لینک هوشمند", url: raw.subscription_url }];
  return {
    id: row.id,
    name: row.name,
    panel: raw.panel,
    location: raw.location ?? null,
    active: raw.keyboard !== false,
    is_test: Boolean(row.free),
    connection_enabled: raw.status_api !== false,
    status: raw.status,
    time_left: raw.time,
    expires_at: raw.date,
    traffic: raw.traffic,
    used: raw.used_traffic,
    remaining: raw.remaining,
    renewable: !["payg", "free"].includes(row.types),
    links: links.filter((link) => link.url),
  };
};

// -------------------------------------------------------------- handlers ---

const ServiceController = {
  create: async (req, res) => {
    const { reseller } = req;
    assertActive(reseller);
    const body = req.body || {};
    const requestId = String(body.request_id || "").slice(0, 64);
    if (!requestId || !Number(body.customer_id)) throw new ApiError(400, "invalid_request", "request_id and customer_id are required");
    body.request_id = requestId;

    const existing = await SelectResellerSaleByRequest({ reseller_id: reseller.id, request_id: requestId });
    if (existing) {
      return ok(res, { service_id: Number(existing.servise_id), kind: existing.kind, cost: existing.cost, balance: await getBalance(reseller), replayed: true });
    }
    const key = `${reseller.id}:${requestId}`;
    if (!inflight.has(key)) inflight.set(key, createOnce(reseller, body).finally(() => inflight.delete(key)));
    ok(res, await inflight.get(key));
  },

  info: async (req, res) => {
    const { row } = await loadOwned(req);
    ok(res, await describe(row));
  },

  renew: async (req, res) => {
    const { reseller } = req;
    assertActive(reseller);
    const catalog = await buildCatalog({ fresh: true });
    assertAllowed(catalog.permissions, "allow_renew");
    const { sale, row } = await loadOwned(req);
    const requestId = String(req.body?.request_id || "").slice(0, 64);
    if (!requestId) throw new ApiError(400, "invalid_request", "request_id is required");
    const replay = await SelectResellerSaleByRequest({ reseller_id: reseller.id, request_id: requestId });
    if (replay) return ok(res, { service_id: row.id, cost: replay.cost, balance: await getBalance(reseller), replayed: true });
    if (["payg", "free"].includes(row.types)) throw new ApiError(400, "not_renewable", "this service cannot be renewed");

    let cost;
    let days;
    let traffic;
    const extra = row.panel === "sanae" ? Number((await selectInbound({ id: Number(row.location) }))?.price || 0) : 0;
    if (sale.pelan_id) {
      const pelan = await selectPelan({ id: sale.pelan_id });
      if (!pelan) throw new ApiError(400, "plan_removed", "the original plan no longer exists");
      cost = pelan.price + extra;
      days = pelan.time;
      traffic = pelan.traficc;
    } else {
      days = sale.days || row.time;
      traffic = sale.traffic || row.traficc;
      cost = Math.round(days * catalog.custom.price_per_day + traffic * catalog.custom.price_per_gb) + extra;
    }
    if (!(cost > 0)) throw new ApiError(400, "not_renewable", "cannot price this renewal");
    if (!(await debit(reseller, cost))) {
      throw new ApiError(402, "insufficient_credit", "insufficient credit balance", { required: cost, balance: await getBalance(reseller) });
    }
    let done = false;
    try {
      done = (await new Servise().Tamdid({ id: row.id, day: days })) !== false;
    } catch (error) {
      console.error("[reseller-api] renew", error?.message || error);
    }
    if (!done) {
      await refund(reseller, cost);
      throw new ApiError(502, "renew_failed", "renewal failed, nothing was charged");
    }
    await CreateResellerSale({
      reseller_id: reseller.id,
      customer_id: sale.customer_id,
      pelan_id: sale.pelan_id,
      cost,
      display_price: Number(req.body?.display_price) || null,
      servise_id: String(row.id),
      kind: "renew",
      request_id: requestId,
      days,
      traffic,
    });
    ok(res, { service_id: row.id, cost, balance: await getBalance(reseller), replayed: false });
  },

  toggleStatus: async (req, res) => {
    assertActive(req.reseller);
    assertAllowed((await buildCatalog()).permissions, "allow_action_status");
    const { row } = await loadOwned(req);
    if (!(await new Servise().ChangeStatus({ id: row.id }))) throw new ApiError(502, "action_failed", "could not change the status");
    ok(res, {});
  },

  revoke: async (req, res) => {
    assertActive(req.reseller);
    assertAllowed((await buildCatalog()).permissions, "allow_action_revoke");
    const { row } = await loadOwned(req);
    if (!(await new Servise().Revokelink({ id: row.id }))) throw new ApiError(502, "action_failed", "could not rotate the link");
    ok(res, {});
  },

  remove: async (req, res) => {
    assertActive(req.reseller);
    assertAllowed((await buildCatalog()).permissions, "allow_action_delete");
    const { row } = await loadOwned(req);
    await new Servise().DeleteServise({ id: row.id });
    ok(res, {});
  },

  stats: async (req, res) => {
    const reseller_id = req.reseller.id;
    ok(res, { operations: await CountResellerSales({ reseller_id }), spent: await SumResellerSales({ reseller_id }) });
  },
};

export default ServiceController;
