import crypto from "crypto";
import { SelectReseller, UpdateReseller } from "../../controllers/Reseller.js";

const WINDOW_MS = 60 * 1000;
const MAX_PER_WINDOW = Number(process.env.RESELLER_API_RATE || 300);
const buckets = new Map(); // reseller_id -> { count, resetAt }
const lastSeen = new Map(); // reseller_id -> timestamp of last DB touch

const deny = (res, status, code, message) => res.status(status).json({ ok: false, error: { code, message } });

// Authenticates one isolated reseller instance:
//   Authorization: Bearer <api key issued at deploy time>
//   X-Reseller-Id: <reseller id>
// Only the SHA-256 hash of the key is stored on the main bot.
const auth = async (req, res, next) => {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
    const id = Number(req.headers["x-reseller-id"]);
    if (!token || !id) return deny(res, 401, "unauthorized", "missing credentials");

    const reseller = await SelectReseller({ id });
    if (!reseller || !reseller.api_key_hash) return deny(res, 401, "unauthorized", "invalid credentials");

    const given = Buffer.from(crypto.createHash("sha256").update(token).digest("hex"));
    const stored = Buffer.from(reseller.api_key_hash);
    if (given.length !== stored.length || !crypto.timingSafeEqual(given, stored)) return deny(res, 401, "unauthorized", "invalid credentials");
    if (reseller.status === "deleted") return deny(res, 403, "reseller_deleted", "reseller no longer exists");

    // simple per-reseller rate limit
    const now = Date.now();
    const bucket = buckets.get(id);
    if (!bucket || bucket.resetAt < now) buckets.set(id, { count: 1, resetAt: now + WINDOW_MS });
    else if (++bucket.count > MAX_PER_WINDOW) return deny(res, 429, "rate_limited", "too many requests");

    if (!lastSeen.has(id) || now - lastSeen.get(id) > WINDOW_MS) {
      lastSeen.set(id, now);
      UpdateReseller({ id }, { last_seen_at: new Date() }).catch(() => {});
    }

    req.reseller = reseller;
    return next();
  } catch (error) {
    console.error("[reseller-api] auth", error);
    return deny(res, 500, "internal_error", "internal error");
  }
};

export default auth;
