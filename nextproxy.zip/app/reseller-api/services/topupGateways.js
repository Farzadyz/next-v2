import sequelize from "../../utils/database.js";
import Users from "../../model/users.js";
import NowpeymentModel from "../../model/nowpeyment.js";
import { bot } from "../../bot/index.js";
import { handleRandom } from "../../bot/utils/utils.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { UpdateResellerTopup } from "../../controllers/ResellerTopup.js";
import Paystar from "../../pay/paystar.js";
import ZarinPal from "../../pay/zarinpal.js";
import Zibals from "../../pay/zibal.js";
import NovinPay from "../../pay/novinpal.js";
import Polam from "../../pay/polam.js";
import TabaPay from "../../pay/tabapay.js";
import TetraPay from "../../pay/terapay.js";
import Rialit from "../../pay/rialit.js";
import AtlasPay from "../../pay/atlaspay.js";
import Nowpeyment, { ToUsd } from "../../pay/nowpeyment.js";
import { CountPeystar, CreatePeystar, SelectPeystar } from "../../controllers/Paystar.js";
import { CreateZarinpal, SelectZarinpal } from "../../controllers/Zarinpal.js";
import { CreateZibal, SelectZibal } from "../../controllers/Zibal.js";
import { CountNovinpay, CreateNovinpay, SelectNovinpay } from "../../controllers/Novinpay.js";
import { CreatePolam, SelectPolam } from "../../controllers/Polam.js";
import { CreateTabaPay, SelectTabaPay } from "../../controllers/TabaPay.js";
import { CreateTerapay, SelectTerapay } from "../../controllers/Terapay.js";
import { CountRialit, CreateRialit, SelectRialit } from "../../controllers/Rialit.js";
import { CountAtlasPay, CreateAtlasPay, SelectAtlasPay } from "../../controllers/AtlasPay.js";
import { CreateNowpeyment, SelectNowpeyment } from "../../controllers/Nowpeyment.js";

// ============================================================================
// Reseller credit top-up invoices.
//
// An invoice is created with the MAIN bot's own payment gateways (main
// merchant codes / API keys), on behalf of the reseller's owner account with
// no `payment` link - so the gateways' existing callbacks credit the owner's
// wallet (= the reseller's credit balance) and the money lands with the main
// admin. Nothing in this file ever touches a reseller's own gateways.
// ============================================================================

const paidByRow = (select, field) => async (ref) => Boolean((await select({ [field]: ref }))?.status);

const GATEWAYS = {
  PAYSTAR: {
    label: "💰 مستقیم (پی‌استار)",
    create: async ({ amount, chatId }) => {
      const create = await new Paystar().CreatePayment({ amount, order_id: (await CountPeystar()) + 1 });
      if (!create || create.status != 1) return null;
      await CreatePeystar({ chat_id: chatId, amount, ref_num: create.data.ref_num });
      return { ref: create.data.ref_num, url: "https://core.paystar.ir/api/pardakht/payment?token=" + create.data.token };
    },
    isPaid: paidByRow(SelectPeystar, "ref_num"),
  },
  ZARINPAL: {
    label: "⭐️ زرین پال",
    create: async ({ amount, chatId }) => {
      const create = await new ZarinPal().CreatePayment({
        amount,
        order_id: handleRandom(20),
        callback_url: `${process.env.URL_DOMAIN}zarinpal`,
      });
      if (!create || !create.invoice_id) return null;
      await CreateZarinpal({ chat_id: chatId, amount, authority: create.invoice_id });
      return { ref: create.invoice_id, url: create.payment_url || create.invoice_url };
    },
    isPaid: paidByRow(SelectZarinpal, "authority"),
  },
  ZIBAL: {
    label: "🧩 زیبال",
    create: async ({ amount, chatId }) => {
      const create = await new Zibals().CreatePeyment({ amount });
      if (!create || create.result != 100) return null;
      await CreateZibal({ chat_id: chatId, amount, trans_id: create.trackId });
      return { ref: String(create.trackId), url: "https://gateway.zibal.ir/start/" + create.trackId };
    },
    isPaid: paidByRow(SelectZibal, "trans_id"),
  },
  NOVINPAL: {
    label: "👑 نوین پال",
    create: async ({ amount, chatId }) => {
      const create = await new NovinPay().CreatePayment({ amount, order_id: (await CountNovinpay()) + 1 });
      if (!create || create.status != 1) return null;
      await CreateNovinpay({ chat_id: chatId, amount, trans_id: create.refId });
      return { ref: String(create.refId), url: "https://nextstory.ir/dragah3.php?token=" + encodeURIComponent(create.refId) };
    },
    isPaid: paidByRow(SelectNovinpay, "trans_id"),
  },
  POLAM: {
    label: "💥 پلام",
    create: async ({ amount, chatId }) => {
      const create = await new Polam().CreatePayment({ amount });
      if (!create || create.status != 1) return null;
      await CreatePolam({ chat_id: chatId, amount, trans_id: create.invoice_key });
      return { ref: create.invoice_key, url: "https://polam.io/invoice/pay/" + create.invoice_key };
    },
    isPaid: paidByRow(SelectPolam, "trans_id"),
  },
  TABAPAY: {
    label: "🧬 تاباپی",
    create: async ({ amount, chatId }) => {
      const create = await new TabaPay().CreatePeyment({ amount });
      if (!create || create.status != "success") return null;
      await CreateTabaPay({ chat_id: chatId, amount, trans_id: create.token });
      return { ref: create.token, url: create.url };
    },
    isPaid: paidByRow(SelectTabaPay, "trans_id"),
  },
  TERAPAY: {
    label: "💳 کارت به کارت خودکار (تراپی)",
    create: async ({ amount, chatId }) => {
      const create = await new TetraPay().createOrder({ amount, hashId: handleRandom(20) });
      if (!create || !create.success) return null;
      await CreateTerapay({ chat_id: chatId, amount, trans_id: create.data.uid });
      return { ref: create.data.uid, url: create.data.payment_url };
    },
    isPaid: paidByRow(SelectTerapay, "trans_id"),
  },
  RIALIT: {
    label: "🏦 ریالیت",
    create: async ({ amount, chatId }) => {
      const create = await new Rialit().CreatePayment({ amount, order_id: (await CountRialit()) + 1, user_id: chatId });
      if (!create || create.status != 1) return null;
      await CreateRialit({ chat_id: chatId, amount, trans_id: create.token });
      return { ref: create.token, url: "https://api.rialit.org/api/v1/redirect/" + create.token };
    },
    isPaid: paidByRow(SelectRialit, "trans_id"),
  },
  ATLASPAY: {
    label: "🔅 اطلس‌پی",
    create: async ({ amount, chatId }) => {
      const create = await new AtlasPay().CreatePayment({ amount, order_id: (await CountAtlasPay()) + 1, user_id: chatId });
      if (!create || !create.orderId) return null;
      await CreateAtlasPay({ chat_id: chatId, amount, order_id: create.orderId, tracking_code: create.trackingCode });
      return { ref: String(create.orderId), url: create.customerStartLink };
    },
    isPaid: paidByRow(SelectAtlasPay, "order_id"),
  },
  NOWPEYMENT: {
    label: "💎 ارز دیجیتال",
    create: async ({ amount, chatId }) => {
      const setting = await SelectSetting();
      if (!setting.nowpayments_enabled) return null;
      const usd = ToUsd(amount, setting.nowpayments_usd_rate);
      const create = await new Nowpeyment(setting.nowpayments_api_key).createPeyment(usd, setting.nowpayments_pay_currency || "trx");
      if (!create || !create.pay_address || !create.pay_amount) return null;
      await CreateNowpeyment({
        chat_id: chatId,
        amount,
        count: create.pay_amount,
        price_count: usd,
        pay_address: create.pay_address,
        payment_id: String(create.payment_id),
        pay_currency: create.pay_currency,
        idServise: null,
      });
      return {
        ref: String(create.payment_id),
        url: null,
        extra: { pay_address: create.pay_address, pay_amount: create.pay_amount, pay_currency: String(create.pay_currency || "").toUpperCase() },
      };
    },
    // crypto is verified by polling the provider (same result as the IPN route);
    // the row is claimed atomically so the wallet can never be credited twice.
    isPaid: async (ref) => {
      const row = await SelectNowpeyment({ payment_id: ref });
      if (!row) return false;
      if (row.deposit) return true;
      const setting = await SelectSetting();
      const status = await new Nowpeyment(setting.nowpayments_api_key).PaymentStatus(ref);
      if (!status || !["finished", "confirmed", "partially_paid"].includes(status.payment_status)) return false;
      const [claimed] = await NowpeymentModel.update({ status: true, deposit: true }, { where: { id: row.id, deposit: false } });
      if (claimed === 1) {
        await Users.update({ price: sequelize.literal(`price + ${Number(row.amount)}`) }, { where: { id: row.chat_id } });
        bot.telegram.sendMessage(row.chat_id, `✅ پرداخت ارز دیجیتال شما تایید و مبلغ ${row.amount} تومان به اعتبار شما اضافه شد.`).catch(() => {});
      }
      return true;
    },
  },
};

// gateways the main admin enabled in the main bot AND the API can invoice
const enabledTopupGateways = (setting) => {
  let list = [];
  try {
    list = JSON.parse(setting.pay || "[]");
  } catch (error) {
    list = [];
  }
  return list
    .filter((item) => item.value && GATEWAYS[item.text])
    .filter((item) => item.text !== "NOWPEYMENT" || setting.nowpayments_enabled)
    .map((item) => ({ key: item.text, label: GATEWAYS[item.text].label }));
};

const createTopupInvoice = async ({ gateway, amount, chatId }) => {
  const adapter = GATEWAYS[gateway];
  if (!adapter) return null;
  try {
    return await adapter.create({ amount, chatId });
  } catch (error) {
    console.error(`[reseller-api] topup ${gateway} create failed`, error?.message || error);
    return null;
  }
};

// refreshes a pending invoice from the gateway table (callbacks credit the wallet)
const syncTopupStatus = async (row) => {
  if (row.status !== "pending") return row.status;
  let paid = false;
  try {
    paid = await GATEWAYS[row.gateway].isPaid(row.ref);
  } catch (error) {
    paid = false;
  }
  if (paid) {
    await UpdateResellerTopup({ id: row.id }, { status: "paid" });
    return "paid";
  }
  if (Date.now() - new Date(row.createdAt).getTime() > 24 * 60 * 60 * 1000) {
    await UpdateResellerTopup({ id: row.id }, { status: "expired" });
    return "expired";
  }
  return "pending";
};

const TOPUP_GATEWAY_LABELS = Object.fromEntries(Object.entries(GATEWAYS).map(([key, value]) => [key, value.label]));

export { enabledTopupGateways, createTopupInvoice, syncTopupStatus, TOPUP_GATEWAY_LABELS };
