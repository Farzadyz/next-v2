import sequelize from "../../utils/database.js";
import { buildCatalog, invalidateCatalog } from "./catalog.js";
import { broadcastToResellers } from "../../bot/reseller/ResellerManager.js";

// ============================================================================
// Instant propagation.
//
// Global Sequelize hooks watch every table a reseller bot depends on (servers,
// plans, settings/permission matrix). Whatever code path changes them (panel
// action, cron, script), the catalog is rebuilt and - only when the sanitized
// snapshot really changed - a signed push tells every running reseller
// instance to refresh immediately. Reseller bots also poll as a safety net.
// ============================================================================

const WATCHED = new Set(["inbound", "inbound_mz", "pelan", "setting"]);
const HOOKS = ["afterCreate", "afterUpdate", "afterDestroy", "afterSave", "afterBulkCreate", "afterBulkUpdate", "afterBulkDestroy"];

const modelName = (...args) => {
  for (const arg of args) {
    if (!arg) continue;
    if (arg.model?.name) return arg.model.name;
    if (Array.isArray(arg) && arg[0]?.constructor?.name) return arg[0].constructor.name;
    if (arg.constructor && arg.constructor !== Object) return arg.constructor.name;
  }
  return "";
};

let timer = null;
let lastRev = null;

const schedule = () => {
  invalidateCatalog();
  clearTimeout(timer);
  timer = setTimeout(async () => {
    try {
      const { rev } = await buildCatalog({ fresh: true });
      if (rev === lastRev) return;
      lastRev = rev;
      await broadcastToResellers("sync", { rev });
    } catch (error) {
      console.error("[reseller-api] sync broadcast failed", error?.message || error);
    }
  }, 400);
};

const installSyncHooks = async () => {
  try {
    lastRev = (await buildCatalog({ fresh: true })).rev;
  } catch (error) {
    lastRev = null;
  }
  for (const hook of HOOKS) {
    sequelize.addHook(hook, (...args) => {
      if (WATCHED.has(modelName(...args))) schedule();
    });
  }
};

export { installSyncHooks };
