import { Op } from "sequelize";
import sequelize from "../../utils/database.js";
import Users from "../../model/users.js";

// The reseller's "Credit Balance" with the main bot is the wallet balance of
// the main-bot account that owns the reseller bot. Top-ups (paid through the
// main bot's own gateways) therefore land in the same balance the API debits.

const getBalance = async (reseller) => {
  const user = await Users.findOne({ where: { id: reseller.owner_id } });
  return user ? Number(user.price) : 0;
};

// atomic conditional debit - can never push the balance below zero
const debit = async (reseller, amount) => {
  const value = Math.round(Number(amount));
  if (!(value > 0)) return true;
  const [affected] = await Users.update(
    { price: sequelize.literal(`price - ${value}`) },
    { where: { id: reseller.owner_id, price: { [Op.gte]: value } } }
  );
  return affected === 1;
};

const refund = async (reseller, amount) => {
  const value = Math.round(Number(amount));
  if (!(value > 0)) return;
  await Users.update({ price: sequelize.literal(`price + ${value}`) }, { where: { id: reseller.owner_id } });
};

export { getBalance, debit, refund };
