// Small helpers shared by every Intermediary API controller.
class ApiError extends Error {
  constructor(status, code, message, extra = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

const ok = (res, data = {}) => res.json({ ok: true, data });

// wraps an async controller: turns thrown ApiError / unexpected errors into JSON
const wrap = (handler) => async (req, res) => {
  try {
    await handler(req, res);
  } catch (error) {
    if (error instanceof ApiError) {
      return res.status(error.status).json({ ok: false, error: { code: error.code, message: error.message, ...error.extra } });
    }
    console.error("[reseller-api]", error);
    return res.status(500).json({ ok: false, error: { code: "internal_error", message: "internal error" } });
  }
};

// mutating calls are refused while the reseller is suspended by the main admin
const assertActive = (reseller) => {
  if (reseller.status !== "active") throw new ApiError(403, "reseller_suspended", "this reseller bot is suspended");
};

const assertAllowed = (permissions, key) => {
  if (!permissions[key]) throw new ApiError(403, "not_permitted", "this feature is disabled by the main admin", { permission: key });
};

export { ApiError, ok, wrap, assertActive, assertAllowed };
