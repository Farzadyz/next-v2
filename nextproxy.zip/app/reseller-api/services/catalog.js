import crypto from "crypto";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectAllInbound } from "../../controllers/Inbound.js";
import { selectAllPelan } from "../../controllers/Pelan.js";
import { parseResellerPermissions, parseResellerAdminPermissions, withLegacyPanelKeys } from "../../utils/resellerPermissions.js";
import { enabledTopupGateways } from "./topupGateways.js";

// The single, sanitized snapshot every reseller bot receives from the main bot:
// config SERVERS, PLANS, pricing rules and the PERMISSION MATRICES
// (`permissions` = customer-facing features, `admin_permissions` = which admin
// panel menus a Reseller Admin may open).
// Panel credentials, sessions, hosts and tunnel addresses are never exposed.
// `rev` changes whenever anything inside changes, so a reseller bot can tell
// instantly (via the sync hook) or on its next poll that it must refresh.

const json = (raw, fallback) => {
  try {
    return JSON.parse(raw) ?? fallback;
  } catch (error) {
    return fallback;
  }
};

let cache = null;
const TTL_MS = 1500;

const invalidateCatalog = () => {
  cache = null;
};

const buildCatalog = async ({ fresh = false } = {}) => {
  if (!fresh && cache && Date.now() - cache.at < TTL_MS) return cache.value;

  const setting = await SelectSetting();
  const [inbounds, pelans] = await Promise.all([selectAllInbound(), selectAllPelan()]);

  const servers = inbounds
    .filter((item) => item.status)
    .sort((a, b) => a.id - b.id)
    .map((item) => ({ id: item.id, name: item.location, kind: item.type, extra_price: Number(item.price || 0) }));

  const plans = pelans
    .sort((a, b) => a.id - b.id)
    .map((item) => ({
      id: item.id,
      name: item.name,
      price: item.price,
      traffic: item.traficc,
      days: item.time,
      panel: item.panel,
      type: item.type,
      connection: item.connection,
    }));

  const customize = json(setting.customize, {});
  const adminPermissions = parseResellerAdminPermissions(setting.reseller_admin_permissions);
  const permissions = withLegacyPanelKeys(parseResellerPermissions(setting.reseller_permissions), adminPermissions);
  // the reseller bot has ONE custom-plan flow (pick days + traffic from the lists): either switch enables it,
  // and the API checks (allow_custom_plan) stay consistent with what the reseller bot shows
  permissions.allow_custom_plan = permissions.allow_custom_plan || permissions.allow_select_custom_plan;
  const body = {
    permissions,
    admin_permissions: adminPermissions,
    servers,
    plans,
    custom: {
      traffic_values: customize.traficcV || [],
      days_values: customize.timeV || [],
      price_per_gb: Number(customize.traficcP || 0),
      price_per_day: Number(customize.timeP || 0),
    },
    payg: {
      enabled_multi: Boolean(setting.payg_enabled_multi),
      enabled_single: Boolean(setting.payg_enabled_single),
      base_amount: Number(setting.payg_base_amount || 0),
    },
    free_traffic_gb: Number(setting.free || 0),
    topup: {
      min: Number(process.env.RESELLER_TOPUP_MIN || 5000),
      max: Number(process.env.RESELLER_TOPUP_MAX || 1000000),
      gateways: enabledTopupGateways(setting),
    },
  };
  const rev = crypto.createHash("sha1").update(JSON.stringify(body)).digest("hex").slice(0, 16);
  const value = { rev, ...body };
  cache = { at: Date.now(), value };
  return value;
};

export { buildCatalog, invalidateCatalog };
