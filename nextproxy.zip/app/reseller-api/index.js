import { Router } from "express";
import auth from "./middleware/auth.js";
import { wrap } from "./services/http.js";
import Config from "./controllers/ConfigController.js";
import Credit from "./controllers/CreditController.js";
import Service from "./controllers/ServiceController.js";

// Intermediary REST API - the ONLY door between an isolated reseller bot and
// the main bot.  Base path: /reseller-api/v1
const api = Router();
api.use(auth);

// config, servers, plans, permission matrix
api.get("/bootstrap", wrap(Config.bootstrap));
api.get("/permissions", wrap(Config.permissions));
api.get("/servers", wrap(Config.servers));
api.get("/plans", wrap(Config.plans));

// credit balance + "Recharge Account" (paid on the main bot's gateways)
api.get("/credit", wrap(Credit.balance));
api.post("/credit/topups", wrap(Credit.createTopup));
api.get("/credit/topups", wrap(Credit.listTopups));
api.get("/credit/topups/:id", wrap(Credit.getTopup));

// config lifecycle (debits the credit balance)
api.post("/services", wrap(Service.create));
api.get("/services/:id", wrap(Service.info));
api.post("/services/:id/renew", wrap(Service.renew));
api.post("/services/:id/status", wrap(Service.toggleStatus));
api.post("/services/:id/revoke", wrap(Service.revoke));
api.delete("/services/:id", wrap(Service.remove));
api.get("/stats", wrap(Service.stats));

const router = Router();
router.use("/reseller-api/v1", api);

export default router;
