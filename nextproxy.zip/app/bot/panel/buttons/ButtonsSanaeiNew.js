import { Markup } from "telegraf";
import { PANEL_TYPES } from "../../../utils/panelTypes.js";
import { SANAEI_TEXTS } from "../utils/SanaeiTexts.js";

// panel type selection of the "add server" process
const InboundPanelTypeButtons = () => {
  return Markup.inlineKeyboard([
    [Markup.button.callback(SANAEI_TEXTS.BUTTON_OLD, "ADDINBOUNDTYPE_" + PANEL_TYPES.SANAEI_OLD)],
    [Markup.button.callback(SANAEI_TEXTS.BUTTON_NEW, "ADDINBOUNDTYPE_" + PANEL_TYPES.SANAEI_NEW)],
  ]);
};

export { InboundPanelTypeButtons };
