import { Markup } from "telegraf";
import { chunk } from "../../utils/utils.js";
import {
  RESELLER_FEATURE_GROUPS,
  RESELLER_PERMISSION_DEFS,
  RESELLER_ADMIN_GROUPS,
  RESELLER_ADMIN_PERMISSION_DEFS,
} from "../../../utils/resellerPermissions.js";

class PanelButtons {
  constructor(ctx) {
    this.i18n = ctx.i18n;
  }

  // Keyboard Panel Menu
  PanelMenuButtons() {
    return Markup.keyboard([
      ...this._adminWebAppRow(),
      [this.i18n.t("PANEL.MENU_PANEL.TOTAL")],
      [this.i18n.t("PANEL.MENU_PANEL.CHANGE_PRICE_NEMAYADNEGI"), this.i18n.t("PANEL.MENU_PANEL.CHANGE_PRICE")],
      [this.i18n.t("PANEL.MENU_PANEL.ADD_GIFT"), this.i18n.t("PANEL.MENU_PANEL.DELETE_GIFT")],
      [this.i18n.t("PANEL.MENU_PANEL.DELETE_AGENT"), this.i18n.t("PANEL.MENU_PANEL.ADD_AGENT")],
      [this.i18n.t("PANEL.MENU_PANEL.CHECK_ACCOUNT"), this.i18n.t("PANEL.MENU_PANEL.CHECK_SERVISE")],
      [this.i18n.t("PANEL.MENU_PANEL.ADD_INBOUND"), this.i18n.t("PANEL.MENU_PANEL.LIST_PANEL")],
      [this.i18n.t("PANEL.MENU_PANEL.ADD_PELAN"), this.i18n.t("PANEL.MENU_PANEL.DELETE_PELAN")],
      [this.i18n.t("PANEL.MENU_PANEL.EDIT_PELAN"), this.i18n.t("PANEL.MENU_PANEL.LIST_AGENT")],
      [this.i18n.t("PANEL.MENU_PANEL.CONFIG_CUSTUMIZE"), this.i18n.t("PANEL.MENU_PANEL.CONFIG_CUSTUMIZE_SELECT")],
      [this.i18n.t("PANEL.MENU_PANEL.CONFIG_PROTOCOL"), this.i18n.t("PANEL.MENU_PANEL.GIFT_INVITE")],
      [this.i18n.t("PANEL.MENU_PANEL.SHOW_PELAN"), this.i18n.t("PANEL.MENU_PANEL.SHOW_PAY")],
      [this.i18n.t("PANEL.MENU_PANEL.ADD_UPGRADE"), this.i18n.t("PANEL.MENU_PANEL.DELETE_UPGRADE")],
      [this.i18n.t("PANEL.MENU_PANEL.SET_ID_CARD"), this.i18n.t("PANEL.MENU_PANEL.LOG_BUY")],
      [this.i18n.t("PANEL.MENU_PANEL.MESSAGE_ALL"), this.i18n.t("PANEL.MENU_PANEL.FORWARD_ALL")],
      [this.i18n.t("PANEL.MENU_PANEL.BLOCK"), this.i18n.t("PANEL.MENU_PANEL.UNBLOCK")],
      [this.i18n.t("PANEL.MENU_PANEL.SET_GIFT_START"), this.i18n.t("PANEL.MENU_PANEL.SET_TRAFIC_FREE")],
      [this.i18n.t("PANEL.MENU_PANEL.SELL_MONTH"), this.i18n.t("PANEL.MENU_PANEL.SELL_CARD")],
      [this.i18n.t("PANEL.MENU_PANEL.ENABLE_ALL"), this.i18n.t("PANEL.MENU_PANEL.DISABLE_ALL")],
      [this.i18n.t("PANEL.MENU_PANEL.SWITCH_DARGAH"), this.i18n.t("PANEL.MENU_PANEL.SABT_LINK")],
      [this.i18n.t("PANEL.MENU_PANEL.SWITCH_DARGAH_CARD")],
      [this.i18n.t("PANEL.MENU_PANEL.CONFIG_PAYG")],
      [this.i18n.t("PANEL.MENU_PANEL.MANAGE_PAYG")],
      [this.i18n.t("PANEL.MENU_PANEL.CONFIG_NOWPAYMENTS"), this.i18n.t("PANEL.MENU_PANEL.CONFIG_REFUND")],
      [this.i18n.t("PANEL.MENU_PANEL.MANAGE_TEXTS")],
      [this.i18n.t("PANEL.MENU_PANEL.MANAGE_RESELLERS")],
      [this.i18n.t("PANEL.MENU_PANEL.CONFIG_RESELLER_BALANCE"), this.i18n.t("PANEL.MENU_PANEL.CONFIG_RESELLER_FEE")],
      [this.i18n.t("PANEL.MENU_PANEL.ADD_INBOUND_MZ"), this.i18n.t("PANEL.MENU_PANEL.LIST_PANEL_MZ")],
      [this.i18n.t("PANEL.MENU_PANEL.FIRST_PAYMENT"), this.i18n.t("PANEL.MENU_PANEL.PIN")],
      ["/start"],
    ]).resize();
  }
  // kept as a separate method (not merged into the array above) so a future
  // change to that literal never silently drops this conditional row
  _adminWebAppRow() {
    return process.env.WEBAPP_URL ? [[Markup.button.webApp("🧩 اپلیکیشن وب (مدیریت)", process.env.WEBAPP_URL)]] : [];
  }


  // Back Panel
  BackPanelButton() {
    return Markup.keyboard([[this.i18n.t("PANEL.MENU_PANEL.BACK_PANEL")]]).resize();
  }

  // getAllPelan
  AllPelanButton(datas, gift = false) {
    const keyboard = [];
    keyboard.push(chunk(datas, 2).map((items) => items.map((item) => (!gift ? item.name : item.code))));
    // add back
    keyboard[0].push([this.i18n.t("PANEL.MENU_PANEL.BACK_PANEL")]);
    return Markup.keyboard(keyboard[0]).resize();
  }

  // proctocol
  ProtoclButton(datas) {
    const checkCard = (item) => {
      if (item.value) {
        return "✔️ " + item.name;
      } else {
        return "✖️ " + item.name;
      }
    };

    return Markup.inlineKeyboard([
      ...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(checkCard(item), "CHANGEPROTOCOL-" + item.name))),
    ]);
  }

  // show pelan
  PelanButton(datas) {
    const checkCard = (item) => {
      if (item.value) {
        return "✔️ " + this.i18n.t(`ESHTERAK_BUY.MENU.${item.text}`);
      } else {
        return "✖️ " + this.i18n.t(`ESHTERAK_BUY.MENU.${item.text}`);
      }
    };

    return Markup.inlineKeyboard([
      ...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(checkCard(item), "CHANGESHOWPELAN|" + item.text))),
    ]);
  }

  // show pay
  PayButton(datas) {
    const checkCard = (item) => {
      if (item.value) {
        return "✔️ " + this.i18n.t(`PRICE.MENU.${item.text}`);
      } else {
        return "✖️ " + this.i18n.t(`PRICE.MENU.${item.text}`);
      }
    };

    return Markup.inlineKeyboard([
      ...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(checkCard(item), "SHOWPAY_" + item.text))),
    ]);
  }

  // accept resid
  AcsseptResidServise(id) {
    return Markup.inlineKeyboard([
      Markup.button.callback(this.i18n.t("PAY.CARD.MENU.ACCEPT"), `ACCEPTRESID_${id}`),
      Markup.button.callback(this.i18n.t("PAY.CARD.MENU.APPROVE"), "APPROVERESID_" + id),
    ]);
  }

  // select inbound
  Inbound(datas) {
    const keyboard = [];
    keyboard.push(chunk(datas, 2).map((items) => items.map((item) => item.damoin + "-" + item.location)));
    // add back
    keyboard[0].push([this.i18n.t("PANEL.MENU_PANEL.BACK_PANEL")]);
    return Markup.keyboard(keyboard[0]).resize();
  }

  // list inbound
  ListInbound(datas) {
    // create data
    const keyboard = [];
    keyboard.push([
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.TAG"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.COUNT"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.ALL"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.PRICE"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.STATUS"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.DELETE"), "JUST_SHOW"),
    ]);
    datas.map((item) => {
      const all = item.port.split(",")[1] - item.usePort;
      const count = item.usePort - item.port.split(",")[0];
      keyboard.push([
        Markup.button.callback(item.location, "EDITINBOUND_" + item.id),
        Markup.button.callback(count, "JUST_SHOW"),
        Markup.button.callback(all, "JUST_SHOW"),
        Markup.button.callback(item.price ?? "✖️", "JUST_SHOW"),
        Markup.button.callback(item.status ? "✅" : "❌", "CHENGESTATUSINBOUND_" + item.id),
        Markup.button.callback("🗑", "DELETEINBOUND_" + item.id),
      ]);
    });
    return Markup.inlineKeyboard(keyboard);
  }

  // list agent
  ListَAgent(datas) {
    const keyboard = [];
    keyboard.push([
      Markup.button.callback(this.i18n.t("PANEL.LIST_AGENT.MENU.ID"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_AGENT.MENU.DISCOUNT"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_AGENT.MENU.DISCOUNT_CASE"), "JUST_SHOW"),
    ]);
    datas.map((item) => {
      const { darsad, number } = JSON.parse(item.agent_price);
      keyboard.push([
        Markup.button.callback(item.id, "CHENGEAGENT_" + item.id),
        Markup.button.callback(darsad, "JUST_SHOW"),
        Markup.button.callback(number, "JUST_SHOW"),
      ]);
    });
    return Markup.inlineKeyboard(keyboard);
  }

  // sell month
  SellMonth(datas, type = "SELLMONTH_", count = 2) {
    return Markup.inlineKeyboard([
      ...chunk(datas, count).map((items) => items.map((item) => Markup.button.callback(item.text, type + item.key))),
    ]);
  }

  // list kharid
  switchDargah(datas, key, prefix = "SWITCHDARGAH_") {
    const checkCard = (item) => {
      if (item.text == key) {
        return "✅ " + this.i18n.t(`PRICE.MENU.${item.text}`);
      } else {
        return this.i18n.t(`PRICE.MENU.${item.text}`);
      }
    };
    return Markup.inlineKeyboard([
      ...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(checkCard(item), prefix + item.text))),
    ]);
  }

  // toggle payg for multi/single location plan types
  payg(multiEnabled, singleEnabled) {
    return Markup.inlineKeyboard([
      [
        Markup.button.callback(
          (multiEnabled ? "✅ " : "❌ ") + this.i18n.t("ESHTERAK_BUY.MENU.MULTILOCATION"),
          "PAYGTOGGLE_multi"
        ),
        Markup.button.callback(
          (singleEnabled ? "✅ " : "❌ ") + this.i18n.t("ESHTERAK_BUY.MENU.TAKLOCATION"),
          "PAYGTOGGLE_single"
        ),
      ],
    ]);
  }

  // paginated list of payg services for the admin management page
  paygList(items, page, hasNext) {
    const key = items.map((item) => [
      Markup.button.callback(
        `${item.suspended_at ? "⛔️" : "✅"} #${item.id} - سرویس ${item.service_id} - کاربر ${item.telegram_id}`,
        "PAYGVIEW_" + item.id
      ),
    ]);
    const nav = [];
    if (page > 0) nav.push(Markup.button.callback("◀️ قبلی", "PAYGLIST_" + (page - 1)));
    if (hasNext) nav.push(Markup.button.callback("بعدی ▶️", "PAYGLIST_" + (page + 1)));
    if (nav.length) key.push(nav);
    return Markup.inlineKeyboard(key);
  }

  // detail view actions for a single payg service
  paygDetail(item) {
    return Markup.inlineKeyboard([
      [Markup.button.callback("📊 نمودار مصرف", "PAYGGRAPH_" + item.id)],
      [Markup.button.callback("🧾 لاگ کسر هزینه‌ها", "PAYGCOST_" + item.id + "_0")],
      [
        Markup.button.callback(item.suspended_at ? "✅ فعال‌سازی" : "⛔️ تعلیق", "PAYGADMINTOGGLE_" + item.id),
        Markup.button.callback("🗑 حذف کامل", "PAYGADMINDELETE_" + item.id),
      ],
      [Markup.button.callback("◀️ بازگشت به لیست", "PAYGLIST_0")],
    ]);
  }

  // cost deduction log of one payg service (paginated, newest first)
  paygCostLog(item, page, hasNext) {
    const rows = [];
    const nav = [];
    if (page > 0) nav.push(Markup.button.callback("◀️ جدیدتر", "PAYGCOST_" + item.id + "_" + (page - 1)));
    if (hasNext) nav.push(Markup.button.callback("قدیمی‌تر ▶️", "PAYGCOST_" + item.id + "_" + (page + 1)));
    if (nav.length) rows.push(nav);
    rows.push([Markup.button.callback("◀️ بازگشت به جزئیات سرویس", "PAYGVIEW_" + item.id)]);
    return Markup.inlineKeyboard(rows);
  }

  // status crypto
  StatusCrypto(status) {
    return Markup.inlineKeyboard([
      Markup.button.callback(this.i18n.t("PANEL.FIRST_PAYMENT.STATUS") + (status ? " ✅" : " ❌"), `CHANCHESTATUSCRYPTO`),
    ]);
  }

  // status NowPayments gateway
  StatusNowPayments(status) {
    return Markup.inlineKeyboard([
      Markup.button.callback((status ? "✅ فعال" : "❌ غیرفعال") + " - تغییر وضعیت", `CHANGESTATUSNOWPAY`),
    ]);
  }

  // status refund feature
  StatusRefund(status) {
    return Markup.inlineKeyboard([
      Markup.button.callback((status ? "✅ فعال" : "❌ غیرفعال") + " - تغییر وضعیت", `CHANGESTATUSREFUND`),
    ]);
  }

  // marzban
  // list inbound
  ListInboundMz(list, datas) {
    // create data
    const keyboard = [];
    keyboard.push([
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL_MZ.MENU.TAG"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL_MZ.MENU.COUNT"), "JUST_SHOW"),
      // Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL.MENU.STATUS"), "JUST_SHOW"),
      Markup.button.callback(this.i18n.t("PANEL.LIST_PANEL_MZ.MENU.DELETE"), "JUST_SHOW"),
    ]);
    datas.map((item) => {
      keyboard.push([
        Markup.button.callback(item.tag, "CHENGETAGINBOUND_" + item.id),
        Markup.button.callback(item.count, "JUST_SHOW"),
        // Markup.button.callback(item.status ? "✅" : "❌", "CHENGESTATUSINBOUND_" + item.id),
        Markup.button.callback("🗑", "DELETEINBOUND_" + item.id),
      ]);
    });
    return Markup.inlineKeyboard(keyboard);
  }

  // ===== Dynamic Text & Button Management =====

  // top-level category picker, e.g. MENU / PANEL / SIGN_UP / ...
  DynTextCategories(categories) {
    const rows = categories.map((item, index) => [Markup.button.callback(`${item.category} (${item.count})`, "DYNTEXTCAT_" + index)]);
    return Markup.inlineKeyboard(chunk(rows.map((r) => r[0]), 2));
  }

  // paginated list of keys inside a category
  DynTextKeys(keys, page, pageSize, overriddenMap) {
    const start = page * pageSize;
    const pageItems = keys.slice(start, start + pageSize);
    const rows = pageItems.map((key, index) => [
      Markup.button.callback((overriddenMap[key] ? "✏️ " : "") + key, "DYNTEXTKEY_" + (start + index)),
    ]);
    const nav = [];
    if (page > 0) nav.push(Markup.button.callback("◀️", "DYNTEXTPAGE_" + (page - 1)));
    nav.push(Markup.button.callback(this.i18n.t("DYNTEXT.MENU.BACK_TO_CATEGORIES"), "DYNTEXTBACKCATS"));
    if (start + pageSize < keys.length) nav.push(Markup.button.callback("▶️", "DYNTEXTPAGE_" + (page + 1)));
    rows.push(nav);
    return Markup.inlineKeyboard(rows);
  }

  // single key detail: edit / reset / back
  DynTextDetail(overridden) {
    const rows = [[Markup.button.callback(this.i18n.t("DYNTEXT.MENU.EDIT"), "DYNTEXTEDIT")]];
    if (overridden) rows.push([Markup.button.callback(this.i18n.t("DYNTEXT.MENU.RESET"), "DYNTEXTRESET")]);
    rows.push([Markup.button.callback(this.i18n.t("DYNTEXT.MENU.BACK_TO_KEYS"), "DYNTEXTBACKKEYS")]);
    return Markup.inlineKeyboard(rows);
  }

  // ===== Reseller Bot Management =====

  // paginated list of reseller bots
  ResellerList(resellers, page, hasNext) {
    const rows = resellers.map((r) => [
      Markup.button.callback(`${r.status === "active" ? "🟢" : "🔴"} @${r.bot_username || r.id}`, "RESELLERVIEW_" + r.id),
    ]);
    const nav = [];
    if (page > 0) nav.push(Markup.button.callback("◀️", "RESELLERLIST_" + (page - 1)));
    if (hasNext) nav.push(Markup.button.callback("▶️", "RESELLERLIST_" + (page + 1)));
    if (nav.length) rows.push(nav);
    rows.push([Markup.button.callback("🔙 مرکز کنترل نمایندگی‌ها", "RESELLERHUB")]);
    return Markup.inlineKeyboard(rows);
  }

  // reseller detail: suspend/activate, delete, back
  ResellerDetail(id, status) {
    const rows = [];
    if (status === "active") {
      rows.push([Markup.button.callback(this.i18n.t("PANEL.RESELLER.MENU.SUSPEND"), "RESELLERSUSPEND_" + id)]);
    } else {
      rows.push([Markup.button.callback(this.i18n.t("PANEL.RESELLER.MENU.ACTIVATE"), "RESELLERACTIVATE_" + id)]);
    }
    rows.push([Markup.button.callback(this.i18n.t("PANEL.RESELLER.MENU.DELETE"), "RESELLERDELETEASK_" + id)]);
    rows.push([Markup.button.callback(this.i18n.t("PANEL.RESELLER.MENU.BACK_TO_LIST"), "RESELLERLIST_0")]);
    return Markup.inlineKeyboard(rows);
  }

  // reseller delete confirmation
  ResellerDeleteConfirm(id) {
    return Markup.inlineKeyboard([
      [Markup.button.callback(this.i18n.t("PANEL.RESELLER.MENU.CONFIRM_DELETE"), "RESELLERDELETE_" + id)],
      [Markup.button.callback(this.i18n.t("PANEL.RESELLER.MENU.BACK_TO_LIST"), "RESELLERVIEW_" + id)],
    ]);
  }

  // ===== Reseller control hub (INLINE / glass buttons only) =====
  //
  // Hub -> [ Reseller list | Reseller Bot Features | Reseller Admin Permissions ]
  // Both matrices are grouped: a category picker first, then one page of
  // toggles per category (keeps every message far below Telegram's 100
  // buttons-per-message limit and every callback_data below 64 bytes).

  // top level hub
  ResellerHub({ resellerCount = 0, featureOn = 0, featureTotal = 0, adminOn = 0, adminTotal = 0 } = {}) {
    return Markup.inlineKeyboard([
      [Markup.button.callback(`🤖 لیست نمایندگان (${resellerCount})`, "RESELLERLIST_0")],
      [Markup.button.callback(`🧩 قابلیت‌های ربات نماینده (${featureOn}/${featureTotal})`, "RESELLERFEATS")],
      [Markup.button.callback(`🛡 دسترسی‌های ادمین نماینده (${adminOn}/${adminTotal})`, "RESELLERADMS")],
    ]);
  }

  // shared builder: category picker of a permission matrix
  _permissionGroups({ groups, defs, perms, groupPrefix, allPrefix, backData }) {
    const buttons = groups.map((group) => {
      const list = defs.filter((def) => def.group === group.key);
      const on = list.filter((def) => perms[def.key]).length;
      return Markup.button.callback(`${group.title} (${on}/${list.length})`, groupPrefix + group.key);
    });
    return Markup.inlineKeyboard([
      ...chunk(buttons, 2),
      [Markup.button.callback("✅ فعال‌سازی همه", allPrefix + "on"), Markup.button.callback("❌ غیرفعال‌سازی همه", allPrefix + "off")],
      [Markup.button.callback("🔙 بازگشت به مرکز کنترل", backData)],
    ]);
  }

  // shared builder: one page of toggles of a permission matrix
  _permissionGroupPage({ groupKey, defs, perms, togglePrefix, setPrefix, backData }) {
    const rows = defs
      .filter((def) => def.group === groupKey)
      .map((def) => [Markup.button.callback(`${perms[def.key] ? "✅" : "❌"} ${def.label}`, togglePrefix + def.key)]);
    rows.push([
      Markup.button.callback("✅ همه این بخش", `${setPrefix}${groupKey}_on`),
      Markup.button.callback("❌ هیچ‌کدام", `${setPrefix}${groupKey}_off`),
    ]);
    rows.push([Markup.button.callback("🔙 بازگشت به دسته‌ها", backData)]);
    return Markup.inlineKeyboard(rows);
  }

  // Reseller Bot Features - category picker
  ResellerPermissions(perms) {
    return this._permissionGroups({
      groups: RESELLER_FEATURE_GROUPS,
      defs: RESELLER_PERMISSION_DEFS,
      perms,
      groupPrefix: "RESELLERFGRP_",
      allPrefix: "RESELLERFALL_",
      backData: "RESELLERHUB",
    });
  }

  // Reseller Bot Features - toggles of one category (one toggle per main-bot feature)
  ResellerFeatureGroup(groupKey, perms) {
    return this._permissionGroupPage({
      groupKey,
      defs: RESELLER_PERMISSION_DEFS,
      perms,
      togglePrefix: "RESELLERPERM_",
      setPrefix: "RESELLERFSET_",
      backData: "RESELLERFEATS",
    });
  }

  // Reseller Admin Permissions - category picker
  ResellerAdminPermissions(perms) {
    return this._permissionGroups({
      groups: RESELLER_ADMIN_GROUPS,
      defs: RESELLER_ADMIN_PERMISSION_DEFS,
      perms,
      groupPrefix: "RESELLERAGRP_",
      allPrefix: "RESELLERAALL_",
      backData: "RESELLERHUB",
    });
  }

  // Reseller Admin Permissions - toggles of one category (one toggle per admin menu/setting)
  ResellerAdminGroup(groupKey, perms) {
    return this._permissionGroupPage({
      groupKey,
      defs: RESELLER_ADMIN_PERMISSION_DEFS,
      perms,
      togglePrefix: "RESELLERAPERM_",
      setPrefix: "RESELLERASET_",
      backData: "RESELLERADMS",
    });
  }
}

export { PanelButtons };
