import { STATE_LIST_ADMIN } from "./state.js";
import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";

const Reseller = {
  [STATE_LIST_ADMIN.CONFIG_RESELLER_BALANCE]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text.trim();
    if (isNaN(text)) return ctx.reply(i18n.t("PANEL.RESELLER.ERROR_NUMBER"));
    await UpdateSetting({ reseller_min_balance: Number(text) });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.RESELLER.SAVED"), menu.PanelMenuButtons());
  },
  [STATE_LIST_ADMIN.CONFIG_RESELLER_FEE]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text.trim();
    if (isNaN(text)) return ctx.reply(i18n.t("PANEL.RESELLER.ERROR_NUMBER"));
    await UpdateSetting({ reseller_setup_fee: Number(text) });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.RESELLER.SAVED"), menu.PanelMenuButtons());
  },
};

export default Reseller;
