import Sanae from "../../../api/sanae.js";
import { selectAllInbound } from "../../../controllers/Inbound.js";
import { CreateServise } from "../../../controllers/Servise.js";
import Servise from "../../model/servise.js";
import SanaeiNew from "../../../api/sanaei_new.js";
import { UpdateInbound } from "../../../controllers/Inbound.js";
import { PANEL_TYPES } from "../../../utils/panelTypes.js";
import { STATE_LIST_ADMIN } from "./state.js";

const SabtLink = {
  // sabt link
  [STATE_LIST_ADMIN.SABT_LINK]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    const match = text.match(/vless:\/\/([0-9a-fA-F\-]+)@/);
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    ctx.reply("⏳");
    const all = await selectAllInbound();
    for (const item of all) {
      // sanaei new versions
      if (item.panel == PANEL_TYPES.SANAEI_NEW) {
        const apiSanaeiNew = new SanaeiNew(item.damoin, item.session, {
          username: item.username,
          password: item.password,
          onSession: (session) => UpdateInbound({ id: item.id }, { session }),
        });
        const term = match ? match[1] : text.trim();
        const client = await apiSanaeiNew.findClient({ term });
        if (client) {
          const modelservise = new Servise();
          const { ids } = await CreateServise({
            uuid: client.uuid,
            id: ctx.from.id,
            location: item.id,
            types: "select",
            data_limit: client.totalGB,
            name: "اشتراک ثبتی",
            email: client.email,
            defaultname: null,
            id_pelan: null,
            traficc: client.totalGB / 1073741824,
            day: client.expiryTime == 0 ? 0 : 30,
            free: false,
            key: await modelservise.handleRandom(5),
            panel: PANEL_TYPES.SANAEI_NEW,
          });
          delete ctx.session.state;
          return ctx.replyWithHTML(i18n.t("PANEL.SABT_LINK.SUCCESS", { id: ids }), menu.PanelMenuButtons());
        }
        continue;
      }
      const apiSanae = new Sanae(item.damoin, item.session);

      const getinbound = await apiSanae.getInbounds();
      if (getinbound) {
        for (const items of getinbound.obj) {
          const setting = JSON.parse(items.settings);
          if (match || uuidRegex.test(text)) {
            const search = match ? match[1] : text;
            var find = setting.clients.find((client) => client.id === search);
          } else {
            var find = setting.clients.find((client) => client.email === text);
          }
          if (find) {
            console.log(find);

            const modelservise = new Servise();
            const { ids } = await CreateServise({
              uuid: find.id,
              id: ctx.from.id,
              location: item.id,
              types: "select",
              data_limit: find.totalGB,
              name: "اشتراک ثبتی",
              email: find.email,
              defaultname: null,
              id_pelan: null,
              traficc: find.totalGB / 1073741824,
              day: find.expiryTime == 0 ? 0 : 30,
              free: false,
              key: await modelservise.handleRandom(5),
              panel: "sanae",
            });
            delete ctx.session.state;
            return ctx.replyWithHTML(i18n.t("PANEL.SABT_LINK.SUCCESS", { id: ids }), menu.PanelMenuButtons());
          }
        }
      }
    }
    ctx.reply(i18n.t("PANEL.SABT_LINK.ERROR"), menu.BackPanelButton());
  },
};

export default SabtLink;
