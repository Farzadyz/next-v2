import SanaeiNew from "../../../api/sanaei_new.js";
import { CreataInboundSanaeiNew } from "../../../controllers/InboundSanaeiNew.js";
import { STATE_LIST_ADMIN } from "./state.js";

const InboundSanaeiNew = {
  // for add inbound (server) of the "Sanaei New Versions" panel type
  [STATE_LIST_ADMIN.ADD_INBOUND_SANAEI_NEW]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n").map((item) => item.trim());
    // error line
    if (!split[8]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error line 8
    if (split[8] != "normal" && split[8] != "economic") return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error port range
    if (!/^\d+,\d+$/.test(split[7])) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // api
    await ctx.reply("⏳");
    const apisanaei = new SanaeiNew(split[0]);
    const result = await apisanaei.Login(split[1], split[2]);

    if (!result) return ctx.reply(i18n.t("PANEL.ADD_INBOUND.ERROR"), menu.BackPanelButton());
    // succefuly & insert (panel = sanaei_new) & send message
    const price = Number(split[9]);
    await CreataInboundSanaeiNew({
      damoin: split[0],
      username: split[1],
      password: split[2],
      location: split[3],
      host: split[4],
      internal: split[5],
      tunel: split[6],
      port: split[7],
      usePort: split[7].split(",")[0],
      type: split[8],
      price: split[9] && !isNaN(price) ? price : null,
      session: result,
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_ADD"), menu.PanelMenuButtons());
  },
};

export default InboundSanaeiNew;
