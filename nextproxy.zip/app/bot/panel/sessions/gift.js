import { DeleteGift, SelectGift, insertGift } from "../../../controllers/Gift.js";
import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Gift = {
  // add gift
  [STATE_LIST_ADMIN.ADD_GIFT]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (!split[2]) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_LINE"));
    if (isNaN(split[2])) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    // error exixt gift
    const selectgift = await SelectGift({ code: split[0] });
    if (selectgift) return ctx.reply(i18n.t("PANEL.ADD_GIFT.EXIXST"));
    insertGift({ code: split[0], gift: split[1], limit: split[2] });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_ADD"), menu.PanelMenuButtons());
  },
  // for delete gift
  [STATE_LIST_ADMIN.DELETE_GIFT]: async ({ ctx, i18n, menu }) => {
    const code = ctx.message.text;
    const codes = await SelectGift({ code });
    // not found
    if (!codes) return ctx.reply(i18n.t("PANEL.DELETE_GIFT.NOT_FOUND"));
    // succefuly & delete & send message
    await DeleteGift({ code });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_DELETE"), menu.PanelMenuButtons());
  },
  // change gift invite
  [STATE_LIST_ADMIN.GIFT_INVITE]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (!split[1]) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_LINE"));
    // error int
    if (isNaN(split[0]) && isNaN(split[1])) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    await UpdateSetting({
      invite: JSON.stringify({
        start: Number(split[0]),
        charge: Number(split[1]),
      }),
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Gift;
