import { CreataUpgrade, DestoryUpgrade, selectUpgrade } from "../../../controllers/Upgrade.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Upgrade = {
  // for add upgrade
  [STATE_LIST_ADMIN.ADD_UPGRADE]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[2]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error type
    if (isNaN(split[1]) && isNaN(split[2])) return ctx.reply(i18n.t("PANEL.ERROR_NUMBER"));
    // succefuly & insert & send message
    CreataUpgrade({ name: split[0], traficc: split[1], price: split[2] });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_ADD"), menu.PanelMenuButtons());
  },
  // for delete upgrade
  [STATE_LIST_ADMIN.DELETE_UPGRADE]: async ({ ctx, i18n, menu }) => {
    const name = ctx.message.text;
    const box = await selectUpgrade({ name });
    // not found
    if (!box) return ctx.reply(i18n.t("PANEL.UPGRADE.NOT_FOUND"));
    // succefuly & delete & send message
    await DestoryUpgrade({ name });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_DELETE"), menu.PanelMenuButtons());
  },
};

export default Upgrade;
