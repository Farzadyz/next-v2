import { STATE_LIST_ADMIN } from "./state.js";
import { UpdateSendall } from "../../../controllers/SendAll.js";

const Send_All = {
  // message all
  [STATE_LIST_ADMIN.MESSAGE_ALL]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message?.text;
    if (!text) return ctx.reply(i18n.t("PANEL.MESSAGE_ALL.ANSWER"));

    await UpdateSendall({ step: "send", text });
    ctx.session.state = null;
    ctx.reply(i18n.t("PANEL.FORWARD_ALL.SUCCEFULY_ALL"), menu.PanelMenuButtons());
  },
  // forward all
  [STATE_LIST_ADMIN.FORWARD_ALL]: async ({ ctx, i18n, menu }) => {
    const message = ctx.message;
    if (!message?.forward_from_chat) return ctx.reply(i18n.t("PANEL.FORWARD_ALL.FORWARRD"));

    // فوروارد مستقیم از کانال مبدأ (پایدارتر از فوروارد از چت خصوصی ادمین)
    await UpdateSendall({ step: "forward", text: message.forward_from_message_id, chat: message.forward_from_chat.id });
    ctx.session.state = null;
    ctx.reply(i18n.t("PANEL.FORWARD_ALL.SUCCEFULY_ALL"), menu.PanelMenuButtons());
  },
};

export default Send_All;
