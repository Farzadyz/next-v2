import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Pay = {
  // add id card
  [STATE_LIST_ADMIN.ADD_ID_CARD]: async ({ ctx, i18n, menu }) => {
    // succefuly & insert & send message
    await UpdateSetting({
      id_card: ctx.message.text,
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Pay;
