import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const NowPaymentsSetting = {
  // ذخیره تنظیمات NowPayments: کلید Api / کلید IPN / نوع ارز / نرخ تبدیل
  [STATE_LIST_ADMIN.CONFIG_NOWPAYMENTS]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (split[3] === undefined) return ctx.reply(i18n.t("PANEL.NOWPAYMENTS_SETTING.ERROR_LINE"));
    if (isNaN(split[3])) return ctx.reply(i18n.t("PANEL.NOWPAYMENTS_SETTING.ERROR_NUMBER"));
    await UpdateSetting({
      nowpayments_api_key: split[0].trim() || null,
      nowpayments_ipn_secret: split[1].trim() || null,
      nowpayments_pay_currency: split[2].trim() || "trx",
      nowpayments_usd_rate: Number(split[3]),
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.NOWPAYMENTS_SETTING.SUCCEFULY"), menu.PanelMenuButtons());
  },
  // ذخیره تنظیمات مدت زمان مجاز لغو و مرجوعی (ساعت)
  [STATE_LIST_ADMIN.CONFIG_REFUND]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text.trim();
    if (isNaN(text)) return ctx.reply(i18n.t("PANEL.REFUND_SETTING.ERROR_NUMBER"));
    await UpdateSetting({ refund_hours: Number(text) });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.REFUND_SETTING.SUCCEFULY"), menu.PanelMenuButtons());
  },
};

export default NowPaymentsSetting;
