import { CreateBlock, DestoryBlock } from "../../../controllers/Block.js";
import { STATE_LIST_ADMIN } from "./state.js";
const Block = {
  // for block user
  [STATE_LIST_ADMIN.BLOCK]: async ({ ctx, i18n, menu }) => {
    CreateBlock({ id: ctx.message.text });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.BLOCK.SUCCEFULLY"), menu.PanelMenuButtons());
    ctx.reply(i18n.t("PANEL.BLOCK.USER"), { chat_id: ctx.message.text });
  },
  // for unblock user
  [STATE_LIST_ADMIN.UNBLOCK]: async ({ ctx, i18n, menu }) => {
    DestoryBlock({ id: ctx.message.text });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.UNBLOCK.SUCCEFULLY"), menu.PanelMenuButtons());
    ctx.reply(i18n.t("PANEL.UNBLOCK.USER"), { chat_id: ctx.message.text });
  },
};

export default Block;
