import Sanae from "../../../api/sanae.js";
import { CreataInbound, DestoryInbound, UpdateInbound, selectInbound } from "../../../controllers/Inbound.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Inbound = {
  // for add inbound
  [STATE_LIST_ADMIN.ADD_INBOUND]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[8]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error line 8
    if (split[8] != "normal" && split[8] != "economic") return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // api
    await ctx.reply("⏳");
    const apisanae = new Sanae(split[0]);
    const result = await apisanae.Login(split[1], split[2]);

    if (!result) return ctx.reply(i18n.t("PANEL.ADD_INBOUND.ERROR"), menu.BackPanelButton());
    // succefuly & insert & send message
    await CreataInbound({
      damoin: split[0],
      username: split[1],
      password: split[2],
      location: split[3],
      host: split[4],
      internal: split[5],
      tunel: split[6],
      port: split[7],
      usePort: split[7].split(",")[0],
      type: split[8],
      price: split[9],
      session: result,
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_ADD"), menu.PanelMenuButtons());
  },
  // for delete inbound
  [STATE_LIST_ADMIN.DELETE_INBOUND]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    const damoin = text.split("-")[0];
    const pelan = await selectInbound({ damoin });
    // not found
    if (!pelan) return ctx.reply(i18n.t("PANEL.DELETE_INBOUND.NOT_FOUND"));
    // succefuly & delete & send message
    await DestoryInbound({ damoin });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_DELETE"), menu.PanelMenuButtons());
  },
  // edit inbound
  [STATE_LIST_ADMIN.EDIT_INBOUND]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[1]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    if (split[2] != "normal" && split[2] != "economic") return ctx.reply(i18n.t("PANEL.ERROR_LINE"));

    // succefuly & update & send message
    UpdateInbound(
      { id: ctx.session.id_inbound },
      { location: split[0], port: split[1], usePort: split[1].split(",")[0], type: split[2], price: split[3] ?? null }
    );
    delete ctx.session.state;
    delete ctx.session.id_inbound;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Inbound;
