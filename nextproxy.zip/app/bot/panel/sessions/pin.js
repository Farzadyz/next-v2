import { STATE_LIST_ADMIN } from "./state.js";
import { UpdateSetting } from "../../../controllers/Setting.js";

const Pin = {
  // pin message
  [STATE_LIST_ADMIN.PIN]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message?.text;
    await UpdateSetting({ pin: text });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Pin;
