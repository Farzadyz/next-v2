import { UpdateBot } from "../../../controllers/Bot.js";
import { UpdateUser, selectUser } from "../../../controllers/Users.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Price = {
  // change price
  [STATE_LIST_ADMIN.CHANGE_PRICE]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (!split[1]) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_LINE"));
    if (isNaN(split[0]) && isNaN(split[1])) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    const selectUsers = await selectUser({ id: split[0] });
    if (!selectUsers) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.NOT_FOUND_USER"));
    await UpdateUser({ id: split[0] }, { price: selectUsers.price + Number(split[1]) });
    ctx.session.state = null;
    ctx.reply(i18n.t("PANEL.CHANGE_PRICE.SEND_PRICE", { price: split[1] }), { chat_id: split[0] });
    ctx.reply(
      i18n.t("PANEL.CHANGE_PRICE.SUCCFULLY", { price: selectUsers.price, newprice: selectUsers.price + Number(split[1]) }),
      menu.PanelMenuButtons()
    );
  },
  // change price nemayandegi
  [STATE_LIST_ADMIN.CHANGE_PRICE_NEMAYADNEGI]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (!split[1]) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_LINE"));
    if (isNaN(split[1])) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    if (split[0].startsWith("@")) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE_NEMAYADNEGI.ERROR"));
    await UpdateBot({ username: split[0], price: split[1] });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.CHANGE_PRICE_NEMAYADNEGI.SUCCFULLY"), menu.PanelMenuButtons());
  },
};

export default Price;
