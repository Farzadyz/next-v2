import { UpdateUser } from "../../../controllers/Users.js";
import { STATE_LIST_ADMIN } from "./state.js";
const Agent = {
  // for add agent
  [STATE_LIST_ADMIN.ADD_AGENT]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (!split[2]) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_LINE"));
    // error int
    if (isNaN(split[0]) && isNaN(split[1]) && isNaN(split[2])) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    UpdateUser({ id: split[0] }, { agent: true, agent_price: JSON.stringify({ darsad: Number(split[1]), number: Number(split[2]) }) });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_ADD"), menu.PanelMenuButtons());
    ctx.reply(i18n.t("PANEL.ADD_AGENT.SEND_USER"), { chat_id: split[0] });
  },
  // for delete agent
  [STATE_LIST_ADMIN.DELETE_AGENT]: async ({ ctx, i18n, menu }) => {
    UpdateUser({ id: ctx.message.text }, { agent: false });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_DELETE"), menu.PanelMenuButtons());
    ctx.reply(i18n.t("PANEL.DELETE_AGENT.SEND_USER"), { chat_id: ctx.message.text });
  },
  // for edit agent
  [STATE_LIST_ADMIN.EDIT_AGENT]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    if (!split[1]) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_LINE"));
    // error int
    if (isNaN(split[0]) && isNaN(split[1])) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    UpdateUser(
      { id: ctx.session.id_agent },
      { agent: true, agent_price: JSON.stringify({ darsad: Number(split[0]), number: Number(split[1]) }) }
    );
    delete ctx.session.state;
    delete ctx.session.id_agent;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Agent;
