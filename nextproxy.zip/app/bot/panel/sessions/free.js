import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Free = {
  // for traficc free
  [STATE_LIST_ADMIN.SET_TRAFIC_FREE]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    if (isNaN(text)) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    delete ctx.session.state;
    await UpdateSetting({
      free: Number(text),
    });
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Free;
