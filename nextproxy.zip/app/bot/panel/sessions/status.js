import Sanae from "../../../api/sanae.js";
import { selectInbound } from "../../../controllers/Inbound.js";
import { SelectALLServiseUser } from "../../../controllers/Servise.js";
import ServiseSanaeiNew from "../../model/servise_sanaei_new.js";
import { PANEL_TYPES } from "../../../utils/panelTypes.js";
import { STATE_LIST_ADMIN } from "./state.js";

const sanaeiNew = new ServiseSanaeiNew();

const Status = {
  // disable all servise
  [STATE_LIST_ADMIN.DISABLE_ALL]: async ({ ctx, i18n, menu }) => {
    const id = ctx.message.text;
    const allservise = await SelectALLServiseUser({ telegram_id: id, offset: 0, limit: 100000 });
    await ctx.reply("⏳");
    for (const item of allservise) {
      // sanaei new versions
      if (item.panel == PANEL_TYPES.SANAEI_NEW) {
        await sanaeiNew.setEnabled({ servises: item, enable: false });
        continue;
      }
      const inbound = await selectInbound({ id: item.location });
      const sanae = new Sanae(inbound.damoin, inbound.session);
      let data = await sanae.findClinet({ email: item.username });
      let getinbound = await sanae.getInbound({ inboundId: data.inboundId });
      var setting = JSON.parse(getinbound.obj.settings);
      setting.clients[0].enable = false;
      getinbound.obj.enable = false;
      await sanae.updateInbound(getinbound.obj);
    }
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.DISABLE_ALL.SUCCFULY"), menu.PanelMenuButtons());
  },
  // enable all servise
  [STATE_LIST_ADMIN.ENABLE_ALL]: async ({ ctx, i18n, menu }) => {
    const id = ctx.message.text;
    const allservise = await SelectALLServiseUser({ telegram_id: id, offset: 0, limit: 100000 });
    await ctx.reply("⏳");
    for (const item of allservise) {
      // sanaei new versions
      if (item.panel == PANEL_TYPES.SANAEI_NEW) {
        await sanaeiNew.setEnabled({ servises: item, enable: true });
        continue;
      }
      const inbound = await selectInbound({ id: item.location });
      const sanae = new Sanae(inbound.damoin, inbound.session);
      let data = await sanae.findClinet({ email: item.username });
      let getinbound = await sanae.getInbound({ inboundId: data.inboundId });
      var setting = JSON.parse(getinbound.obj.settings);
      setting.clients[0].enable = true;
      getinbound.obj.enable = true;
      await sanae.updateInbound(getinbound.obj);
    }
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.ENABLE_ALL.SUCCFULY"), menu.PanelMenuButtons());
  },
};

export default Status;
