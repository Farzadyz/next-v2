import { STATE_LIST_ADMIN } from "./state.js";
import { setOverride, getCategories, getKeysInCategory } from "../../utils/DynText.js";

const DynText = {
  // admin sent the replacement text for the key they were editing
  [STATE_LIST_ADMIN.EDIT_DYNTEXT]: async ({ ctx, i18n, menu }) => {
    const key = ctx.session.dynText?.selectedKey;
    delete ctx.session.state;
    if (!key) {
      const categories = getCategories();
      ctx.session.dynText = { categories: categories.map((c) => c.category) };
      return ctx.reply(i18n.t("DYNTEXT.DETAIL.NOT_FOUND"), menu.PanelMenuButtons());
    }
    const value = ctx.message.text;
    await setOverride(key, value);
    // refresh the key list for this category so the ✏️ badge shows up on return
    const category = ctx.session.dynText.category;
    if (category) ctx.session.dynText.keys = getKeysInCategory(category);
    ctx.reply(i18n.t("DYNTEXT.SAVED"), menu.PanelMenuButtons());
  },
};

export default DynText;
