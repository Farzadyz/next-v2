import { CreataPelan, DestoryPelan, UpdatePelan, selectPelan } from "../../../controllers/Pelan.js";
import { UpdateSetting } from "../../../controllers/Setting.js";
import { PANEL_TYPES } from "../../../utils/panelTypes.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Pelan = {
  // for add pelan
  [STATE_LIST_ADMIN.ADD_PELAN]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[4]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error type
    if (isNaN(split[1]) && isNaN(split[2]) && isNaN(split[3])) return ctx.reply(i18n.t("PANEL.ERROR_NUMBER"));
    // succefuly & insert & send message
    await CreataPelan({
      name: split[0],
      traficc: split[1],
      time: split[2],
      price: split[3],
      panel: split[4],
      type: split[5] ?? "normal",
      connection: split[4] == "sanae" || split[4] == PANEL_TYPES.SANAEI_NEW ? "single" : "multi",
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_ADD"), menu.PanelMenuButtons());
  },
  // for delete pelan
  [STATE_LIST_ADMIN.DELETE_PELAN]: async ({ ctx, i18n, menu }) => {
    const name = ctx.message.text;
    const pelan = await selectPelan({ name });
    // not found
    if (!pelan) return ctx.reply(i18n.t("PANEL.DELETE_PELAN.NOT_FOUND"));
    // succefuly & delete & send message
    await DestoryPelan({ name });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_DELETE"), menu.PanelMenuButtons());
  },
  // for edit pelan
  [STATE_LIST_ADMIN.EDIT_PELAN]: async ({ ctx, i18n, menu }) => {
    const name = ctx.message.text;
    const pelan = await selectPelan({ name });
    // not found
    if (!pelan) return ctx.reply(i18n.t("PANEL.DELETE_PELAN.NOT_FOUND"));
    // succefuly & save & send message
    ctx.session.state = STATE_LIST_ADMIN.EDIT_PELAN_REPLACE;
    ctx.session.id_pelan = pelan.id;
    const list = `<code>${pelan.name}\n${pelan.traficc}\n${pelan.time}\n${pelan.price}\n${pelan.panel}\n${pelan.type}</code>`;
    ctx.replyWithHTML(i18n.t("PANEL.EDIT_PELAN.EDIT", { list }), menu.BackPanelButton());
  },
  // for replace pelan
  [STATE_LIST_ADMIN.EDIT_PELAN_REPLACE]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[5]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error type
    if (isNaN(split[1]) && isNaN(split[2]) && isNaN(split[3])) return ctx.reply(i18n.t("PANEL.ERROR_NUMBER"));
    // succefuly & update & send message
    UpdatePelan(
      { id: ctx.session.id_pelan },
      { name: split[0], traficc: split[1], time: split[2], price: split[3], panel: split[4], type: split[5] }
    );
    delete ctx.session.state;
    delete ctx.session.id_pelan;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
  // for config customize pelan
  [STATE_LIST_ADMIN.CONFIG_CUSTUMIZE]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[5]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error type
    if (isNaN(split[0]) && isNaN(split[1]) && isNaN(split[2]) && isNaN(split[3]) && isNaN(split[4]) && isNaN(split[5]))
      return ctx.reply(i18n.t("PANEL.ERROR_NUMBER"));
    // succefuly & insert & send message
    await UpdateSetting({
      subscribe: JSON.stringify({
        minT: Number(split[0]),
        maxT: Number(split[1]),
        priceT: Number(split[2]),
        minD: Number(split[3]),
        maxD: Number(split[4]),
        priceD: Number(split[5]),
      }),
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
  // for config customize select pelan
  [STATE_LIST_ADMIN.CONFIG_CUSTUMIZE_SELECT]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[3]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error type
    if (isNaN(split[0]) && isNaN(split[2])) return ctx.reply(i18n.t("PANEL.ERROR_NUMBER"));
    // succefuly & insert & send message
    await UpdateSetting({
      customize: JSON.stringify({
        timeP: Number(split[0]),
        timeV: split[1].split(",").map(Number),
        traficcP: Number(split[2]),
        traficcV: split[3].split(",").map(Number),
      }),
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Pelan;
