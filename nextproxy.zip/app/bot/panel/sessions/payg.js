import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Payg = {
  // ذخیره تنظیمات عددی PAYG: هزینه ایجاد / نرخ روزانه و مصرف مولتی لوکیشن / نرخ روزانه و مصرف تک لوکیشن / حالت اولیه / حجم اولیه / روز اولیه
  [STATE_LIST_ADMIN.CONFIG_PAYG]: async ({ ctx, i18n, menu }) => {
    const split = ctx.message.text.split("\n");
    // error line
    if (!split[7]) return ctx.reply(i18n.t("PANEL.ERROR_LINE"));
    // error type (خط ششم حالته، نه عدد)
    if (
      isNaN(split[0]) ||
      isNaN(split[1]) ||
      isNaN(split[2]) ||
      isNaN(split[3]) ||
      isNaN(split[4]) ||
      isNaN(split[6]) ||
      isNaN(split[7])
    ) {
      return ctx.reply(i18n.t("PANEL.ERROR_NUMBER"));
    }
    const mode = split[5].trim() === "auto" ? "auto" : "fixed";
    // succefuly & update & send message
    await UpdateSetting({
      payg_base_amount: Number(split[0]),
      payg_daily_rate_multi: Number(split[1]),
      payg_data_rate_multi: Number(split[2]),
      payg_daily_rate_single: Number(split[3]),
      payg_data_rate_single: Number(split[4]),
      payg_initial_mode: mode,
      payg_initial_traffic: Number(split[6]),
      payg_initial_days: Number(split[7]),
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Payg;
