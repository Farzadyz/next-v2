import { SelectServise } from "../../../controllers/Servise.js";
import MyEshterak from "../../actions/myEshterak.js";
import { Buttons } from "../../buttons/ButtonManager.js";
import { STATE_LIST_ADMIN } from "./state.js";

const CkeckServise = {
  // for check account
  [STATE_LIST_ADMIN.CHECK_SERVISE]: async ({ ctx, i18n, menu }) => {
    const selectUsers = await SelectServise({ id: ctx.message.text });
    if (!selectUsers) return ctx.reply(i18n.t("PANEL.CHECK_SERVISE.NOT_FOUND"), menu.BackPanelButton());
    ctx.reply(i18n.t("PANEL.CHECK_SERVISE.RESULT"), menu.PanelMenuButtons());
    delete ctx.session.state;
    const menus = new Buttons(ctx);

    return MyEshterak.MYESHTERAK({ ctx, i18n, menu: menus, isMatch: ["myeshterak_" + ctx.message.text] });
  },
};

export default CkeckServise;
