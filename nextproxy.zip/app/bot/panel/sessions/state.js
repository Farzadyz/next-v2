const STATE_LIST_ADMIN = {
  // agent
  ADD_AGENT: "add_agent",
  DELETE_AGENT: "delete_agent",
  EDIT_AGENT: "edit_agent",
  // inbound
  ADD_INBOUND: "add_inbound",
  DELETE_INBOUND: "delete_inbound",
  SET_PRICE_INBOUND: "set_price_inbound",
  EDIT_INBOUND: "edit_inbound",
  // inbound (sanaei new versions)
  ADD_INBOUND_SANAEI_NEW: "add_inbound_sanaei_new",
  // pelan
  ADD_PELAN: "add_pelan",
  DELETE_PELAN: "delete_pelan",
  EDIT_PELAN: "edit_pelan",
  EDIT_PELAN_REPLACE: "edit_pelan_replace",
  CONFIG_CUSTUMIZE: "config_custumize",
  CONFIG_CUSTUMIZE_SELECT: "config_cutomize_select",
  CONFIG_PAYG: "config_payg",
  CONFIG_NOWPAYMENTS: "config_nowpayments",
  CONFIG_REFUND: "config_refund",
  // price
  CHANGE_PRICE: "change_price",
  // price nemayandegi
  CHANGE_PRICE_NEMAYADNEGI: "change_price_nemayandegi",
  // upgrade
  ADD_UPGRADE: "add_upgrade",
  DELETE_UPGRADE: "delete_upgrade",
  // gift
  ADD_GIFT: "ADD_GIFT",
  GIFT_INVITE: "gift_invaite",
  DELETE_GIFT: "delete_gift",
  // card
  ADD_ID_CARD: "add_id_card",
  // buy
  LOG_BUY: "log_buy",
  // message all && forward
  MESSAGE_ALL: "message_all",
  FORWARD_ALL: "forward_all",
  // block && unblock
  BLOCK: "block",
  UNBLOCK: "unblock",
  // start gift
  SET_GIFT_START: "set_start_gift",
  // free
  SET_TRAFIC_FREE: "set_traficc_free",
  // check account
  CHECK_ACCOUNT: "check_account",
  // check servise
  CHECK_SERVISE: "check_servise",
  // status servise
  DISABLE_ALL: "disable_servise",
  ENABLE_ALL: "enable_servise",
  // sabt link
  SABT_LINK: "sabt_link",
  // pin
  PIN: "pin",
  // marzban
  // inbound
  ADD_INBOUND_MZ: "add_inbound_mz",
  CHANGE_TAG_INBOUND_MZ: "change_tag_inbound_mz",
  // dynamic text & button management
  EDIT_DYNTEXT: "edit_dyntext",
  // reseller bot management
  CONFIG_RESELLER_BALANCE: "config_reseller_balance",
  CONFIG_RESELLER_FEE: "config_reseller_fee",
};

export { STATE_LIST_ADMIN };
