import { CountServise, SelectALLServiseUser } from "../../../controllers/Servise.js";
import { selectUser } from "../../../controllers/Users.js";
import { STATE_LIST_ADMIN } from "./state.js";

const CkeckAccount = {
  // for check account
  [STATE_LIST_ADMIN.CHECK_ACCOUNT]: async ({ ctx, i18n, menu }) => {
    const id = ctx.message.text;
    const selectUsers = await selectUser({ id });
    if (!selectUsers) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.NOT_FOUND_USER"), menu.BackPanelButton());
    const count = await CountServise({ telegram_id: id });
    // Get Servise
    const servises = await SelectALLServiseUser({
      telegram_id: id,
      offset: 0,
    });
    let list = "";
    for (const item of servises) {
      list += item.id + ", ";
    }
    delete ctx.session.state;
    ctx.replyWithHTML(
      i18n.t("PANEL.CHECK_ACCOUNT.LIST", {
        id,
        price: selectUsers.price,
        count,
        list,
      }),
      menu.PanelMenuButtons()
    );
  },
};

export default CkeckAccount;
