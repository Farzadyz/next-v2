import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Gift_Start = {
  // for set gift start
  [STATE_LIST_ADMIN.SET_GIFT_START]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    if (isNaN(text)) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    // succefuly & insert & send message
    await UpdateSetting({
      gift: text,
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Gift_Start;
