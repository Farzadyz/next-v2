import Marzban from "../../../api/marzban.js";
import { CreataInboundMz, UpdateInboundMz } from "../../../controllers/InboundMz.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Inbound_Mz = {
  // for add inbound
  [STATE_LIST_ADMIN.ADD_INBOUND_MZ]: async ({ ctx, i18n, menu }) => {
    const tag = ctx.message.text;
    const marzban = new Marzban();
    const result = await marzban.getInbounds({ tag });
    // error tag
    if (!result) return ctx.reply(i18n.t("PANEL.ADD_INBOUND_MZ.ERROR_TAG"));
    const { network, protocol, port, tls } = result;
    // succefuly & insert & send message
    const id = await CreataInboundMz({ type: "ALL", tag, network, protocol, port, tls });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.ADD_INBOUND_MZ.SUCCEFULY", { id }), menu.PanelMenuButtons());
  },
  // for edit tag inbound
  [STATE_LIST_ADMIN.CHANGE_TAG_INBOUND_MZ]: async ({ ctx, i18n, menu }) => {
    const tag = ctx.message.text;
    const marzban = new Marzban();
    const result = await marzban.getInbounds({ tag });
    // error tag
    if (!result) return ctx.reply(i18n.t("PANEL.ADD_INBOUND_MZ.ERROR_TAG"));
    const { network, protocol, port, tls } = result;
    // succefuly & update & send message
    await UpdateInboundMz({ id: ctx.session.id_inbound }, { tag, network, protocol, port, tls });
    delete ctx.session.state;
    delete ctx.session.id_inbound;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Inbound_Mz;
