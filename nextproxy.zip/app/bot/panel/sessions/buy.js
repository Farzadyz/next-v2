import { UpdateSetting } from "../../../controllers/Setting.js";
import { STATE_LIST_ADMIN } from "./state.js";

const Buy = {
  // for cog buy
  [STATE_LIST_ADMIN.LOG_BUY]: async ({ ctx, i18n, menu }) => {
    const log_buy = ctx.message.text;
    // succefuly & insert & send message
    await UpdateSetting({
      log_buy,
    });
    delete ctx.session.state;
    ctx.reply(i18n.t("PANEL.SUCCEFULY_SET"), menu.PanelMenuButtons());
  },
};

export default Buy;
