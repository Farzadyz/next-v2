import { PanelButtons } from "./buttons/ButtonsPanel.js";
import { STATE_LIST_ADMIN } from "./sessions/state.js";
// session
import Pelan from "./sessions/pelan.js";
import Price from "./sessions/price.js";
import Upgrade from "./sessions/upgrade.js";
import Gift from "./sessions/gift.js";
import Pay from "./sessions/pay.js";
import Buy from "./sessions/buy.js";
import Inbound from "./sessions/inbound.js";
import InboundSanaeiNew from "./sessions/inbound_sanaei_new.js";
import Send_All from "./sessions/sendall.js";
import Block from "./sessions/block.js";
import Gift_Start from "./sessions/giftStart.js";
import Agent from "./sessions/agent.js";
import Free from "./sessions/free.js";
import CkeckAccount from "./sessions/checkaccount.js";
import CkeckServise from "./sessions/checkservise.js";
import Status from "./sessions/status.js";
import SabtLink from "./sessions/sabtlink.js";
import Inbound_Mz from "./sessions/inbound_mz.js";
import Pin from "./sessions/pin.js";
import Payg from "./sessions/payg.js";
import NowPaymentsSetting from "./sessions/nowpaymentsSetting.js";
import DynText from "./sessions/dyntext.js";
import ResellerSetting from "./sessions/reseller.js";

export default async (ctx) => {
  const session = ctx.session;
  if (session && session.state) {
    const values = Object.values(STATE_LIST_ADMIN);
    if (values.includes(session.state) && EventListener[session.state]) {
      if (!ctx.message || typeof ctx.message.text !== "string") return;
      const menu = new PanelButtons(ctx);
      return EventListener[session.state]({ ctx, i18n: ctx.i18n, menu });
    }
  }
};

const EventListener = {
  // session agent
  ...Agent,
  // session inbound
  ...Inbound,
  // session inbound (sanaei new versions)
  ...InboundSanaeiNew,
  // session pelan
  ...Pelan,
  // session change price
  ...Price,
  // session upgrade
  ...Upgrade,
  // session gift
  ...Gift,
  // session pay
  ...Pay,
  // session buy
  ...Buy,
  // session sendall
  ...Send_All,
  // session block
  ...Block,
  // session gift start
  ...Gift_Start,
  // session free
  ...Free,
  // session account
  ...CkeckAccount,
  // session servise
  ...CkeckServise,
  // session status
  ...Status,
  // session sabtlink
  ...SabtLink,
  // session pin
  ...Pin,
  // session payg
  ...Payg,
  // session nowpayments & refund settings
  ...NowPaymentsSetting,
  // session dynamic text & button management
  ...DynText,
  // session reseller bot settings
  ...ResellerSetting,
  // marzban
  // session Inbound_Mz
  ...Inbound_Mz,
};
