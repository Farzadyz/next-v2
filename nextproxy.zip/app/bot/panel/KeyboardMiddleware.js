import { countAddedMonthFree, countAddedWeekFree, countFree } from "../../controllers/Free.js";
import { selectAllGift } from "../../controllers/Gift.js";
import { selectAllInbound } from "../../controllers/Inbound.js";
import { selectAllInboundMz } from "../../controllers/InboundMz.js";
import { selectAllPelan } from "../../controllers/Pelan.js";
import {
  countAddedMonthPeyment,
  countAddedTodayPeyment,
  countAddedWeekPeyment,
  countAddedYearPeyment,
  countAllPeyment,
} from "../../controllers/Peyment.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { SelectAllPaygService, CountPaygService } from "../../controllers/PaygService.js";
import { selectAllUpgrade } from "../../controllers/Upgrade.js";
import { countAddedMonth, countAddedToday, countAddedWeek, countAddedYear, countUser, selectAllAgent } from "../../controllers/Users.js";
import I18N, { I18NK } from "../utils/I18n.js";
import { PanelButtons } from "./buttons/ButtonsPanel.js";
import { STATE_LIST_ADMIN } from "./sessions/state.js";
import { getCategories } from "../utils/DynText.js";
import { renderResellerList, renderResellerPermissions } from "./actions/reseller.js";
import { InboundPanelTypeButtons } from "./buttons/ButtonsSanaeiNew.js";
import { SANAEI_TEXTS } from "./utils/SanaeiTexts.js";

export default async (ctx) => {
  const text = ctx.message?.text;
  if (!text) return true;
  if (I18N(ctx, "PANEL.MENU_PANEL").includes(text)) {
    const EventListener = {
      // button total
      [ctx.i18n.t("PANEL.MENU_PANEL.TOTAL")]: async ({ ctx, i18n }) => {
        const total = await countUser();
        const buy = await countAllPeyment();
        const today = await countAddedToday();
        const week = await countAddedWeek();
        const month = await countAddedMonth();
        const year = await countAddedYear();
        const todayBuy = await countAddedTodayPeyment();
        const weekBuy = await countAddedWeekPeyment();
        const monthBuy = await countAddedMonthPeyment();
        const yearBuy = await countAddedYearPeyment();
        const weekFree = await countAddedWeekFree();
        const monthFree = await countAddedMonthFree();
        const free = await countFree();
        ctx.reply(
          i18n.t("PANEL.TOTAL", {
            total,
            buy,
            today,
            week,
            month,
            year,
            todayBuy,
            weekBuy,
            monthBuy,
            yearBuy,
            weekFree,
            monthFree,
            free,
          })
        );
      },
      // button add agent
      [ctx.i18n.t("PANEL.MENU_PANEL.ADD_AGENT")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ADD_AGENT;
        ctx.reply(i18n.t("PANEL.ADD_AGENT.ANSWER"), menu.BackPanelButton());
      },
      // button delete agent
      [ctx.i18n.t("PANEL.MENU_PANEL.DELETE_AGENT")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.DELETE_AGENT;
        ctx.reply(i18n.t("PANEL.DELETE_AGENT.ANSWER"), menu.BackPanelButton());
      },
      // button list agent
      [ctx.i18n.t("PANEL.MENU_PANEL.LIST_AGENT")]: async ({ ctx, menu, i18n }) => {
        const allAgent = await selectAllAgent();
        if (allAgent.length < 1) return ctx.reply(i18n.t("PANEL.LIST_AGENT.NONE"));
        ctx.reply(i18n.t("PANEL.LIST_AGENT.ANSWER"), menu.ListَAgent(allAgent));
      },
      // button add inbound - first select the panel type (Sanaei <= 2.6.6 / Sanaei New Versions)
      [ctx.i18n.t("PANEL.MENU_PANEL.ADD_INBOUND")]: async ({ ctx }) => {
        delete ctx.session.state;
        ctx.reply(SANAEI_TEXTS.SELECT_TYPE, InboundPanelTypeButtons());
      },
      // button list inbound
      [ctx.i18n.t("PANEL.MENU_PANEL.LIST_PANEL")]: async ({ ctx, menu, i18n }) => {
        const allPelan = await selectAllInbound();
        if (allPelan.length < 1) return ctx.reply(i18n.t("PANEL.LIST_PANEL.NONE"));
        ctx.reply(i18n.t("PANEL.LIST_PANEL.ANSWER"), menu.ListInbound(allPelan));
      },
      // button add pelan
      [ctx.i18n.t("PANEL.MENU_PANEL.ADD_PELAN")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ADD_PELAN;
        ctx.reply(i18n.t("PANEL.ADD_PELAN"), menu.BackPanelButton());
      },
      // button delete pelan
      [ctx.i18n.t("PANEL.MENU_PANEL.DELETE_PELAN")]: async ({ ctx, menu, i18n }) => {
        const allPelan = await selectAllPelan();
        if (allPelan.length < 1) return ctx.reply(i18n.t("PANEL.DELETE_PELAN.NONE"));
        ctx.session.state = STATE_LIST_ADMIN.DELETE_PELAN;
        ctx.reply(i18n.t("PANEL.DELETE_PELAN.ANSWER"), menu.AllPelanButton(allPelan));
      },
      // button delete pelan
      [ctx.i18n.t("PANEL.MENU_PANEL.EDIT_PELAN")]: async ({ ctx, menu, i18n }) => {
        const allPelan = await selectAllPelan();
        if (allPelan.length < 1) return ctx.reply(i18n.t("PANEL.EDIT_PELAN.NONE"));
        ctx.session.state = STATE_LIST_ADMIN.EDIT_PELAN;
        ctx.reply(i18n.t("PANEL.EDIT_PELAN.ANSWER"), menu.AllPelanButton(allPelan));
      },
      // button config custumize pelan
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_CUSTUMIZE")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_CUSTUMIZE;
        ctx.reply(i18n.t("PANEL.CONFIG_CUSTUMIZE"), menu.BackPanelButton());
      },
      // button config custumize && select pelan
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_CUSTUMIZE_SELECT")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_CUSTUMIZE_SELECT;
        ctx.reply(i18n.t("PANEL.CONFIG_CUSTUMIZE_SELECT"), menu.BackPanelButton());
      },
      // button config payg (pay as you go)
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_PAYG")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        await ctx.reply(i18n.t("PANEL.PAYG_TOGGLE.ANSWER"), menu.payg(setting.payg_enabled_multi, setting.payg_enabled_single));
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_PAYG;
        ctx.reply(
          i18n.t("PANEL.CONFIG_PAYG", {
            base: setting.payg_base_amount ?? 0,
            dailyMulti: setting.payg_daily_rate_multi ?? 0,
            dataMulti: setting.payg_data_rate_multi ?? 0,
            dailySingle: setting.payg_daily_rate_single ?? 0,
            dataSingle: setting.payg_data_rate_single ?? 0,
            mode: setting.payg_initial_mode ?? "fixed",
            traficc: setting.payg_initial_traffic ?? 0,
            day: setting.payg_initial_days ?? 0,
          }),
          menu.BackPanelButton()
        );
      },
      // button manage payg services list + usage graph
      [ctx.i18n.t("PANEL.MENU_PANEL.MANAGE_PAYG")]: async ({ ctx, menu }) => {
        const total = await CountPaygService();
        const items = await SelectAllPaygService({ offset: 0, limit: 5 });
        const hasNext = 5 < total;
        const text = items.length ? `📋 لیست سرویس‌های PAYG (${total} مورد)` : "❌ هیچ سرویس PAYG ثبت نشده است";
        ctx.reply(text, menu.paygList(items, 0, hasNext));
      },
      // button config NowPayments (crypto payment gateway)
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_NOWPAYMENTS")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        await ctx.reply(i18n.t("PANEL.NOWPAYMENTS_SETTING.TOGGLE_ANSWER"), menu.StatusNowPayments(setting.nowpayments_enabled));
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_NOWPAYMENTS;
        ctx.reply(
          i18n.t("PANEL.NOWPAYMENTS_SETTING.ANSWER", {
            apiKey: setting.nowpayments_api_key || "-",
            ipnSecret: setting.nowpayments_ipn_secret || "-",
            payCurrency: setting.nowpayments_pay_currency || "-",
            usdRate: setting.nowpayments_usd_rate ?? 0,
          }),
          menu.BackPanelButton()
        );
      },
      // button config refund (cancel & refund)
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_REFUND")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        await ctx.reply(i18n.t("PANEL.REFUND_SETTING.TOGGLE_ANSWER"), menu.StatusRefund(setting.refund_enabled));
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_REFUND;
        ctx.reply(i18n.t("PANEL.REFUND_SETTING.ANSWER", { hours: setting.refund_hours ?? 0 }), menu.BackPanelButton());
      },
      // button manage dynamic texts & buttons
      [ctx.i18n.t("PANEL.MENU_PANEL.MANAGE_TEXTS")]: async ({ ctx, menu, i18n }) => {
        const categories = getCategories();
        ctx.session.dynText = { categories: categories.map((c) => c.category) };
        ctx.reply(i18n.t("DYNTEXT.CATEGORIES.TITLE"), menu.DynTextCategories(categories));
      },
      // button manage reseller bots
      [ctx.i18n.t("PANEL.MENU_PANEL.MANAGE_RESELLERS")]: async ({ ctx, menu, i18n }) => {
        await renderResellerList({ ctx, i18n, menu, page: 0, edit: false });
        renderResellerPermissions({ ctx, i18n, menu });
      },
      // button config reseller minimum balance
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_RESELLER_BALANCE")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_RESELLER_BALANCE;
        ctx.reply(i18n.t("PANEL.RESELLER.ASK_BALANCE", { value: setting.reseller_min_balance }), menu.BackPanelButton());
      },
      // button config reseller setup fee
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_RESELLER_FEE")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        ctx.session.state = STATE_LIST_ADMIN.CONFIG_RESELLER_FEE;
        ctx.reply(i18n.t("PANEL.RESELLER.ASK_FEE", { value: setting.reseller_setup_fee }), menu.BackPanelButton());
      },
      // button config protocok
      [ctx.i18n.t("PANEL.MENU_PANEL.CONFIG_PROTOCOL")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        ctx.reply(i18n.t("PANEL.CONFIG_PROTOCOL"), menu.ProtoclButton(JSON.parse(setting.protocol)));
      },
      // button show pelan
      [ctx.i18n.t("PANEL.MENU_PANEL.SHOW_PELAN")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        ctx.reply(i18n.t("PANEL.SHOW_PELAN"), menu.PelanButton(JSON.parse(setting.showpelan)));
      },
      // change price
      [ctx.i18n.t("PANEL.MENU_PANEL.CHANGE_PRICE")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.CHANGE_PRICE;
        ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ANSWER"), menu.BackPanelButton());
      },
      // change price nemayandegi
      [ctx.i18n.t("PANEL.MENU_PANEL.CHANGE_PRICE_NEMAYADNEGI")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.CHANGE_PRICE_NEMAYADNEGI;
        ctx.reply(i18n.t("PANEL.CHANGE_PRICE_NEMAYADNEGI.ANSWER"), menu.BackPanelButton());
      },
      // button add upgrade
      [ctx.i18n.t("PANEL.MENU_PANEL.ADD_UPGRADE")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ADD_UPGRADE;
        ctx.reply(i18n.t("PANEL.UPGRADE.ADD"), menu.BackPanelButton());
      },
      // button delete upgrade
      [ctx.i18n.t("PANEL.MENU_PANEL.DELETE_UPGRADE")]: async ({ ctx, menu, i18n }) => {
        const Allupgrade = await selectAllUpgrade();
        if (Allupgrade < 1) return ctx.reply(i18n.t("PANEL.UPGRADE.NONE"));
        ctx.session.state = STATE_LIST_ADMIN.DELETE_UPGRADE;
        ctx.reply(i18n.t("PANEL.UPGRADE.ANSWER"), menu.AllPelanButton(Allupgrade));
      },
      // button add gift
      [ctx.i18n.t("PANEL.MENU_PANEL.ADD_GIFT")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ADD_GIFT;
        ctx.reply(i18n.t("PANEL.ADD_GIFT.ANSWER"), menu.BackPanelButton());
      },
      // button delete gift
      [ctx.i18n.t("PANEL.MENU_PANEL.DELETE_GIFT")]: async ({ ctx, menu, i18n }) => {
        const allPelan = await selectAllGift();
        if (allPelan.length < 1) return ctx.reply(i18n.t("PANEL.DELETE_GIFT.NONE"));
        ctx.session.state = STATE_LIST_ADMIN.DELETE_GIFT;
        ctx.reply(i18n.t("PANEL.DELETE_GIFT.ANSWER"), menu.AllPelanButton(allPelan, true));
      },
      // button show pay
      [ctx.i18n.t("PANEL.MENU_PANEL.SHOW_PAY")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        ctx.reply(i18n.t("PANEL.SHOW_PAY"), menu.PayButton(JSON.parse(setting.pay)));
      },
      // button add id card
      [ctx.i18n.t("PANEL.MENU_PANEL.SET_ID_CARD")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ADD_ID_CARD;
        ctx.reply(i18n.t("PANEL.SET_ID_CARD"), menu.BackPanelButton());
      },
      // button gift invite
      [ctx.i18n.t("PANEL.MENU_PANEL.GIFT_INVITE")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.GIFT_INVITE;
        ctx.reply(i18n.t("PANEL.GIFT_INVITE.ANSWER"), menu.BackPanelButton());
      },
      // button log buy
      [ctx.i18n.t("PANEL.MENU_PANEL.LOG_BUY")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.LOG_BUY;
        ctx.reply(i18n.t("PANEL.LOG_BUY"), menu.BackPanelButton());
      },
      // button message all
      [ctx.i18n.t("PANEL.MENU_PANEL.MESSAGE_ALL")]: ({ ctx, menu, i18n }) => {
        ctx.reply(i18n.t("PANEL.MESSAGE_ALL.SELECT"), menu.SellMonth(I18NK(ctx, "PANEL.MESSAGE_ALL.MENU"), "SENDMESSAGE_", 1));
      },
      // button forward all
      [ctx.i18n.t("PANEL.MENU_PANEL.FORWARD_ALL")]: ({ ctx, menu, i18n }) => {
        ctx.reply(i18n.t("PANEL.MESSAGE_ALL.SELECT"), menu.SellMonth(I18NK(ctx, "PANEL.MESSAGE_ALL.MENU"), "SENDFORWARD_", 1));
      },
      // button pin
      [ctx.i18n.t("PANEL.MENU_PANEL.PIN")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.PIN;
        ctx.reply(i18n.t("PANEL.PIN.ANSWER"), menu.BackPanelButton());
      },
      // button block
      [ctx.i18n.t("PANEL.MENU_PANEL.BLOCK")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.BLOCK;
        ctx.reply(i18n.t("PANEL.BLOCK.ANSWER"), menu.BackPanelButton());
      },
      // button unblock
      [ctx.i18n.t("PANEL.MENU_PANEL.UNBLOCK")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.UNBLOCK;
        ctx.reply(i18n.t("PANEL.UNBLOCK.ANSWER"), menu.BackPanelButton());
      },
      // button start gift
      [ctx.i18n.t("PANEL.MENU_PANEL.SET_GIFT_START")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.SET_GIFT_START;
        ctx.reply(i18n.t("PANEL.SET_GIFT_START"), menu.BackPanelButton());
      },
      // button sell month
      [ctx.i18n.t("PANEL.MENU_PANEL.SELL_MONTH")]: ({ ctx, menu, i18n }) => {
        ctx.reply(i18n.t("PANEL.SELL_MONTH.ANSWER"), menu.SellMonth(I18NK(ctx, "PANEL.SELL_MONTH.MENU")));
      },
      // button sell card
      [ctx.i18n.t("PANEL.MENU_PANEL.SELL_CARD")]: ({ ctx, menu, i18n }) => {
        ctx.reply(i18n.t("PANEL.SELL_MONTH.ANSWER"), menu.SellMonth(I18NK(ctx, "PANEL.SELL_MONTH.MENU"), "SELLCARD_"));
      },
      // button start gift
      [ctx.i18n.t("PANEL.MENU_PANEL.SET_PRICE_INBOUND")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.SET_PRICE_INBOUND;
        ctx.reply(i18n.t("PANEL.SET_PRICE_INBOUND"), menu.BackPanelButton());
      },
      // button traficc free
      [ctx.i18n.t("PANEL.MENU_PANEL.SET_TRAFIC_FREE")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.SET_TRAFIC_FREE;
        ctx.reply(i18n.t("PANEL.SET_TRAFIC_FREE"), menu.BackPanelButton());
      },
      // button check account
      [ctx.i18n.t("PANEL.MENU_PANEL.CHECK_ACCOUNT")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.CHECK_ACCOUNT;
        ctx.reply(i18n.t("PANEL.CHECK_ACCOUNT.ANSWER"), menu.BackPanelButton());
      },
      // button check servise
      [ctx.i18n.t("PANEL.MENU_PANEL.CHECK_SERVISE")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.CHECK_SERVISE;
        ctx.reply(i18n.t("PANEL.CHECK_SERVISE.ANSWER"), menu.BackPanelButton());
      },
      // button disable servise
      [ctx.i18n.t("PANEL.MENU_PANEL.DISABLE_ALL")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.DISABLE_ALL;
        ctx.reply(i18n.t("PANEL.DISABLE_ALL.ANSWER"), menu.BackPanelButton());
      },
      // button enable servise
      [ctx.i18n.t("PANEL.MENU_PANEL.ENABLE_ALL")]: ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ENABLE_ALL;
        ctx.reply(i18n.t("PANEL.ENABLE_ALL.ANSWER"), menu.BackPanelButton());
      },
      // buttons support
      [ctx.i18n.t("PANEL.MENU_PANEL.SABT_LINK")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.SABT_LINK;
        ctx.reply(i18n.t("PANEL.SABT_LINK.ANSWER"), menu.BackPanelButton());
      },
      // button check payment
      [ctx.i18n.t("PANEL.MENU_PANEL.SWITCH_DARGAH")]: async ({ ctx, menu, i18n }) => {
        const { default_pay, pay } = await SelectSetting();
        ctx.reply(i18n.t("PANEL.SWITCH_DARGAH.ANSWER"), menu.switchDargah(JSON.parse(pay), default_pay));
      },
      // button switch card to card gateway
      [ctx.i18n.t("PANEL.MENU_PANEL.SWITCH_DARGAH_CARD")]: async ({ ctx, menu, i18n }) => {
        const { default_pay_card, pay } = await SelectSetting();
        ctx.reply(i18n.t("PANEL.SWITCH_DARGAH_CARD.ANSWER"), menu.switchDargah(JSON.parse(pay), default_pay_card, "SWITCHDARGAHCARD_"));
      },
      // button check payment
      [ctx.i18n.t("PANEL.MENU_PANEL.FIRST_PAYMENT")]: async ({ ctx, menu, i18n }) => {
        const { first_payment } = await SelectSetting();
        ctx.reply(i18n.t("PANEL.FIRST_PAYMENT.ANSWER"), menu.StatusCrypto(first_payment));
      },
      // button add inbound mz
      [ctx.i18n.t("PANEL.MENU_PANEL.ADD_INBOUND_MZ")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST_ADMIN.ADD_INBOUND_MZ;
        ctx.reply(i18n.t("PANEL.ADD_INBOUND_MZ.ANSWER"), menu.BackPanelButton());
      },
      // button list inbound mz
      [ctx.i18n.t("PANEL.MENU_PANEL.LIST_PANEL_MZ")]: async ({ ctx, menu, i18n }) => {
        const allPelan = await selectAllInboundMz();
        if (allPelan.length < 1) return ctx.reply(i18n.t("PANEL.LIST_PANEL_MZ.NONE"));
        ctx.reply(i18n.t("PANEL.LIST_PANEL.ANSWER"), menu.ListInboundMz(I18NK(ctx, "PANEL.LIST_PANEL_MZ.MENUS"), allPelan));
      },
    };

    const menu = new PanelButtons(ctx);
    return EventListener[text]({ ctx, i18n: ctx.i18n, menu });
  } else {
    return true;
  }
};
