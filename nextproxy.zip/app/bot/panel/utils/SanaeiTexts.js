// Texts of the "add server" panel type selection (Sanaei <= 2.6.6 / Sanaei New Versions)
const SANAEI_TEXTS = {
  SELECT_TYPE: "❓ لطفا نوع پنل سرور را انتخاب کنید :",
  BUTTON_OLD: "Sanaei <= 2.6.6",
  BUTTON_NEW: "Sanaei New Versions",
  ADD_NEW_ANSWER:
    "❓ (Sanaei New Versions)\n\nلطفا در خط اول دامین مورد نظر (همراه با پورت و مسیر پنل)\nدر خط دوم یوزرنیم ورود \nدر خط سوم پسوورد ورود\nدر خط چهارم نام لوکیشن\nو در خط پنجم ادرس host\nدر خط ششم ادرس لینک داخلی\nدر خط هفتم آدرس لینک مستقیم\nو در خط هشتم بازه پورت رو که با , از هم جدا شدند را وارد کنید(1000,2000)\nدر خط نهم اقتصادی بودن یا معمولی بودن پنل را وارد کنید (normal/economic)\nدر خط دهم اگر سرور vip است قیمت ان را به تومان و عدد وارد کنید و در غیر صورت این خط را خالی بزارید",
};

export { SANAEI_TEXTS };
