import { PanelButtons } from "./buttons/ButtonsPanel.js";
// actions
import Protocol from "./actions/protocol.js";
import Pelan from "./actions/pelan.js";
import Price from "./actions/price.js";
import Inbound from "./actions/inbound.js";
import InboundSanaeiNew from "./actions/inbound_sanaei_new.js";
import SellMonth from "./actions/sellMonth.js";
import Agent from "./actions/agent.js";
import Dargah from "./actions/dargah.js";
import Crypto from "./actions/crypto.js";
import Inbound_Mz from "./actions/inbound_mz.js";
import SendAll from "./actions/sendall.js";
import Payg from "./actions/payg.js";
import DynText from "./actions/dyntext.js";
import Reseller from "./actions/reseller.js";

const ActionMap = {
  // price
  ACCEPTRESID: /^ACCEPTRESID_\w+/,
  APPROVERESID: /^APPROVERESID_\w+/,
  SHOWPAY: /^SHOWPAY_\w+/,
  // sell month
  SELLMONTH: /^SELLMONTH_\w+/,
  SELLCARD: /^SELLCARD_\w+/,
  // inbound
  CHENGESTATUSINBOUND: /^CHENGESTATUSINBOUND_\w+/,
  EDITINBOUND: /^EDITINBOUND_\w+/,
  DELETEINBOUND: /^DELETEINBOUND_\w+/,
  // select panel type of a new inbound (must stay ABOVE CHANGESHOWPELAN)
  ADDINBOUNDTYPE: /^ADDINBOUNDTYPE_\w+/,
  // agent
  CHENGEAGENT: /^CHENGEAGENT_\w+/,
  // protocol
  CHANGEPROTOCOL: /^CHANGEPROTOCOL-\w+/,
  // dargah
  SWITCHDARGAH: /^SWITCHDARGAH_\w+/,
  SWITCHDARGAHCARD: /^SWITCHDARGAHCARD_\w+/,
  PAYGTOGGLE: /^PAYGTOGGLE_\w+/,
  PAYGLIST: /^PAYGLIST_\w+/,
  PAYGVIEW: /^PAYGVIEW_\w+/,
  PAYGCOST: /^PAYGCOST_\w+/,
  PAYGADMINTOGGLE: /^PAYGADMINTOGGLE_\w+/,
  PAYGADMINDELETE: /^PAYGADMINDELETE_\w+/,
  PAYGGRAPH: /^PAYGGRAPH_\w+/,
  CHANCHESTATUSCRYPTO: "CHANCHESTATUSCRYPTO",
  CHANGESTATUSNOWPAY: "CHANGESTATUSNOWPAY",
  CHANGESTATUSREFUND: "CHANGESTATUSREFUND",
  // inbound mz
  CHENGETAGINBOUND: /^CHENGETAGINBOUND_\w+/,
  DELETEINBOUND: /^DELETEINBOUND_\w+/,
  // sendall
  SENDMESSAGE: /^SENDMESSAGE_\w+/,
  SENDFORWARD: /^SENDFORWARD_\w+/,
  // dynamic text & button management
  // NOTE: these must stay ABOVE CHANGESHOWPELAN below - its regex
  // (/^CHANGESHOWPELAN|\w+/) unintentionally matches almost any callback
  // data, so anything placed after it in this object never gets reached.
  DYNTEXTCAT: /^DYNTEXTCAT_\d+/,
  DYNTEXTPAGE: /^DYNTEXTPAGE_\d+/,
  DYNTEXTKEY: /^DYNTEXTKEY_\d+/,
  DYNTEXTEDIT: "DYNTEXTEDIT",
  DYNTEXTRESET: "DYNTEXTRESET",
  DYNTEXTBACKCATS: "DYNTEXTBACKCATS",
  DYNTEXTBACKKEYS: "DYNTEXTBACKKEYS",
  // reseller bot management (must also stay above CHANGESHOWPELAN)
  RESELLERLIST: /^RESELLERLIST_\d+/,
  RESELLERVIEW: /^RESELLERVIEW_\d+/,
  RESELLERSUSPEND: /^RESELLERSUSPEND_\d+/,
  RESELLERACTIVATE: /^RESELLERACTIVATE_\d+/,
  RESELLERDELETEASK: /^RESELLERDELETEASK_\d+/,
  RESELLERDELETE: /^RESELLERDELETE_\d+/,
  // reseller control hub (inline): Reseller Bot Features + Reseller Admin Permissions
  RESELLERHUB: /^RESELLERHUB$/,
  RESELLERFEATS: /^RESELLERFEATS$/,
  RESELLERFGRP: /^RESELLERFGRP_\w+/,
  RESELLERPERM: /^RESELLERPERM_\w+/,
  RESELLERFSET: /^RESELLERFSET_\w+/,
  RESELLERFALL: /^RESELLERFALL_\w+/,
  RESELLERADMS: /^RESELLERADMS$/,
  RESELLERAGRP: /^RESELLERAGRP_\w+/,
  RESELLERAPERM: /^RESELLERAPERM_\w+/,
  RESELLERASET: /^RESELLERASET_\w+/,
  RESELLERAALL: /^RESELLERAALL_\w+/,
  // pelan
  CHANGESHOWPELAN: /^CHANGESHOWPELAN|\w+/,
};

export default async (ctx) => {
  const callback_data = ctx.update.callback_query.data;
  const actionValues = Object.values(ActionMap);
  for (let index = 0; index < actionValues.length; index++) {
    const isMatch = callback_data.match(actionValues[index]);
    if (isMatch && EventListener[Object.keys(ActionMap)[index]]) {
      const menu = new PanelButtons(ctx);
      return EventListener[Object.keys(ActionMap)[index]]({ ctx, isMatch, i18n: ctx.i18n, menu });
    }
  }
};

const EventListener = {
  // Action protocol
  ...Protocol,
  // Action pelan
  ...Pelan,
  // Action price
  ...Price,
  // Action inbound
  ...Inbound,
  // Action inbound (sanaei new versions)
  ...InboundSanaeiNew,
  // Action sell month
  ...SellMonth,
  // Action Agent
  ...Agent,
  // Action Dargah
  ...Dargah,
  // Action Payg
  ...Payg,
  // Action Crypto
  ...Crypto,
  // Action Inbound Mz
  ...Inbound_Mz,
  // Action SendAll
  ...SendAll,
  // Action Dynamic Text & Button Management
  ...DynText,
  // Action Reseller Bot Management
  ...Reseller,
};
