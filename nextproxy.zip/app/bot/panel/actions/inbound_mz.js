import { selectAllInboundMz, DestoryInboundMz } from "../../../controllers/InboundMz.js";
import { I18NK } from "../../utils/I18n.js";
import { STATE_LIST_ADMIN } from "../sessions/state.js";

const Inbound_Mz = {
  // change tag inbound
  CHENGETAGINBOUND: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    ctx.session.id_inbound = id;
    ctx.session.state = STATE_LIST_ADMIN.CHANGE_TAG_INBOUND_MZ;
    ctx.reply(i18n.t("PANEL.ADD_INBOUND_MZ.EDIT_TAG"), menu.BackPanelButton());
  },
  // delete inbound
  DELETEINBOUND: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    DestoryInboundMz({ id });
    await ctx.answerCbQuery(i18n.t("PANEL.LIST_PANEL_MZ.DELETE"));
    const allPelan = await selectAllInboundMz();
    if (allPelan.length < 1) return ctx.editMessageText(i18n.t("PANEL.LIST_PANEL_MZ.NONE"));
    ctx.editMessageText(i18n.t("PANEL.LIST_PANEL_MZ.ANSWER"), menu.ListInboundMz(I18NK(ctx, "PANEL.LIST_PANEL_MZ.MENUS"), allPelan));
  },
};

export default Inbound_Mz;
