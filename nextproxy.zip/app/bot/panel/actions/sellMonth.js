import momentJalaali from "moment-jalaali";
import { SelectAllPeyment } from "../../../controllers/Peyment.js";
import { selectUser } from "../../../controllers/Users.js";
import CreatePdf from "../../pdf/index.js";
import { Input } from "telegraf";
import fs from "fs";
import CreateExcel from "../../excel/index.js";
import { SelectAllCard } from "../../../controllers/Card.js";

const SellMonth = {
  // change show name
  SELLMONTH: async ({ ctx, i18n, menu, isMatch, card }) => {
    const type = isMatch[0].split("_")[1];
    await ctx.reply(i18n.t("PARDAZESH"));
    // create data
    const get = card ? await SelectAllCard() : await SelectAllPeyment();
    const data = [];
    for (const item of get) {
      const user = await selectUser({ id: item.telegram_id || item.chat_id });
      if (user) {
        const newItemArray = [
          item.id,
          user.phone,
          item.telegram_id || item.chat_id,
          item.price || item.amount,
          momentJalaali(item.updatedAt).format("jYYYY/jM/jD HH:mm:ss"),
        ];
        data.push(newItemArray);
      }
    }
    // get type
    if (type == "PDF") {
      var fileName = await CreatePdf(data);
    } else {
      var fileName = await CreateExcel(data);
    }
    // send
    await ctx.sendDocument(Input.fromLocalFile(fileName), {
      caption: !card ? i18n.t("PANEL.SELL_MONTH.CAPTION") : i18n.t("PANEL.SELL_CARD"),
      ...menu.PanelMenuButtons(),
    });
    // delete
    fs.unlinkSync(fileName);
  },
  // for action sell card
  SELLCARD: async ({ ctx, i18n, menu, isMatch }) => {
    return SellMonth.SELLMONTH({ ctx, i18n, menu, isMatch, card: true });
  },
};

export default SellMonth;
