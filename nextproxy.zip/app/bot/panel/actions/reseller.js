import { SelectAllResellers, SelectReseller, CountResellers, UpdateReseller, DeleteReseller } from "../../../controllers/Reseller.js";
import { CountResellerSales, SumResellerSales } from "../../../controllers/ResellerSale.js";
import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";
import { selectUser } from "../../../controllers/Users.js";
import { stopResellerBot, launchResellerBot, destroyReseller, isInstanceRunning } from "../../reseller/ResellerManager.js";
import { NumberFormat } from "../../utils/utils.js";
import {
  RESELLER_FEATURE_GROUPS,
  RESELLER_PERMISSION_DEFS,
  RESELLER_PERMISSION_KEYS,
  RESELLER_ADMIN_GROUPS,
  RESELLER_ADMIN_PERMISSION_DEFS,
  RESELLER_ADMIN_PERMISSION_KEYS,
  parseResellerPermissions,
  parseResellerAdminPermissions,
} from "../../../utils/resellerPermissions.js";

const PAGE_SIZE = 8;

const renderResellerList = async ({ ctx, i18n, menu, page = 0, edit = true }) => {
  const count = await CountResellers();
  const resellers = await SelectAllResellers({ offset: page * PAGE_SIZE, limit: PAGE_SIZE });
  const text = count ? i18n.t("PANEL.RESELLER.LIST_TITLE", { count }) : i18n.t("PANEL.RESELLER.LIST_EMPTY");
  const markup = menu.ResellerList(resellers, page, (page + 1) * PAGE_SIZE < count);
  if (edit) return ctx.editMessageText(text, markup);
  return ctx.reply(text, markup);
};

const renderDetail = async ({ ctx, i18n, menu, id }) => {
  const reseller = await SelectReseller({ id });
  if (!reseller) return renderResellerList({ ctx, i18n, menu, page: 0 });
  const sales = await CountResellerSales({ reseller_id: id });
  const total = await SumResellerSales({ reseller_id: id });
  const owner = await selectUser({ id: reseller.owner_id });
  const text =
    i18n.t("PANEL.RESELLER.DETAIL", {
      username: reseller.bot_username || "-",
      owner: reseller.owner_id,
      status: reseller.status === "active" ? "🟢 فعال" : "🔴 مسدود",
      sales,
      total: NumberFormat(total),
    }) +
    `\n💳 اعتبار فعلی: ${NumberFormat(owner?.price ?? 0)} تومان` +
    `\n🖥 نمونه ایزوله: ${isInstanceRunning(reseller.id) ? "🟢 در حال اجرا" : "🔴 متوقف"} (${reseller.deploy_status})` +
    (reseller.last_error ? `\n⚠️ آخرین خطا: ${String(reseller.last_error).slice(0, 120)}` : "");
  return ctx.editMessageText(text, { ...menu.ResellerDetail(reseller.id, reseller.status), parse_mode: "html" });
};

// ============================================================================
// Reseller control hub - everything below is INLINE keyboards (glass buttons).
//
// Two master matrices live in the `setting` table:
//   reseller_permissions        -> "Reseller Bot Features"
//   reseller_admin_permissions  -> "Reseller Admin Permissions"
// Saving either one changes the `setting` table; the global sync hook then
// pushes the new matrices to every running reseller bot instantly.
// ============================================================================

const FEATURE_GROUP_KEYS = RESELLER_FEATURE_GROUPS.map((group) => group.key);
const ADMIN_GROUP_KEYS = RESELLER_ADMIN_GROUPS.map((group) => group.key);

const safeParse = (raw) => {
  try {
    const parsed = JSON.parse(raw || "{}");
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (error) {
    return {};
  }
};

const loadMatrices = async () => {
  const setting = await SelectSetting();
  return {
    features: parseResellerPermissions(setting.reseller_permissions),
    admin: parseResellerAdminPermissions(setting.reseller_admin_permissions),
    storedFeatures: safeParse(setting.reseller_permissions),
  };
};

// keeps unknown/legacy keys that are already stored, only overwrites known ones
const saveFeatures = (storedFeatures, features) => UpdateSetting({ reseller_permissions: JSON.stringify({ ...storedFeatures, ...features }) });
const saveAdmin = (admin) => UpdateSetting({ reseller_admin_permissions: JSON.stringify(admin) });

const countOn = (defs, perms) => defs.filter((def) => perms[def.key]).length;

// Telegram rejects an edit that changes nothing ("message is not modified") - that is not an error for us
const safeEdit = async (ctx, text, markup) => {
  try {
    await ctx.editMessageText(text, markup);
  } catch (error) {
    const message = String(error?.description || error?.message || "");
    if (!/message is not modified/i.test(message)) throw error;
  }
};

const send = ({ ctx, edit, text, markup }) => (edit ? safeEdit(ctx, text, markup) : ctx.reply(text, markup));

const renderResellerHub = async ({ ctx, menu, edit = true }) => {
  const { features, admin } = await loadMatrices();
  const resellerCount = await CountResellers();
  const featureTotal = RESELLER_PERMISSION_DEFS.length;
  const adminTotal = RESELLER_ADMIN_PERMISSION_DEFS.length;
  const featureOn = countOn(RESELLER_PERMISSION_DEFS, features);
  const adminOn = countOn(RESELLER_ADMIN_PERMISSION_DEFS, admin);
  const text =
    "🔐 مرکز کنترل ربات‌های نمایندگی\n\n" +
    `🧩 قابلیت‌های ربات نماینده: ${featureOn} از ${featureTotal} فعال\n` +
    `🛡 دسترسی‌های ادمین نماینده: ${adminOn} از ${adminTotal} مجاز\n\n` +
    "👇 یک بخش را انتخاب کنید. هر تغییر بلافاصله برای همه ربات‌های نمایندگی اعمال می‌شود.";
  return send({ ctx, edit, text, markup: menu.ResellerHub({ resellerCount, featureOn, featureTotal, adminOn, adminTotal }) });
};

const renderFeatureGroups = async ({ ctx, menu, edit = true }) => {
  const { features } = await loadMatrices();
  const text =
    "🧩 قابلیت‌های ربات نماینده\n\n" +
    `${countOn(RESELLER_PERMISSION_DEFS, features)} از ${RESELLER_PERMISSION_DEFS.length} قابلیت فعال است.\n\n` +
    "👇 یک دسته را انتخاب کنید تا تک‌تک قابلیت‌های ربات اصلی را برای نمایندگان روشن یا خاموش کنید.";
  return send({ ctx, edit, text, markup: menu.ResellerPermissions(features) });
};

const renderFeatureGroup = async ({ ctx, menu, groupKey }) => {
  const group = RESELLER_FEATURE_GROUPS.find((item) => item.key === groupKey);
  if (!group) return renderFeatureGroups({ ctx, menu });
  const { features } = await loadMatrices();
  const list = RESELLER_PERMISSION_DEFS.filter((def) => def.group === groupKey);
  const text = `🧩 ${group.title}\n${countOn(list, features)} از ${list.length} فعال\n\n👇 با لمس هر مورد، وضعیت آن برای همه نمایندگان تغییر می‌کند.`;
  return safeEdit(ctx, text, menu.ResellerFeatureGroup(groupKey, features));
};

const renderAdminGroups = async ({ ctx, menu, edit = true }) => {
  const { admin } = await loadMatrices();
  const text =
    "🛡 دسترسی‌های ادمین نماینده\n\n" +
    `${countOn(RESELLER_ADMIN_PERMISSION_DEFS, admin)} از ${RESELLER_ADMIN_PERMISSION_DEFS.length} منو/تنظیم برای ادمین نماینده مجاز است.\n\n` +
    "👇 یک دسته را انتخاب کنید تا مشخص کنید ادمین ربات نماینده به کدام منوها و تنظیمات پنل خودش دسترسی داشته باشد.";
  return send({ ctx, edit, text, markup: menu.ResellerAdminPermissions(admin) });
};

const renderAdminGroup = async ({ ctx, menu, groupKey }) => {
  const group = RESELLER_ADMIN_GROUPS.find((item) => item.key === groupKey);
  if (!group) return renderAdminGroups({ ctx, menu });
  const { admin } = await loadMatrices();
  const list = RESELLER_ADMIN_PERMISSION_DEFS.filter((def) => def.group === groupKey);
  const text = `🛡 ${group.title}\n${countOn(list, admin)} از ${list.length} مجاز\n\n👇 ✅ یعنی ادمین نماینده به این بخش دسترسی دارد، ❌ یعنی از پنل او حذف می‌شود.`;
  return safeEdit(ctx, text, menu.ResellerAdminGroup(groupKey, admin));
};

// kept under the old name: the reply-keyboard entry "Manage resellers" calls it
// right after the reseller list, it now opens the inline control hub
const renderResellerPermissions = ({ ctx, i18n, menu, edit = false }) => renderResellerHub({ ctx, menu, edit });

const Reseller = {
  RESELLERLIST: async ({ ctx, i18n, menu, isMatch }) => {
    const page = Number(isMatch[0].split("_")[1] || 0);
    renderResellerList({ ctx, i18n, menu, page });
  },
  RESELLERVIEW: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    renderDetail({ ctx, i18n, menu, id });
  },
  RESELLERSUSPEND: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    await UpdateReseller({ id }, { status: "suspended" });
    await stopResellerBot(Number(id));
    await ctx.answerCbQuery(i18n.t("PANEL.RESELLER.SUSPENDED"), { show_alert: true });
    renderDetail({ ctx, i18n, menu, id });
  },
  RESELLERACTIVATE: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    await UpdateReseller({ id }, { status: "active" });
    const reseller = await SelectReseller({ id });
    await launchResellerBot(reseller).catch(() => {});
    await ctx.answerCbQuery(i18n.t("PANEL.RESELLER.ACTIVATED"), { show_alert: true });
    renderDetail({ ctx, i18n, menu, id });
  },
  RESELLERDELETEASK: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    await ctx.editMessageText(i18n.t("PANEL.RESELLER.DELETE_CONFIRM"), menu.ResellerDeleteConfirm(id));
  },
  // removes the instance completely: process, code folder and its database
  RESELLERDELETE: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    await destroyReseller(Number(id));
    await DeleteReseller({ id });
    await ctx.answerCbQuery(i18n.t("PANEL.RESELLER.DELETED"), { show_alert: true });
    renderResellerList({ ctx, i18n, menu, page: 0 });
  },
  // ---------------------------------------------------------------- hub ---
  RESELLERHUB: async ({ ctx, menu }) => {
    await ctx.answerCbQuery();
    renderResellerHub({ ctx, menu });
  },

  // ------------------------------------------- Reseller Bot Features ---
  RESELLERFEATS: async ({ ctx, menu }) => {
    await ctx.answerCbQuery();
    renderFeatureGroups({ ctx, menu });
  },
  RESELLERFGRP: async ({ ctx, menu, isMatch }) => {
    const groupKey = isMatch[0].split("_")[1];
    if (!FEATURE_GROUP_KEYS.includes(groupKey)) return ctx.answerCbQuery();
    await ctx.answerCbQuery();
    renderFeatureGroup({ ctx, menu, groupKey });
  },
  // toggles one feature (validated against the canonical list) and re-renders its category
  RESELLERPERM: async ({ ctx, menu, isMatch }) => {
    const key = isMatch[0].replace("RESELLERPERM_", "");
    if (!RESELLER_PERMISSION_KEYS.includes(key)) return ctx.answerCbQuery();
    const { features, storedFeatures } = await loadMatrices();
    features[key] = !features[key];
    await saveFeatures(storedFeatures, features);
    await ctx.answerCbQuery("✅ برای همه نمایندگان اعمال شد");
    const def = RESELLER_PERMISSION_DEFS.find((item) => item.key === key);
    renderFeatureGroup({ ctx, menu, groupKey: def.group });
  },
  // enable / disable every feature of one category
  RESELLERFSET: async ({ ctx, menu, isMatch }) => {
    const [, groupKey, mode] = isMatch[0].split("_");
    if (!FEATURE_GROUP_KEYS.includes(groupKey) || !["on", "off"].includes(mode)) return ctx.answerCbQuery();
    const { features, storedFeatures } = await loadMatrices();
    for (const def of RESELLER_PERMISSION_DEFS) if (def.group === groupKey) features[def.key] = mode === "on";
    await saveFeatures(storedFeatures, features);
    await ctx.answerCbQuery("✅ برای همه نمایندگان اعمال شد");
    renderFeatureGroup({ ctx, menu, groupKey });
  },
  // enable / disable every feature
  RESELLERFALL: async ({ ctx, menu, isMatch }) => {
    const mode = isMatch[0].split("_")[1];
    if (!["on", "off"].includes(mode)) return ctx.answerCbQuery();
    const { features, storedFeatures } = await loadMatrices();
    for (const key of RESELLER_PERMISSION_KEYS) features[key] = mode === "on";
    await saveFeatures(storedFeatures, features);
    await ctx.answerCbQuery("✅ برای همه نمایندگان اعمال شد");
    renderFeatureGroups({ ctx, menu });
  },

  // --------------------------------------- Reseller Admin Permissions ---
  RESELLERADMS: async ({ ctx, menu }) => {
    await ctx.answerCbQuery();
    renderAdminGroups({ ctx, menu });
  },
  RESELLERAGRP: async ({ ctx, menu, isMatch }) => {
    const groupKey = isMatch[0].split("_")[1];
    if (!ADMIN_GROUP_KEYS.includes(groupKey)) return ctx.answerCbQuery();
    await ctx.answerCbQuery();
    renderAdminGroup({ ctx, menu, groupKey });
  },
  // toggles one admin-panel permission and re-renders its category
  RESELLERAPERM: async ({ ctx, menu, isMatch }) => {
    const key = isMatch[0].replace("RESELLERAPERM_", "");
    if (!RESELLER_ADMIN_PERMISSION_KEYS.includes(key)) return ctx.answerCbQuery();
    const { admin } = await loadMatrices();
    admin[key] = !admin[key];
    await saveAdmin(admin);
    await ctx.answerCbQuery("✅ برای پنل همه نمایندگان اعمال شد");
    const def = RESELLER_ADMIN_PERMISSION_DEFS.find((item) => item.key === key);
    renderAdminGroup({ ctx, menu, groupKey: def.group });
  },
  // allow / restrict every admin-panel permission of one category
  RESELLERASET: async ({ ctx, menu, isMatch }) => {
    const [, groupKey, mode] = isMatch[0].split("_");
    if (!ADMIN_GROUP_KEYS.includes(groupKey) || !["on", "off"].includes(mode)) return ctx.answerCbQuery();
    const { admin } = await loadMatrices();
    for (const def of RESELLER_ADMIN_PERMISSION_DEFS) if (def.group === groupKey) admin[def.key] = mode === "on";
    await saveAdmin(admin);
    await ctx.answerCbQuery("✅ برای پنل همه نمایندگان اعمال شد");
    renderAdminGroup({ ctx, menu, groupKey });
  },
  // allow / restrict every admin-panel permission
  RESELLERAALL: async ({ ctx, menu, isMatch }) => {
    const mode = isMatch[0].split("_")[1];
    if (!["on", "off"].includes(mode)) return ctx.answerCbQuery();
    const { admin } = await loadMatrices();
    for (const key of RESELLER_ADMIN_PERMISSION_KEYS) admin[key] = mode === "on";
    await saveAdmin(admin);
    await ctx.answerCbQuery("✅ برای پنل همه نمایندگان اعمال شد");
    renderAdminGroups({ ctx, menu });
  },
};

export default Reseller;
export { renderResellerList, renderResellerHub, renderResellerPermissions };
