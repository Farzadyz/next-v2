import { STATE_LIST_ADMIN } from "../sessions/state.js";

const Agent = {
  // add inbound
  CHENGEAGENT: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    ctx.session.state = STATE_LIST_ADMIN.EDIT_AGENT;
    ctx.session.id_agent = id;
    ctx.reply(i18n.t("PANEL.LIST_AGENT.EDIT", { id }), menu.BackPanelButton());
  },
};

export default Agent;
