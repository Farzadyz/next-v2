import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";
import {
  SelectAllPaygService,
  CountPaygService,
  SelectPaygService,
  UpdatePaygService,
  DeletePaygServiceRow,
} from "../../../controllers/PaygService.js";
import { SelectPaygUsageLogs } from "../../../controllers/PaygUsageLog.js";
import { SelectPaygCostLogs, CountPaygCostLogs, SumPaygCostLogsByType } from "../../../controllers/PaygCostLog.js";
import { selectUser } from "../../../controllers/Users.js";
import ServiseModel from "../../model/servise.js";
import momentJalali from "moment-jalaali";
import moment from "moment-timezone";

const PAGE_SIZE = 5;
const COST_PAGE_SIZE = 10;

// تاریخ/ساعت شمسی به وقت تهران
const fmtDate = (value) =>
  momentJalali(moment.tz(value, "Asia/Tehran").format("YYYY-MM-DD HH:mm:ss"), "YYYY-MM-DD HH:mm:ss").format("jYYYY/jMM/jDD HH:mm");
const fmtTime = (value) => moment.tz(value, "Asia/Tehran").format("HH:mm");
// عدد دقیق (بدون گرد کردن به ۳ رقم معنی‌دار)
const fmt = (value) => Math.round(Number(value) || 0).toLocaleString("en-US");
const fmtBytes = (bytes) => {
  const value = Number(bytes) || 0;
  if (value >= 1073741824) return (value / 1073741824).toFixed(3) + " گیگابایت";
  return (value / 1048576).toFixed(2) + " مگابایت";
};

const COST_TYPES = {
  creation: "🆕 هزینه ایجاد سرویس",
  daily: "📅 هزینه ثابت روزانه",
  data: "📡 هزینه مصرف داده",
};

const Payg = {
  // فعال/غیرفعال کردن PAYG برای مولتی لوکیشن یا تک لوکیشن
  PAYGTOGGLE: async ({ ctx, menu, isMatch }) => {
    const type = isMatch[0].split("_")[1];
    const field = type == "multi" ? "payg_enabled_multi" : "payg_enabled_single";
    const setting = await SelectSetting();
    await UpdateSetting({ [field]: !setting[field] });
    const updated = await SelectSetting();
    ctx.editMessageReplyMarkup(menu.payg(updated.payg_enabled_multi, updated.payg_enabled_single).reply_markup);
  },
  // لیست صفحه‌بندی‌شده سرویس‌های PAYG
  PAYGLIST: async ({ ctx, menu, isMatch }) => {
    const page = Number(isMatch[0].split("_")[1] || 0);
    const total = await CountPaygService();
    const items = await SelectAllPaygService({ offset: page * PAGE_SIZE, limit: PAGE_SIZE });
    const hasNext = (page + 1) * PAGE_SIZE < total;
    const text = items.length ? `📋 لیست سرویس‌های PAYG (${total} مورد)` : "❌ هیچ سرویس PAYG ثبت نشده است";
    if (ctx.updateType === "callback_query") {
      return ctx.editMessageText(text, menu.paygList(items, page, hasNext));
    }
    ctx.reply(text, menu.paygList(items, page, hasNext));
  },
  // نمایش جزئیات یک سرویس PAYG
  PAYGVIEW: async ({ ctx, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const item = await SelectPaygService({ id });
    if (!item) return ctx.answerCbQuery("❌ یافت نشد", { show_alert: true });
    const user = await selectUser({ id: item.telegram_id });
    const sums = await SumPaygCostLogsByType({ payg_service_id: item.id });
    const totalDeducted = sums.reduce((sum, row) => sum + row.total, 0);
    const text =
      `⚡️ سرویس PAYG #${item.id}\n\n` +
      `🔹 آیدی سرویس : ${item.service_id}\n` +
      `👤 کاربر : ${item.telegram_id}\n` +
      `💰 موجودی فعلی کیف پول : ${user ? user.price : "نامشخص"} تومان\n` +
      `📦 حجم اولیه : ${item.initial_traffic} گیگابایت\n` +
      `📅 روز اولیه : ${item.initial_days} روز\n` +
      `💸 مجموع هزینه‌های کسر شده : ${fmt(totalDeducted)} تومان\n` +
      `📡 وضعیت : ${item.suspended_at ? "⛔️ تعلیق‌شده" : "✅ فعال"}\n` +
      (item.suspended_at ? `⏱ زمان تعلیق : ${item.suspended_at}\n` : "");
    ctx.editMessageText(text, menu.paygDetail(item));
  },
  // لاگ دقیق کسر هزینه‌های یک سرویس PAYG (هزینه ایجاد، هزینه روزانه، هزینه مصرف داده) - صفحه‌بندی‌شده، جدیدترین اول
  PAYGCOST: async ({ ctx, menu, isMatch }) => {
    const [, id, pageRaw] = isMatch[0].split("_");
    const page = Math.max(0, Number(pageRaw || 0));
    const item = await SelectPaygService({ id });
    if (!item) return ctx.answerCbQuery("❌ یافت نشد", { show_alert: true });

    const total = await CountPaygCostLogs({ payg_service_id: item.id });
    if (!total) return ctx.answerCbQuery("⚠️ هنوز هیچ کسر هزینه‌ای برای این سرویس ثبت نشده", { show_alert: true });

    const rows = await SelectPaygCostLogs({ payg_service_id: item.id, offset: page * COST_PAGE_SIZE, limit: COST_PAGE_SIZE });
    const sums = await SumPaygCostLogsByType({ payg_service_id: item.id });
    const byType = Object.fromEntries(sums.map((row) => [row.type, row]));
    const grandTotal = sums.reduce((sum, row) => sum + row.total, 0);
    const pages = Math.max(1, Math.ceil(total / COST_PAGE_SIZE));

    let text =
      `🧾 لاگ کسر هزینه‌های سرویس PAYG #${item.id}\n` +
      `🔹 آیدی سرویس : ${item.service_id}\n` +
      `👤 کاربر : ${item.telegram_id}\n\n` +
      `📊 جمع کل کسرها به تفکیک نوع\n` +
      `${COST_TYPES.creation} : ${fmt(byType.creation?.total)} تومان\n` +
      `${COST_TYPES.daily} : ${fmt(byType.daily?.total)} تومان (${fmt(byType.daily?.count)} روز)\n` +
      `${COST_TYPES.data} : ${fmt(byType.data?.total)} تومان (${fmtBytes(byType.data?.bytes)})\n` +
      `💸 مجموع کل : ${fmt(grandTotal)} تومان\n\n` +
      `📜 تاریخچه کسرها - صفحه ${page + 1} از ${pages} (جدیدترین اول)\n`;

    for (const row of rows) {
      const start = new Date(row.createdAt).getTime();
      const end = new Date(row.updatedAt).getTime();
      // ردیف مصرف داده که چند کسر پشت‌سرهم در آن جمع شده، بازه زمانی دارد
      const when = end - start > 60000 ? `${fmtDate(row.createdAt)} تا ${fmtTime(row.updatedAt)}` : fmtDate(row.createdAt);
      text += `\n#${row.id} • ${when}\n${COST_TYPES[row.type] || row.type} : ${fmt(row.amount)} تومان`;
      if (row.requested > row.amount) text += ` (از ${fmt(row.requested)} تومان - موجودی ناکافی)`;
      if (row.type === "data") text += `\n   📦 حجم صورتحساب‌شده : ${fmtBytes(row.traffic_bytes)}`;
      if (row.balance_after !== null) text += `\n   💼 موجودی بعد از کسر : ${fmt(row.balance_after)} تومان`;
      text += "\n";
    }

    await ctx.answerCbQuery();
    const hasNext = (page + 1) * COST_PAGE_SIZE < total;
    ctx.editMessageText(text, menu.paygCostLog(item, page, hasNext));
  },
  // تعلیق/فعال‌سازی دستی توسط ادمین
  PAYGADMINTOGGLE: async ({ ctx, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const item = await SelectPaygService({ id });
    if (!item) return ctx.answerCbQuery("❌ یافت نشد", { show_alert: true });

    const servises = new ServiseModel();
    if (item.suspended_at) {
      // فعال‌سازی دستی - درخواست صریح فعال‌سازی به پنل (تایید‌شده)؛ چرخه هزینه روزانه از نو شروع می‌شود
      const enabled = await servises.SetStatus({ id: item.service_id, enable: true });
      if (!enabled) return ctx.answerCbQuery("❌ فعال‌سازی روی پنل تایید نشد", { show_alert: true });
      await UpdatePaygService({ id: item.id }, { suspended_at: null, warned: false, daily_billed_at: null });
    } else {
      // تعلیق دستی - درخواست صریح غیرفعال‌سازی به پنل (تایید‌شده)
      const disabled = await servises.SetStatus({ id: item.service_id, enable: false });
      if (!disabled) return ctx.answerCbQuery("❌ غیرفعال‌سازی روی پنل تایید نشد", { show_alert: true });
      await UpdatePaygService({ id: item.id }, { suspended_at: new Date() });
    }
    const updated = await SelectPaygService({ id });
    return Payg.PAYGVIEW({ ctx, menu, isMatch: ["PAYGVIEW_" + updated.id] });
  },
  // حذف کامل دستی توسط ادمین
  PAYGADMINDELETE: async ({ ctx, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const item = await SelectPaygService({ id });
    if (!item) return ctx.answerCbQuery("❌ یافت نشد", { show_alert: true });

    const servises = new ServiseModel();
    await servises.DeleteServise({ id: item.service_id });
    await DeletePaygServiceRow({ id: item.id });
    ctx.editMessageText("🗑 سرویس با موفقیت حذف شد");
  },
  // ساخت و ارسال نمودار مصرف بر اساس QuickChart (بدون نیاز به وابستگی جدید روی سرور)
  PAYGGRAPH: async ({ ctx, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const logs = await SelectPaygUsageLogs({ payg_service_id: id, limit: 30 });
    if (!logs.length) return ctx.answerCbQuery("⚠️ هنوز داده مصرفی برای این سرویس ثبت نشده", { show_alert: true });

    const labels = logs.map((_, index) => index + 1);
    const usageGB = logs.map((l) => Number((l.used_traffic_bytes / 1073741824).toFixed(2)));

    const chartConfig = {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            label: "مصرف تجمعی (گیگابایت)",
            data: usageGB,
            fill: true,
            borderColor: "rgb(56, 189, 248)",
            backgroundColor: "rgba(56, 189, 248, 0.2)",
          },
        ],
      },
      options: {
        title: { display: true, text: "روند مصرف سرویس PAYG #" + id },
      },
    };

    const url = "https://quickchart.io/chart?width=700&height=400&c=" + encodeURIComponent(JSON.stringify(chartConfig));
    await ctx.answerCbQuery();
    ctx.replyWithPhoto({ url }, { caption: "📊 نمودار مصرف سرویس PAYG #" + id });
  },
};

export default Payg;
