import { SelectCard, UpdateCard } from "../../../controllers/Card.js";
import { CreateFree } from "../../../controllers/Free.js";
import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";
import { UpdateUser, selectUser } from "../../../controllers/Users.js";

const Price = {
  // change show pay
  SHOWPAY: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_")[1];
    const setting = await SelectSetting();
    const showpay = JSON.parse(setting.pay);
    showpay.forEach((item) => {
      if (item.text === match) {
        item.value = item.value == true ? false : true;
      }
    });
    await UpdateSetting({ pay: JSON.stringify(showpay) });
    ctx.editMessageText(i18n.t("PANEL.SHOW_PAY"), menu.PayButton(showpay));
  },
  // for accept peymant and install sercise
  ACCEPTRESID: async ({ ctx, i18n, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const Card = await SelectCard({ id });
    const userData = await selectUser({ id: Card.chat_id });
    UpdateUser({ id: Card.chat_id }, { price: userData.price + Card.amount });
    ctx.reply(i18n.t("PAY.CARD.SUCCEFULLY_PEY", { amount: Card.amount }), { chat_id: Card.chat_id });
    await ctx.deleteMessage();
    ctx.reply(i18n.t("PAY.CARD.SUCCEFULLY_SEND_PRICE"));
    UpdateCard(Card.chat_id, { status: true });
    // send porsant
    if (userData.inviter) {
      const setting = await SelectSetting();
      const { charge } = JSON.parse(setting.invite);
      const percentageAmount = (charge / 100) * Card.amount;
      const userInvier = await selectUser({ id: userData.inviter });
      UpdateUser({ id: userData.inviter }, { price: userInvier.price + percentageAmount });
      CreateFree({ chat_id: userData.inviter, amount: percentageAmount, type: "charge" });
      ctx.replyWithHTML(i18n.t("PRICE.SEND_INVITE", { percentageAmount }), { chat_id: userData.inviter });
    }
  },
  // for approve resid
  APPROVERESID: async ({ ctx, i18n, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const Card = await SelectCard({ id });
    ctx.reply(i18n.t("PAY.CARD.ERROR_SEND_CARD"), { chat_id: Card.chat_id });
    await ctx.deleteMessage();
    ctx.reply(i18n.t("PAY.CARD.ERROR_SEND_PRICE"));
  },
};

export default Price;
