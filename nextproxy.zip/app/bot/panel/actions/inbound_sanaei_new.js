import { STATE_LIST_ADMIN } from "../sessions/state.js";
import { PANEL_TYPES } from "../../../utils/panelTypes.js";
import { SANAEI_TEXTS } from "../utils/SanaeiTexts.js";

const InboundSanaeiNew = {
  // select the panel type of the server that is going to be added
  ADDINBOUNDTYPE: async ({ ctx, i18n, menu, isMatch }) => {
    const type = isMatch[0].replace("ADDINBOUNDTYPE_", "");
    try {
      await ctx.answerCbQuery();
    } catch (error) {}
    try {
      await ctx.deleteMessage();
    } catch (error) {}
    // Sanaei New Versions
    if (type === PANEL_TYPES.SANAEI_NEW) {
      ctx.session.state = STATE_LIST_ADMIN.ADD_INBOUND_SANAEI_NEW;
      return ctx.reply(SANAEI_TEXTS.ADD_NEW_ANSWER, menu.BackPanelButton());
    }
    // Sanaei <= 2.6.6
    if (type === PANEL_TYPES.SANAEI_OLD) {
      ctx.session.state = STATE_LIST_ADMIN.ADD_INBOUND;
      return ctx.reply(i18n.t("PANEL.ADD_INBOUND.ANSWER"), menu.BackPanelButton());
    }
  },
};

export default InboundSanaeiNew;
