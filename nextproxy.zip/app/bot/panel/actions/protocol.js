import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";

const Protocol = {
  // change protocol
  CHANGEPROTOCOL: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("-")[1];
    const setting = await SelectSetting();
    const protocol = JSON.parse(setting.protocol);
    protocol.forEach((item) => {
      if (item.name === match) {
        item.value = item.value == true ? false : true;
      }
    });
    await UpdateSetting({ protocol: JSON.stringify(protocol) });
    ctx.editMessageText(i18n.t("PANEL.CONFIG_PROTOCOL"), menu.ProtoclButton(protocol));
  },
};

export default Protocol;
