import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";

const Pelan = {
  // change show name
  CHANGESHOWPELAN: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch.input.split("|")[1];
    const setting = await SelectSetting();
    const showpelan = JSON.parse(setting.showpelan);
    showpelan.forEach((item) => {
      if (item.text === match) {
        item.value = item.value == true ? false : true;
      }
    });
    await UpdateSetting({ showpelan: JSON.stringify(showpelan) });
    ctx.editMessageText(i18n.t("PANEL.SHOW_PELAN"), menu.PelanButton(showpelan));
  },
};

export default Pelan;
