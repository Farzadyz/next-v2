import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";

const Crypto = {
  // change cryto
  CHANCHESTATUSCRYPTO: async ({ ctx, i18n, menu }) => {
    const { first_payment } = await SelectSetting();
    const status = first_payment ? false : true;
    await UpdateSetting({ first_payment: status });
    ctx.editMessageText(i18n.t("PANEL.FIRST_PAYMENT.ANSWER"), menu.StatusCrypto(status));
  },
  // toggle NowPayments gateway on/off
  CHANGESTATUSNOWPAY: async ({ ctx, i18n, menu }) => {
    const { nowpayments_enabled } = await SelectSetting();
    const status = !nowpayments_enabled;
    await UpdateSetting({ nowpayments_enabled: status });
    ctx.editMessageText(i18n.t("PANEL.NOWPAYMENTS_SETTING.TOGGLE_ANSWER"), menu.StatusNowPayments(status));
  },
  // toggle refund feature on/off
  CHANGESTATUSREFUND: async ({ ctx, i18n, menu }) => {
    const { refund_enabled } = await SelectSetting();
    const status = !refund_enabled;
    await UpdateSetting({ refund_enabled: status });
    ctx.editMessageText(i18n.t("PANEL.REFUND_SETTING.TOGGLE_ANSWER"), menu.StatusRefund(status));
  },
};

export default Crypto;
