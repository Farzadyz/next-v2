import { STATE_LIST_ADMIN } from "../sessions/state.js";
import {
  getCategories,
  getKeysInCategory,
  getDefaultValue,
  getCurrentValue,
  isOverridden,
  removeOverride,
} from "../../utils/DynText.js";

const PAGE_SIZE = 8;

// Renders the category picker (top-level yaml sections like MENU, PANEL, ...).
const renderCategories = ({ ctx, i18n, menu, edit }) => {
  const categories = getCategories();
  ctx.session.dynText = { categories: categories.map((c) => c.category) };
  const text = i18n.t("DYNTEXT.CATEGORIES.TITLE");
  const markup = menu.DynTextCategories(categories);
  if (edit) return ctx.editMessageText(text, markup);
  return ctx.reply(text, markup);
};

// Renders the paginated key list for whichever category is stored in session.
const renderKeys = ({ ctx, i18n, menu, page = 0 }) => {
  const state = ctx.session.dynText || {};
  const category = state.category;
  const keys = state.keys || [];
  if (!keys.length) {
    return ctx.editMessageText(i18n.t("DYNTEXT.KEYS.EMPTY"), menu.DynTextCategories(getCategories()));
  }
  state.page = page;
  ctx.session.dynText = state;
  const overriddenMap = {};
  keys.forEach((key) => {
    overriddenMap[key] = isOverridden(key);
  });
  const text = i18n.t("DYNTEXT.KEYS.TITLE", { category, count: keys.length });
  return ctx.editMessageText(text, menu.DynTextKeys(keys, page, PAGE_SIZE, overriddenMap));
};

// Renders the detail view (current value + edit/reset/back) for the key the
// admin just tapped, keeping the selected key in session for the follow-up
// edit/reset callbacks (avoids stuffing long i18n keys into callback_data).
const renderDetail = ({ ctx, i18n, menu }) => {
  const state = ctx.session.dynText || {};
  const key = state.selectedKey;
  if (!key || getDefaultValue(key) === undefined) {
    return ctx.editMessageText(i18n.t("DYNTEXT.DETAIL.NOT_FOUND"), menu.DynTextCategories(getCategories()));
  }
  const overridden = isOverridden(key);
  const text = i18n.t("DYNTEXT.DETAIL.TITLE", {
    key,
    value: getCurrentValue(key),
    overridden: overridden ? i18n.t("DYNTEXT.DETAIL.OVERRIDDEN_BADGE") : i18n.t("DYNTEXT.DETAIL.DEFAULT_BADGE"),
  });
  return ctx.editMessageText(text, menu.DynTextDetail(overridden));
};

const DynText = {
  // admin picked a category
  DYNTEXTCAT: async ({ ctx, i18n, menu, isMatch }) => {
    const index = Number(isMatch[0].split("_")[1]);
    const category = (ctx.session.dynText?.categories || [])[index];
    if (!category) return renderCategories({ ctx, i18n, menu, edit: true });
    const keys = getKeysInCategory(category);
    ctx.session.dynText = { ...ctx.session.dynText, category, keys, page: 0 };
    renderKeys({ ctx, i18n, menu, page: 0 });
  },
  // pagination inside the current category's key list
  DYNTEXTPAGE: async ({ ctx, i18n, menu, isMatch }) => {
    const page = Number(isMatch[0].split("_")[1] || 0);
    renderKeys({ ctx, i18n, menu, page });
  },
  // admin picked a specific key from the list
  DYNTEXTKEY: async ({ ctx, i18n, menu, isMatch }) => {
    const index = Number(isMatch[0].split("_")[1]);
    const state = ctx.session.dynText || {};
    const key = (state.keys || [])[index];
    if (!key) return renderKeys({ ctx, i18n, menu, page: state.page || 0 });
    ctx.session.dynText = { ...state, selectedKey: key };
    renderDetail({ ctx, i18n, menu });
  },
  // start the "send me the new text" flow for the selected key
  DYNTEXTEDIT: async ({ ctx, i18n, menu }) => {
    const key = ctx.session.dynText?.selectedKey;
    if (!key) return renderCategories({ ctx, i18n, menu, edit: true });
    ctx.session.state = STATE_LIST_ADMIN.EDIT_DYNTEXT;
    await ctx.answerCbQuery();
    ctx.reply(
      i18n.t("DYNTEXT.ASK_NEW_VALUE", {
        example: "${نام_متغیر}",
        back: i18n.t("PANEL.MENU_PANEL.BACK_PANEL"),
      }),
      menu.BackPanelButton()
    );
  },
  // reset the selected key back to the yaml default
  DYNTEXTRESET: async ({ ctx, i18n, menu }) => {
    const key = ctx.session.dynText?.selectedKey;
    if (!key) return renderCategories({ ctx, i18n, menu, edit: true });
    if (!isOverridden(key)) {
      await ctx.answerCbQuery(i18n.t("DYNTEXT.RESET_NOT_OVERRIDDEN"), { show_alert: true });
      return;
    }
    await removeOverride(key);
    await ctx.answerCbQuery(i18n.t("DYNTEXT.RESET_CONFIRM"), { show_alert: true });
    renderDetail({ ctx, i18n, menu });
  },
  // back to the category list
  DYNTEXTBACKCATS: async ({ ctx, i18n, menu }) => {
    renderCategories({ ctx, i18n, menu, edit: true });
  },
  // back to the current category's key list
  DYNTEXTBACKKEYS: async ({ ctx, i18n, menu }) => {
    const state = ctx.session.dynText || {};
    if (!state.category) return renderCategories({ ctx, i18n, menu, edit: true });
    renderKeys({ ctx, i18n, menu, page: state.page || 0 });
  },
};

export default DynText;
