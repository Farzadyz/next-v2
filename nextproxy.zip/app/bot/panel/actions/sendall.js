import { UpdateSendall } from "../../../controllers/SendAll.js";
import { STATE_LIST_ADMIN } from "../sessions/state.js";

const SendAll = {
  // send message
  SENDMESSAGE: async ({ ctx, i18n, menu, isMatch, message = true }) => {
    const match = isMatch.input.split("_")[1];
    await UpdateSendall({ type: match });
    let text;
    if (message) {
      text = i18n.t("PANEL.MESSAGE_ALL.ANSWER");
      ctx.session.state = STATE_LIST_ADMIN.MESSAGE_ALL;
    } else {
      text = i18n.t("PANEL.FORWARD_ALL.ANSWER");
      ctx.session.state = STATE_LIST_ADMIN.FORWARD_ALL;
    }
    ctx.reply(text, menu.BackPanelButton());
  },
  // send forward
  SENDFORWARD: async ({ ctx, i18n, menu, isMatch }) => {
    return SendAll.SENDMESSAGE({ ctx, i18n, menu, isMatch, message: false });
  },
};

export default SendAll;
