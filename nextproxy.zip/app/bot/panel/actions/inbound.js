import { selectAllInbound, DestoryInbound, UpdateInbound, selectInbound } from "../../../controllers/Inbound.js";
import { I18NK } from "../../utils/I18n.js";
import { STATE_LIST_ADMIN } from "../sessions/state.js";

const Inbound = {
  // delete inbound
  DELETEINBOUND: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    DestoryInbound({ id });
    await ctx.answerCbQuery(i18n.t("PANEL.LIST_PANEL.DELETE"));
    const allPelan = await selectAllInbound();
    if (allPelan.length < 1) return ctx.editMessageText(i18n.t("PANEL.LIST_PANEL.NONE"));
    ctx.editMessageText(i18n.t("PANEL.LIST_PANEL.ANSWER"), menu.ListInbound(allPelan));
  },
  // change status inbound
  CHENGESTATUSINBOUND: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const { status } = await selectInbound({ id });
    await UpdateInbound({ id }, { status: status ? false : true });
    const allPelan = await selectAllInbound();
    ctx.editMessageText(i18n.t("PANEL.LIST_PANEL.ANSWER"), menu.ListInbound(allPelan));
  },
  // edit inbound
  EDITINBOUND: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    ctx.session.id_inbound = id;
    ctx.session.state = STATE_LIST_ADMIN.EDIT_INBOUND;
    const { location, port, price, type } = await selectInbound({ id });
    const list = `<code>${location}\n${port}\n${type}\n${price ?? ""}</code>`;
    ctx.replyWithHTML(i18n.t("PANEL.ADD_INBOUND.EDIT", { list }), menu.BackPanelButton());
  },
};

export default Inbound;
