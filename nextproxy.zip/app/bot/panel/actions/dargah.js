import { SelectSetting, UpdateSetting } from "../../../controllers/Setting.js";

const Dargah = {
  // switch dargah
  SWITCHDARGAH: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_")[1];
    const { default_pay, pay } = await SelectSetting();
    const find = JSON.parse(pay).find((e) => e.text == match);
    if (find.text == default_pay) return true;
    await UpdateSetting({ default_pay: find.text });
    ctx.editMessageText(i18n.t("PANEL.SWITCH_DARGAH.ANSWER"), menu.switchDargah(JSON.parse(pay), find.text));
  },
  // switch dargah card to card
  SWITCHDARGAHCARD: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_")[1];
    const { default_pay_card, pay } = await SelectSetting();
    const find = JSON.parse(pay).find((e) => e.text == match);
    if (find.text == default_pay_card) return true;
    await UpdateSetting({ default_pay_card: find.text });
    ctx.editMessageText(i18n.t("PANEL.SWITCH_DARGAH_CARD.ANSWER"), menu.switchDargah(JSON.parse(pay), find.text, "SWITCHDARGAHCARD_"));
  },
};

export default Dargah;
