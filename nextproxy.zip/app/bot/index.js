// telegraf
import { Telegraf, session } from "telegraf";
import { message } from "telegraf/filters";
import TelegrafI18n from "i18n-telegraf";
// session
import { MySQL } from "@telegraf/session/mysql";

// anti spam
import { limit } from "@grammyjs/ratelimiter";

// Middleware
import CommendMiddleware from "./middleware/CommendMiddleware.js";
import KeyboardMiddleware from "./middleware/KeyboardMiddleware.js";
import ActionMiddleware from "./middleware/ActionMiddleware.js";
import SessionMiddleware from "./middleware/SessionMiddleware.js";
import InlineQueryMiddleware from "./middleware/InlineQueryMiddleware.js";
import SignupMiddleware, {
  STATE_LIST_SIGNUP,
} from "./middleware/SignupMiddleware.js";
import { Join } from "./buttons/ButtonManager.js";
import Is_join from "./utils/join.js";

// PanelMiddleware
import PanelActionMiddleware from "./panel/ActionMiddleware.js";
import PanelKeyboardMiddleware from "./panel/KeyboardMiddleware.js";
import PanelSessionMiddleware from "./panel/SessionMiddleware.js";
import { SelectBlock } from "../controllers/Block.js";
import { SelectSetting } from "../controllers/Setting.js";
import { loadDynTextCache, patchI18n } from "./utils/DynText.js";

const bot = new Telegraf(process.env.BOT_TOKEN);

const i18nL = new TelegrafI18n({
  directory: "locales",
  sessionName: "session",
  useSession: true,
});

const startBot = async () => {
  // ====== Middlware Ckeck User ====== //
  bot.use(async (ctx, next) => {
    const admins = JSON.parse(process.env.RESID);
    const find = admins.find((e) => e == ctx.from?.id);
    if (ctx.chat?.type == "private" || ctx.inlineQuery || find) return next();
  });

  // ====== Middlware Anti Spam ====== //
  bot.use(
    limit({
      timeFrame: 2500,
      limit: 2,
      onLimitExceeded: (ctx) => {
        if (ctx?.update?.callback_query) {
          ctx.answerCbQuery("⏳");
        }
      },
    }),
  );

  bot.use((ctx, next) => {
    next().catch((err) => console.error(err));
  });

  // ====== Middlware Block ====== //
  bot.use(async (ctx, next) => {
    const block = await SelectBlock({ id: ctx.from.id });
    if (!block) return next();
  });

  // ====== Middlware Session ====== //
  const store = MySQL({
    host: "localhost",
    database: process.env.USER_DATA,
    user: process.env.NAME_DATA,
    password: process.env.PASSWORD_DATA,
  });

  bot.use(
    session({ store, defaultSession: () => ({ __language_code: "fa" }) }),
  );

  // ====== Middlware i18n ====== //
  bot.use(i18nL.middleware());

  // ====== Middlware Dynamic Text Override ====== //
  // Loads DB-edited texts/buttons into memory once, then makes every
  // ctx.i18n.t(...) call in the bot check that cache before the yaml default.
  await loadDynTextCache();
  bot.use((ctx, next) => {
    patchI18n(ctx.i18n);
    return next();
  });

  // ====== Middlware Commend ====== //
  bot.command(/.*/, CommendMiddleware);

  // ====== Middlware sigh up ====== //
  // bot.on(message, SignupMiddleware);

  // ====== Middlware Ckeck Join ====== //
  bot.use(async (ctx, next) => {
    if (await Is_join(ctx)) return next();
    ctx.reply(ctx.i18n.t("JOIN.ANSWER"), Join(ctx.i18n));
  });

  // ====== Middlware Keyboard ====== //
  bot.on(message("text"), KeyboardMiddleware);

  // ====== Middlware inlinequery ====== //
  bot.on("inline_query", InlineQueryMiddleware);

  // ====== Middlware Callback_query ====== //
  bot.on("callback_query", ActionMiddleware);

  // ====== Middlware Session ====== //
  bot.on([message("text"), message("photo")], SessionMiddleware);

  bot.on([message, "callback_query"], async (ctx, next) => {
    const admins = JSON.parse(process.env.ADMIN);
    const find = admins.find((e) => e == ctx.from.id);
    if (find) {
      if (ctx.update?.callback_query?.data) {
        return PanelActionMiddleware(ctx);
      } else {
        const nexts = await PanelKeyboardMiddleware(ctx, next);
        if (nexts) await PanelSessionMiddleware(ctx);
      }
    }
  });

  // ====== Menu button web app ====== //
  // The chat "menu button" (next to the message box) is, like an inline
  // button, a launch context Telegram DOES sign initData for - so this
  // gives users a second reliable way into the Mini App besides the
  // "🧩 اپلیکیشن وب" reply-keyboard row above.
  if (process.env.WEBAPP_URL) {
    await bot.telegram.setChatMenuButton({
      menu_button: { type: "web_app", text: "اپلیکیشن", web_app: { url: process.env.WEBAPP_URL } },
    });
  }

  bot.launch();
};

export { startBot, bot, i18nL };
