import { SelectSetting } from "../../controllers/Setting.js";
import { UpdateUser, insertUser, selectUser } from "../../controllers/Users.js";
import { Buttons, sendMainMenu } from "../buttons/ButtonManager.js";
import { PanelButtons } from "../panel/buttons/ButtonsPanel.js";
import { SelectALLServise, SelectServise } from "../../controllers/Servise.js";
import { CreateFree } from "../../controllers/Free.js";
import MyEshterak from "../actions/myEshterak.js";
import { selectInboundMz } from "../../controllers/InboundMz.js";
import Marzban from "../../api/marzban.js";

const MAIN_COMMEND = {
  INVITE: /^(\/[Ss]tart) ref_(.*)/,
  START: /^(\/[Ss][Tt][Aa][Rr][Tt])/,
  MYESHTERAK: /^(\/myeshterak_)(.*)/,
  PANEL: "/panel",
  CLEAR_INBOUND: /^(\/clear_inbound_)(.*)/,
};

export default async (ctx) => {
  const text = ctx.message.text;
  const actionValues = Object.values(MAIN_COMMEND);
  for (let index = 0; index < actionValues.length; index++) {
    const isMatch = text.match(actionValues[index]);
    if (isMatch && EventListener[Object.keys(MAIN_COMMEND)[index]]) {
      const menu = new Buttons(ctx);
      return EventListener[Object.keys(MAIN_COMMEND)[index]]({ ctx, i18n: ctx.i18n, menu, isMatch });
    }
  }
};

const EventListener = {
  // Join User in invite freand
  INVITE: async ({ ctx, i18n, menu, isMatch }) => {
    const existmatch = await selectUser({ id: isMatch[2] });
    const existUser = await selectUser({ id: ctx.from.id });
    if (isMatch[2] != ctx.from.id && existmatch && !existUser) {
      const setting = await SelectSetting();
      const { start, charge } = JSON.parse(setting.invite);
      const member = existmatch.member + 1;
      await UpdateUser({ id: isMatch[2] }, { member, price: existmatch.price + start });
      await insertUser({ id: ctx.from.id, inviter: isMatch[2] });
      ctx.replyWithHTML(i18n.t("START_GIFT_MESSAGE", { start, charge }), {
        chat_id: isMatch[2],
      });
      // setting
      if (setting.gift > 0) {
        await UpdateUser({ id: ctx.from.id }, { price: setting.gift });
        ctx.replyWithHTML(i18n.t("SIGN_UP.GIFT", { gift: setting.gift }));
        CreateFree({ chat_id: ctx.from.id, amount: setting.gift, type: "start" });
        CreateFree({ chat_id: isMatch[2], amount: start, type: "invite" });
      }
    }
    sendMainMenu(ctx, i18n.t("START_MESSAGE", { bot: process.env.BOTNAME, name: ctx.from.first_name }), menu);
  },
  // start
  START: async ({ ctx, menu, i18n }) => {
    const setting = await SelectSetting();
    // pin message
    if (setting.pin) {
      const message = await ctx.reply(setting.pin);
      await ctx.pinChatMessage(message.message_id);
    }

    ctx.session.state = undefined;
    sendMainMenu(ctx, i18n.t("START_MESSAGE", { bot: process.env.BOTNAME, name: ctx.from.first_name }), menu);
    insertUser({ id: ctx.from.id });
  },
  // my eshterak
  MYESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const select = await SelectServise({ id });
    const admins = JSON.parse(process.env.ADMIN);
    const find = admins.find((e) => e == ctx.from.id);
    if (select && (ctx.from.id == select.telegram_id || find)) {
      return MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch: [`my_${id}`] });
    }
  },
  // Commend for panel Admin
  PANEL: ({ ctx, i18n }) => {
    const admins = JSON.parse(process.env.ADMIN);
    const find = admins.find((e) => e == ctx.from.id);
    if (find) {
      delete ctx.session.state;
      const menuPanel = new PanelButtons(ctx);
      ctx.reply(i18n.t("PANEL.MESSAGE_PANEL"), menuPanel.PanelMenuButtons());
    }
  },
  // Commend for panel Admin
  CLEAR_INBOUND: async ({ ctx, i18n, isMatch }) => {
    const admins = JSON.parse(process.env.ADMIN);
    const find = admins.find((e) => e == ctx.from.id);
    if (find) {
      await ctx.reply("⏳");
      const match = isMatch[0].split("_");
      // select inbound
      const selectinbound = await selectInboundMz({ id: match[2] });
      const allServise = await SelectALLServise(match[3] ?? null);
      const servise = new Marzban();
      allServise.map(async (item) => {
        const data = await servise.getUser({ username: item.username });
        if (data) {
          try {
            data.inbounds[selectinbound.protocol] = data.inbounds[selectinbound.protocol].filter((tag) => tag !== selectinbound.tag);
            servise.modifyUser({ username: item.username, data });
          } catch (error) {}
        }
      });
      ctx.reply(i18n.t("PANEL.SUCCEFULY_DELETE"));
    }
  },
};
