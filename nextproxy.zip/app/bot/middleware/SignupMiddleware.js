import { parsePhoneNumber } from "libphonenumber-js";
import { CreateNumber, SelectNumber } from "../../controllers/Number.js";
import { UpdateUser } from "../../controllers/Users.js";
import { Buttons, sendMainMenu } from "../buttons/ButtonManager.js";

export const STATE_LIST_SIGNUP = {
  SEND_PHONE: "send_phone",
  SEND_CODE_PHONE: "send_code_phone",
  CHECK_CODE: "check_code_phone",
  SEND_CARD: "send_card",
};

export default async (ctx, next) => {
  // update last message
  const session = ctx.session;
  const admins = JSON.parse(process.env.ADMIN);
  const find = admins.find((e) => e == ctx.from.id);
  if (session.signup === true || find) return next();

  const values = Object.values(STATE_LIST_SIGNUP);
  const signup = session?.signup || "send_phone";
  if (values.includes(signup) && EventListener[signup]) {
    const menu = new Buttons(ctx);
    return EventListener[signup]({ ctx, i18n: ctx.i18n, menu });
  }
};

const EventListener = {
  [STATE_LIST_SIGNUP.SEND_PHONE]: async ({ ctx, i18n, menu }) => {
    ctx.reply(i18n.t("SIGN_UP.PHONE_NUMBER"), menu.SendNumber());
    ctx.session.signup = STATE_LIST_SIGNUP.SEND_CODE_PHONE;
  },
  [STATE_LIST_SIGNUP.SEND_CODE_PHONE]: async ({ ctx, i18n, menu }) => {
    const contact = ctx.message?.contact;
    // error contact && error for contact
    if (!contact || (contact && ctx.message.forward_date)) return ctx.reply(i18n.t("SIGN_UP.ERROR_KEYBOARD"), menu.SendNumber());
    const parsedPhoneNumber = await parsePhoneNumber(contact.phone_number, "IR");
    if (parsedPhoneNumber && parsedPhoneNumber.country != "IR") return ctx.reply(i18n.t("SIGN_UP.ERROR_NUMBER"));
    // check phone
    const selectPhone = await SelectNumber({ phonenumber: parsedPhoneNumber.number });
    if (selectPhone) return ctx.reply(i18n.t("SIGN_UP.AGAIN_NUMBER"));
    await CreateNumber({ phonenumber: parsedPhoneNumber.number });
    await UpdateUser({ id: ctx.from.id }, { phone: parsedPhoneNumber.number });
    ctx.session.signup = true;
    await ctx.reply(i18n.t("SIGN_UP.DONE"));
    await sendMainMenu(ctx, i18n.t("START_MESSAGE", { bot: process.env.BOTNAME, name: ctx.from.first_name }), menu);
  },
};
