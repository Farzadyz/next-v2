import { Buttons } from "../buttons/ButtonManager.js";

// actions
import BuyEshterak from "../actions/buyeshterak.js";
import MyEshterak from "../actions/myEshterak.js";
import Upgrade from "../actions/UpgradeEshterak.js";
import Tamdid from "../actions/TamdidEshterak.js";
import Utils from "../actions/UtilsEshterak.js";
import Support from "../actions/support.js";
import Price from "../actions/price.js";
import Pay from "../actions/pay.js";
import Gift from "../actions/gift.js";
import Agent from "../actions/agent.js";
import Questions from "../actions/question.js";
import Setname from "../actions/setname.js";
import Payg from "../actions/payg.js";
import Refund from "../actions/RefundEshterak.js";

const ActionMap = {
  // buy eshterak
  PELAN_CHOESE: "PELAN_CHOESE",
  PELAN_CUSTOMIZE: "PELAN_CUSTOMIZE",
  PELAN_SELECTCUSTOMIZE: "PELAN_SELECTCUSTOMIZE",
  PELAN_ECONOMIC: "PELAN_ECONOMIC",
  TYPELOCATION: /^TYPELOCATION_\w+/,
  CUSTUMIZEDAY: /^CUSTUMIZEDAY_\w+/,
  CUSTUMIZETRAFICC: /^CUSTUMIZETRAFICC_\w+/,
  BUYPRICEGIFT: /^BUYPRICEGIFT_\w+/,
  PELAN_FREE: "PELAN_FREE",
  BACK_PELAN: "BACK_PELAN",
  CHOOSE: /^CHOOSE_\w+/,
  MZCHOOSE: /^MZCHOOSE_\w+/,
  PAYG: /^PAYG_\w+/,
  PAYGLOC: /^PAYGLOC_\w+/,
  SERVISE: /^SERVICE_\w+/,
  PEYMENT: /^PEYMENT_\w+/,
  PEYDARGAH: /^PEYDARGAH_\w+/,
  PEYDARGAHCARD: /^PEYDARGAHCARD_\w+/,
  GIFT: /^GIFT_\w+/,
  SETNAME: /^SETNAME_\w+/,
  // My Eshterak
  PAGE: /^PAGE_\w+/,
  MYESHTERAK: /^MYESHTERAK_\w+/,
  BACKESHTERAK: /^BACKESHTERAK_\w+/,
  UPDATE_ESHTERAK: /^UPDATEESHTERAK_\w+/,
  QRCODE: /^QRCODE_\w+/,
  CHANGESTATUS: /^CHANGESTATUS_\w+/,
  BACKINFO: "BACKINFO",
  // Tamdid Eshterak
  TAMDID_ESHTERAK: /^TAMDIDESHTERAK_\w+/,
  FAINAL_TAMDID: /^TAMDID_\w+/,
  // Delete Eshterak
  DELETEESHTERAK: /^DELETEESHTERAK_\w+/,
  VERIFYDELETEESHTERAK: /^VERIFYDELETEESHTERAK_\w+/,
  // Cancel & Refund Eshterak
  REFUNDESHTERAK: /^REFUNDESHTERAK_\w+/,
  VERIFYREFUNDESHTERAK: /^VERIFYREFUNDESHTERAK_\w+/,
  // Change Password Eshterak
  CHANGEPASESHTERAK: /^CHANGEPASESHTERAK_\w+/,
  VERIFYCHANGEPASESHTERAK: /^VERIFYCHANGEPASESHTERAK_\w+/,
  // Upgrade Eshterak
  UPGERATE: /^UPGERATE_\w+/,
  FAINALUPGERADE: /^FAINALUPGERADE_\w+/,
  ERTEGA: /^ERTEGA_\w+/,
  // redirect
  REDIRECT: /^REDIRECT_\w+/,
  // support
  ANSWERSUPPORT: /^ANSWERSUPPORT_\w+/,
  // price
  CHARGE: "CHARGE",
  ZARINPAL: /^ZARINPAL_\w+/,
  ATLASPAY: /^ATLASPAY_\w+/,
  ZIBAL: /^ZIBAL_\w+/,
  PAYSTAR: /^PAYSTAR_\w+/,
  NOWPEYMENT: /^NOWPEYMENT_\w+/,
  CRYPTOPAY: /^CRYPTOPAY_\w+/,
  NOWCRYPTOCHECK: /^NOWCRYPTOCHECK_\w+/,
  CARD: /^CARD_\w+/,
  NOVINPAL: /^NOVINPAL_\w+/,
  POLAM: /^POLAM_\w+/,
  TABAPAY: /^TABAPAY_\w+/,
  SIZAPAY: /^SIZAPAY_\w+/,
  ZIRGOZAR: /^ZIRGOZAR_\w+/,
  TERAPAY: /^TERAPAY_\w+/,
  RIALIT: /^RIALIT_\w+/,
  // pay
  NOWPEY: /^NOWPEY_\w+/,
  // question
  QUESTION: /^QUESTION_\w+/,
  BK_MENU_QUESTION: "BACKMENUQUESTION",
  // agent
  AGENTQUESTION: /^AGENTQUESTION_\w+/,
  BACK_QUESTION: "BACKQUESTION",
};

export default async (ctx, next) => {
  const callback_data = ctx.update.callback_query.data;
  const actionValues = Object.values(ActionMap);
  for (let index = 0; index < actionValues.length; index++) {
    const isMatch = callback_data.match(actionValues[index]);
    if (isMatch && EventListener[Object.keys(ActionMap)[index]]) {
      const menu = new Buttons(ctx);
      return EventListener[Object.keys(ActionMap)[index]]({ ctx, isMatch, i18n: ctx.i18n, menu });
    }
  }
  return next();
};

const EventListener = {
  // Action Buy Eshterak
  ...BuyEshterak,
  // Action Gift
  ...Gift,
  // Action for my eshterak,
  ...MyEshterak,
  // Action for upgrade eshterak
  ...Upgrade,
  // Action for tamdid eshterak
  ...Tamdid,
  // Action for utils eshterak
  ...Utils,
  // Action support
  ...Support,
  // Action price
  ...Price,
  // Action pay
  ...Pay,
  // Action questions
  ...Questions,
  // Action agent
  ...Agent,
  // Action setname
  ...Setname,
  // Action pay as you go
  ...Payg,
  // Action cancel & refund
  ...Refund,
};
