import { CountServise, SelectALLServiseUser } from "../../controllers/Servise.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectUser, UpdateUser } from "../../controllers/Users.js";
import { SelectResellerByOwner } from "../../controllers/Reseller.js";
import { Buttons, sendMainMenu } from "../buttons/ButtonManager.js";
import { STATE_LIST } from "../sessions/state.js";
import I18N, { I18NK } from "../utils/I18n.js";
import { NumberFormat } from "../utils/utils.js";
import momentJalali from "moment-jalaali";
import moment from "moment-timezone";

export default async (ctx, next) => {
  const text = ctx.message.text;
  if (I18N(ctx, "MENU").includes(text)) {
    const EventListener = {
      // buttons back
      [ctx.i18n.t("MENU.BACK")]: async ({ ctx, menu, i18n }) => {
        delete ctx.session.state;
        sendMainMenu(ctx, i18n.t("START_MESSAGE", { bot: process.env.BOTNAME, name: ctx.from.first_name }), menu);
      },
      // buttons buy eshterak
      [ctx.i18n.t("MENU.ESHTERAK_BUY")]: async ({ ctx, menu, i18n }) => {
        const setting = await SelectSetting();
        const showpelan = JSON.parse(setting.showpelan);
        let find = showpelan.filter((e) => e.value == true);
        // filter free pelan
        const { free } = await selectUser({ id: ctx.from.id });
        if (free) {
          find = find.filter((e) => e.text != "free");
        }
        // error not pelan
        if (find.length < 1) return ctx.reply(i18n.t("ESHTERAK_BUY.NOT_EXIXST"));
        const { message_id } = await ctx.reply("🛒");
        ctx.telegram.editMessageText(ctx.from.id, message_id, null, i18n.t("ESHTERAK_BUY.BUY_ESHTERAK_MESSAGE"), {
          parse_mode: "html",
          ...menu.SelectPelan(find),
        });
      },
      // buttons my eshterak
      [ctx.i18n.t("MENU.MY_ESHTERAK")]: async ({ ctx, i18n, menu }) => {
        const countServise = await CountServise({ telegram_id: ctx.from.id });
        if (countServise < 1) return ctx.reply(i18n.t("MY_ESHTERAK.NOT_FOUND_MY_ESHTERAK"));
        ctx.sendChatAction("typing");
        // Get Servise
        const servises = await SelectALLServiseUser({
          telegram_id: ctx.from.id,
          offset: 0,
          limit: 10,
        });
        const { message_id } = await ctx.reply("🔍");
        const keyboard = await menu.Myeshterakkeyboard(servises, 1, countServise);
        ctx.telegram.editMessageText(ctx.from.id, message_id, null, i18n.t("MY_ESHTERAK.MY_ESHTERAK", { count: countServise }), {
          ...keyboard,
        });
      },
      // buttons account
      [ctx.i18n.t("MENU.ACCONT")]: async ({ ctx, i18n }) => {
        const { message_id } = await ctx.reply("💻");
        const { createdAt, price, member, agent } = await selectUser({ id: ctx.from.id });
        const buy = await CountServise({ telegram_id: ctx.from.id });
        await ctx.deleteMessage(message_id);
        ctx.replyWithHTML(
          i18n.t("ACCONT", {
            id: ctx.from.id,
            ozv: momentJalali(createdAt).format("jYYYY/jMM/jDD"),
            member,
            buy,
            agent: agent ? "✅" : "❌",
            price,
            day: momentJalali().format("jYYYY/jMM/jDD"),
            time: moment.tz("Asia/Tehran").format("HH:mm:ss"),
          })
        );
      },
      // buttons support
      [ctx.i18n.t("MENU.SUPPORT")]: async ({ ctx, menu, i18n }) => {
        ctx.session.state = STATE_LIST.SUPPORT;
        const { message_id } = await ctx.reply("📜");
        await ctx.deleteMessage(message_id);
        ctx.reply(i18n.t("SUPPORT.ANSWER", { support: process.env.IDSUPPORT }), menu.BackButton());
      },
      // buttons charge account
      [ctx.i18n.t("MENU.PRICE")]: async ({ ctx, i18n, menu }) => {
        const setting = await SelectSetting();
        const pay = JSON.parse(setting.pay).filter((e) => e.value == true);
        // error not pay
        if (pay.length < 1) return ctx.reply(i18n.t("PRICE.NONE_TYPE"));
        const { message_id } = await ctx.reply("💰");
        await ctx.deleteMessage(message_id);
        ctx.session.state = STATE_LIST.COUNT_PRICE;
        ctx.reply(i18n.t("PRICE.ANSWER"), menu.BackButton());
      },
      // buttons charge account
      [ctx.i18n.t("MENU.FREE_PROXY")]: async ({ ctx, i18n }) => {
        const { message_id } = await ctx.reply("💌");
        ctx.telegram.editMessageText(
          ctx.from.id,
          message_id,
          null,
          i18n.t("FREE_PROXY.ANSWER", {
            id: ctx.from.id,
            bot: process.env.BOTNAME,
            idBot: (await ctx.telegram.getMe()).username,
          }),
          {
            parse_mode: "html",
          }
        );
        const setting = await SelectSetting();
        const { start, charge } = JSON.parse(setting.invite);
        ctx.reply(
          i18n.t("FREE_PROXY.CAPTION", {
            caption: i18n.t("FREE_PROXY.PORSANT", { start, charge }),
          })
        );
      },
      // buttons get agent
      [ctx.i18n.t("MENU.GET_AGENT")]: async ({ ctx, menu, i18n }) => {
        const { message_id } = await ctx.reply("🔑");
        await ctx.deleteMessage(message_id);
        ctx.session.state = STATE_LIST.GET_AGENT;
        ctx.reply(i18n.t("GET_AGENT.ANSWER"), menu.GetAgent());
      },
      // buttons questions
      [ctx.i18n.t("MENU.QUESTION")]: async ({ ctx, menu, i18n }) => {
        const { message_id } = await ctx.reply("❓");
        await ctx.deleteMessage(message_id);
        ctx.reply(i18n.t("QUESTION.ANSWER"), menu.QuestionsAgent(I18NK(ctx, "QUESTION.MENU"), true));
      },
      // buttons reseller bot
      [ctx.i18n.t("MENU.RESELLER")]: async ({ ctx, menu, i18n }) => {
        const existing = await SelectResellerByOwner({ owner_id: ctx.from.id });
        if (existing) return ctx.replyWithHTML(i18n.t("RESELLER.ALREADY_HAVE", { username: existing.bot_username, status: existing.status }));
        const { reseller_min_balance, reseller_setup_fee } = await SelectSetting();
        const user = await selectUser({ id: ctx.from.id });
        if (user.price < reseller_min_balance) {
          return ctx.reply(i18n.t("RESELLER.LOW_BALANCE", { min: NumberFormat(reseller_min_balance), price: NumberFormat(user.price) }), menu.BackButton());
        }
        // Setup fee is deducted now (per the requested flow); it is refunded
        // automatically in the next step if the token turns out invalid.
        await UpdateUser({ id: ctx.from.id }, { price: user.price - reseller_setup_fee });
        ctx.session.resellerFee = reseller_setup_fee;
        ctx.session.state = STATE_LIST.ASK_RESELLER_TOKEN;
        ctx.reply(i18n.t("RESELLER.ASK_TOKEN", { fee: NumberFormat(reseller_setup_fee) }), menu.BackButton());
      },
    };

    const menu = new Buttons(ctx);
    return EventListener[text]({ ctx, i18n: ctx.i18n, menu });
  }

  return next();
};
