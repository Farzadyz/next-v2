import { Buttons } from "../buttons/ButtonManager.js";
// Sessions
import { STATE_LIST } from "../sessions/state.js";
import BuyEshterak from "../sessions/buyeshterak.js";
import Gift from "../sessions/gift.js";
import Support from "../sessions/support.js";
import Price from "../sessions/price.js";
import Agent from "../sessions/agent.js";
import Setname from "../sessions/setname.js";
import Redireact from "../sessions/redireact.js";
import ResellerSession from "../sessions/reseller.js";

export default async (ctx, next) => {
  const session = ctx.session;

  if (session && session.state) {
    const values = Object.values(STATE_LIST);
    if (values.includes(session.state) && EventListener[session.state]) {
      const menu = new Buttons(ctx);
      return EventListener[session.state]({ ctx, i18n: ctx.i18n, menu });
    }
  }
  return next();
};

const EventListener = {
  // session buy eshterak
  ...BuyEshterak,
  // session gift
  ...Gift,
  // session support
  ...Support,
  // session price
  ...Price,
  // session agent
  ...Agent,
  // session setname
  ...Setname,
  // session rediract
  ...Redireact,
  // session reseller bot
  ...ResellerSession,
};
