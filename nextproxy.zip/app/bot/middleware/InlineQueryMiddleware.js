import { SearchServise } from "../../controllers/Servise.js";
import { Buttons } from "../buttons/ButtonManager.js";

const ActionMap = {
  // player
  SEARCHESTERAK: /^\w+/,
};

export default async (ctx) => {
  const actionValues = Object.values(ActionMap);
  for (let index = 0; index < actionValues.length; index++) {
    const isMatch = ctx.inlineQuery.query.match(actionValues[index]);
    if (isMatch && EventListener[Object.keys(ActionMap)[index]]) {
      const menu = new Buttons(ctx);
      return EventListener[Object.keys(ActionMap)[index]]({ ctx, isMatch, i18n: ctx.i18n, menu });
    }
  }
};

const EventListener = {
  SEARCHESTERAK: async ({ ctx, isMatch }) => {
    let text = isMatch.input;
    const regex = /vless:\/\/([0-9a-fA-F-]{36})/;
    const match = text.match(regex);
    if (match) {
      text = match[1];
    }
    const admins = JSON.parse(process.env.ADMIN);
    const find = admins.find((e) => e == ctx.from.id);
    const select = await SearchServise(ctx.from.id, text, find ? true : false);
    // not found
    if (select.length < 1) return false;
    const array = [];
    let i = 1;
    for (const item of select) {
      array.push({
        id: i,
        type: "article",
        title: item.id,
        description: `${item.username} - ${item.name}`,
        input_message_content: {
          message_text: "/myeshterak_" + item.id,
        },
      });
      i++;
    }
    ctx.answerInlineQuery(array);
  },
};
