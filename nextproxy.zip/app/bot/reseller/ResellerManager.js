import fs from "fs";
import path from "path";
import crypto from "crypto";
import axios from "axios";
import { spawn } from "child_process";
import { Telegraf } from "telegraf";
import sequelize from "../../utils/database.js";
import Reseller from "../../model/reseller.js";
import ResellerSale from "../../model/resellersale.js";
import ResellerTopup from "../../model/resellertopup.js";
import { SelectActiveResellers, SelectReseller, SelectResellersWithPort, UpdateReseller } from "../../controllers/Reseller.js";

// ============================================================================
// Isolated reseller instance manager.
//
// Every reseller bot is deployed as a full, physically separate clone:
//   <RESELLERS_DIR>/<id>/            own copy of /reseller-template (code)
//   <RESELLERS_DIR>/<id>/.env        own bot token + API key + hook secret
//   <RESELLERS_DIR>/<id>/data/       own SQLite database (nothing shared)
// and runs as its own OS process. The instance only talks to the main bot
// through the Intermediary REST API (/reseller-api/v1). The main bot only
// talks back through the signed local hook (/internal/sync) to push instant
// changes (servers, permissions, credit).
// ============================================================================

const TEMPLATE_DIR = path.resolve(process.env.RESELLER_TEMPLATE_DIR || "reseller-template");
const INSTANCES_DIR = path.resolve(process.env.RESELLERS_DIR || "resellers");
const API_URL = process.env.RESELLER_API_URL || "http://127.0.0.1:3100";
const BASE_PORT = Number(process.env.RESELLER_BASE_PORT || 4100);
const COPY_SKIP = new Set(["node_modules", "data", "logs", ".env", "instance.pid"]);

const children = new Map(); // reseller_id -> { child, stopping, startedAt }
const restartCounts = new Map(); // reseller_id -> consecutive crash count
const sha256 = (value) => crypto.createHash("sha256").update(value).digest("hex");

const templateVersion = () => {
  try {
    return JSON.parse(fs.readFileSync(path.join(TEMPLATE_DIR, "package.json"), "utf8")).version || "0";
  } catch (error) {
    return "0";
  }
};

const publicBase = () => {
  const base = process.env.URL_DOMAIN || "";
  return base.endsWith("/") ? base : base + "/";
};

// ---------------------------------------------------------------- schema ---

// `sequelize.sync()` never adds columns to an existing table, so the new
// columns of the reseller tables are added here (idempotent, no `alter`).
const ensureColumns = async (Model) => {
  const qi = sequelize.getQueryInterface();
  const table = Model.getTableName();
  let described;
  try {
    described = await qi.describeTable(table);
  } catch (error) {
    await Model.sync();
    return;
  }
  for (const [name, attribute] of Object.entries(Model.rawAttributes)) {
    if (!described[name]) await qi.addColumn(table, name, attribute);
  }
};

const ensureResellerSchema = async () => {
  await ensureColumns(Reseller);
  await ensureColumns(ResellerSale);
  await ensureColumns(ResellerTopup);
  try {
    await sequelize.getQueryInterface().addIndex("reseller_sales", ["reseller_id", "request_id"], { name: "reseller_sales_request_idx" });
  } catch (error) {
    // index already exists
  }
};

// ---------------------------------------------------------------- deploy ---

const run = (command, args, cwd) =>
  new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, stdio: "ignore", shell: process.platform === "win32" });
    child.on("error", reject);
    child.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(`${command} exited with code ${code}`))));
  });

// copies the CODE of the template (never touches .env / data / logs)
const copyCode = (dir) => {
  fs.mkdirSync(dir, { recursive: true });
  fs.cpSync(TEMPLATE_DIR, dir, {
    recursive: true,
    force: true,
    filter: (source) => {
      const relative = path.relative(TEMPLATE_DIR, source);
      if (!relative) return true;
      return !COPY_SKIP.has(relative.split(path.sep)[0]);
    },
  });
  fs.writeFileSync(path.join(dir, ".template-version"), templateVersion());
};

const writeEnv = (reseller, apiKey) => {
  const lines = [
    `BOT_TOKEN=${reseller.bot_token}`,
    `RESELLER_ID=${reseller.id}`,
    `OWNER_ID=${reseller.owner_id}`,
    `MAIN_API_URL=${API_URL}`,
    `MAIN_API_KEY=${apiKey}`,
    `HOOK_SECRET=${reseller.hook_secret}`,
    `PORT=${reseller.port}`,
    `PUBLIC_URL=${publicBase()}r/${reseller.id}`,
    `DB_FILE=./data/reseller.sqlite`,
  ];
  fs.writeFileSync(path.join(reseller.dir, ".env"), lines.join("\n") + "\n", { mode: 0o600 });
};

const installDeps = async (dir) => {
  const target = path.join(dir, "node_modules");
  if (fs.existsSync(target)) return;
  const shared = path.join(TEMPLATE_DIR, "node_modules");
  if (fs.existsSync(shared)) {
    fs.symlinkSync(shared, target, "junction");
    return;
  }
  await run("npm", ["install", "--omit=dev", "--no-audit", "--no-fund"], dir);
};

// Builds a brand new isolated instance (fresh api key + hook secret).
const provisionReseller = async (reseller) => {
  const apiKey = crypto.randomBytes(32).toString("hex");
  const hookSecret = crypto.randomBytes(24).toString("hex");
  const dir = path.join(INSTANCES_DIR, String(reseller.id));
  await UpdateReseller(
    { id: reseller.id },
    { api_key_hash: sha256(apiKey), hook_secret: hookSecret, port: BASE_PORT + reseller.id, dir, deploy_status: "deploying", last_error: null }
  );
  const fresh = await SelectReseller({ id: reseller.id });
  try {
    copyCode(dir);
    writeEnv(fresh, apiKey);
    await installDeps(dir);
    return fresh;
  } catch (error) {
    await UpdateReseller({ id: reseller.id }, { deploy_status: "failed", last_error: String(error?.message || error) });
    throw error;
  }
};

// Legacy rows (created before the API architecture) or wiped folders get rebuilt.
const ensureProvisioned = async (reseller) => {
  if (reseller.dir && reseller.api_key_hash && fs.existsSync(path.join(reseller.dir, ".env"))) {
    const versionFile = path.join(reseller.dir, ".template-version");
    const current = fs.existsSync(versionFile) ? fs.readFileSync(versionFile, "utf8") : "";
    // template code was updated on the main server -> refresh the clone's code
    if (current !== templateVersion()) copyCode(reseller.dir);
    await installDeps(reseller.dir);
    return reseller;
  }
  return provisionReseller(reseller);
};

// ------------------------------------------------------------- processes ---

// kills an orphaned instance left over from a crashed main process (only when
// /proc proves the pid really is the instance running from this folder)
const killStale = (dir) => {
  try {
    const pid = Number(fs.readFileSync(path.join(dir, "instance.pid"), "utf8"));
    if (!pid || pid === process.pid) return;
    if (fs.realpathSync(`/proc/${pid}/cwd`) === fs.realpathSync(dir)) process.kill(pid, "SIGTERM");
  } catch (error) {
    // no stale process
  }
};

const spawnInstance = (reseller) => {
  killStale(reseller.dir);
  fs.mkdirSync(path.join(reseller.dir, "logs"), { recursive: true });
  const log = fs.openSync(path.join(reseller.dir, "logs", "instance.log"), "a");
  const child = spawn(process.execPath, ["index.js"], {
    cwd: reseller.dir,
    stdio: ["ignore", log, log],
    // the clone never inherits the main bot's secrets - it reads its own .env
    env: { PATH: process.env.PATH, HOME: process.env.HOME, TZ: process.env.TZ, NODE_ENV: "production" },
  });
  const entry = { child, stopping: false, startedAt: Date.now() };
  children.set(reseller.id, entry);
  fs.writeFileSync(path.join(reseller.dir, "instance.pid"), String(child.pid));
  UpdateReseller({ id: reseller.id }, { deploy_status: "running" }).catch(() => {});

  child.on("exit", async (code) => {
    try {
      fs.closeSync(log);
    } catch (error) {}
    if (entry.stopping || children.get(reseller.id) !== entry) return;
    children.delete(reseller.id);
    const fresh = await SelectReseller({ id: reseller.id }).catch(() => null);
    if (!fresh || fresh.status !== "active") return;
    const crashes = Date.now() - entry.startedAt > 60000 ? 0 : (restartCounts.get(reseller.id) || 0) + 1;
    restartCounts.set(reseller.id, crashes);
    const delay = Math.min(2000 * 2 ** crashes, 60000);
    console.error(`[Reseller ${reseller.id}] instance exited (${code}), restarting in ${delay}ms`);
    await UpdateReseller({ id: reseller.id }, { deploy_status: "failed", last_error: `exit code ${code}` }).catch(() => {});
    setTimeout(() => {
      SelectReseller({ id: reseller.id })
        .then((row) => {
          if (row && row.status === "active" && !children.has(row.id)) spawnInstance(row);
        })
        .catch(() => {});
    }, delay);
  });
  return entry;
};

const stopResellerBot = (resellerId) =>
  new Promise((resolve) => {
    const entry = children.get(resellerId);
    if (!entry || !entry.child) return resolve();
    entry.stopping = true;
    children.delete(resellerId);
    const timer = setTimeout(() => entry.child.kill("SIGKILL"), 5000);
    entry.child.once("exit", () => {
      clearTimeout(timer);
      UpdateReseller({ id: resellerId }, { deploy_status: "stopped" }).catch(() => {});
      resolve();
    });
    entry.child.kill("SIGTERM");
  });

const stopAllResellerBots = () => {
  for (const [, entry] of children) {
    entry.stopping = true;
    try {
      entry.child?.kill("SIGTERM");
    } catch (error) {}
  }
  children.clear();
};

// (re)starts one isolated instance
const launchResellerBot = async (reseller) => {
  await stopResellerBot(reseller.id);
  try {
    const row = await SelectReseller({ id: reseller.id });
    if (!row) return null;
    const ready = await ensureProvisioned(row);
    spawnInstance(ready);
    return ready;
  } catch (error) {
    console.error(`[Reseller ${reseller.id}] launch failed:`, error.message);
    await UpdateReseller({ id: reseller.id }, { deploy_status: "failed", last_error: String(error?.message || error) });
    throw error;
  }
};

const launchAllActiveResellers = async () => {
  const resellers = await SelectActiveResellers();
  for (const reseller of resellers) {
    if (reseller.status !== "active") continue;
    try {
      await launchResellerBot(reseller);
    } catch (error) {
      // one broken instance must never prevent the others from starting
    }
  }
};

// deploys a brand-new reseller and starts it (used right after a valid token)
const deployAndLaunch = async (reseller) => {
  const fresh = await provisionReseller(reseller);
  spawnInstance(fresh);
  return fresh;
};

// removes the code + database of an instance completely
const destroyReseller = async (resellerId) => {
  const reseller = await SelectReseller({ id: resellerId });
  await stopResellerBot(resellerId);
  if (reseller?.dir && path.resolve(reseller.dir).startsWith(INSTANCES_DIR + path.sep)) {
    fs.rmSync(reseller.dir, { recursive: true, force: true });
  }
};

const isInstanceRunning = (resellerId) => children.has(resellerId);

// ----------------------------------------------------------------- hooks ---

// Signed push from the main bot to one isolated instance (instant sync).
const notifyReseller = async (reseller, event, payload = {}) => {
  if (!reseller?.port || !reseller.hook_secret) return false;
  const body = JSON.stringify({ event, payload, ts: Date.now() });
  const signature = crypto.createHmac("sha256", reseller.hook_secret).update(body).digest("hex");
  try {
    await axios.post(`http://127.0.0.1:${reseller.port}/internal/sync`, body, {
      headers: { "Content-Type": "application/json", "X-Signature": signature },
      timeout: 3000,
    });
    return true;
  } catch (error) {
    return false;
  }
};

const broadcastToResellers = async (event, payload = {}) => {
  const rows = await SelectResellersWithPort();
  await Promise.allSettled(rows.filter((row) => children.has(row.id)).map((row) => notifyReseller(row, event, payload)));
};

// ------------------------------------------------------------ validation ---

const validateBotToken = async (token) => {
  try {
    const probe = new Telegraf(token);
    const me = await probe.telegram.getMe();
    return { valid: true, username: me.username };
  } catch (error) {
    return { valid: false };
  }
};

export {
  ensureResellerSchema,
  validateBotToken,
  launchResellerBot,
  stopResellerBot,
  stopAllResellerBots,
  launchAllActiveResellers,
  deployAndLaunch,
  destroyReseller,
  isInstanceRunning,
  notifyReseller,
  broadcastToResellers,
};
