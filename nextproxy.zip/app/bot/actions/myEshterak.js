import Servise from "../model/servise.js";
import { CountServise, SelectALLServiseUser, SelectServise as SelectServiseRow } from "../../controllers/Servise.js";
import { SelectSetting } from "../../controllers/Setting.js";

const MyEshterak = {
  BACKESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    try {
      await ctx.deleteMessage(ctx.update.callback_query.message.message_id);
    } catch (error) {
      console.log(error);
    }
    await MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch });
  },
  // back info
  BACKINFO: async ({ ctx, i18n, menu }) => {
    return MyEshterak.PAGE({ ctx, i18n, menu, isMatch: ["PAGE_1"] });
  },
  // action my eshterak
  MYESHTERAK: async ({ ctx, i18n, menu, isMatch, edit }) => {
    const id = isMatch[0].split("_")[1];
    // class servise
    const servises = new Servise();
    const getServise = await servises.SelectServise({ id, i18n });

    // not found servise
    if (!getServise) return ctx.editMessageText(i18n.t("MY_ESHTERAK.ERROR_PAGE"));
    try {
      await ctx.answerCbQuery(i18n.t("MY_ESHTERAK.LOAD_PAGE"));
    } catch (error) {}
    const {
      panel,
      status,
      keyboard,
      location,
      time,
      remaining,
      traffic,
      used_traffic,
      status_api,
      internal,
      tunel,
      name,
      subscription_url,
    } = getServise;
    if (!status) return ctx.reply(i18n.t("MY_ESHTERAK.ERROR_CONNECT_AXIOS"));
    // بررسی امکان لغو و مرجوعی سرویس (تازه خریداری شده)
    let canRefund = false;
    try {
      const raw = await SelectServiseRow({ id });
      if (raw && raw.price > 0 && !raw.free && !raw.refunded_at) {
        const setting = await SelectSetting();
        if (setting.refund_enabled) {
          const hoursPassed = (Date.now() - new Date(raw.createdAt).getTime()) / 3600000;
          if (hoursPassed <= Number(setting.refund_hours || 0)) canRefund = true;
        }
      }
    } catch (error) {}
    // send status eshterak
    const textsend = i18n.t(panel == "sanae" ? "MY_ESHTERAK.SEE_ESHTERAK_SANAE" : "MY_ESHTERAK.SEE_ESHTERAK_MARZBAN", {
      id,
      location,
      status,
      time,
      traffic,
      remaining,
      used_traffic,
      internal,
      tunel,
      name,
      token: subscription_url,
    });
    if (edit)
      return ctx.editMessageText(textsend, {
        ...menu.InfoMyestErakkeyboard(id, keyboard, status_api, canRefund),
        disable_web_page_preview: true,
        parse_mode: "html",
      });
    ctx.replyWithHTML(textsend, {
      ...menu.InfoMyestErakkeyboard(id, keyboard, status_api, canRefund),
      disable_web_page_preview: true,
    });
  },
  // update eshterak
  UPDATE_ESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    await ctx.answerCbQuery(i18n.t("MY_ESHTERAK.SUCCEFULY_UPDATE"));
    try {
      await ctx.deleteMessage(ctx.update.callback_query.message.message_id);
    } catch (error) {}
    await MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch });
  },
  // ______________ page eshterak ______________ //
  PAGE: async ({ ctx, i18n, menu, isMatch }) => {
    const countServise = await CountServise({ telegram_id: ctx.from.id });
    const page = Number(isMatch[0].split("_")[1]);
    if (countServise.length < 1) return ctx.editMessageText(i18n.t("MY_ESHTERAK.NOT_FOUND_MY_ESHTERAK"));
    ctx.answerCbQuery(i18n.t("MY_ESHTERAK.LOAD_PAGE"));
    // paganiation in my eshterak
    const servises = await SelectALLServiseUser({
      telegram_id: ctx.from.id,
      offset: (page - 1) * 10,
      limit: 10,
    });
    if (servises.length < 1) return ctx.editMessageText(i18n.t("MY_ESHTERAK.ERROR_PAGE"));
    ctx.editMessageText(
      i18n.t("MY_ESHTERAK.MY_ESHTERAK", { count: countServise }),
      await menu.Myeshterakkeyboard(servises, page, countServise)
    );
  },
};

export default MyEshterak;
