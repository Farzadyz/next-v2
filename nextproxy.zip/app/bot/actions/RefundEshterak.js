import { SelectServise } from "../../controllers/Servise.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { UpdateUser, selectUser } from "../../controllers/Users.js";
import { CreateFree } from "../../controllers/Free.js";
import Servise from "../model/servise.js";

// بررسی امکان لغو و مرجوعی یک سرویس
async function checkEligibility(idServise) {
  const setting = await SelectSetting();
  if (!setting.refund_enabled) {
    return { ok: false, key: "REFUND.DISABLED" };
  }
  const servise = await SelectServise({ id: idServise });
  if (!servise) {
    return { ok: false, key: "REFUND.NOT_FOUND" };
  }
  if (!servise.price || servise.price <= 0 || servise.free || servise.refunded_at) {
    return { ok: false, key: "REFUND.NOT_ELIGIBLE" };
  }
  const hours = Number(setting.refund_hours || 0);
  const hoursPassed = (Date.now() - new Date(servise.createdAt).getTime()) / 3600000;
  if (hoursPassed > hours) {
    return { ok: false, key: "REFUND.EXPIRED", data: { hours } };
  }
  return { ok: true, servise, setting };
}

const Refund = {
  // نمایش تایید لغو و مرجوعی
  REFUNDESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    const idServise = isMatch[0].split("_")[1];
    const check = await checkEligibility(idServise);
    if (!check.ok) {
      return ctx.answerCbQuery(i18n.t(check.key, check.data || {}), { show_alert: true });
    }
    const { id, name, price } = check.servise;
    ctx.editMessageText(i18n.t("REFUND.ALERT", { id, name, price }), {
      ...menu.RefundEshterakinlineKeyboard(id),
      parse_mode: "html",
    });
  },
  // انجام لغو و مرجوعی نهایی
  VERIFYREFUNDESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    const idServise = isMatch[0].split("_")[1];
    const check = await checkEligibility(idServise);
    if (!check.ok) {
      return ctx.editMessageText(i18n.t(check.key, check.data || {}), { parse_mode: "html" });
    }
    const { id, name, price, telegram_id } = check.servise;
    // حذف سرویس از پنل و دیتابیس
    const servises = new Servise();
    await servises.DeleteServise({ id });
    // بازگشت وجه به کیف پول کاربر
    const user = await selectUser({ id: telegram_id });
    if (user) {
      await UpdateUser({ id: telegram_id }, { price: user.price + Number(price) });
      await CreateFree({ chat_id: telegram_id, amount: price, type: "refund" });
    }
    ctx.editMessageText(i18n.t("REFUND.SUCCESS", { id, name, price }), { parse_mode: "html" });
  },
};

export default Refund;
