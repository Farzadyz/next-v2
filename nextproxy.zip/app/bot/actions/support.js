import { STATE_LIST } from "../sessions/state.js";

const Support = {
  // answer support
  ANSWERSUPPORT: ({ ctx, i18n, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    ctx.session.asnwer_id = id;
    ctx.session.state = STATE_LIST.SUPPORT_ADMIN;
    ctx.reply(i18n.t("SUPPORT.EDIT"));
  },
};

export default Support;
