import { SelectNowpeyment, UpdateNowpeyment } from "../../controllers/Nowpeyment.js";
import { UpdateUser, selectUser } from "../../controllers/Users.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { CreateFree } from "../../controllers/Free.js";
import { SelectPeyment, UpdatePeyment } from "../../controllers/Peyment.js";
import Servise from "../model/servise.js";
import MyEshterak from "./myEshterak.js";
import { CreateAlert } from "../../controllers/Alert.js";
import Aranex from "../../pay/aranex.js";
import Nowpeyment from "../../pay/nowpeyment.js";

const Pay = {
  // payment nowpeay
  NOWPEY: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    await ctx.answerCbQuery(i18n.t("PARDAZESH"));
    const check = await SelectNowpeyment({ payment_id: id });
    // not found
    if (check?.deposit) return false;
    const nowpey = new Aranex();
    const status = await nowpey.VerifyPayment({ id });
    // payment succefuly
    if (status.result) {
      if (check.idServise) {
        // enable servise
        await UpdatePeyment({ id: check.idServise }, { status: true });
        const { location, types, idPlan, traficc, day, name, defaultname, gift, price } = await SelectPeyment({ id: check.idServise });
        // create api servise
        const Servises = new Servise();
        const { result: results, id: ids } = await Servises.createServise({
          id: ctx.from.id,
          traficc,
          day,
          name,
          idPlan,
          defaultname,
          location,
          types2: types,
          price,
        });
        // error to create
        if (!results) return ctx.reply(i18n.t("ESHTERAK_BUY.ERROR_TO_CREATED"));
        ctx.replyWithHTML(i18n.t("ESHTERAK_BUY.SECCEFULY_PLAN", { id: ids }), menu.MainMenuButtons());
        await UpdateUser({ id: ctx.from.id }, { first_payment: true });
        await MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch: [`new_${ids}`] });
        CreateAlert({ primaryId: ids });
        // send meesage buy
        const { log_buy } = await SelectSetting();
        const gifts = JSON.parse(gift);
        ctx.replyWithHTML(
          i18n.t("ESHTERAK_BUY.NEW_BUY", {
            type: "خرید",
            id: ctx.from.id,
            name: ctx.from.first_name,
            username: ctx.from.username,
            idEshterak: ids,
            pelan: name,
            price,
            day,
            traficc,
            gift: gifts ? i18n.t("ESHTERAK_BUY.LOG_BUY_GIFT", { code: gifts.code, gift: gifts.gift }) : "",
          }),
          {
            chat_id: log_buy,
          }
        );
      } else {
        const selectUsers = await selectUser({ id: ctx.from.id });
        await UpdateUser({ id: ctx.from.id }, { price: selectUsers.price + check.amount, first_payment: true });
        ctx.reply(i18n.t("PAY.NOWPEYMENT.SUCCEFULLY_PEY", { amount: check.amount }));
        // send porsant
        if (selectUsers.inviter) {
          const setting = await SelectSetting();
          const { charge } = JSON.parse(setting.invite);
          const percentageAmount = (charge / 100) * check.amount;
          const userInvier = await selectUser({ id: selectUsers.inviter });
          UpdateUser({ id: selectUsers.inviter }, { price: userInvier.price + percentageAmount });
          CreateFree({ chat_id: selectUsers.inviter, amount: percentageAmount, type: "charge" });
          ctx.replyWithHTML(i18n.t("PRICE.SEND_INVITE", { percentageAmount }), { chat_id: selectUsers.inviter });
        }
      }
      return ctx.deleteMessage();
    } else {
      ctx.reply(i18n.t("PAY.NOWPEYMENT.DEFAULT_PEY"));
    }
  },
  // check real NowPayments crypto payment (wallet top-up or config invoice)
  NOWCRYPTOCHECK: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    await ctx.answerCbQuery(i18n.t("CRYPTO.CHECKING"));
    const check = await SelectNowpeyment({ id });
    if (!check) return ctx.reply(i18n.t("CRYPTO.NOT_FOUND"));
    if (check.deposit) return ctx.reply(i18n.t("CRYPTO.ALREADY_DONE"));
    const setting = await SelectSetting();
    const nowpay = new Nowpeyment(setting.nowpayments_api_key);
    const status = await nowpay.PaymentStatus(check.payment_id);
    const paid = status && ["finished", "confirmed", "partially_paid"].includes(status.payment_status);
    if (!paid) return ctx.reply(i18n.t("CRYPTO.PENDING"));
    await UpdateNowpeyment(check.id, { status: true, deposit: true });
    if (check.idServise) {
      // enable servise (config invoice payment)
      await UpdatePeyment({ id: check.idServise }, { status: true });
      const { location, types, idPlan, traficc, day, name, defaultname, gift, price } = await SelectPeyment({ id: check.idServise });
      // create api servise
      const Servises = new Servise();
      const { result: results, id: ids } = await Servises.createServise({
        id: ctx.from.id,
        traficc,
        day,
        name,
        idPlan,
        defaultname,
        location,
        types2: types,
        price,
      });
      // error to create
      if (!results) return ctx.reply(i18n.t("ESHTERAK_BUY.ERROR_TO_CREATED"));
      ctx.replyWithHTML(i18n.t("ESHTERAK_BUY.SECCEFULY_PLAN", { id: ids }), menu.MainMenuButtons());
      await UpdateUser({ id: ctx.from.id }, { first_payment: true });
      await MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch: [`new_${ids}`] });
      CreateAlert({ primaryId: ids });
      // send meesage buy
      const { log_buy } = await SelectSetting();
      const gifts = JSON.parse(gift);
      ctx.replyWithHTML(
        i18n.t("ESHTERAK_BUY.NEW_BUY", {
          type: "خرید",
          id: ctx.from.id,
          name: ctx.from.first_name,
          username: ctx.from.username,
          idEshterak: ids,
          pelan: name,
          price,
          day,
          traficc,
          gift: gifts ? i18n.t("ESHTERAK_BUY.LOG_BUY_GIFT", { code: gifts.code, gift: gifts.gift }) : "",
        }),
        {
          chat_id: log_buy,
        }
      );
    } else {
      // credit wallet (top up)
      const selectUsers = await selectUser({ id: ctx.from.id });
      await UpdateUser({ id: ctx.from.id }, { price: selectUsers.price + Number(check.amount), first_payment: true });
      ctx.reply(i18n.t("CRYPTO.SUCCESS_CHARGE", { amount: check.amount }));
      // send porsant (referral bonus)
      if (selectUsers.inviter) {
        const { invite } = await SelectSetting();
        const { charge } = JSON.parse(invite);
        const percentageAmount = (charge / 100) * Number(check.amount);
        const userInvier = await selectUser({ id: selectUsers.inviter });
        UpdateUser({ id: selectUsers.inviter }, { price: userInvier.price + percentageAmount });
        CreateFree({ chat_id: selectUsers.inviter, amount: percentageAmount, type: "charge" });
        ctx.replyWithHTML(i18n.t("PRICE.SEND_INVITE", { percentageAmount }), { chat_id: selectUsers.inviter });
      }
    }
    return ctx.deleteMessage();
  },
};

export default Pay;
