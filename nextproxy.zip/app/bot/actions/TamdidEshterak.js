import Servise from "../model/servise.js";
import { CreatePeyment, SelectPeyment, UpdatePeyment } from "../../controllers/Peyment.js";
import { UpdateUser, selectUser } from "../../controllers/Users.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { CreateAlert, SelectAlert, UpdateAlert } from "../../controllers/Alert.js";
import { NumberFormat } from "../utils/utils.js";

const Tamdid = {
  // tamdid eshterak
  TAMDID_ESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_");
    // class servise
    const servises = new Servise();
    const id = match[1];
    const getServise = await servises.StatusTamdid({ id, i18n });
    // not found servise
    if (!getServise) return ctx.answerCbQuery(i18n.t("MY_ESHTERAK.TAMDID.ERROR_TAMDID"));
    const { status, price, traficc, time, location, types, panel, type } = getServise;
    // have day and value
    if (status && !match[2]) return ctx.editMessageText(i18n.t("MY_ESHTERAK.TAMDID.HAVE_ON"), menu.TamdidinlineKeyboardOne(id));
    // check upgerade
    const user = await selectUser({ id: ctx.from.id });
    if (user.agent && type == "normal") {
      const { darsad, number } = JSON.parse(user.agent_price);
      var percentageAmount = price - (price * (price > 100000 ? darsad : number)) / 100;
      if (price != percentageAmount) {
        var newprice = `<del>${NumberFormat(price)}</del> ${NumberFormat(percentageAmount)}`;
      }
    }

    // create peyment
    const peyment = await CreatePeyment({
      location,
      types,
      idServise: id,
      price: percentageAmount ?? price,
      name: "تمدید",
      day: time,
      traficc,
      telegram_id: ctx.from.id,
      panel,
    });
    ctx.editMessageText(i18n.t("MY_ESHTERAK.TAMDID.TAMDID_ESHTERAK", { id, time, price: newprice ?? NumberFormat(price), traficc }), {
      ...menu.TamdidEshterak(peyment),
      parse_mode: "html",
    });
  },
  // Fainal tamdid
  FAINAL_TAMDID: async ({ ctx, i18n, isMatch }) => {
    const peyment = isMatch[0].split("_")[1];
    // select peyment
    const { price, status, day, idServise, name, traficc } = await SelectPeyment({ id: peyment });
    //  peyment again error
    if (status) return ctx.editMessageText(i18n.t("ESHTERAK_BUY.PEYMENT_AGGIN_ERROR"));
    // no price
    const userData = await selectUser({ id: ctx.from.id });
    if (userData.price < price) return ctx.answerCbQuery(i18n.t("ESHTERAK_BUY.NO_PRICE", { price: userData.price }), { show_alert: true });
    // update price && update eshterak
    // class servise
    const servises = new Servise();
    const result = await servises.Tamdid({ id: idServise, day });
    if (!result) return ctx.reply(i18n.t("MY_ESHTERAK.TAMDID.ERROR"));
    await UpdateUser({ id: ctx.from.id }, { price: userData.price - price });
    await UpdatePeyment({ id: peyment }, { status: true });
    ctx.editMessageText(i18n.t("MY_ESHTERAK.TAMDID.SUCCEFULY_TAMDID"));
    // insert and update alert
    const alert = await SelectAlert({ primaryId: idServise });
    if (alert) {
      UpdateAlert({ primaryId: idServise }, { alertValue: false, alertDate: false });
    } else {
      CreateAlert({ primaryId: idServise });
    }
    // send meesage buy
    const { log_buy } = await SelectSetting();
    ctx.replyWithHTML(
      i18n.t("ESHTERAK_BUY.NEW_BUY", {
        type: "تمدید",
        id: ctx.from.id,
        name: ctx.from.first_name,
        username: ctx.from.username,
        idEshterak: idServise,
        pelan: name,
        price,
        day,
        traficc,
        gift: "",
      }),
      {
        chat_id: log_buy,
      }
    );
  },
};

export default Tamdid;
