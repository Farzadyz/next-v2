import { STATE_LIST } from "../sessions/state.js";
import { CreateCard } from "../../controllers/Card.js";
import { handleRandom, NumberFormat } from "../utils/utils.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { CountPeystar, CreatePeystar } from "../../controllers/Paystar.js";
import { CreateNowpeyment } from "../../controllers/Nowpeyment.js";
import { CountAtlasPay, CreateAtlasPay } from "../../controllers/AtlasPay.js";
import { CreateZarinpal } from "../../controllers/Zarinpal.js";
import Paystar from "../../pay/paystar.js";
import Nowpeyment, { ToUsd } from "../../pay/nowpeyment.js";
import AtlasPay from "../../pay/atlaspay.js";
import ZarinPal from "../../pay/zarinpal.js";
import axios from "axios";
import Zibals from "../../pay/zibal.js";
import { CreateZibal } from "../../controllers/Zibal.js";
import { CountNovinpay, CreateNovinpay } from "../../controllers/Novinpay.js";
import NovinPay from "../../pay/novinpal.js";
import Polam from "../../pay/polam.js";
import { CreatePolam } from "../../controllers/Polam.js";
import TuxSwap from "../../pay/tuxswap.js";
import Aranex from "../../pay/aranex.js";
import TabaPay from "../../pay/tabapay.js";
import { CreateTabaPay } from "../../controllers/TabaPay.js";
import SizePay from "../../pay/sizepay.js";
import { CreateSizapay } from "../../controllers/Sizepay.js";
import Zirgozar from "../../pay/zirgozar.js";
import { CreateZirgozar } from "../../controllers/Zirgozar.js";
import TetraPay from "../../pay/terapay.js";
import { CreateTerapay } from "../../controllers/Terapay.js";
import Rialit from "../../pay/rialit.js";
import { CountRialit, CreateRialit } from "../../controllers/Rialit.js";

const Price = {
  // charge account
  CHARGE: async ({ ctx, i18n, menu }) => {
    const setting = await SelectSetting();
    const pay = JSON.parse(setting.pay).filter((e) => e.value == true);
    // error not pay
    if (pay.length < 1) return ctx.reply(i18n.t("PRICE.NONE_TYPE"));
    ctx.session.state = STATE_LIST.COUNT_PRICE;
    ctx.reply(i18n.t("PRICE.ANSWER"), menu.BackButton());
  },
  // create peyment paystar
  PAYSTAR: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    // paystar pal
    const count = await CountPeystar();
    const vendas = new Paystar();
    const create = await vendas.CreatePayment({ amount, order_id: count + 1 });
    if (!create || create.status != 1) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreatePeystar({
      chat_id: ctx.from.id,
      amount,
      ref_num: create.data.ref_num,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_PAYSTAR", { amount: NumberFormat(amount) }), {
      ...menu.Pay("https://core.paystar.ir/api/pardakht/payment?token=" + create.data.token),
    });
  },
  // create peyment card
  CARD: async ({ ctx, i18n, menu, isMatch }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    await ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.BackButton());
    // create pay for payment in database
    const id = await CreateCard({
      chat_id: ctx.from.id,
      amount,
    });
    ctx.session.amount = id;
    ctx.session.state = STATE_LIST.SEND_PHOTO;
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_CARD", { amount: NumberFormat(amount), card: process.env.CARD }));
  },
  // create peyment nowpeyment (crypto - wallet top up) NOWPEYMENT_amount
  NOWPEYMENT: async ({ ctx, i18n, menu, isMatch }) => {
    const amount = isMatch[0].split("_")[1];
    delete ctx.session.state;
    const setting = await SelectSetting();
    if (!setting.nowpayments_enabled) {
      return ctx.reply(i18n.t("CRYPTO.DISABLE"), menu.MainMenuButtons());
    }
    ctx.reply(i18n.t("CRYPTO.CREATE_LOADING"));
    const usdAmount = ToUsd(amount, setting.nowpayments_usd_rate);
    const nowpay = new Nowpeyment(setting.nowpayments_api_key);
    const create = await nowpay.createPeyment(usdAmount, setting.nowpayments_pay_currency || "trx");
    if (!create || !create.pay_address || !create.pay_amount) {
      return ctx.reply(i18n.t("CRYPTO.ERROR_CREATE"), menu.MainMenuButtons());
    }
    const rowId = await CreateNowpeyment({
      chat_id: ctx.from.id,
      amount,
      count: create.pay_amount,
      price_count: usdAmount,
      pay_address: create.pay_address,
      payment_id: String(create.payment_id),
      pay_currency: create.pay_currency,
      idServise: null,
    });
    ctx.replyWithHTML(
      i18n.t("CRYPTO.INVOICE", {
        payAmount: create.pay_amount,
        payCurrency: (create.pay_currency || "").toUpperCase(),
        payAddress: create.pay_address,
      }),
      menu.CryptoInvoice(rowId)
    );
  },
  // create peyment nowpeyment (crypto - config invoice) CRYPTOPAY_amount_idPeyment
  CRYPTOPAY: async ({ ctx, i18n, menu, isMatch }) => {
    const amount = isMatch[0].split("_")[1];
    const idPeyment = isMatch[0].split("_")[2];
    const setting = await SelectSetting();
    if (!setting.nowpayments_enabled) {
      return ctx.answerCbQuery(i18n.t("CRYPTO.DISABLE"), { show_alert: true });
    }
    await ctx.answerCbQuery(i18n.t("CRYPTO.CREATE_LOADING"));
    const usdAmount = ToUsd(amount, setting.nowpayments_usd_rate);
    const nowpay = new Nowpeyment(setting.nowpayments_api_key);
    const create = await nowpay.createPeyment(usdAmount, setting.nowpayments_pay_currency || "trx");
    if (!create || !create.pay_address || !create.pay_amount) {
      return ctx.reply(i18n.t("CRYPTO.ERROR_CREATE"), menu.MainMenuButtons());
    }
    const rowId = await CreateNowpeyment({
      chat_id: ctx.from.id,
      amount,
      count: create.pay_amount,
      price_count: usdAmount,
      pay_address: create.pay_address,
      payment_id: String(create.payment_id),
      pay_currency: create.pay_currency,
      idServise: idPeyment,
    });
    ctx.replyWithHTML(
      i18n.t("CRYPTO.INVOICE", {
        payAmount: create.pay_amount,
        payCurrency: (create.pay_currency || "").toUpperCase(),
        payAddress: create.pay_address,
      }),
      menu.CryptoInvoice(rowId)
    );
  },
  // create peyment zarinpal
  // create peyment tonpays
  ZARINPAL: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    // tonpays
    const zarinpal = new ZarinPal();
    const hash = await handleRandom(20);
    const create = await zarinpal.CreatePayment({
      amount,
      order_id: hash,
      callback_url: `${process.env.URL_DOMAIN}zarinpal`,
    });
    if (!create || !create.invoice_id) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateZarinpal({
      chat_id: ctx.from.id,
      amount,
      authority: create.invoice_id,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_ZARINPAL", { amount: NumberFormat(create.final_amount) }), {
      ...menu.PayTonpays(create.payment_url || create.invoice_url),
    });
  },
  // create peyment zibal
  ZIBAL: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    // zarin pal
    const zibal = new Zibals();
    const create = await zibal.CreatePeyment({ amount });
    if (!create || create.result != 100) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateZibal({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.trackId,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_ZIBAL", { amount: NumberFormat(amount) }), {
      ...menu.Pay("https://gateway.zibal.ir/start/" + create.trackId),
    });
  },
  // create peyment atlaspay
  ATLASPAY: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    // atlaspay
    const count = await CountAtlasPay();
    const atlaspay = new AtlasPay();
    const create = await atlaspay.CreatePayment({ amount, order_id: count + 1, user_id: ctx.from.id });
    if (!create || !create.orderId) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateAtlasPay({
      chat_id: ctx.from.id,
      amount,
      order_id: create.orderId,
      tracking_code: create.trackingCode,
      payment,
    });
    // send message link
    ctx.replyWithHTML(
      i18n.t("PRICE.SUCCESS_ATLASPAY", {
        amount: NumberFormat(create.totalAmountToman),
        trackingCode: create.trackingCode,
      }),
      {
        ...menu.PayAtlaspay(create.customerStartLink),
      }
    );
  },
  // create peyment novinpal
  NOVINPAL: async ({ ctx, i18n, menu, isMatch }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    // venda pal
    const count = await CountNovinpay();
    const vendas = new NovinPay();
    const create = await vendas.CreatePayment({ amount, order_id: count + 1 });
    if (!create || create.status != 1) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateNovinpay({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.refId,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_NOVIN", { amount: NumberFormat(amount) }), {
      ...menu.Pay2("https://nextstory.ir/dragah3.php?token=" + encodeURIComponent(create.refId)),
    });
  },
  // create peyment rialit
  RIALIT: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    // rialit
    const count = await CountRialit();
    const vendas = new Rialit();
    const create = await vendas.CreatePayment({ amount, order_id: count + 1, user_id: ctx.from.id });
    if (!create || create.status != 1) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateRialit({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.token,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_RIALIT", { amount: NumberFormat(amount) }), {
      ...menu.Pay("https://api.rialit.org/api/v1/redirect/" + create.token),
    });
  },
  // create peyment polam
  POLAM: async ({ ctx, i18n, menu, isMatch }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    const vendas = new Polam();
    const create = await vendas.CreatePayment({ price: amount });
    if (!create || create.status != 1) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreatePolam({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.invoice_key,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_VENDA", { amount: NumberFormat(amount) }), {
      ...menu.Pay("https://polam.io/invoice/pay/" + create.invoice_key),
    });
  },
  // create peyment tabapay
  TABAPAY: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    const vendas = new TabaPay();
    const create = await vendas.CreatePeyment({ amount });
    if (!create || create.status != "success") return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateTabaPay({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.token,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_TABAPAY", { amount: NumberFormat(amount) }), {
      ...menu.Pay(create.url),
    });
  },
  // create peyment zirgozar
  ZIRGOZAR: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    const vendas = new Zirgozar();
    const create = await vendas.createPaymentLink({ amount });
    if (!create || !create.result) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateZirgozar({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.token,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_ZIRGOZAR", { amount: NumberFormat(amount) }), {
      ...menu.Pay(create.link),
    });
  },
  // create peyment hooshpay
  TERAPAY: async ({ ctx, i18n, menu, isMatch, payment }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    const vendas = new TetraPay();
    const hash = await handleRandom(20);
    const create = await vendas.createOrder({ amount, hashId: hash });

    if (!create || !create.success) return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateTerapay({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.data.uid,
      payment,
    });
    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_TERAPAY", { amount: NumberFormat(amount) }), {
      ...menu.Pay(create.data.payment_url),
    });
  },
  // create peyment sizpay
  SIZAPAY: async ({ ctx, i18n, menu, isMatch }) => {
    const amount = isMatch[0].split("_")[1];
    // loading create ling
    delete ctx.session.state;
    ctx.reply(i18n.t("PRICE.LODING_CREATE_LINK_MESSAGE"), menu.MainMenuButtons());
    const vendas = new SizePay();
    const create = await vendas.createPayment({ amount });
    if (!create || create.ResCod != "0" || create.ResCod != "00") return ctx.reply(i18n.t("PRICE.ERROR_CREATE_LINK_MESSAGE"));
    // create pay for payment in database
    await CreateSizapay({
      chat_id: ctx.from.id,
      amount,
      trans_id: create.Token,
    });

    // send message link
    ctx.replyWithHTML(i18n.t("PRICE.SUCCESS_SIZAPAY", { amount: NumberFormat(amount) }), {
      ...menu.PaySizpay(process.env.URL_DOMAIN + "sizpay?token=" + create.Token),
    });
  },
};

export default Price;
