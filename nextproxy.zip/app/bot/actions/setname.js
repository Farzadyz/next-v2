import { STATE_LIST } from "../sessions/state.js";

const Setname = {
  // set name
  SETNAME: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    ctx.session.state = STATE_LIST.SETNAME;
    ctx.session.id = id;
    ctx.reply(i18n.t("SETNAME.ANSWER"), menu.BackButton());
  },
};

export default Setname;
