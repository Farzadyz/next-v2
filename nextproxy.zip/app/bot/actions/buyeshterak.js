import { STATE_LIST } from "../sessions/state.js";
import { selectAllPelan, selectAllPelanLocation, selectPelan } from "../../controllers/Pelan.js";
import { UpdateUser, selectUser } from "../../controllers/Users.js";
import { NumberFormat } from "../utils/utils.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { CreatePeyment, SelectPeyment, UpdatePeyment } from "../../controllers/Peyment.js";
import Servise from "../model/servise.js";
import { CreateAlert } from "../../controllers/Alert.js";
import { I18NK } from "../utils/I18n.js";
import { selectAllInboundType, selectFirstInbound, selectInbound } from "../../controllers/Inbound.js";
import MyEshterak from "./myEshterak.js";
import Price from "./price.js";
import moment from "moment";

const BuyEshterak = {
  // back pelan
  BACK_PELAN: async ({ ctx, i18n, menu }) => {
    const setting = await SelectSetting();
    const showpelan = JSON.parse(setting.showpelan);
    let find = showpelan.filter((e) => e.value == true);
    const { free } = await selectUser({ id: ctx.from.id });
    if (free) {
      find = find.filter((e) => e.text != "free");
    }
    // error not pelan
    if (find.length < 1) return ctx.editMessageText(i18n.t("ESHTERAK_BUY.NOT_EXIXST"));
    ctx.editMessageText(i18n.t("ESHTERAK_BUY.BUY_ESHTERAK_MESSAGE"), { ...menu.SelectPelan(find), parse_mode: "html" });
  },
  // select type Location
  PELAN_CHOESE: async ({ ctx, i18n, menu }) => {
    const setting = await SelectSetting();
    ctx.editMessageText(i18n.t("ESHTERAK_BUY.TYPE_PELAN"), menu.TypeLocation(setting.payg_enabled_multi, setting.payg_enabled_single));
  },
  // PELAN_ECONOMIC
  PELAN_ECONOMIC: async ({ ctx, i18n, menu }) => {
    return BuyEshterak.TYPELOCATION({ ctx, i18n, menu, isMatch: ["TYPELOCATION_single_economic"] });
  },
  // show all pelan
  TYPELOCATION: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_");
    ctx.session.typelocation = match[2];
    const allChoosePelean = await selectAllPelanLocation({ connection: match[1], type: match[2] });
    if (allChoosePelean.length < 1) return ctx.answerCbQuery(i18n.t("ESHTERAK_BUY.NOT_EXIXST"), { show_alert: true });

    ctx.editMessageText(i18n.t("ESHTERAK_BUY.CHOOSE"), menu.SelectPelanChoose(allChoosePelean, match[1]));
  },
  // login to customize pelan
  PELAN_CUSTOMIZE: async ({ ctx, i18n, menu }) => {
    ctx.session.state = STATE_LIST.SENDDAY;
    const setting = await SelectSetting();
    const subscribe = JSON.parse(setting.subscribe);
    ctx.session.panellocation = "sanae";
    ctx.replyWithHTML(i18n.t("ESHTERAK_BUY.CUSTOMIZE.DAY", { price: NumberFormat(subscribe.priceD) }), menu.BackButton());
  },
  // send day selectcustumize pelan
  PELAN_SELECTCUSTOMIZE: async ({ ctx, i18n, menu }) => {
    const setting = await SelectSetting();
    const subscribe = JSON.parse(setting.customize);
    ctx.session.panellocation = "sanae";
    ctx.editMessageText(i18n.t("ESHTERAK_BUY.SELECTCUSTOMIZE.DAY"), {
      ...menu.SelectPelanCustumize(subscribe.timeV),
      parse_mode: "html",
    });
  },
  // select day selectcustumize
  CUSTUMIZEDAY: async ({ ctx, i18n, menu, isMatch }) => {
    const day = isMatch[0].split("_")[1];
    ctx.session.time = day;
    const setting = await SelectSetting();
    const subscribe = JSON.parse(setting.customize);
    ctx.editMessageText(i18n.t("ESHTERAK_BUY.SELECTCUSTOMIZE.TRAFFIC"), {
      ...menu.SelectPelanCustumizeTraficc(subscribe.traficcV),
      parse_mode: "html",
    });
  },
  // select trafiic selectcustumize
  CUSTUMIZETRAFICC: async ({ ctx, i18n, menu, isMatch }) => {
    const traficc = isMatch[0].split("_")[1];
    const setting = await SelectSetting();
    const subscribe = JSON.parse(setting.customize);
    const { time } = ctx.session;
    const prices = Number(traficc) * subscribe.traficcP + Number(time) * subscribe.timeP;
    ctx.session.traficc = traficc;
    ctx.session.price = prices;
    ctx.session.name = "انتخابی ، سفارشی";
    ctx.session.type = "select-sefareshi";
    // select servise
    const inbound = JSON.parse(setting.inbound);
    const price = [];
    for (const item of inbound) {
      price.push(item.price);
    }
    ctx.editMessageText(i18n.t("ESHTERAK_BUY.INBOUND.ANSWER", { price_game: price[0], price_web: price[1], price_hybrid: price[2] }), {
      ...menu.SelectServise(I18NK(ctx, "ESHTERAK_BUY.INBOUND.MENU")),
      parse_mode: "html",
    });
  },
  // pelan free
  PELAN_FREE: async ({ ctx, i18n, menu }) => {
    const { free } = await selectUser({ id: ctx.from.id });
    // error get
    if (free) return ctx.answerCbQuery(i18n.t("ESHTERAK_BUY.NO_FREE"));
    await UpdateUser({ id: ctx.from.id }, { free: true });
    // create api servise
    const Servises = new Servise();
    const setting = await SelectSetting();
    const { id: loid } = await selectFirstInbound();

    const { id } = await Servises.createServise({
      location: loid,
      id: ctx.from.id,
      traficc: setting.free,
      day: 1,
      name: "🎁 اشتراک تست",
      free: true,
      defaultname: true,
      types2: "free",
      panel: "sanae",
    });
    ctx.replyWithHTML(i18n.t("ESHTERAK_BUY.SECCEFULY_PLAN", { id }), menu.MainMenuButtons());
    await ctx.deleteMessage();
  },
  // select pelan choose pelean
  CHOOSE: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_");
    ctx.session.id = match[1];
    const { panel } = await selectPelan({ id: match[1] });
    ctx.session.panellocation = panel;
    ctx.session.type = "select";
    const { typelocation } = ctx.session;
    const allPelan = await selectAllInboundType(typelocation);
    if (allPelan.length < 1) return ctx.answerCbQuery(i18n.t("ESHTERAK_BUY.NOT_EXIXST"), { show_alert: true });
    ctx.editMessageText(i18n.t("ESHTERAK_BUY.INBOUND.ANSWER"), {
      ...menu.SelectServise(allPelan),
      parse_mode: "html",
    });
  },
  // select pelan choose pelean
  MZCHOOSE: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_");
    ctx.session.id = match[1];
    const { panel } = await selectPelan({ id: match[1] });
    ctx.session.type = "select";
    ctx.session.panellocation = panel;
    return BuyEshterak.SERVISE({ ctx, i18n, menu, isMatch: ["none_0"] });
  },
  // buy price gift
  BUYPRICEGIFT: async ({ ctx, i18n, menu, isMatch }) => {
    const payment = isMatch[0].split("_")[1];
    const { price, updatedAt } = await SelectPeyment({ id: payment });

    const now = new Date();

    // اختلاف زمان به میلی‌ثانیه
    const diffMs = now - updatedAt;

    // تبدیل به ساعت
    const diffHours = diffMs / (1000 * 60 * 60);

    if (diffHours >= 5) return ctx.editMessageText(i18n.t("ESHTERAK_BUY.ERROR_TIME_GIFT"));
    const { first_payment } = await SelectSetting();
    const user = await selectUser({ id: ctx.from.id });

    ctx.reply(i18n.t("ESHTERAK_BUY.PAYMENT_GIFT"), {
      ...menu.FinalBuy(payment, price, user.first_payment, first_payment, true),
    });
  },
  // select pelan choose pelean
  SERVISE: async ({ ctx, i18n, menu, isMatch }) => {
    const location = isMatch[0].split("_")[1];
    const { id: ids, type: types, panellocation } = ctx.session;
    if (types == "select") {
      var { price, name, time, traficc, type, connection } = await selectPelan({ id: ids });
    } else {
      var { price, name, time, traficc } = ctx.session;
    }

    const selectinbounds = await selectInbound({ id: location });
    // servise vip
    let textservervip = "";
    if (selectinbounds?.price) {
      var price = price + selectinbounds.price;
      textservervip = i18n.t("ESHTERAK_BUY.SERVER_VIP", { price: selectinbounds.price });
    }

    const user = await selectUser({ id: ctx.from.id });
    if (user.agent && selectinbounds?.type == "normal" && type == "normal") {
      const { darsad, number } = JSON.parse(user.agent_price);
      var percentageAmount = price - (price * (price > 100000 ? darsad : number)) / 100;
      if (price != percentageAmount) {
        var newprice = `<del>${NumberFormat(price)}</del> ${NumberFormat(percentageAmount)}`;
      }
    }

    // price trx
    let firsttrxprice = percentageAmount ?? price;
    const { first_payment } = await SelectSetting();

    // create peyment
    const id = await CreatePeyment({
      location,
      types,
      price: percentageAmount ?? price,
      name,
      day: time,
      traficc,
      telegram_id: ctx.from.id,
      idPlan: ids,
      panel: panellocation,
      connection,
    });
    ctx.editMessageText(
      i18n.t("ESHTERAK_BUY.FIANAL_BUY", {
        newPrice: newprice ?? NumberFormat(price),
        pelan: name,
        location: selectinbounds?.location || i18n.t("ESHTERAK_BUY.MULTI"),
        time,
        traficc,
        textservervip,
      }),
      {
        ...menu.FinalBuy(id, firsttrxprice, user.first_payment, first_payment),
        parse_mode: "html",
      }
    );
  },
  // create and peyment servise which dargah
  PEYDARGAH: async ({ ctx, i18n, menu, isMatch }) => {
    const payment = isMatch[0].split("_")[1];
    const { price, status } = await SelectPeyment({ id: payment });
    // error peyment
    if (status) return ctx.editMessageText(i18n.t("ESHTERAK_BUY.PEYMENT_AGGIN_ERROR"));
    const { default_pay } = await SelectSetting();
    return Price[default_pay]({ ctx, i18n, menu, isMatch: ["ok_" + price], payment });
  },
  // create and peyment servise which dargah (card to card switch)
  PEYDARGAHCARD: async ({ ctx, i18n, menu, isMatch }) => {
    const payment = isMatch[0].split("_")[1];
    const { price, status } = await SelectPeyment({ id: payment });
    // error peyment
    if (status) return ctx.editMessageText(i18n.t("ESHTERAK_BUY.PEYMENT_AGGIN_ERROR"));
    const { default_pay_card } = await SelectSetting();
    return Price[default_pay_card]({ ctx, i18n, menu, isMatch: ["ok_" + price], payment });
  },
  // create and peyment servise
  PEYMENT: async ({ ctx, i18n, menu, isMatch }) => {
    const idPeyment = isMatch[0].split("_")[1];
    const idUser = ctx.from.id;
    const { location, types, price, idPlan, traficc, status, day, name, gift, defaultname, panel, connection } = await SelectPeyment({
      id: idPeyment,
    });
    // error peyment
    if (status) return ctx.editMessageText(i18n.t("ESHTERAK_BUY.PEYMENT_AGGIN_ERROR"));
    // no price kafi
    const userData = await selectUser({ id: idUser });
    if (userData.price < price) return ctx.answerCbQuery(i18n.t("ESHTERAK_BUY.NO_PRICE"), { show_alert: true });
    await UpdatePeyment({ id: idPeyment }, { status: true });
    // create api servise
    const { message_id } = await ctx.reply("⏳");
    const Servises = new Servise();
    const { result, id } = await Servises.createServise({
      id: ctx.from.id,
      traficc,
      day,
      name,
      idPlan,
      defaultname,
      location,
      types2: types,
      panel,
      price,
    });
    try {
      await ctx.deleteMessage(message_id);
    } catch (error) {}
    // error to create
    if (!result) return ctx.reply(i18n.t("ESHTERAK_BUY.ERROR_TO_CREATED"));
    await UpdateUser({ id: ctx.from.id }, { price: userData.price - price, first_payment: true });
    ctx.replyWithHTML(i18n.t("ESHTERAK_BUY.SECCEFULY_PLAN", { id }), menu.MainMenuButtons());
    await MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch: [`new_${id}`] });
    try {
      await ctx.deleteMessage();
    } catch (error) {}
    // insert to alert
    CreateAlert({ primaryId: id });
    // send meesage buy
    const { log_buy } = await SelectSetting();
    const gifts = JSON.parse(gift);
    ctx.replyWithHTML(
      i18n.t("ESHTERAK_BUY.NEW_BUY", {
        type: "خرید",
        id: idUser,
        name: ctx.from.first_name,
        username: ctx.from.username,
        idEshterak: id,
        pelan: name,
        price,
        day,
        traficc,
        gift: gifts ? i18n.t("ESHTERAK_BUY.LOG_BUY_GIFT", { code: gifts.code, gift: gifts.gift }) : "",
      }),
      {
        chat_id: log_buy,
      }
    );
  },
};

export default BuyEshterak;
