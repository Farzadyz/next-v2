import { Input } from "telegraf";

import { DeleteServise, SelectServise } from "../../controllers/Servise.js";
import { generateQR } from "../utils/qrcode.js";
import Servise from "../model/servise.js";
import MyEshterak from "./myEshterak.js";
import { STATE_LIST } from "../sessions/state.js";

const Utils = {
  // delete eshterak
  DELETEESHTERAK: async ({ ctx, menu, i18n, isMatch }) => {
    const idServise = isMatch[0].split("_")[1];
    const servise = await SelectServise({ id: idServise });
    if (!servise) return ctx.editMessageText(i18n.t("MY_ESHTERAK.ERROR_PAGE"));
    const { id, name } = servise;
    ctx.editMessageText(i18n.t("MY_ESHTERAK.DELETE.ALERT", { id, name }), {
      ...menu.DeleteEshterakinlineKeyboard(id),
      parse_mode: "html",
    });
  },
  // verify delete eshterak
  VERIFYDELETEESHTERAK: async ({ ctx, i18n, isMatch }) => {
    const idServise = isMatch[0].split("_")[1];
    const servise = await SelectServise({ id: idServise });
    const { id, name } = servise;
    const servises = new Servise();
    servises.DeleteServise({ id });
    ctx.editMessageText(i18n.t("MY_ESHTERAK.DELETE.SUCCEFULY", { id, name }), { parse_mode: "html" });
  },
  // change password secret
  CHANGEPASESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    const idServise = isMatch[0].split("_")[1];
    ctx.editMessageText(i18n.t("MY_ESHTERAK.CHANGEPASS.ANSWER"), menu.ChangePasswordinlineKeyboard(idServise));
  },
  // ______________ 𝕮𝖍𝖆𝖓𝖌𝖊 𝕻𝖆𝖘𝖘 𝕰𝖘𝖍𝖙𝖊𝖗𝖆𝖐 ______________ //
  VERIFYCHANGEPASESHTERAK: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    //  revoke sub
    const servises = new Servise();
    await servises.Revokelink({ id });
    ctx.editMessageText(i18n.t("MY_ESHTERAK.CHANGEPASS.SUCCFULLY", { id }), {
      ...menu.UpdateEshterakinlineKeyboard(id),
      parse_mode: "html",
    });
  },
  // QR code
  QRCODE: async ({ ctx, i18n, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    //  revoke sub
    // class servise
    const servises = new Servise();
    const getServise = await servises.SelectServise({ id, i18n });
    // not found servise
    if (!getServise) return ctx.editMessageText(i18n.t("MY_ESHTERAK.ERROR_PAGE"));
    if (getServise.panel == "marzban") return ctx.sendPhoto(Input.fromBuffer(await generateQR(getServise.subscription_url)));
    ctx.sendPhoto(Input.fromBuffer(await generateQR(getServise.internal)), {
      caption: i18n.t("MY_ESHTERAK.QRCODE.INTER"),
    });
    ctx.sendPhoto(Input.fromBuffer(await generateQR(getServise.tunel)), {
      caption: i18n.t("MY_ESHTERAK.QRCODE.TUNEL"),
    });
  },
  // change status
  CHANGESTATUS: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    // class servise
    const servises = new Servise();
    await servises.ChangeStatus({ id });
    return MyEshterak.MYESHTERAK({ ctx, i18n, menu, isMatch: ["my_" + id], edit: true });
  },
  // redireact
  REDIRECT: async ({ ctx, menu, i18n, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const servise = await SelectServise({ id });
    if (!servise) return ctx.editMessageText(i18n.t("MY_ESHTERAK.ERROR_PAGE"));
    ctx.session.state = STATE_LIST.REDIRECT;
    ctx.session.id = id;
    ctx.reply(i18n.t("MY_ESHTERAK.REDIRECT.ANSWER"), {
      ...menu.BackButton(),
    });
  },
};

export default Utils;
