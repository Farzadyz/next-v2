import { CreateAlert, SelectAlert, UpdateAlert } from "../../controllers/Alert.js";
import { selectAllUpgrade, selectUpgrade } from "../../controllers/Upgrade.js";
import { selectUser, UpdateUser } from "../../controllers/Users.js";
import Servise from "../model/servise.js";
import { NumberFormat } from "../utils/utils.js";

const Upgrade = {
  // upgrade eshterak
  UPGERATE: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    // class servise
    const servises = new Servise();
    const getServise = await servises.SelectServiseAlert({ id, i18n });
    // flo upgrade
    if ((getServise.used_traffic * 100) / getServise.traffic >= 80 === false)
      return ctx.answerCbQuery(i18n.t("MY_ESHTERAK.UPGERADE.FLO_UPGERADE"), { show_alert: true });
    const Allupgrade = await selectAllUpgrade();
    // null
    if (Allupgrade.length < 1) return ctx.answerCbQuery(i18n.t("MY_ESHTERAK.UPGERADE.NULLS"));
    ctx.reply(i18n.t("MY_ESHTERAK.UPGERADE.SELECT_GIG"), menu.Upgerateeshterak(id, Allupgrade));
  },
  // fianal upgrade
  FAINALUPGERADE: async ({ ctx, i18n, menu, isMatch }) => {
    const match = isMatch[0].split("_");
    const { price, traficc } = await selectUpgrade({ id: match[2] });
    const user = await selectUser({ id: ctx.from.id });
    if (user.agent) {
      const { darsad, number } = JSON.parse(user.agent_price);
      var percentageAmount = price - (price * (price > 100000 ? darsad : number)) / 100;
      if (price != percentageAmount) {
        var newprice = `<del>${NumberFormat(price)}</del> ${NumberFormat(percentageAmount)}`;
      }
    }

    ctx.editMessageText(
      i18n.t("MY_ESHTERAK.UPGERADE.UPGERATE_ESHTERAK", { id: match[1], price: newprice ?? NumberFormat(price), traficc }),
      {
        ...menu.FainalUpgeradeEshterak(match[1], match[2]),
        parse_mode: "html",
      }
    );
  },
  // ertega upgrade
  ERTEGA: async ({ ctx, i18n, isMatch }) => {
    const match = isMatch[0].split("_");
    var { price, traficc } = await selectUpgrade({ id: match[2] });
    const userData = await selectUser({ id: ctx.from.id });
    if (userData.agent) {
      const { darsad, number } = JSON.parse(userData.agent_price);
      var percentageAmount = price - (price * (price > 100000 ? darsad : number)) / 100;
      var price = percentageAmount ?? price;
    }

    // no price
    if (userData.price < price) return ctx.answerCbQuery(i18n.t("ESHTERAK_BUY.NO_PRICE", { price: userData.price }), { show_alert: true });

    const servises = new Servise();
    const result = await servises.upgradeServise({ id: match[1], traficc, idUpgarade: match[2] });
    if (!result) return ctx.reply(i18n.t("MY_ESHTERAK.TAMDID.ERROR"));
    // update user
    await UpdateUser({ id: ctx.from.id }, { price: userData.price - price });
    ctx.editMessageText(i18n.t("MY_ESHTERAK.UPGERADE.SUCCEFULY_UPGERADE"));
    // insert and update alert
    const alert = await SelectAlert({ primaryId: match[1] });
    if (alert) {
      UpdateAlert({ primaryId: match[1] }, { alertValue: false });
    } else {
      CreateAlert({ primaryId: match[1] });
    }
  },
};

export default Upgrade;
