import { SelectSetting } from "../../controllers/Setting.js";
import { UpdateUser, selectUser } from "../../controllers/Users.js";
import { selectAllInboundType } from "../../controllers/Inbound.js";
import { CreatePaygService } from "../../controllers/PaygService.js";
import { NumberFormat } from "../utils/utils.js";
import Servise from "../model/servise.js";

// محاسبه حجم/روز اولیه سرویس PAYG بر اساس تنظیمات ادمین
// حالت fixed: مقادیر ثابتی که ادمین دستی وارد کرده
// حالت auto: بر اساس موجودی باقیمانده کیف پول (بعد از کسر هزینه ایجاد) و نرخ روزانه/مصرف مخصوص همان نوع پلن (مولتی یا تک لوکیشن) محاسبه می‌شود
const calcInitial = ({ setting, remainingBalance, panel }) => {
  if (setting.payg_initial_mode === "auto") {
    const dailyRate = Number((panel === "wiguard" ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0);
    const dataRate = Number((panel === "wiguard" ? setting.payg_data_rate_multi : setting.payg_data_rate_single) || 0);
    const traficc = dataRate > 0 ? Math.max(1, Math.floor(remainingBalance / dataRate)) : 1;
    const day = dailyRate > 0 ? Math.max(1, Math.floor(remainingBalance / dailyRate)) : 1;
    return { traficc, day };
  }
  return {
    traficc: Math.max(1, Number(setting.payg_initial_traffic || 1)),
    day: Math.max(1, Number(setting.payg_initial_days || 1)),
  };
};

const chargeAndCreate = async ({ ctx, i18n, menu, panel, location }) => {
  const setting = await SelectSetting();
  const fee = Number(setting.payg_base_amount || 0);
  // توجه: answerCbQuery قبل از فراخوانی این تابع توسط caller (PAYG/PAYGLOC) صدا زده شده
  // پس اینجا دیگه نباید answerCbQuery دوباره صدا زده بشه - یک callback query فقط یک‌بار قابل answer شدنه
  if (fee <= 0) return ctx.reply(i18n.t("PAYG.NOT_CONFIGURED"));

  const user = await selectUser({ id: ctx.from.id });
  if (user.price < fee) {
    return ctx.reply(i18n.t("PAYG.NOT_ENOUGH", { amount: NumberFormat(fee) }));
  }

  // فقط هزینه ایجاد سرویس کسر می‌شود - مابقی موجودی برای کسر پیوسته دست‌نخورده باقی می‌ماند
  const remainingBalance = user.price - fee;
  await UpdateUser({ id: ctx.from.id }, { price: remainingBalance });

  const { traficc, day } = calcInitial({ setting, remainingBalance, panel });

  const Servises = new Servise();
  const { result, id } = await Servises.createServise({
    id: ctx.from.id,
    traficc,
    day,
    name: "⚡️ اشتراک اشتراکی (PAYG)",
    defaultname: true,
    idPlan: null,
    free: false,
    location,
    types2: "payg",
    panel,
  });

  // خطا در ساخت - بازگشت وجه
  if (!result) {
    const freshUser = await selectUser({ id: ctx.from.id });
    await UpdateUser({ id: ctx.from.id }, { price: freshUser.price + fee });
    return ctx.reply(i18n.t("ESHTERAK_BUY.ERROR_TO_CREATED"));
  }

  await CreatePaygService({ service_id: id, telegram_id: ctx.from.id, initial_traffic: traficc, initial_days: day });

  ctx.replyWithHTML(
    i18n.t("PAYG.SUCCESS", { id, amount: NumberFormat(fee), traficc, day }),
    menu.MainMenuButtons()
  );
};

const Payg = {
  // انتخاب پرداخت به ازای مصرف - مولتی لوکیشن از پنل واسط Gard (wiguard) استفاده می‌کند
  // نه Marzban مستقیم - همون پنلی که پلن‌های مولتی لوکیشن این ربات ازش استفاده می‌کنن
  // تک لوکیشن (sanae) قبل از ساخت باید لوکیشن انتخاب بشه
  //
  // نکته تاخیر: answerCbQuery همیشه اول از همه (سینکرون‌ترین نقطه ممکن) صدا زده میشه
  // تا اسپینر روی دکمه تلگرام بلافاصله بسته بشه و کاربر منتظر نمونه - قبلا در حالت
  // تک‌لوکیشن اصلا صدا زده نمیشد که باعث تاخیر/هنگ ظاهری روی دکمه میشد
  PAYG: async ({ ctx, i18n, menu, isMatch }) => {
    await ctx.answerCbQuery();
    const type = isMatch[0].split("_")[1];
    if (type == "single") {
      const inbounds = await selectAllInboundType("normal");
      if (inbounds.length < 1) return ctx.reply(i18n.t("ESHTERAK_BUY.NOT_EXIXST"));
      return ctx.editMessageText(i18n.t("PAYG.SELECT_LOCATION"), menu.PaygLocations(inbounds));
    }
    return chargeAndCreate({ ctx, i18n, menu, panel: "wiguard", location: "payg" });
  },
  // ساخت سرویس PAYG بعد از انتخاب لوکیشن (تک لوکیشن)
  PAYGLOC: async ({ ctx, i18n, menu, isMatch }) => {
    await ctx.answerCbQuery();
    const id = isMatch[0].split("_")[1];
    return chargeAndCreate({ ctx, i18n, menu, panel: "sanae", location: id });
  },
};

export default Payg;

