import { SelectPeyment } from "../../controllers/Peyment.js";
import { selectUser } from "../../controllers/Users.js";
import { STATE_LIST } from "../sessions/state.js";

const Gift = {
  // send gift
  GIFT: async ({ ctx, i18n, menu, isMatch }) => {
    const id = isMatch[0].split("_")[1];
    const { gift } = await SelectPeyment({ id });
    const user = await selectUser({ id: ctx.from.id });
    // error one
    if (JSON.parse(gift)) return ctx.answerCbQuery(i18n.t("GIFT.ERROR_ONE"));
    // error agent
    if (user.agent) return ctx.answerCbQuery(i18n.t("GIFT.ERROR_AGENT"));
    ctx.session.state = STATE_LIST.GIFT;
    ctx.session.id = id;
    ctx.replyWithHTML(i18n.t("GIFT.GIFT_MESSAGE"), menu.BackButton());
  },
};

export default Gift;
