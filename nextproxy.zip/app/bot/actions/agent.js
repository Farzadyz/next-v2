import { I18NK } from "../utils/I18n.js";

const Agent = {
  // back question
  BACK_QUESTION: async ({ ctx, i18n, menu }) => {
    ctx.editMessageText(i18n.t("GET_AGENT.QUESTION.ANSWER"), menu.QuestionsAgent(I18NK(ctx, "GET_AGENT.QUESTION.MENU")));
  },
  // get agent
  AGENTQUESTION: async ({ ctx, i18n, menu, isMatch }) => {
    const key = isMatch[0].split("_")[1];
    ctx.editMessageText(i18n.t("GET_AGENT.QUESTION." + key), menu.BackQuestions());
  },
};

export default Agent;
