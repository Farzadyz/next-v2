import { I18NK } from "../utils/I18n.js";

const Questions = {
  // back question
  BK_MENU_QUESTION: async ({ ctx, i18n, menu }) => {
    ctx.editMessageText(i18n.t("QUESTION.ANSWER"), menu.QuestionsAgent(I18NK(ctx, "QUESTION.MENU"), true));
  },
  // get question
  QUESTION: async ({ ctx, i18n, menu, isMatch }) => {
    const key = isMatch[0].split("_")[1];
    ctx.editMessageText(i18n.t("QUESTION." + key), menu.BackQuestions(true));
  },
};

export default Questions;
