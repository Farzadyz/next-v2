import moment from "moment";
import momentt from "moment-timezone";
import { CreateServise, DeleteServise, SelectServise, UpdateServise } from "../../controllers/Servise.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectPelan } from "../../controllers/Pelan.js";
import { UpdateInbound, selectInbound } from "../../controllers/Inbound.js";
import Sanae from "../../api/sanae.js";
import { selectAllInboundMzType } from "../../controllers/InboundMz.js";
import Marzban from "../../api/marzban.js";
import Wigard from "../../api/wigard.js";
import ServiseSanaeiNew from "./servise_sanaei_new.js";
import { PANEL_TYPES } from "../../utils/panelTypes.js";

class Servise {
  constructor() {
    this.marzban = new Marzban();
    this.wigard = new Wigard();
    // Sanaei new versions (isolated from the legacy Sanaei logic)
    this.sanaeiNew = new ServiseSanaeiNew();
  }
  // create Servise
  async createServise({ id, traficc, day, name, defaultname, idPlan, free, location, types2, panel, uuids, username, ids, price }) {
    const data_limit = traficc * 1073741824;

    // Sanaei family: the real panel type comes from the selected server (sanae | sanaei_new)
    panel = await this.sanaeiNew.resolvePanel({ panel, location });

    const email = await this.handleRandom(15);
    const uuid = uuids ?? (await this.generateuuid());
    if (!uuids) {
      var { ids, username } = await CreateServise({
        uuid,
        id,
        location,
        types: types2,
        data_limit,
        name,
        email,
        defaultname,
        id_pelan: idPlan,
        traficc,
        day,
        free,
        key: await this.handleRandom(10),
        panel,
        price,
      });
    }

    let create;
    if (panel == "sanae") {
      create = await this.CreateSanae({
        location,
        username: uuids ? email : username,
        uuid,
        email: uuids ? username : email,
        data_limit,
        day,
        ids,
      });
    } else if (panel == "marzban") {
      create = await this.CreateMarzban({ type: "ALL", username, data_limit, day, ids });
    } else if (panel == "wiguard") {
      const res = await this.CreateWigard({ username: email, data_limit, day, ids });
      if (!res.result) return res;
      await UpdateServise({ id: ids }, { uuid: res.data[0]?.access_key });
      create = { result: true, id: ids };
    } else if (panel == PANEL_TYPES.SANAEI_NEW) {
      create = await this.sanaeiNew.create({
        location,
        username: uuids ? email : username,
        uuid,
        email: uuids ? username : email,
        data_limit,
        day,
        ids,
      });
    }

    return create;
  }

  // create sanae
  async CreateSanae({ location, username, uuid, email, data_limit, day, ids }) {
    const addDay = momentt.tz("Asia/Tehran").add(day, "days");
    const expire = addDay.valueOf();
    // find panel in protocol
    const findprotocol = await selectInbound({ id: location });
    if (!findprotocol) return false;
    // create
    this.sanae = new Sanae(findprotocol.damoin, findprotocol.session);
    const splirtport = findprotocol.port.split(",");
    const result = await this.sanae.addInbound({
      name: username,
      port: findprotocol.usePort,
      maxport: splirtport[1],
      uuid,
      email,
      data_limit,
      expire,
      header: findprotocol.host,
    });
    // error to create
    if (!result.success) {
      await DeleteServise({ id: ids });
      return { result: false };
    }
    await UpdateInbound({ id: findprotocol.id }, { usePort: result.port });
    return { result: true, id: ids };
  }

  // createa marzban
  async CreateMarzban({ type, username, data_limit, day, ids }) {
    const addDay = momentt.tz("Asia/Tehran").add(day, "days").format("YYYY-MM-DD HH:mm:ss");
    const expire = Date.parse(addDay) / 1000;
    const types = {};
    const allinoundoftype = await selectAllInboundMzType({ type, status: true });
    for (const item of allinoundoftype) {
      const protocol = item.protocol;
      const tag = item.tag;
      if (!types[protocol]) {
        types[protocol] = [];
      }
      types[protocol].push(tag);
    }
    const res = await this.marzban.addUser({ username, data_limit, expire, types });
    if (!res) {
      await DeleteServise({ id: ids });
      return { result: false };
    }
    // await this.createProtocol(ids);
    return { result: true, id: ids };
  }

  // createa wigard
  async CreateWigard({ username, data_limit, day }) {
    const addDay = momentt.tz("Asia/Tehran").add(day, "days").format("YYYY-MM-DD HH:mm:ss");
    const expire = Date.parse(addDay) / 1000;

    const res = await this.wigard.addUser({ username, limit_expire: expire, limit_usage: data_limit });

    if (!res) return { result: false };

    return { result: true, data: res };
  }

  /*
  @select Servise
  */

  // select servise
  async SelectServise({ id, i18n }) {
    const servises = await SelectServise({ id });
    // error servise
    if (!servises) return false;
    switch (servises.panel) {
      case "sanae":
        return this.SelectServiseSanae({ i18n, servises });
      case "marzban":
        return this.SelectServiseMarzban({ i18n, servises });
      case "wiguard":
        return this.SelectServiseWigard({ i18n, servises });
      case PANEL_TYPES.SANAEI_NEW:
        return this.sanaeiNew.select({ i18n, servises });
    }
  }

  // select servise sanae
  async SelectServiseSanae({ i18n, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    this.sanae = new Sanae(inbound?.damoin, inbound?.session);
    const servise = await this.sanae.findClinet({ email: servises.username });
    if (!servise) return { status: false };
    const getinbound = await this.sanae.getInbound({ inboundId: servise.inboundId });
    const newDay = momentt(servise.expiryTime).tz("Asia/Tehran").format("YYYY-MM-DD HH:mm:ss"); // status
    let status;
    let keyboard;
    if (newDay > moment().format("YYYY-MM-DD HH:mm:ss") && servise.total - (servise.up + servise.down) > 0) {
      status = i18n.t("MY_ESHTERAK.MENU.STATUS_ON");
      keyboard = true;
    } else {
      status = i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      keyboard = false;
    }
    // day
    const convertTime = moment(newDay).diff(moment().format("YYYY-MM-DD HH:mm:ss"), "days");
    if (convertTime === 0) {
      var hoursDiff = moment(newDay).diff(moment(), "hours");
      var minutesDiff = moment(newDay).diff(moment(), "minutes") % 60;

      var time = Math.max(0, hoursDiff) + " ساعت و " + Math.max(0, minutesDiff) + " دقیقه";
    } else if (convertTime < 0) {
      var time = 0 + " روز";
    } else {
      var time = convertTime + " روز";
    }
    // free
    if (servises.free) keyboard = "free";
    // fuction link
    const Link = ({ uuid, title, host, getinbound }) => {
      return `vless://${uuid}@${title}:${getinbound?.obj?.port}?type=ws&security=none&path=%2F&host=${host}#Nextproxy_bot`;
    };

    return {
      status,
      keyboard,
      location: inbound.location,
      name: servises.name,
      status_api: servises.status,
      expiryTime: servise.expiryTime,
      total: servise.total,
      up: servise.up,
      down: servise.down,
      time,
      date: newDay,
      traffic: this.trafficConvert(servise.total),
      used_traffic: this.trafficConvert(servise.up + servise.down),
      remaining: this.trafficConvert(servise.total - (servise.up + servise.down)),
      internal: await Link({ uuid: servises.uuid, title: inbound.internal, host: inbound.host, getinbound }),
      tunel: await Link({ uuid: servises.uuid, title: inbound.tunel, host: inbound.host, getinbound }),
      panel: servises.panel,
    };
  }

  // select servise marzban
  async SelectServiseMarzban({ i18n, servises }) {
    const servise = await this.marzban.getUser({ username: servises.username });
    if (!servise) return { status: false };
    const newDay = moment(servise.expire * 1000).format("YYYY-MM-DD HH:mm:ss");
    // status
    let status;
    let keyboard;
    //
    if (servises.time > 0 && servises.traficc > 0) {
      // limited
      if (newDay > moment().format("YYYY-MM-DD HH:mm:ss") && servise.data_limit - servise.used_traffic > 0) {
        status = i18n.t("MY_ESHTERAK.MENU.STATUS_ON");
        keyboard = true;
      } else {
        status = i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
        keyboard = false;
      }
    } else {
      // time
      if (servises.time > 0) {
        keyboard = newDay > moment().format("YYYY-MM-DD HH:mm:ss") ? true : false;
        status =
          newDay > moment().format("YYYY-MM-DD HH:mm:ss") ? i18n.t("MY_ESHTERAK.MENU.STATUS_ON") : i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      } else {
        // traficc
        keyboard = servise.data_limit - servise.used_traffic > 0 ? true : false;
        status =
          servise.data_limit - servise.used_traffic > 0 ? i18n.t("MY_ESHTERAK.MENU.STATUS_ON") : i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      }
    }

    // day
    const convertTime = moment(newDay).diff(moment().format("YYYY-MM-DD HH:mm:ss"), "days");
    if (convertTime === 0) {
      var hoursDiff = moment(newDay).diff(moment(), "hours");
      var minutesDiff = moment(newDay).diff(moment(), "minutes") % 60;

      var time = Math.max(0, hoursDiff) + " ساعت و " + Math.max(0, minutesDiff) + " دقیقه";
    } else if (convertTime < 0) {
      var time = 0 + " روز";
    } else {
      var time = convertTime + " روز";
    }
    // free
    if (servises.free) keyboard = "free";
    return {
      status: servises.time > 0 ? status : i18n.t("MY_ESHTERAK.MENU.STATUS_ON"),
      keyboard,
      status_api: servise.status == "active" ? true : false,
      time: servises.time > 0 ? time : "♾",
      date: newDay,
      traffic: servises.traficc > 0 ? this.trafficConvert(servise.data_limit) : "♾",
      used_traffic: this.trafficConvert(servise.used_traffic),
      remaining: servises.traficc > 0 ? this.trafficConvert(servise.data_limit - servise.used_traffic) : "♾",
      subscription_url: servise.subscription_url,
      panel: servises.panel,
    };
  }

  async SelectServiseWigard({ i18n, servises }) {
    const servise = await this.wigard.getUser({ username: servises.username });
    if (!servise) return { status: false };

    const now = moment();
    const expireDate = moment(servise.limit_expire * 1000);
    const newDay = expireDate.format("YYYY-MM-DD HH:mm:ss");

    // وضعیت و کیبورد
    let status;
    let keyboard;

    const hasTimeLimit = servises.time > 0;
    const hasTrafficLimit = servises.traficc > 0;
    const remainingTraffic = servise.limit_usage - servise.total_usage;
    const isActive = expireDate.isAfter(now) && remainingTraffic > 0;

    if (hasTimeLimit && hasTrafficLimit) {
      status = isActive ? i18n.t("MY_ESHTERAK.MENU.STATUS_ON") : i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      keyboard = isActive;
    } else if (hasTimeLimit) {
      status = expireDate.isAfter(now) ? i18n.t("MY_ESHTERAK.MENU.STATUS_ON") : i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      keyboard = expireDate.isAfter(now);
    } else if (hasTrafficLimit) {
      status = remainingTraffic > 0 ? i18n.t("MY_ESHTERAK.MENU.STATUS_ON") : i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      keyboard = remainingTraffic > 0;
    }

    // زمان باقی مانده
    let time;
    const daysDiff = expireDate.diff(now, "days");
    if (daysDiff > 0) {
      time = `${daysDiff} روز`;
    } else if (daysDiff === 0) {
      const hoursDiff = expireDate.diff(now, "hours");
      const minutesDiff = expireDate.diff(now, "minutes") % 60;
      time = `${Math.max(0, hoursDiff)} ساعت و ${Math.max(0, minutesDiff)} دقیقه`;
    } else {
      time = "0 روز";
    }

    // حالت رایگان
    if (servises.free) keyboard = "free";

    return {
      status: hasTimeLimit ? status : i18n.t("MY_ESHTERAK.MENU.STATUS_ON"),
      keyboard,
      status_api: servise.status === "active",
      time: hasTimeLimit ? time : "♾",
      date: newDay,
      traffic: hasTrafficLimit ? this.trafficConvert(servise.limit_usage) : "♾",
      used_traffic: this.trafficConvert(servise.total_usage),
      remaining: hasTrafficLimit ? this.trafficConvert(remainingTraffic) : "♾",
      subscription_url: servise.link.replace("https://versub.vercel.app/guards/", `${process.env.URL_DOMAIN}link/`),
      panel: servises.panel,
    };
  }

  /*
  @Alert select
  */

  // select servise
  async SelectServiseAlert({ id }) {
    const servises = await SelectServise({ id });
    // error servise
    if (!servises) return false;
    if (servises.panel == "sanae") return this.SelectServiseAlertSanae({ id, servises });
    if (servises.panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.selectAlert({ id, servises });
    if (servises.panel == "wiguard") return this.SelectServiseAlertWigard({ id, servises });
    return this.SelectServiseAlertMarzban({ id, servises });
  }

  // select servise - wiguard (multi location / Gard intermediary)
  async SelectServiseAlertWigard({ id, servises }) {
    const servise = await this.wigard.getUser({ username: servises.username });
    if (!servise) return false;
    return {
      id,
      expire: servise.limit_expire,
      belongs: servises.telegram_id,
      name: servises.username,
      traffic: servise.limit_usage,
      used_traffic: servise.total_usage,
      remaining: this.trafficConvert(servise.limit_usage - servise.total_usage),
    };
  }

  // select servise
  async SelectServiseAlertSanae({ id, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    this.sanae = new Sanae(inbound.damoin, inbound.session);
    const servise = await this.sanae.findClinet({ email: servises.username });
    if (!servise) return "error-get";
    return {
      id,
      expire: servise.expiryTime,
      belongs: servises.telegram_id,
      name: servises.username,
      traffic: servise.total,
      used_traffic: servise.up + servise.down,
      remaining: this.trafficConvert(servise.total - (servise.up + servise.down)),
    };
  }

  // select servise
  async SelectServiseAlertMarzban({ id, servises }) {
    const servise = await this.marzban.getUser({ username: servises.username });
    if (!servise) return false;
    return {
      id,
      expire: servise.expire,
      belongs: servises.telegram_id,
      name: servises.username,
      traffic: servise.data_limit,
      used_traffic: servise.used_traffic,
      remaining: this.trafficConvert(servise.data_limit - servise.used_traffic),
    };
  }

  // select servise auto delete
  async SelectServiseAutoDelete(servises) {
    const servise = await this.marzban.getUser({ username: servises.username });
    if (!servise) return false;
    const newDay = moment(servise.expire * 1000).format("YYYY-MM-DD HH:mm:ss");
    // status
    let status;
    if (newDay > moment().format("YYYY-MM-DD HH:mm:ss") && servise.data_limit - servise.used_traffic > 0) {
      status = true;
    } else {
      status = false;
    }

    return {
      status,
    };
  }

  // upgrade servise
  async upgradeServise({ id, traficc, idUpgarade }) {
    const { username, location, data_limit, panel } = await SelectServise({ id });
    // update
    // UpdateServise({ id }, { upgerade: idUpgarade });
    if (panel == "sanae") return this.upgradeServiseSanae({ traficc, username, location, data_limit });
    if (panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.upgrade({ id, traficc });
    return this.upgradeServiseMarzban({ traficc, username, data_limit });
  }

  // upgrade servise
  async upgradeServiseSanae({ traficc, username, location, data_limit }) {
    const inbound = await selectInbound({ id: location });
    this.sanae = new Sanae(inbound.damoin, inbound.session);
    let data = await this.sanae.findClinet({ email: username });
    let getinbound = await this.sanae.getInbound({ inboundId: data.inboundId });
    var setting = JSON.parse(getinbound.obj.settings);
    setting.clients[0].enable = true;
    setting.clients[0].totalGB = data_limit + traficc * 1073741824;
    getinbound.obj.settings = JSON.stringify(setting);
    getinbound.obj.enable = true;
    getinbound.obj.total = data_limit + traficc * 1073741824;
    const reset = await this.sanae.updateInbound(getinbound.obj);
    if (!reset || !reset.success) return false;
    return true;
  }

  // upgrade servise
  async upgradeServiseMarzban({ traficc, data_limit, username }) {
    const data = {
      data_limit: data_limit + traficc * 1073741824,
    };
    await this.marzban.modifyUser({ username, data });
    return true;
  }

  /*
  @ tamdis
  @ Status Tamdid
  */

  // tamdid
  async Tamdid({ id, day }) {
    const { username, location, uuid, data_limit, panel } = await SelectServise({ id });
    if (panel == "sanae") return this.TamdidSanae({ id, day, username, location, uuid, data_limit });
    if (panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.tamdid({ id, day });
    return this.TamdidMarzban({ id, day, username, data_limit });
  }

  // tamdid
  async TamdidSanae({ id, day, username, location, uuid, data_limit }) {
    const addDay = moment().add({ days: day });
    const expire = addDay.valueOf();
    await UpdateServise({ id }, { used_traffic: 0, expire, upgerade: null });
    const inbound = await selectInbound({ id: location });
    const sanae = new Sanae(inbound.damoin, inbound.session);
    const data = await sanae.findClinet({ email: username });
    const getinbound = await sanae.getInbound({ inboundId: data.inboundId });
    if (!data || !getinbound) return false;
    await sanae.deleteInbound({ inboundId: data.inboundId });
    const result = await sanae.addInbound({
      name: "Userbot" + id,
      port: getinbound?.obj?.port,
      maxport: getinbound?.obj?.port + 1,
      uuid,
      email: username,
      data_limit,
      expire,
      header: inbound.host,
    });
    // error to create
    if (!result.success) return false;
    return true;
  }

  async TamdidMarzban({ id, day, username, data_limit }) {
    const addDay = momentt.tz("Asia/Tehran").add(day, "days").format("YYYY-MM-DD HH:mm:ss");
    const expire = Date.parse(addDay) / 1000;
    await UpdateServise({ id }, { used_traffic: 0, expire, upgerade: null });
    const data = {
      data_limit,
      used_traffic: 0,
      expire,
    };
    await this.marzban.modifyUser({ username, data });
    await this.marzban.resetUser({ username });
    return { username };
  }

  // get Status Tamdid
  async StatusTamdid({ id, i18n }) {
    const servise = await SelectServise({ id });
    const servises = await this.SelectServise({ id, i18n });
    if (!servise) return false;
    let price;
    let traficc;
    let time;
    let status;
    let Uprice;
    let Utraficc;
    let type;
    // get status servise
    const newDay = momentt(servises.expiryTime).tz("Asia/Tehran").format("YYYY-MM-DD HH:mm:ss");
    if (newDay > moment().format("YYYY-MM-DD HH:mm:ss") && servises.total - (servises.up + servises.down) > 0) {
      status = true;
    } else {
      status = false;
    }
    // id_pelan Dasht
    const setting = await SelectSetting();
    // type select
    switch (servise.types) {
      case "select":
        // دریافت اطلاعات پلن انتخابی
        const pelan = await selectPelan({ id: servise.id_pelan });
        if (!pelan) return false;
        price = pelan.price;
        traficc = pelan.traficc;
        time = pelan.time;
        type = pelan.type;
        break;
      case "sefareshi":
        // محاسبه قیمت بر اساس اطلاعات سفارشی
        const subscribeSef = JSON.parse(setting.subscribe);
        traficc = servise.traficc;
        time = servise.time;
        price = Number(traficc) * subscribeSef.priceT + Number(time) * subscribeSef.priceD;
        break;
      case "select-sefareshi":
        // محاسبه قیمت بر اساس اطلاعات سفارشی سفارشی شده
        const subscribeSelSef = JSON.parse(setting.customize);
        traficc = servise.traficc;
        time = servise.time;
        price = Number(traficc) * subscribeSelSef.traficcP + Number(time) * subscribeSelSef.timeP;
        break;
    }
    // servise vip
    const selectinbounds = await selectInbound({ id: servise.location });
    if (selectinbounds?.price) {
      price += selectinbounds.price;
    }
    return {
      status,
      price,
      traficc,
      time,
      Uprice,
      Utraficc,
      location: servises.location || 0,
      types: servise.types,
      panel: servise.panel,
      type,
    };
  }

  // change status sercise
  async ChangeStatus({ id }) {
    const servises = await SelectServise({ id });
    // error servise
    if (!servises) return false;
    if (servises.panel == "sanae") return this.ChangeStatusSanae({ id, servises });
    if (servises.panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.changeStatus({ id, servises });
    if (servises.panel == "wiguard") return this.ChangeStatusWigard({ id, servises });
    return this.ChangeStatusMarzban({ id, servises });
  }

  // change status wiguard (multi location / Gard intermediary)
  async ChangeStatusWigard({ id, servises }) {
    const data = await this.wigard.getUser({ username: servises.username });
    if (!data) return false;
    const newStatus = data.status === "active" ? "disabled" : "active";
    const statusDb = !servises.status;
    await UpdateServise({ id }, { status: statusDb });
    await this.wigard.modifyUser({ username: servises.username, data: { status: newStatus } });
    return true;
  }

  // change status sanae
  async ChangeStatusSanae({ id, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    this.sanae = new Sanae(inbound.damoin, inbound.session);
    let data = await this.sanae.findClinet({ email: servises.username });
    if (!data) return false;
    const status = servises.status ? false : true;
    data.enable = status;
    data.uuid = servises.uuid;
    await UpdateServise({ id }, { status });
    await this.sanae.updateClinet(data);
    return true;
  }

  // change status sercise
  async ChangeStatusMarzban({ id, servises }) {
    let data = await this.marzban.getUser({ username: servises.username });
    if (!data) return false;
    const status = data.status == "active" ? "disabled" : "active";
    data.status = status;
    const statusDb = servises.status == "active" ? false : true;
    await UpdateServise({ id }, { status: statusDb });
    await this.marzban.modifyUser({ username: servises.username, data });
    return true;
  }

  /*
  @ explicit enable / disable (PAYG suspension) - never a toggle.
  @ The panel is asked to apply the state, the result is verified on the panel and
  @ the bot database (servise.status) follows only after the panel really applied it.
  */

  async SetStatus({ id, enable }) {
    const servises = await SelectServise({ id });
    if (!servises) return false;
    const state = !!enable;
    let applied = false;
    for (let attempt = 0; attempt < 3 && !applied; attempt++) {
      try {
        applied = await this.ApplyStatus({ servises, enable: state });
      } catch (error) {
        console.error("SetStatus error for service", id, error.message);
      }
    }
    if (!applied) return false;
    await UpdateServise({ id }, { status: state });
    return true;
  }

  // apply + verify the state on the panel of the service
  async ApplyStatus({ servises, enable }) {
    if (servises.panel == "sanae") return this.ApplyStatusSanae({ servises, enable });
    if (servises.panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.setEnabled({ servises, enable });
    if (servises.panel == "wiguard") return this.ApplyStatusWigard({ servises, enable });
    return this.ApplyStatusMarzban({ servises, enable });
  }

  // sanae (<= 2.6.6): inbound + client are switched, then both are read back
  async ApplyStatusSanae({ servises, enable }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const sanae = new Sanae(inbound.damoin, inbound.session);
    const data = await sanae.findClinet({ email: servises.username });
    if (!data) return false;
    const verify = async () => {
      const client = await sanae.findClinet({ email: servises.username });
      const current = await sanae.getInbound({ inboundId: data.inboundId });
      return !!client && !!current?.obj && client.enable === enable && current.obj.enable === enable;
    };
    // 1) whole inbound (drops the live connection)
    const getinbound = await sanae.getInbound({ inboundId: data.inboundId });
    if (!getinbound || !getinbound.obj) return false;
    const setting = JSON.parse(getinbound.obj.settings);
    if (setting.clients && setting.clients[0]) setting.clients[0].enable = enable;
    getinbound.obj.settings = JSON.stringify(setting);
    getinbound.obj.enable = enable;
    await sanae.updateInbound(getinbound.obj);
    if (await verify()) return true;
    // 2) client only
    data.enable = enable;
    data.uuid = servises.uuid;
    await sanae.updateClinet(data);
    return verify();
  }

  // wiguard (multi location / Gard intermediary)
  async ApplyStatusWigard({ servises, enable }) {
    const data = await this.wigard.getUser({ username: servises.username });
    if (!data) return false;
    const status = enable ? "active" : "disabled";
    await this.wigard.modifyUser({ username: servises.username, data: { status } });
    const check = await this.wigard.getUser({ username: servises.username });
    return !!check && check.status === status;
  }

  // marzban
  async ApplyStatusMarzban({ servises, enable }) {
    const data = await this.marzban.getUser({ username: servises.username });
    if (!data) return false;
    const status = enable ? "active" : "disabled";
    data.status = status;
    await this.marzban.modifyUser({ username: servises.username, data });
    const check = await this.marzban.getUser({ username: servises.username });
    return !!check && check.status === status;
  }

  // change status sercise
  async Revokelink({ id }) {
    const servises = await SelectServise({ id });
    // error servise
    if (!servises) return false;
    if (servises.panel == "sanae") return this.RevokelinkSanae({ id, servises });
    if (servises.panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.revokeLink({ id, servises });
    return this.RevokelinkMarzban({ username: servises.username });
  }

  // Revoke Link Sanae
  async RevokelinkSanae({ id, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    this.sanae = new Sanae(inbound.damoin, inbound.session);
    let data = await this.sanae.findClinet({ email: servises.username });
    if (!data) return false;
    const uuid = await this.generateuuid();
    data.uuid = uuid;
    data.id = servises.uuid;
    await UpdateServise({ id }, { uuid });
    await this.sanae.revokeLink(data);
    return true;
  }

  // Revoke Link Marzban
  async RevokelinkMarzban({ username }) {
    await this.marzban.revokeSub({ username });
    return true;
  }

  // delete servise
  async DeleteServise({ id }) {
    const servises = await SelectServise({ id });
    // error servise
    if (!servises) return false;
    await DeleteServise({ id });
    if (servises.panel == "sanae") return this.DeleteServiseSanae({ servises });
    if (servises.panel == PANEL_TYPES.SANAEI_NEW) return this.sanaeiNew.delete({ servises });
    if (servises.panel == "wiguard") return this.DeleteServiseWigard({ servises });
    return this.DeleteServiseMarzban({ username: servises.username });
  }

  // Delete servise wiguard (multi location / Gard intermediary)
  async DeleteServiseWigard({ servises }) {
    await this.wigard.DeleteUser({ username: servises.username });
  }

  // Delete servise Sanae
  async DeleteServiseSanae({ servises }) {
    const inbound = await selectInbound({ id: servises.location });
    this.sanae = new Sanae(inbound.damoin, inbound.session);
    let data = await this.sanae.findClinet({ email: servises.username });
    await this.sanae.deleteInbound({ inboundId: data.inboundId });
  }

  async DeleteServiseMarzban({ username }) {
    await this.marzban.DeleteUser({ username });
  }

  // generate uuid
  generateuuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
      var r = (Math.random() * 16) | 0,
        v = c == "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  // random key
  handleRandom(length) {
    const charset = "0123456789abcdefghijklmnopqrstuvwxyz";
    let password = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
      password += charset.charAt(Math.floor(Math.random() * n));
    }
    return password;
  }

  // traficc convert
  trafficConvert(byte) {
    const kb = 1024;
    const mb = 1048576;
    const gb = 1073741824;
    if (byte > gb) {
      return Math.round(byte / gb, 2) + " گیگ";
    } else if (byte > mb) {
      return Math.round(byte / mb, 2) + " مگابایت";
    } else if (byte > kb) {
      return Math.round(byte / kb, 2) + " کیلوبایت";
    } else if (byte < 0) {
      return 0;
    } else {
      return Math.round(byte, 2) + " بایت";
    }
  }
}

export default Servise;
