import moment from "moment";
import momentt from "moment-timezone";
import { DeleteServise, SelectServise, UpdateServise } from "../../controllers/Servise.js";
import { UpdateInbound, selectInbound } from "../../controllers/Inbound.js";
import SanaeiNew from "../../api/sanaei_new.js";
import { PANEL_TYPES, isSanaeiFamily } from "../../utils/panelTypes.js";

const GB = 1073741824;

/*
 * Services of the "Sanaei New Versions" panel type (panel = "sanaei_new").
 * Isolated from the legacy Sanaei (<= 2.6.6) logic in ./servise.js.
 *
 * Model: every service owns one inbound (vless / ws, taken from the server port range) that contains one client.
 * The client (first-class entity) carries the traffic limit / expiry / uuid / enable flag.
 */
class ServiseSanaeiNew {
  // api client of a server; an expired session is renewed and saved automatically
  api(inbound) {
    return new SanaeiNew(inbound.damoin, inbound.session, {
      username: inbound.username,
      password: inbound.password,
      onSession: (session) => UpdateInbound({ id: inbound.id }, { session }),
    });
  }

  // "sanae" | "sanaei_new" plans use the real panel type of the selected server
  async resolvePanel({ panel, location }) {
    if (!isSanaeiFamily(panel)) return panel;
    if (location === undefined || location === null || location === "") return panel;
    try {
      const inbound = await selectInbound({ id: location });
      if (inbound && isSanaeiFamily(inbound.panel)) return inbound.panel;
    } catch (error) {
      console.error("resolvePanel error:", error.message);
    }
    return panel;
  }

  // inbound id of the inbound that owns the service client
  async inboundIdOf(api, email) {
    const traffic = await api.getClientTraffic({ email });
    if (traffic?.inboundId) return traffic.inboundId;
    const client = await api.getClient({ email });
    return client?.inboundIds?.[0] ?? null;
  }

  /*
  @ create
  */

  async create({ location, username, uuid, email, data_limit, day, ids }) {
    const expire = momentt.tz("Asia/Tehran").add(day, "days").valueOf();
    // find server
    const findprotocol = await selectInbound({ id: location });
    if (!findprotocol) {
      await DeleteServise({ id: ids });
      return { result: false };
    }
    const api = this.api(findprotocol);
    const splitport = findprotocol.port.split(",");
    // inbound
    const inbound = await api.addInbound({
      name: username,
      port: findprotocol.usePort,
      maxport: splitport[1],
      header: findprotocol.host,
    });
    if (!inbound.success || !inbound.id) {
      await DeleteServise({ id: ids });
      return { result: false };
    }
    // client
    const added = await api.addClient({
      inboundId: inbound.id,
      client: {
        id: uuid,
        email,
        subId: email,
        totalGB: data_limit,
        expiryTime: expire,
        limitIp: 2,
        tgId: 0,
        comment: "",
        enable: true,
      },
    });
    if (!added) {
      await api.deleteInbound({ inboundId: inbound.id });
      await DeleteServise({ id: ids });
      return { result: false };
    }
    await UpdateInbound({ id: findprotocol.id }, { usePort: inbound.port });
    return { result: true, id: ids };
  }

  /*
  @ select
  */

  async select({ i18n, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return { status: false };
    const api = this.api(inbound);
    const servise = await api.getClientTraffic({ email: servises.username });
    if (!servise) return { status: false };
    const inboundId = servise.inboundId || (await this.inboundIdOf(api, servises.username));
    const getinbound = inboundId ? await api.getInbound({ inboundId }) : false;
    if (!getinbound) return { status: false };

    const expiry = Number(servise.expiryTime) || 0;
    const total = Number(servise.total) || 0;
    const used = (Number(servise.up) || 0) + (Number(servise.down) || 0);
    const now = Date.now();
    const newDay = momentt(expiry).tz("Asia/Tehran").format("YYYY-MM-DD HH:mm:ss");

    // status (0 = unlimited)
    let status;
    let keyboard;
    if ((expiry === 0 || expiry > now) && (total === 0 || total - used > 0)) {
      status = i18n.t("MY_ESHTERAK.MENU.STATUS_ON");
      keyboard = true;
    } else {
      status = i18n.t("MY_ESHTERAK.MENU.STATUS_OFF");
      keyboard = false;
    }

    // day
    let time;
    if (expiry === 0) {
      time = "♾";
    } else {
      const remain = expiry - now;
      const days = Math.trunc(remain / 86400000);
      if (days === 0) {
        const hoursDiff = Math.floor(remain / 3600000);
        const minutesDiff = Math.floor(remain / 60000) % 60;
        time = Math.max(0, hoursDiff) + " ساعت و " + Math.max(0, minutesDiff) + " دقیقه";
      } else if (days < 0) {
        time = 0 + " روز";
      } else {
        time = days + " روز";
      }
    }
    // free
    if (servises.free) keyboard = "free";
    // function link
    const Link = ({ uuid, title, host, port }) => {
      return `vless://${uuid}@${title}:${port}?type=ws&security=none&path=%2F&host=${host}#Nextproxy_bot`;
    };

    return {
      status,
      keyboard,
      location: inbound.location,
      name: servises.name,
      status_api: servises.status,
      expiryTime: servise.expiryTime,
      total: servise.total,
      up: servise.up,
      down: servise.down,
      time,
      date: newDay,
      traffic: total === 0 ? "♾" : this.trafficConvert(total),
      used_traffic: this.trafficConvert(used),
      remaining: total === 0 ? "♾" : this.trafficConvert(total - used),
      internal: Link({ uuid: servises.uuid, title: inbound.internal, host: inbound.host, port: getinbound.port }),
      tunel: Link({ uuid: servises.uuid, title: inbound.tunel, host: inbound.host, port: getinbound.port }),
      // presentation family: the bot renders / QR-encodes it exactly like the Sanaei links (SEE_ESHTERAK_SANAE)
      panel: PANEL_TYPES.SANAEI_OLD,
      // real panel type of the service
      panel_type: servises.panel,
    };
  }

  async selectAlert({ id, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const servise = await api.getClientTraffic({ email: servises.username });
    if (!servise) return "error-get";
    return {
      id,
      expire: servise.expiryTime,
      belongs: servises.telegram_id,
      name: servises.username,
      traffic: servise.total,
      used_traffic: servise.up + servise.down,
      remaining: this.trafficConvert(servise.total - (servise.up + servise.down)),
    };
  }

  /*
  @ upgrade (add traffic)
  */

  async upgrade({ id, traficc }) {
    const servises = await SelectServise({ id });
    if (!servises) return false;
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const client = await api.getClient({ email: servises.username });
    if (!client) return false;
    const current = Number(client.totalGB) > 0 ? Number(client.totalGB) : Number(servises.data_limit) || 0;
    const payload = api.buildClientPayload(client, { totalGB: current + traficc * GB, enable: true }, servises.uuid);
    const updated = await api.updateClient({ email: servises.username, client: payload });
    if (!updated) return false;
    const inboundId = client.inboundIds[0] ?? (await this.inboundIdOf(api, servises.username));
    if (inboundId) await api.setInboundEnable({ inboundId, enable: true });
    return true;
  }

  /*
  @ tamdid (renew)
  */

  async tamdid({ id, day }) {
    const servises = await SelectServise({ id });
    if (!servises) return false;
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const client = await api.getClient({ email: servises.username });
    if (!client) return false;
    const expire = moment().add({ days: day }).valueOf();
    const totalGB = Number(servises.data_limit) > 0 ? Number(servises.data_limit) : Number(client.totalGB) || 0;
    // reset usage, then apply the new limits
    await api.resetClientTraffic({ email: servises.username });
    const payload = api.buildClientPayload(client, { totalGB, expiryTime: expire, enable: true }, servises.uuid);
    const updated = await api.updateClient({ email: servises.username, client: payload });
    if (!updated) return false;
    const inboundId = client.inboundIds[0] ?? (await this.inboundIdOf(api, servises.username));
    if (inboundId) await api.setInboundEnable({ inboundId, enable: true });
    await UpdateServise({ id }, { used_traffic: 0, expire, upgerade: null, status: true });
    return true;
  }

  /*
  @ status
  */

  // toggle
  async changeStatus({ id, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const client = await api.getClient({ email: servises.username });
    if (!client) return false;
    const status = servises.status ? false : true;
    await UpdateServise({ id }, { status });
    const payload = api.buildClientPayload(client, { enable: status }, servises.uuid);
    const updated = await api.updateClient({ email: servises.username, client: payload });
    if (!updated) {
      await UpdateServise({ id }, { status: servises.status });
      return false;
    }
    return true;
  }

  // force enable / disable (client + inbound) - used by the admin tools and the PAYG suspension.
  // returns true only when the panel confirms the new state (read back after the update)
  async setEnabled({ servises, enable }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const state = !!enable;
    const client = await api.getClient({ email: servises.username });
    if (!client) return false;
    const payload = api.buildClientPayload(client, { enable: state }, servises.uuid);
    const updated = await api.updateClient({ email: servises.username, client: payload });
    const inboundId = client.inboundIds[0] ?? (await this.inboundIdOf(api, servises.username));
    if (inboundId) await api.setInboundEnable({ inboundId, enable: state });
    if (!updated) return false;
    // verify
    const check = await api.getClient({ email: servises.username });
    if (!check || !!check.enable !== state) return false;
    if (inboundId) {
      const checkInbound = await api.getInbound({ inboundId });
      if (checkInbound && !!checkInbound.enable !== state) return false;
    }
    return true;
  }

  /*
  @ revoke link (new uuid)
  */

  async revokeLink({ id, servises }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const client = await api.getClient({ email: servises.username });
    if (!client) return false;
    const uuid = this.generateuuid();
    const payload = api.buildClientPayload(client, { id: uuid }, servises.uuid);
    const updated = await api.updateClient({ email: servises.username, client: payload });
    if (!updated) return false;
    await UpdateServise({ id }, { uuid });
    return true;
  }

  /*
  @ delete
  */

  async delete({ servises }) {
    const inbound = await selectInbound({ id: servises.location });
    if (!inbound) return false;
    const api = this.api(inbound);
    const inboundId = await this.inboundIdOf(api, servises.username);
    if (inboundId) await api.deleteInbound({ inboundId });
    // removes the client (and its traffic row) when it is still left behind
    await api.deleteClient({ email: servises.username });
    return true;
  }

  /*
  @ utils
  */

  // generate uuid
  generateuuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
      var r = (Math.random() * 16) | 0,
        v = c == "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  // traficc convert
  trafficConvert(byte) {
    const kb = 1024;
    const mb = 1048576;
    const gb = 1073741824;
    if (byte > gb) {
      return Math.round(byte / gb, 2) + " گیگ";
    } else if (byte > mb) {
      return Math.round(byte / mb, 2) + " مگابایت";
    } else if (byte > kb) {
      return Math.round(byte / kb, 2) + " کیلوبایت";
    } else if (byte < 0) {
      return 0;
    } else {
      return Math.round(byte, 2) + " بایت";
    }
  }
}

export default ServiseSanaeiNew;
