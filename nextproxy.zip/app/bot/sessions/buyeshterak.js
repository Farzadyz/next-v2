import { selectAllInboundType } from "../../controllers/Inbound.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { NumberFormat } from "../utils/utils.js";
import { STATE_LIST } from "./state.js";

const BuyEshterak = {
  // for send day user
  [STATE_LIST.SENDDAY]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    const setting = await SelectSetting();
    const subscribe = JSON.parse(setting.subscribe);
    if (text < subscribe.minD || text > subscribe.maxD)
      return ctx.reply(i18n.t("ESHTERAK_BUY.CUSTOMIZE.ERROR_DAY", { min: subscribe.minD, max: subscribe.maxD }), {
        parse_mode: "html",
      });
    if (Number(text) % 5 !== 0) return ctx.reply(i18n.t("ESHTERAK_BUY.CUSTOMIZE.ERROR_FLOW_DAY"));
    ctx.session.state = STATE_LIST.SENDTRAFICC;
    ctx.session.time = text;
    ctx.reply(i18n.t("ESHTERAK_BUY.CUSTOMIZE.TRAFFIC", { price: NumberFormat(subscribe.priceT) }), {
      ...menu.BackButton(),
      parse_mode: "html",
    });
  },
  // for send traffic user
  [STATE_LIST.SENDTRAFICC]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    const setting = await SelectSetting();
    const subscribe = JSON.parse(setting.subscribe);
    if (text < subscribe.minT || text > subscribe.maxT)
      return ctx.reply(i18n.t("ESHTERAK_BUY.CUSTOMIZE.ERROR_DAY", { min: subscribe.minT, max: subscribe.maxT }), {
        parse_mode: "html",
      });
    if (Number(text) % 5 !== 0) return ctx.reply(i18n.t("ESHTERAK_BUY.CUSTOMIZE.ERROR_FLOW_DAY"));
    // save to session
    delete ctx.session.state;
    const { time } = ctx.session;
    const prices = Number(text) * subscribe.priceT + Number(time) * subscribe.priceD;
    ctx.session.traficc = text;
    ctx.session.price = prices;
    ctx.session.name = "سفارشی";
    ctx.session.type = "sefareshi";
    const allPelan = await selectAllInboundType();
    ctx.reply(i18n.t("ESHTERAK_BUY.INBOUND.ANSWER"), {
      ...menu.SelectServise(allPelan),
      parse_mode: "html",
    });
  },
};

export default BuyEshterak;
