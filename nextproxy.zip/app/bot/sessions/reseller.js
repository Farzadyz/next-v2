import { STATE_LIST } from "./state.js";
import { selectUser, UpdateUser } from "../../controllers/Users.js";
import { CreateReseller, DeleteReseller, SelectResellerByToken } from "../../controllers/Reseller.js";
import { validateBotToken, deployAndLaunch, destroyReseller } from "../reseller/ResellerManager.js";
import { NumberFormat } from "../utils/utils.js";

const Reseller = {
  [STATE_LIST.ASK_RESELLER_TOKEN]: async ({ ctx, i18n, menu }) => {
    const token = ctx.message.text.trim();
    const fee = ctx.session.resellerFee ?? 0;
    delete ctx.session.state;
    delete ctx.session.resellerFee;

    const refundAndReply = async (message) => {
      const user = await selectUser({ id: ctx.from.id });
      if (fee > 0) await UpdateUser({ id: ctx.from.id }, { price: user.price + fee });
      return ctx.reply(message, menu.MainMenuButtons());
    };

    const existing = await SelectResellerByToken({ bot_token: token });
    if (existing) return refundAndReply(i18n.t("RESELLER.TOKEN_TAKEN"));

    const { valid, username } = await validateBotToken(token);
    if (!valid) return refundAndReply(i18n.t("RESELLER.TOKEN_INVALID"));

    const reseller = await CreateReseller({ owner_id: ctx.from.id, bot_token: token, bot_username: username });
    await ctx.reply("⏳ در حال ساخت نسخه اختصاصی و ایزوله ربات شما (کد و دیتابیس مستقل) ...");
    try {
      // own code folder + own database + own process, linked to us only by the REST API
      await deployAndLaunch(reseller);
    } catch (error) {
      console.error("[Reseller] deploy failed", error);
      await destroyReseller(reseller.id).catch(() => {});
      await DeleteReseller({ id: reseller.id }).catch(() => {});
      return refundAndReply("❌ راه‌اندازی ربات نمایندگی با خطا مواجه شد. مبلغ کسر شده به کیف پول شما بازگردانده شد؛ لطفا بعدا دوباره تلاش کنید.");
    }

    ctx.replyWithHTML(i18n.t("RESELLER.CREATED", { username, fee: NumberFormat(fee) }), menu.MainMenuButtons());
  },
};

export default Reseller;
