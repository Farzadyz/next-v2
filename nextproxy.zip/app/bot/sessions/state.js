const STATE_LIST = {
  //  buy eshterak
  SENDTRAFICC: "send_traficc_customize",
  SENDDAY: "send_day",
  // redirect
  REDIRECT: "redireact",
  // gift
  GIFT: "send_gift",
  // setname
  SETNAME: "setname",
  // support
  SUPPORT: "support",
  SUPPORT_ADMIN: "support_admin",
  // price
  COUNT_PRICE: "count_price",
  SEND_PHOTO: "send_photo",
  // get agent
  GET_AGENT: "get_agent",
  // reseller bot
  ASK_RESELLER_TOKEN: "ask_reseller_token",
};

export { STATE_LIST };
