import I18N, { I18NK } from "../utils/I18n.js";
import { STATE_LIST } from "./state.js";

const Agent = {
  // get agent
  [STATE_LIST.GET_AGENT]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    if (I18N(ctx, "GET_AGENT.MENU").includes(text)) {
      const EventListener = {
        // charge && get acaent
        [i18n.t("GET_AGENT.MENU.CHARGE_GET_AGENT")]: async ({ ctx, menu, i18n }) => {
          ctx.reply(i18n.t("GET_AGENT.CHARGE_GET_AGENT"), menu.RediretSupport());
        },
        // terms recepit
        [i18n.t("GET_AGENT.MENU.TERMS_RECEIPT")]: async ({ ctx, i18n }) => {
          ctx.reply(i18n.t("GET_AGENT.TERMS_RECEIPT"));
        },
        // terms recepit
        [i18n.t("GET_AGENT.MENU.QUESTION")]: async ({ ctx, i18n }) => {
          ctx.reply(i18n.t("GET_AGENT.QUESTION.ANSWER"), menu.QuestionsAgent(I18NK(ctx, "GET_AGENT.QUESTION.MENU")));
        },
      };
      return EventListener[text]({ ctx, i18n, menu });
    }
  },
};

export default Agent;
