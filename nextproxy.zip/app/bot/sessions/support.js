import { STATE_LIST } from "./state.js";

const Support = {
  // send message for admin
  [STATE_LIST.SUPPORT]: ({ ctx, i18n, menu }) => {
    ctx.session.state = undefined;
    ctx.reply(i18n.t("SUPPORT.SEND_SUCCEFULY"), menu.MainMenuButtons());
    const admins = JSON.parse(process.env.ADMIN);
    // send message for admins
    admins.map((id) =>
      ctx.reply(`${ctx.message.text}\n@${ctx.from.username}`, {
        chat_id: id,
        ...menu.AdminSupportButton(ctx.from.id),
      })
    );
  },
  // answer admin
  [STATE_LIST.SUPPORT_ADMIN]: ({ ctx, i18n }) => {
    delete ctx.session.state;
    ctx.reply(ctx.message.text, { chat_id: ctx.session.asnwer_id });
    ctx.reply(i18n.t("SUPPORT.SUCCESFULY_SUPPORT_MESSAGE"));
  },
};

export default Support;
