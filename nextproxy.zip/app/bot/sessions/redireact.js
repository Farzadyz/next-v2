import { UpdateServise } from "../../controllers/Servise.js";
import { selectUser } from "../../controllers/Users.js";
import Servise from "../model/servise.js";
import { STATE_LIST } from "./state.js";

const Redireact = {
  // redireact
  [STATE_LIST.REDIRECT]: async ({ ctx, i18n, menu }) => {
    const id = ctx.message.text;
    if (isNaN(id)) return ctx.reply(i18n.t("PANEL.CHANGE_PRICE.ERROR_NUMBER"));
    const selectUsers = await selectUser({ id });
    if (!selectUsers) return ctx.reply(i18n.t("MY_ESHTERAK.REDIRECT.NOT_FOUND"));
    const ids = ctx.session.id;
    UpdateServise({ id: ids }, { telegram_id: id });
    ctx.replyWithHTML(i18n.t("MY_ESHTERAK.REDIRECT.SEND", { ids }), {
      chat_id: id,
    });
    ctx.reply(i18n.t("MY_ESHTERAK.REDIRECT.SUCCEFULY"), menu.MainMenuButtons());
    delete ctx.session.state;
    delete ctx.session.id;
    const servises = new Servise();
    await servises.ChangeStatus({ id: ids });
  },
};

export default Redireact;
