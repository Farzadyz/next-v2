import { selectInbound } from "../../controllers/Inbound.js";
import { SelectPeyment, UpdatePeyment } from "../../controllers/Peyment.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectUser } from "../../controllers/Users.js";
import { STATE_LIST } from "../sessions/state.js";
import { NumberFormat } from "../utils/utils.js";

const Setname = {
  // set name
  [STATE_LIST.SETNAME]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    // error lentgh
    if (text.length > 25 || !/^[a-zA-Z0-9]*$/.test(text) || /\s/.test(text)) return ctx.reply(i18n.t("SETNAME.ERROR_LENTGH"));
    delete ctx.session.state;
    var { price, traficc, day, name, location } = await SelectPeyment({ id: ctx.session.id });
    const selectinbounds = await selectInbound({ id: location });
    // servise vip
    let textservervip = "";
    if (selectinbounds.price) {
      textservervip = i18n.t("ESHTERAK_BUY.SERVER_VIP", { price: selectinbounds.price });
    }

    var name = `<del>${name}</del> ${text}`;
    const trxprice = price - (price * 10) / 100;
    const { first_payment } = await SelectSetting();
    const user = await selectUser({ id: ctx.from.id });

    await ctx.replyWithHTML(
      i18n.t("ESHTERAK_BUY.FIANAL_BUY", {
        newPrice: NumberFormat(price),
        location: selectinbounds.location,
        pelan: name,
        time: day,
        traficc,
        textservervip,
      }),
      menu.FinalBuy(ctx.session.id, trxprice, user.first_payment, first_payment)
    );
    ctx.reply(i18n.t("SETNAME.SUCCEFULY"));
    UpdatePeyment({ id: ctx.session.id }, { name: text, defaultname: false });
  },
};

export default Setname;
