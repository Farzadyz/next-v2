import { SelectCard } from "../../controllers/Card.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { PanelButtons } from "../panel/buttons/ButtonsPanel.js";
import { NumberFormat } from "../utils/utils.js";
import { STATE_LIST } from "./state.js";

const Price = {
  // send count price
  [STATE_LIST.COUNT_PRICE]: async ({ ctx, i18n, menu }) => {
    const text = ctx.message.text;
    // error number
    if (isNaN(text)) return ctx.reply(i18n.t("PRICE.ERROR_NUMBER"));
    // error min and max
    if (text < 5000 || text > 1000000) return ctx.reply(i18n.t("PRICE.ERROR_NUMBER_BIG"));
    const setting = await SelectSetting();
    const pay = JSON.parse(setting.pay).filter((e) => e.value == true);
    ctx.reply(i18n.t("PRICE.SELECT_TYPE"), menu.SelectPay(pay, text));
  },
  [STATE_LIST.SEND_PHOTO]: async ({ ctx, i18n, menu }) => {
    if (!ctx.message?.photo) return ctx.reply(i18n.t("PAY.CARD.ERROR_PHOTO"));

    const datacard = await SelectCard({ id: ctx.session.amount });
    ctx.reply(i18n.t("PAY.CARD.ANSWER"), menu.MainMenuButtons());
    const menuPanel = new PanelButtons(ctx);
    // setting
    const setting = await SelectSetting();
    ctx.sendPhoto(ctx.message.photo[0].file_id, {
      caption: i18n.t("PAY.CARD.SEND_ADMIN", { amount: NumberFormat(datacard.amount), id: ctx.from.id }),
      chat_id: setting.id_card,
      ...menuPanel.AcsseptResidServise(datacard.id),
    });
  },
};

export default Price;
