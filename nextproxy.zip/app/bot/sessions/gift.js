import { SelectGift, UpdateGift } from "../../controllers/Gift.js";
import { selectInbound } from "../../controllers/Inbound.js";
import { SelectPeyment, UpdatePeyment } from "../../controllers/Peyment.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectUser } from "../../controllers/Users.js";
import { NumberFormat } from "../utils/utils.js";
import { STATE_LIST } from "./state.js";

const Gift = {
  // send gift
  [STATE_LIST.GIFT]: async ({ ctx, i18n, menu }) => {
    // delete ctx.session.state;
    const gift = await SelectGift({ code: ctx.message.text });
    // error code
    if (!gift || JSON.parse(gift.used).length >= gift.limit) return ctx.reply(i18n.t("GIFT.ERROR_GIFT_MESSAGE"));
    // before used
    const used = JSON.parse(gift.used);
    const find = used.find((e) => e == ctx.from.id);
    if (find) return ctx.reply(i18n.t("GIFT.ERROR_BEFORE"));
    used.push(ctx.from.id);
    await UpdateGift({ code: ctx.message.text }, { used: JSON.stringify(used) });
    // select peyment
    var { price, traficc, day, name, location } = await SelectPeyment({ id: ctx.session.id });
    let textGift;
    // darsad
    if (gift.gift.includes("%")) {
      const match = gift.gift.split("%");
      const filter = match.filter(Boolean);
      var percentage = parseFloat(filter[0]) / 100;
      price -= price * percentage;
      textGift = " درصد";
      await ctx.reply(i18n.t("GIFT.SUCCESS_GIFT_MESSAGE", { gift: gift.gift }));
    } else {
      price -= gift.gift;
      textGift = " تومان";
      await ctx.reply(i18n.t("GIFT.SUCCESS_GIFT_MESSAGE_PRICE", { gift: gift.gift }));
    }
    await UpdatePeyment({ id: ctx.session.id }, { price, gift: JSON.stringify({ code: gift.code, gift: gift.gift + textGift }) });
    const selectinbounds = await selectInbound({ id: location });
    // servise vip
    let textservervip = "";
    if (selectinbounds.price) {
      textservervip = i18n.t("ESHTERAK_BUY.SERVER_VIP", { price: selectinbounds.price });
    }
    const trxprice = price - (price * 10) / 100;
    const { first_payment } = await SelectSetting();
    const user = await selectUser({ id: ctx.from.id });

    ctx.replyWithHTML(
      i18n.t("ESHTERAK_BUY.FIANAL_BUY", {
        newPrice: NumberFormat(price),
        location: selectinbounds.location,
        pelan: name,
        time: day,
        traficc,
        textservervip,
      }),
      menu.FinalBuy(ctx.session.id, trxprice, user.first_payment, first_payment)
    );
  },
};

export default Gift;
