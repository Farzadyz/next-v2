// get pagination
const getPagination = (current, maxpage, callback = "PAGE") => {
  var keys = [];
  if (current > 1) keys.push({ text: `1`, callback_data: callback + "_1" });
  if (current > 2) keys.push({ text: `${current - 1}`, callback_data: callback + "_" + (current - 1).toString() });
  keys.push({ text: `✔️ ${current}`, callback_data: "NONE" });
  if (current < maxpage - 1) keys.push({ text: `${current + 1}`, callback_data: callback + "_" + (current + 1).toString() });
  if (current < maxpage) keys.push({ text: `${maxpage}`, callback_data: callback + "_" + maxpage.toString() });

  return keys;
};

export { getPagination };
