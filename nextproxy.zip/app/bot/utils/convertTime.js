function convertDaysToDuration(days) {
  const years = Math.floor(days / 365);
  const months = Math.floor((days % 365) / 30);
  const remainingDays = days % 30;

  let result = "";

  if (years > 0) {
    result += `${years} سال`;
  }

  if (months > 0) {
    result += `${result.length > 0 ? " و " : ""}${months} ماه`;
  }

  if (remainingDays > 0) {
    result += `${result.length > 0 ? " و " : ""}${remainingDays} روز`;
  }

  if (result.length === 0) {
    result = "صفر روز";
  }

  return result;
}

export { convertDaysToDuration };
