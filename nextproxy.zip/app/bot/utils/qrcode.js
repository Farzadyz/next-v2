import QRCode from "qrcode";
import fs from "fs";
import { Input } from "telegraf";

// With async/await
const generateQR = (text) =>
  new Promise((res, rej) =>
    QRCode.toBuffer(text, { errorCorrectionLevel: "H" }, (err, buffer) => {
      if (err) rej(err);
      res(buffer);
    })
  );

export { generateQR };
