const I18N = (ctx, url) => {
  const data = ctx.i18n.t(url);
  let array = [];
  Object.entries(data).forEach(([key]) => {
    array.push(ctx.i18n.t(`${url}.${key}`));
  });
  return array;
};

export const I18NK = (ctx, url) => {
  const data = ctx.i18n.t(url);
  let array = [];
  Object.entries(data).forEach(([key]) => {
    array.push({ text: ctx.i18n.t(`${url}.${key}`), key });
  });
  return array;
};

export default I18N;
