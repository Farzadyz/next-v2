const Is_join = async (ctx) => {
  try {
    const ckeckJoin = await ctx.telegram.getChatMember(process.env.CHANNEL, ctx.from.id);
    if (ckeckJoin.status == "left" || ckeckJoin.status == "kicked") return false;
    return true;
  } catch (error) {
    return false;
  }
};

export default Is_join;
