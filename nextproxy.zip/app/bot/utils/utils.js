// chunk for joda sazi array
const chunk = (arr, size) => Array.from({ length: Math.ceil(arr.length / size) }, (v, i) => arr.slice(i * size, i * size + size));

const NumberFormat = (number) => {
  return new Intl.NumberFormat("us-us", { maximumSignificantDigits: 3 }).format(number);
};

// random key
const handleRandom = (length) => {
  const charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
  let password = "";
  for (var i = 0, n = charset.length; i < length; ++i) {
    password += charset.charAt(Math.floor(Math.random() * n));
  }
  return password;
};

export { chunk, NumberFormat, handleRandom };
