import fs from "fs";
import path from "path";
import yaml from "js-yaml";
import { SelectAllBotTexts, UpsertBotText, DeleteBotText } from "../../controllers/BotText.js";

// ============================================================================
// Dynamic Text & Button Management
//
// Every bot text and button label already flows through ctx.i18n.t(key, ...)
// against locales/fa.yaml. Instead of touching every call site, this module
// patches ctx.i18n.t once per request so it checks an in-memory cache (backed
// by the `bot_texts` table) before falling back to the yaml default. Editing
// a text in the admin panel updates the cache immediately, so changes are
// live with no restart and no code changes required anywhere else.
// ============================================================================

const LOCALE_PATH = path.resolve("locales", "fa.yaml");

// key -> current override value (string, with ${var} placeholders untouched)
let overrideCache = {};
// key -> default value taken from locales/fa.yaml (flattened, dot-notated)
let defaultsFlat = {};
// ordered list of top-level yaml sections, e.g. ["MENU", "PANEL", ...]
let categoryList = [];

const isPlainObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);

// Turn the nested yaml object into a flat { "PANEL.MENU_PANEL.BACK_PANEL": "..." } map.
const flatten = (node, prefix, out) => {
  Object.entries(node).forEach(([key, value]) => {
    const fullKey = prefix ? `${prefix}.${key}` : key;
    if (isPlainObject(value)) {
      flatten(value, fullKey, out);
    } else if (value !== undefined && value !== null) {
      out[fullKey] = String(value);
    }
  });
  return out;
};

// Re-read locales/fa.yaml from disk. Called once at startup; safe to call
// again later (e.g. from a manual admin "reload" action) since it never
// touches the database overrides.
const loadDefaults = () => {
  try {
    const raw = fs.readFileSync(LOCALE_PATH, "utf8");
    const parsed = yaml.load(raw) || {};
    defaultsFlat = flatten(parsed, "", {});
    categoryList = Object.keys(parsed);
  } catch (error) {
    console.error("[DynText] Failed to parse locales/fa.yaml:", error.message);
    // Keep whatever we already had cached rather than wiping it out.
    if (!categoryList.length) categoryList = [];
  }
};

// Pull every override row from the database into memory. Called once at
// bot startup, and re-run implicitly (per-key) whenever the admin edits a
// text through setOverride()/removeOverride() below.
const loadDynTextCache = async () => {
  loadDefaults();
  try {
    const rows = await SelectAllBotTexts();
    overrideCache = {};
    rows.forEach((row) => {
      overrideCache[row.text_key] = row.value;
    });
  } catch (error) {
    console.error("[DynText] Failed to load overrides from database:", error.message);
  }
};

// Replace ${varName} placeholders the same way the values in fa.yaml do.
const applyTemplate = (str, params) => {
  if (!params || typeof str !== "string") return str;
  return str.replace(/\$\{(\w+)\}/g, (match, name) => (Object.prototype.hasOwnProperty.call(params, name) ? params[name] : match));
};

// Called by ctx.i18n.t after patching - returns the live text for a key, or
// null if there is no default and no override for it (caller should fall
// back to whatever the original i18n implementation would have returned).
const resolveText = (key, params) => {
  if (Object.prototype.hasOwnProperty.call(overrideCache, key)) {
    return applyTemplate(overrideCache[key], params);
  }
  return null;
};

// Idempotently wraps ctx.i18n.t so DB overrides take priority over the yaml
// defaults, without needing any change in the ~80 files that already call
// ctx.i18n.t(...) throughout the bot.
const patchI18n = (i18n) => {
  if (!i18n || i18n.__dynTextPatched) return;
  const originalT = i18n.t.bind(i18n);
  i18n.t = (key, params) => {
    const override = resolveText(key, params);
    if (override !== null) return override;
    return originalT(key, params);
  };
  i18n.__dynTextPatched = true;
};

// ---- Admin-panel browsing helpers ----------------------------------------

const getCategories = () => {
  return categoryList.map((category) => ({
    category,
    count: Object.keys(defaultsFlat).filter((key) => key === category || key.startsWith(`${category}.`)).length,
  }));
};

const getKeysInCategory = (category) => {
  return Object.keys(defaultsFlat)
    .filter((key) => key === category || key.startsWith(`${category}.`))
    .sort();
};

const getDefaultValue = (key) => defaultsFlat[key];

const getCurrentValue = (key) => (Object.prototype.hasOwnProperty.call(overrideCache, key) ? overrideCache[key] : defaultsFlat[key]);

const isOverridden = (key) => Object.prototype.hasOwnProperty.call(overrideCache, key);

// ---- Admin-panel write helpers --------------------------------------------

const setOverride = async (key, value) => {
  await UpsertBotText({ text_key: key, value });
  overrideCache[key] = value;
};

const removeOverride = async (key) => {
  await DeleteBotText({ text_key: key });
  delete overrideCache[key];
};

export {
  loadDynTextCache,
  patchI18n,
  getCategories,
  getKeysInCategory,
  getDefaultValue,
  getCurrentValue,
  isOverridden,
  setOverride,
  removeOverride,
};
