import { jsPDF } from "jspdf";
import "./calibril-normal.js"; // Light
import "./calibri-normal.js"; // Light
import "jspdf-autotable";

const CreatePdf = async (body) => {
  const unit = "pt";
  const size = "A4"; // Use A1, A2, A3 or A4
  const orientation = "portrait"; // portrait or landscape

  const doc = new jsPDF(orientation, unit, size);
  doc.setLanguage("fa-IR");
  doc.setFont("calibril");

  // Or use javascript directly:
  doc.autoTable({
    columnStyles: { halign: "left" },
    columns: [
      { header: "ایدی", dataKey: "id" },
      { header: "شماره تماس", dataKey: "phone" },
      { header: "ایدی عددی خریدار", dataKey: "belongs" },
      { header: "(مبلغ)تومان ", dataKey: "price" },
      { header: "تاریخ خرید", dataKey: "time" },
    ],
    body,
    theme: "striped",
    columnStyles: { halign: "left" },
    headStyles: { fillColor: "#60C4A6", fontSize: 10 },
    styles: { font: "calibri", halign: "center", align: "right" },
  });
  const timestamp = new Date().getTime();
  const randomNum = Math.floor(Math.random() * 100000);
  doc.save("app/bot/pdf/" + timestamp + randomNum + ".pdf");
  return "app/bot/pdf/" + timestamp + randomNum + ".pdf";
};

export default CreatePdf;
