import { Markup } from "telegraf";
import { chunk } from "../utils/utils.js";
import { getPagination } from "../utils/pagination.js";
import Servise from "../model/servise.js";
import { i18nL } from "../index.js";
import { convertDaysToDuration } from "../utils/convertTime.js";

const Join = () => {
  return Markup.inlineKeyboard([Markup.button.url("🔗 عضویت در کانال", "https://t.me/+y-UOUS0KWXhkNmY0")]);
};

// FIX (initData empty / 401 "missing"): a web_app button placed on the
// regular reply keyboard (Markup.keyboard) never receives signed initData -
// Telegram's own docs state initData is empty when a Mini App is launched
// from a keyboard button or from inline mode. Inline keyboard buttons DO NOT
// have that limitation and, like a keyboard button, open the Mini App on a
// single tap - so the app button is now sent as its own message with an
// inline button (see sendMainMenu below) instead of living on the keyboard.
const WebAppOpenButton = () => {
  return Markup.inlineKeyboard([Markup.button.webApp("🚀 ورود به اپلیکیشن", process.env.WEBAPP_URL)]);
};

// Sends the main menu exactly as before, then - if a Mini App is configured -
// immediately follows it with a second message containing ONLY the inline
// open-app button, so opening the app is always a single tap for the user,
// with no dead placeholder button and no round trip through the bot.
const sendMainMenu = async (ctx, text, menu) => {
  await ctx.reply(text, menu.MainMenuButtons());
  if (process.env.WEBAPP_URL) {
    await ctx.replyWithHTML(
      "🌐 <b>اپلیکیشن اختصاصی</b>\nمدیریت اشتراک‌ها، کیف پول و حسابت، همه‌جا یکجا.",
      WebAppOpenButton(),
    );
  }
};

class Buttons {
  constructor(ctx) {
    this.i18n = ctx?.i18n ?? null;
  }

  // Keyboard Main Menu
  // BUGFIX: the "🤖 ربات نمایندگی" (request/create reseller bot) row was
  // missing here entirely, even though its i18n key (MENU.RESELLER) and its
  // full handling logic already existed in KeyboardMiddleware.js - the
  // button simply never got rendered into the keyboard, so users had no way
  // to reach it. Restored below as its own row.
  MainMenuButtons() {
    const rows = [
      [this.i18n.t("MENU.ESHTERAK_BUY")],
      [this.i18n.t("MENU.MY_ESHTERAK"), this.i18n.t("MENU.ACCONT")],
      [this.i18n.t("MENU.PRICE"), this.i18n.t("MENU.SUPPORT"), this.i18n.t("MENU.FREE_PROXY")],
      [this.i18n.t("MENU.GET_AGENT"), this.i18n.t("MENU.QUESTION")],
      [this.i18n.t("MENU.RESELLER")],
    ];
    // The app-open button is no longer a row on this keyboard - see
    // sendMainMenu() above for why (a keyboard web_app button can't carry
    // signed initData). sendMainMenu() sends it as a separate inline button
    // right after this menu instead.
    return Markup.keyboard(rows).resize();
  }

  // Keyboard Back
  BackButton() {
    return Markup.keyboard([[this.i18n.t("MENU.BACK")]]).resize();
  }

  // send Number
  SendNumber() {
    return Markup.keyboard([Markup.button.contactRequest(this.i18n.t("SIGN_UP.MENU.SEND_NUMBER"))]).resize();
  }

  // support inlinekeyboard
  AdminSupportButton(id) {
    return Markup.inlineKeyboard([Markup.button.callback("پاسخ", "ANSWERSUPPORT_" + id)]);
  }

  // Keyboard get agent
  GetAgent() {
    return Markup.keyboard([
      [this.i18n.t("GET_AGENT.MENU.TERMS_RECEIPT"), this.i18n.t("GET_AGENT.MENU.QUESTION")],
      [this.i18n.t("GET_AGENT.MENU.CHARGE_GET_AGENT"), this.i18n.t("MENU.BACK")],
    ]).resize();
  }

  // Keyboard rediret to support
  RediretSupport() {
    return Markup.inlineKeyboard([Markup.button.url(this.i18n.t("GET_AGENT.MENU.RESIVE_AGENT"), "https://t.me/" + process.env.IDSUPPORT)]);
  }

  //  Inline Keyboard questions agent
  QuestionsAgent(datas, menu = false) {
    const key = [
      ...chunk(datas, 1).map((items) =>
        items.map((item) => Markup.button.callback(item.text, (menu ? "QUESTION_" : "AGENTQUESTION_") + item.key))
      ),
    ];
    return Markup.inlineKeyboard(key);
  }

  // inlineKeyboard back question
  BackQuestions(menu = false) {
    return Markup.inlineKeyboard([[Markup.button.callback(this.i18n.t("MENU.BACK"), menu ? "BACKMENUQUESTION" : "BACKQUESTION")]]);
  }

  // buy Eshtreak
  // Inline Keyboard select pelean
  SelectPelan(datas) {
    return Markup.inlineKeyboard(
      chunk(datas, 2).map((items) =>
        items.map((item) => Markup.button.callback(this.i18n.t(`ESHTERAK_BUY.MENU.${item.text}`), item.callback))
      )
    );
  }

  // type location
  TypeLocation(paygMulti, paygSingle) {
    const key = [
      [
        Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.MULTILOCATION"), "TYPELOCATION_multi_normal"),
        Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.TAKLOCATION"), "TYPELOCATION_single_normal"),
      ],
    ];
    if (paygMulti) key.push([Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.PAYG_MULTI"), "PAYG_multi")]);
    if (paygSingle) key.push([Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.PAYG_SINGLE"), "PAYG_single")]);
    key.push([Markup.button.callback(this.i18n.t("MENU.BACK"), "BACK_PELAN")]);
    return Markup.inlineKeyboard(key);
  }

  // Inline Keyboard select location for single-location PAYG purchase
  PaygLocations(datas) {
    const key = datas.map((item) => [Markup.button.callback(item.location, "PAYGLOC_" + item.id)]);
    key.push([Markup.button.callback(this.i18n.t("MENU.BACK"), "BACK_PELAN")]);
    return Markup.inlineKeyboard(key);
  }

  // Inline Keyboard select pelan choose
  SelectPelanChoose(datas, type) {
    const key = datas.map((item) => [Markup.button.callback(item.name, type == "single" ? "CHOOSE_" + item.id : "MZCHOOSE_" + item.id)]);
    key.push([Markup.button.callback(this.i18n.t("MENU.BACK"), "BACK_PELAN")]);
    return Markup.inlineKeyboard(key);
  }

  //  Inline Keyboard select custumize choose
  SelectPelanCustumize(datas) {
    const key = [
      ...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(convertDaysToDuration(item), "CUSTUMIZEDAY_" + item))),
    ];
    key.push([Markup.button.callback(this.i18n.t("MENU.BACK"), "BACK_PELAN")]);
    return Markup.inlineKeyboard(key);
  }

  //  Inline Keyboard select custumize traffic
  SelectPelanCustumizeTraficc(datas) {
    const key = [...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(item + " گیگ", "CUSTUMIZETRAFICC_" + item)))];
    key.push([Markup.button.callback(this.i18n.t("MENU.BACK"), "BACK_PELAN")]);
    return Markup.inlineKeyboard(key);
  }

  // select servise
  SelectServise(datas) {
    const key = [...chunk(datas, 2).map((items) => items.map((item) => Markup.button.callback(item.location, "SERVICE_" + item.id)))];
    key.push([Markup.button.callback(this.i18n.t("MENU.BACK"), "BACK_PELAN")]);
    return Markup.inlineKeyboard(key);
  }

  // inlineKeyboard Fainal buy Eshterak
  // inlineKeyboard Final buy Eshterak
  FinalBuy(id, amount, firstpayment, frstSetting, justpay = false) {
    const key = [];

    if (frstSetting) {
      // ردیف اول: پرداخت فوری
      const firstRow = [Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.FINAL_TRX"), "PEYDARGAHCARD_" + id)];

      // اگر پرداخت اولی است، دکمه‌های اضافی اضافه کن
      if (firstpayment) {
        firstRow.splice(1, 0, Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.FAINAL"), "PEYMENT_" + id));
        key.push(firstRow);
        key.push([Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), "PEYDARGAH_" + id)]);
      } else {
        key.push(firstRow);
      }

      // دکمه‌های هدیه و تنظیم نام فقط اگر justpay=false باشد
      if (!justpay) {
        key.push([
          Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.GIFT"), "GIFT_" + id),
          Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.SETNAME"), "SETNAME_" + id),
        ]);
      }
      key.push([Markup.button.callback(this.i18n.t("CRYPTO.MENU.CRYPTO_PAY"), "CRYPTOPAY_" + amount + "_" + id)]);

      return Markup.inlineKeyboard(key);
    } else {
      // حالت غیر frstSetting
      const buttons = [
        [
          Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), "PEYDARGAH_" + id),
          Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.FAINAL"), "PEYMENT_" + id),
        ],
        [Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.FINAL_TRX"), "PEYDARGAHCARD_" + id)],
        [Markup.button.callback(this.i18n.t("CRYPTO.MENU.CRYPTO_PAY"), "CRYPTOPAY_" + amount + "_" + id)],
      ];

      // دکمه‌های GIFT و SETNAME فقط اگر justpay=false باشد
      if (!justpay) {
        buttons.push([
          Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.GIFT"), "GIFT_" + id),
          Markup.button.callback(this.i18n.t("ESHTERAK_BUY.MENU.SETNAME"), "SETNAME_" + id),
        ]);
      }

      return Markup.inlineKeyboard(buttons);
    }
  }

  // inlineKeyboard crypto (NowPayments) invoice - check button
  CryptoInvoice(id) {
    return Markup.inlineKeyboard([[Markup.button.callback(this.i18n.t("CRYPTO.MENU.CHECK"), "NOWCRYPTOCHECK_" + id)]]);
  }

  // inlineKeyboard send connection
  SendConnection() {
    return Markup.inlineKeyboard([
      [
        Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.CONNECT_ANDROID"), "https://t.me/test"),
        Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.CONNECT_IOS"), "https://t.me/test"),
      ],
      [Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.CONNECT_PC"), "https://t.me/test")],
    ]);
  }

  async Myeshterakkeyboard(datas, page, count) {
    let addPagination = [];
    if (count > 10) {
      const countPage = Math.ceil(count / 10);
      addPagination = getPagination(page, countPage);
    }
    const Servises = new Servise();

    // اجرای تمام promise‌ها و دریافت نتایج نهایی
    const dataWithButtons = await Promise.all(
      datas.map(async (data) => {
        const getServise = await Servises.SelectServise({ id: data.id, i18n: this.i18n });
        return [
          Markup.button.callback(
            `${this.i18n.t("MY_ESHTERAK.MENU.TEXT_ID")} : ${data.id} - (${
              data.defaultname ? Servises.trafficConvert(data.data_limit) : data.name
            }) - ${getServise && getServise.keyboard ? "🟢" : "🔴"}`,
            "MYESHTERAK_" + data.id
          ),
        ];
      })
    );

    return Markup.inlineKeyboard([
      [Markup.button.switchToChat(this.i18n.t("MY_ESHTERAK.MENU.SEARCH"), "")],
      ...dataWithButtons,
      addPagination,
    ]);
  }

  // inlineKeyboard My Eshterak
  InfoMyestErakkeyboard(id, status, status_api, canRefund = false) {
    let keyboard;
    if (status == "free") {
      keyboard = [
        [
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.DELETE"), "DELETEESHTERAK_" + id),
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.REFRESH"), "UPDATEESHTERAK_" + id),
        ],
      ];
    } else if (!status) {
      keyboard = [
        [
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.DELETE"), "DELETEESHTERAK_" + id),
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.TAMDID"), "TAMDIDESHTERAK_" + id),
        ],
        [Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.UPDATE"), "UPGERATE_" + id)],
      ];
    } else {
      keyboard = [
        [
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.QR_CODE"), "QRCODE_" + id),
          Markup.button.callback(`${this.i18n.t("MY_ESHTERAK.MENU.STATUS_API")} : ${status_api ? "✅" : "❌"}`, `CHANGESTATUS_${id}`),
        ],
        [
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.UPDATE"), "UPGERATE_" + id),
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.TAMDID"), "TAMDIDESHTERAK_" + id),
        ],
        [
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.REFRESH"), "UPDATEESHTERAK_" + id),
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.PASSWORD"), "CHANGEPASESHTERAK_" + id),
        ],
        [
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.REDIRECT"), "REDIRECT_" + id),
          Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.DELETE"), "DELETEESHTERAK_" + id),
        ],
      ];
    }
    if (canRefund) {
      keyboard.push([Markup.button.callback(this.i18n.t("REFUND.MENU.CANCEL_REFUND"), "REFUNDESHTERAK_" + id)]);
    }
    return Markup.inlineKeyboard([...keyboard, [Markup.button.callback(this.i18n.t("MENU.BACK"), "BACKINFO")]]);
  }

  // inlineKeyboard Upgerate Eshterak
  Upgerateeshterak(id, datas) {
    return Markup.inlineKeyboard([
      ...datas.map((data) => {
        return [Markup.button.callback(data.name + " - " + data.price + " تومان", `FAINALUPGERADE_${id}_${data.id}`)];
      }),
    ]);
  }

  // inlineKeyboard Fainal Upgerate Eshterak
  FainalUpgeradeEshterak(id, id_upgrade) {
    return Markup.inlineKeyboard([[Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.BT_UPGERADE"), `ERTEGA_${id}_${id_upgrade}`)]]);
  }

  // inlineKeyboard Tamdid Eshterak
  TamdidinlineKeyboardOne(id, back = true) {
    if (back) {
      return Markup.inlineKeyboard([
        [Markup.button.callback(i18nL.t("fa", "MY_ESHTERAK.MENU.TAMDID"), "TAMDIDESHTERAK_" + id + "_NOMARRID")],

        [Markup.button.callback(this.i18n.t("MENU.BACK"), "BACKESHTERAK_" + id)],
      ]);
    } else {
      return Markup.inlineKeyboard([
        [Markup.button.callback(i18nL.t("fa", "MY_ESHTERAK.MENU.TAMDID"), "TAMDIDESHTERAK_" + id + "_NOMARRID")],
      ]);
    }
  }

  // inlineKeyboard Tamdid Eshterak
  TamdidEshterak(id) {
    return Markup.inlineKeyboard([[Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.BT_TAMDID"), "TAMDID_" + id)]]);
  }

  // inlineKeyboard Delete Eshterak
  DeleteEshterakinlineKeyboard(id) {
    return Markup.inlineKeyboard([
      [Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.DELETE"), "VERIFYDELETEESHTERAK_" + id)],
      [Markup.button.callback(this.i18n.t("MENU.BACK"), "BACKESHTERAK_" + id)],
    ]);
  }

  // inlineKeyboard Refund (cancel & refund) Eshterak
  RefundEshterakinlineKeyboard(id) {
    return Markup.inlineKeyboard([
      [Markup.button.callback(this.i18n.t("REFUND.MENU.CANCEL_REFUND"), "VERIFYREFUNDESHTERAK_" + id)],
      [Markup.button.callback(this.i18n.t("MENU.BACK"), "BACKESHTERAK_" + id)],
    ]);
  }

  // inlineKeyboard Update Eshterak
  UpdateEshterakinlineKeyboard(id) {
    return Markup.inlineKeyboard([[Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.REFRESH"), "UPDATEESHTERAK_" + id)]]);
  }

  // inlineKeyboard Verify Change Password and secret Eshterak
  ChangePasswordinlineKeyboard(id) {
    return Markup.inlineKeyboard([
      [Markup.button.callback(this.i18n.t("MY_ESHTERAK.MENU.PASSWORD"), "VERIFYCHANGEPASESHTERAK_" + id)],
      [Markup.button.callback(this.i18n.t("MENU.BACK"), "BACKESHTERAK_" + id)],
    ]);
  }

  // pay
  // Inline Keyboard select pay
  SelectPay(datas, price) {
    return Markup.inlineKeyboard(
      chunk(datas, 2).map((items) =>
        items.map((item) => Markup.button.callback(this.i18n.t(`PRICE.MENU.${item.text}`), item.text + "_" + price))
      )
    );
  }

  // pay in peyment
  Pay(url) {
    return Markup.inlineKeyboard([
      [Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), process.env.URL_DOMAIN + "payment?url=" + url)],
    ]);
  }

  // pay in trapi
  PayTerapi(url, bot_url) {
    return Markup.inlineKeyboard([
      [Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), process.env.URL_DOMAIN + "payment?url=" + url)],
      [Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.FIBAIL_BOT_PAY"), bot_url)],
    ]);
  }

  PaySizpay(url) {
    return Markup.inlineKeyboard([[Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), url)]]);
  }

  // pay atlaspay - customerStartLink is already a t.me deep link, must NOT be wrapped
  // through the domain proxy (menu.Pay) or telegram opens it as a webpage instead of natively
  PayAtlaspay(url) {
    return Markup.inlineKeyboard([[Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), url)]]);
  }

  // pay tonpays - payment_url/invoice_url is a t.me deep link, same reasoning as PayAtlaspay
  PayTonpays(url) {
    return Markup.inlineKeyboard([[Markup.button.url(this.i18n.t("ESHTERAK_BUY.MENU.FINAIL_PAY"), url)]]);
  }

  // check in peyment
  CheckPay(id, link) {
    return Markup.inlineKeyboard([
      [Markup.button.url(this.i18n.t("PRICE.MENU_SARAFI"), link)],
      [Markup.button.callback(this.i18n.t("PRICE.MENU_NOWPAY"), "NOWPEY_" + id)],
    ]);
  }

  // support inlinekeyboard
  buyPriceGift(id) {
    return Markup.inlineKeyboard([Markup.button.callback(i18nL.t("fa", "ESHTERAK_BUY.MENU.BUY"), "BUYPRICEGIFT_" + id)]);
  }
}

export { Buttons, Join, WebAppOpenButton, sendMainMenu };
