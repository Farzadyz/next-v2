import ExcelJS from "exceljs";

const CreateExcel = async (body) => {
  // Create a workbook and add a worksheet
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Sheet 1");

  // Define column headers
  const columns = [
    { header: "ایدی", key: "id" },
    { header: "شماره تماس", key: "code" },
    { header: "ایدی عددی خریدار", key: "telegram_id" },
    { header: "مبلغ (تومان)", key: "price" },
    { header: "تاریخ خرید", key: "createdAt" },
  ];

  // Add columns to the worksheet
  worksheet.columns = columns;

  // Add data to the worksheet
  body.forEach((row) => {
    worksheet.addRow(row);
  });

  // Generate a unique filename for the Excel file
  const timestamp = new Date().getTime();
  const randomNum = Math.floor(Math.random() * 100000);
  const excelFilePath = `app/bot/excel/${timestamp}${randomNum}.xlsx`;

  // Save the workbook as an Excel file
  await workbook.xlsx.writeFile(excelFilePath);

  return excelFilePath;
};

export default CreateExcel;
