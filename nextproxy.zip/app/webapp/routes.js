import { Router } from "express";
import { telegramAuth, requireAdmin } from "./auth.js";
import * as UserApi from "./controllers/userApi.js";
import * as AdminApi from "./controllers/adminApi.js";
import * as ShopApi from "./controllers/shopApi.js";
import * as ServiceApi from "./controllers/serviceApi.js";

// ============================================================================
// REST surface for the Telegram Mini App, mounted at /webapp/api.
// EVERY route below runs behind telegramAuth first (verified initData) - there
// is no unauthenticated route in this router. Admin routes additionally run
// behind requireAdmin, which checks the SAME process.env.ADMIN list the bot
// itself uses - a regular user's initData will always fail that check with a
// plain 403, however it is called or what it claims about itself.
// ============================================================================

const router = Router();
router.use("/webapp/api", telegramAuth);

const ok = (res, data = {}) => res.json({ ok: true, ...data });
const fail = (res, error, status = 400) => res.status(status).json({ ok: false, error });
const wrap = (handler) => async (req, res) => {
  try {
    await handler(req, res);
  } catch (error) {
    console.error("[webapp api]", req.method, req.path, error);
    fail(res, "server_error", 500);
  }
};

// ------------------------------------------------------------------- role --

router.get(
  "/webapp/api/me",
  wrap(async (req, res) => {
    const profile = await UserApi.profile(req.telegramUser.id);
    ok(res, {
      role: req.isAdmin ? "admin" : "user",
      telegram: req.telegramUser,
      exists: Boolean(profile),
    });
  })
);

// ------------------------------------------------------------------- user --

router.get(
  "/webapp/api/wallet",
  wrap(async (req, res) => ok(res, await UserApi.wallet(req.telegramUser.id)))
);

router.get(
  "/webapp/api/transactions",
  wrap(async (req, res) => ok(res, { items: await UserApi.transactions(req.telegramUser.id) }))
);

router.get(
  "/webapp/api/services",
  wrap(async (req, res) => {
    const profile = await UserApi.profile(req.telegramUser.id);
    ok(res, { items: await UserApi.services(req.telegramUser.id, profile?.language) });
  })
);

router.get(
  "/webapp/api/referral",
  wrap(async (req, res) => ok(res, await ShopApi.referralInfo(req.telegramUser.id)))
);

router.get(
  "/webapp/api/reseller",
  wrap(async (req, res) => ok(res, { reseller: await UserApi.resellerStatus(req.telegramUser.id) }))
);

router.post(
  "/webapp/api/reseller/request",
  wrap(async (req, res) => {
    const result = await UserApi.requestReseller(req.telegramUser.id, req.body?.bot_token);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.get(
  "/webapp/api/tickets",
  wrap(async (req, res) => ok(res, { items: await UserApi.listTickets(req.telegramUser.id) }))
);

router.post(
  "/webapp/api/tickets",
  wrap(async (req, res) => {
    const result = await UserApi.createTicket(req.telegramUser.id, req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// -------------------------------------------------------- purchase / shop --
// Full standalone replacement for the bot's "Buy config" flow - see
// app/webapp/controllers/shopApi.js for the bot-flow each route mirrors.

router.get(
  "/webapp/api/purchase/meta",
  wrap(async (req, res) => ok(res, await ShopApi.purchaseMeta(req.telegramUser.id)))
);

router.get(
  "/webapp/api/purchase/plans",
  wrap(async (req, res) => ok(res, { items: await ShopApi.listPlans(req.query.connection, req.query.type || "normal") }))
);

router.get(
  "/webapp/api/purchase/locations",
  wrap(async (req, res) => ok(res, { items: await ShopApi.listLocations(req.query.type || "normal") }))
);

router.get(
  "/webapp/api/purchase/custom-options",
  wrap(async (req, res) => ok(res, await ShopApi.customOptions()))
);

router.post(
  "/webapp/api/purchase/quote",
  wrap(async (req, res) => {
    const result = await ShopApi.purchaseQuote(req.telegramUser.id, req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/purchase/free",
  wrap(async (req, res) => {
    const result = await ShopApi.purchaseFree(req.telegramUser.id);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/purchase/payg",
  wrap(async (req, res) => {
    const result = await ShopApi.purchasePayg(req.telegramUser.id, req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// -------------------------------------------------------------- payments --

router.post(
  "/webapp/api/payments/:id/pay-wallet",
  wrap(async (req, res) => {
    const result = await ShopApi.payWithWallet(req.telegramUser.id, req.params.id, req.telegramUser);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/payments/:id/pay-gateway",
  wrap(async (req, res) => {
    const result = await ShopApi.payWithGateway(req.telegramUser.id, req.params.id, req.body?.gateway);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.get(
  "/webapp/api/purchase/gateways",
  wrap(async (req, res) => ok(res, await ShopApi.purchaseGateways()))
);

router.post(
  "/webapp/api/payments/:id/coupon",
  wrap(async (req, res) => {
    const result = await ShopApi.applyCoupon(req.telegramUser.id, req.params.id, req.body?.code);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// ---------------------------------------------------------------- renewal --

router.post(
  "/webapp/api/services/:id/renew/quote",
  wrap(async (req, res) => {
    const result = await ShopApi.renewQuote(req.telegramUser.id, req.params.id);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// ------------------------------------------------------ service management --
// Full "My Services" action set, mirroring the bot's own inline keyboard for
// a service (see app/bot/buttons/ButtonManager.js InfoMyestErakkeyboard) -
// see app/webapp/controllers/serviceApi.js for the bot flow each route mirrors.

router.get(
  "/webapp/api/services/:id/manage",
  wrap(async (req, res) => {
    const profile = await UserApi.profile(req.telegramUser.id);
    const result = await ServiceApi.manageOverview(req.telegramUser.id, req.params.id, profile?.language);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.get(
  "/webapp/api/services/:id/links",
  wrap(async (req, res) => {
    const profile = await UserApi.profile(req.telegramUser.id);
    const result = await ServiceApi.getServiceLinks(req.telegramUser.id, req.params.id, profile?.language);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/services/:id/toggle-status",
  wrap(async (req, res) => {
    const profile = await UserApi.profile(req.telegramUser.id);
    const result = await ServiceApi.toggleStatus(req.telegramUser.id, req.params.id, profile?.language);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/services/:id/revoke-link",
  wrap(async (req, res) => {
    const profile = await UserApi.profile(req.telegramUser.id);
    const result = await ServiceApi.revokeLink(req.telegramUser.id, req.params.id, profile?.language);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.delete(
  "/webapp/api/services/:id",
  wrap(async (req, res) => {
    const result = await ServiceApi.deleteService(req.telegramUser.id, req.params.id);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.get(
  "/webapp/api/services/:id/upgrades",
  wrap(async (req, res) => {
    const result = await ServiceApi.upgradeOverview(req.telegramUser.id, req.params.id);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/services/:id/upgrade",
  wrap(async (req, res) => {
    const result = await ServiceApi.purchaseUpgrade(req.telegramUser.id, req.params.id, req.body?.upgrade_id);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.get(
  "/webapp/api/services/:id/refund",
  wrap(async (req, res) => {
    const result = await ServiceApi.refundOverview(req.telegramUser.id, req.params.id);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/services/:id/refund",
  wrap(async (req, res) => {
    const result = await ServiceApi.refundService(req.telegramUser.id, req.params.id);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/services/:id/transfer",
  wrap(async (req, res) => {
    const result = await ServiceApi.transferService(req.telegramUser.id, req.params.id, req.body?.target_id);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// -------------------------------------------------------------- wallet ----

router.get(
  "/webapp/api/wallet/gateways",
  wrap(async (req, res) => ok(res, await ShopApi.walletGateways()))
);

router.post(
  "/webapp/api/wallet/topup",
  wrap(async (req, res) => {
    const result = await ShopApi.walletTopup(req.telegramUser.id, req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/wallet/topup/card/:id/receipt",
  wrap(async (req, res) => {
    const result = await ShopApi.walletTopupCardReceipt(req.telegramUser.id, req.params.id, req.body?.image_base64);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

router.post(
  "/webapp/api/wallet/topup/crypto/:id/check",
  wrap(async (req, res) => {
    const result = await ShopApi.checkCryptoTopup(req.telegramUser.id, req.params.id, req.telegramUser);
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// ---------------------------------------------------------------- admin ----

router.use("/webapp/api/admin", requireAdmin);

// servers
router.get(
  "/webapp/api/admin/servers",
  wrap(async (req, res) => ok(res, { items: await AdminApi.listServers() }))
);
router.post(
  "/webapp/api/admin/servers",
  wrap(async (req, res) => {
    const result = await AdminApi.createServer(req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);
router.put(
  "/webapp/api/admin/servers/:id",
  wrap(async (req, res) => {
    const result = await AdminApi.updateServer(req.params.id, req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);
router.delete(
  "/webapp/api/admin/servers/:id",
  wrap(async (req, res) => {
    const result = await AdminApi.deleteServer(req.params.id);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

// users
router.get(
  "/webapp/api/admin/users",
  wrap(async (req, res) => ok(res, { items: await AdminApi.searchUsers(req.query.q) }))
);
router.post(
  "/webapp/api/admin/users/:id/balance",
  wrap(async (req, res) => {
    const result = await AdminApi.adjustUserBalance(req.params.id, Number(req.body?.delta || 0));
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);
router.post(
  "/webapp/api/admin/users/:id/block",
  wrap(async (req, res) => {
    const result = await AdminApi.setUserBlocked(req.params.id, Boolean(req.body?.blocked));
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);
router.get(
  "/webapp/api/admin/users/:id/services",
  wrap(async (req, res) => ok(res, { items: await AdminApi.userServices(req.params.id) }))
);

// resellers
router.get(
  "/webapp/api/admin/resellers",
  wrap(async (req, res) => ok(res, { items: await AdminApi.listResellers() }))
);
router.get(
  "/webapp/api/admin/resellers/permissions",
  wrap(async (req, res) => ok(res, await AdminApi.resellerPermissionsView()))
);
router.put(
  "/webapp/api/admin/resellers/permissions/features",
  wrap(async (req, res) => ok(res, await AdminApi.saveResellerFeatures(req.body || {})))
);
router.put(
  "/webapp/api/admin/resellers/permissions/admin",
  wrap(async (req, res) => ok(res, await AdminApi.saveResellerAdminPermissions(req.body || {})))
);

// payg
router.get(
  "/webapp/api/admin/payg",
  wrap(async (req, res) => ok(res, await AdminApi.listPayg(Number(req.query.page || 0))))
);
router.get(
  "/webapp/api/admin/payg/:id/costs",
  wrap(async (req, res) => {
    const result = await AdminApi.paygCostLog(req.params.id, Number(req.query.page || 0));
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);

// settings
router.get(
  "/webapp/api/admin/settings",
  wrap(async (req, res) => ok(res, await AdminApi.getSettings()))
);
router.put(
  "/webapp/api/admin/settings",
  wrap(async (req, res) => {
    const result = await AdminApi.updateSettings(req.body || {});
    if (!result.ok) return fail(res, result.error);
    ok(res, result);
  })
);

// tickets
router.get(
  "/webapp/api/admin/tickets",
  wrap(async (req, res) => ok(res, { items: await AdminApi.listTickets(req.query.status) }))
);
router.post(
  "/webapp/api/admin/tickets/:id/reply",
  wrap(async (req, res) => {
    const result = await AdminApi.replyTicket(req.params.id, req.body?.reply);
    if (!result.ok) return fail(res, result.error, 404);
    ok(res, result);
  })
);
router.post(
  "/webapp/api/admin/tickets/:id/close",
  wrap(async (req, res) => ok(res, await AdminApi.closeTicket(req.params.id)))
);

export default router;
