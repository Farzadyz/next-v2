import crypto from "crypto";

// ============================================================================
// Telegram Mini App authentication.
//
// The Mini App sends the raw `initData` string Telegram gives it (via the
// `X-Telegram-Init-Data` header). This module verifies it cryptographically
// per Telegram's documented algorithm (never trust the `user` field alone -
// it is plain, unsigned JSON and can be forged by anyone) and resolves the
// caller's role from the SAME admin list the bot itself uses (process.env.ADMIN).
// ============================================================================

// how long an initData payload stays valid after Telegram issued it
const MAX_AUTH_AGE_SECONDS = 24 * 60 * 60;

const adminIds = () => {
  try {
    const list = JSON.parse(process.env.ADMIN || "[]");
    return new Set((Array.isArray(list) ? list : [list]).map((id) => String(id)));
  } catch (error) {
    return new Set();
  }
};

// Telegram's verification algorithm (https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app):
//   secret_key = HMAC_SHA256(key = "WebAppData", data = bot_token)
//   data_check_string = every field except `hash`, "key=value" sorted by key, joined with "\n"
//   expected_hash = HMAC_SHA256(key = secret_key, data = data_check_string) as hex
const verifyInitData = (initData, botToken) => {
  if (!initData || typeof initData !== "string") return { ok: false, reason: "missing" };
  if (!botToken) return { ok: false, reason: "server_not_configured" };

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return { ok: false, reason: "missing" };
  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
  const expectedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

  const given = Buffer.from(hash, "hex");
  const expected = Buffer.from(expectedHash, "hex");
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) {
    return { ok: false, reason: "bad_signature" };
  }

  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Date.now() / 1000 - authDate > MAX_AUTH_AGE_SECONDS) {
    return { ok: false, reason: "expired" };
  }

  let user = null;
  try {
    user = JSON.parse(params.get("user") || "null");
  } catch (error) {
    user = null;
  }
  if (!user || !user.id) return { ok: false, reason: "missing" };

  return { ok: true, user, authDate };
};

// Express middleware: verifies initData and attaches req.telegramUser / req.isAdmin.
// Any endpoint mounted after this without an explicit skip is authenticated -
// there is no "trust the client" fallback anywhere in this module.
const telegramAuth = (req, res, next) => {
  const initData = req.get("X-Telegram-Init-Data");
  const result = verifyInitData(initData, process.env.BOT_TOKEN);
  if (!result.ok) {
    const status = result.reason === "server_not_configured" ? 500 : 401;
    return res.status(status).json({ ok: false, error: result.reason });
  }
  req.telegramUser = result.user;
  req.isAdmin = adminIds().has(String(result.user.id));
  next();
};

// Blocks every route declared after it unless the verified caller is a main-bot admin.
// This is the ONLY gate standing between a regular user and admin endpoints - it is
// applied on the backend router, never inferred from anything the frontend sends.
const requireAdmin = (req, res, next) => {
  if (!req.isAdmin) return res.status(403).json({ ok: false, error: "forbidden" });
  next();
};

export { verifyInitData, telegramAuth, requireAdmin, adminIds };
