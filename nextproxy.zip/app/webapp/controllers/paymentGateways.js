// ============================================================================
// Every payment gateway the bot itself supports (see app/bot/actions/price.js),
// re-implemented here WITHOUT a Telegraf ctx so the Mini App's REST endpoints
// can create the exact same database rows the bot creates and hand back a
// plain { url } / { crypto } / { manual } result instead of a chat message.
//
// This module deliberately does NOT duplicate any gateway's settlement logic:
// the existing webhook routes (app/routes/zarinpal.js, zibal.js, ...) are left
// completely untouched and keep deciding what happens when a gateway confirms
// payment - a row with `payment: null` tops up the wallet, a row with
// `payment: <peyment id>` provisions/renews that order. Creating the row the
// same way the bot does is all that's needed for the Mini App to plug into
// that existing settlement pipeline.
// ============================================================================

import { handleRandom, NumberFormat } from "../../bot/utils/utils.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { CreateCard } from "../../controllers/Card.js";
import { CountPeystar, CreatePeystar } from "../../controllers/Paystar.js";
import { CreateNowpeyment } from "../../controllers/Nowpeyment.js";
import { CountAtlasPay, CreateAtlasPay } from "../../controllers/AtlasPay.js";
import { CreateZarinpal } from "../../controllers/Zarinpal.js";
import { CreateZibal } from "../../controllers/Zibal.js";
import { CountNovinpay, CreateNovinpay } from "../../controllers/Novinpay.js";
import { CreatePolam } from "../../controllers/Polam.js";
import { CountRialit, CreateRialit } from "../../controllers/Rialit.js";
import { CreateTabaPay } from "../../controllers/TabaPay.js";
import { CreateSizapay } from "../../controllers/Sizepay.js";
import { CreateZirgozar } from "../../controllers/Zirgozar.js";
import { CreateTerapay } from "../../controllers/Terapay.js";

import Paystar from "../../pay/paystar.js";
import Nowpeyment, { ToUsd } from "../../pay/nowpeyment.js";
import ZarinPal from "../../pay/zarinpal.js";
import Zibals from "../../pay/zibal.js";
import AtlasPay from "../../pay/atlaspay.js";
import NovinPay from "../../pay/novinpal.js";
import Polam from "../../pay/polam.js";
import TabaPay from "../../pay/tabapay.js";
import SizePay from "../../pay/sizepay.js";
import Zirgozar from "../../pay/zirgozar.js";
import TetraPay from "../../pay/terapay.js";
import Rialit from "../../pay/rialit.js";

// same bounds the bot enforces on the "how much to charge" step
const MIN_AMOUNT = 5000;
const MAX_AMOUNT = 1000000;

// CARD is manual bank-transfer + admin approval, it has no online settlement
// route and (unlike every other gateway model) its DB row has no `payment`
// column to link back to an order - the bot itself only ever offers it as a
// wallet top-up, never as a way to pay for a specific purchase.
const PURCHASE_CAPABLE = new Set([
  "PAYSTAR",
  "ZARINPAL",
  "ZIBAL",
  "ATLASPAY",
  "NOVINPAL",
  "POLAM",
  "TABAPAY",
  "SIZAPAY",
  "ZIRGOZAR",
  "TERAPAY",
  "RIALIT",
  "NOWPEYMENT",
]);

const getEnabledGateways = async ({ forPurchase = false } = {}) => {
  const setting = await SelectSetting();
  const list = JSON.parse(setting.pay || "[]").filter((item) => item.value == true);
  const usable = forPurchase ? list.filter((item) => PURCHASE_CAPABLE.has(item.text)) : list;
  return usable.map((item) => ({ code: item.text }));
};

const validateAmount = (amount) => {
  const value = Number(amount);
  if (!value || isNaN(value)) return "invalid_amount";
  if (value < MIN_AMOUNT || value > MAX_AMOUNT) return "amount_out_of_range";
  return null;
};

// `payment` is undefined/null for a wallet top-up, or a Peyment row id when
// this gateway link is meant to settle an existing purchase/renewal order -
// exactly the same distinction app/bot/actions/price.js encodes.
const createGatewayCharge = async ({ gateway, amount, telegramId, payment = null }) => {
  const amountError = validateAmount(amount);
  if (amountError) return { ok: false, error: amountError };
  if (payment && !PURCHASE_CAPABLE.has(gateway)) return { ok: false, error: "gateway_not_supported_for_purchase" };

  switch (gateway) {
    case "CARD": {
      if (payment) return { ok: false, error: "gateway_not_supported_for_purchase" };
      const setting = await SelectSetting();
      const id = await CreateCard({ chat_id: telegramId, amount });
      return { ok: true, kind: "manual_card", topup_id: id, amount: Number(amount), card_number: process.env.CARD, admin_chat_id: setting.id_card };
    }

    case "PAYSTAR": {
      const count = await CountPeystar();
      const create = await new Paystar().CreatePayment({ amount, order_id: count + 1 });
      if (!create || create.status != 1) return { ok: false, error: "gateway_error" };
      await CreatePeystar({ chat_id: telegramId, amount, ref_num: create.data.ref_num, payment });
      return { ok: true, kind: "redirect", url: "https://core.paystar.ir/api/pardakht/payment?token=" + create.data.token };
    }

    case "ZARINPAL": {
      const hash = await handleRandom(20);
      const create = await new ZarinPal().CreatePayment({
        amount,
        order_id: hash,
        callback_url: `${process.env.URL_DOMAIN}zarinpal`,
      });
      if (!create || !create.invoice_id) return { ok: false, error: "gateway_error" };
      await CreateZarinpal({ chat_id: telegramId, amount, authority: create.invoice_id, payment });
      return { ok: true, kind: "redirect", url: create.payment_url || create.invoice_url };
    }

    case "ZIBAL": {
      const create = await new Zibals().CreatePeyment({ amount });
      if (!create || create.result != 100) return { ok: false, error: "gateway_error" };
      await CreateZibal({ chat_id: telegramId, amount, trans_id: create.trackId, payment });
      return { ok: true, kind: "redirect", url: "https://gateway.zibal.ir/start/" + create.trackId };
    }

    case "ATLASPAY": {
      const count = await CountAtlasPay();
      const create = await new AtlasPay().CreatePayment({ amount, order_id: count + 1, user_id: telegramId });
      if (!create || !create.orderId) return { ok: false, error: "gateway_error" };
      await CreateAtlasPay({ chat_id: telegramId, amount, order_id: create.orderId, tracking_code: create.trackingCode, payment });
      return { ok: true, kind: "redirect", url: create.customerStartLink };
    }

    case "NOVINPAL": {
      const count = await CountNovinpay();
      const create = await new NovinPay().CreatePayment({ amount, order_id: count + 1 });
      if (!create || create.status != 1) return { ok: false, error: "gateway_error" };
      await CreateNovinpay({ chat_id: telegramId, amount, trans_id: create.refId });
      return { ok: true, kind: "redirect", url: "https://nextstory.ir/dragah3.php?token=" + encodeURIComponent(create.refId) };
    }

    case "POLAM": {
      const create = await new Polam().CreatePayment({ price: amount });
      if (!create || create.status != 1) return { ok: false, error: "gateway_error" };
      await CreatePolam({ chat_id: telegramId, amount, trans_id: create.invoice_key });
      return { ok: true, kind: "redirect", url: "https://polam.io/invoice/pay/" + create.invoice_key };
    }

    case "TABAPAY": {
      const create = await new TabaPay().CreatePeyment({ amount });
      if (!create || create.status != "success") return { ok: false, error: "gateway_error" };
      await CreateTabaPay({ chat_id: telegramId, amount, trans_id: create.token, payment });
      return { ok: true, kind: "redirect", url: create.url };
    }

    case "ZIRGOZAR": {
      const create = await new Zirgozar().createPaymentLink({ amount });
      if (!create || !create.result) return { ok: false, error: "gateway_error" };
      await CreateZirgozar({ chat_id: telegramId, amount, trans_id: create.token, payment });
      return { ok: true, kind: "redirect", url: create.link };
    }

    case "TERAPAY": {
      const hash = await handleRandom(20);
      const create = await new TetraPay().createOrder({ amount, hashId: hash });
      if (!create || !create.success) return { ok: false, error: "gateway_error" };
      await CreateTerapay({ chat_id: telegramId, amount, trans_id: create.data.uid, payment });
      return { ok: true, kind: "redirect", url: create.data.payment_url };
    }

    case "SIZAPAY": {
      const create = await new SizePay().createPayment({ amount });
      if (!create || (create.ResCod != "0" && create.ResCod != "00")) return { ok: false, error: "gateway_error" };
      await CreateSizapay({ chat_id: telegramId, amount, trans_id: create.Token });
      return { ok: true, kind: "redirect", url: process.env.URL_DOMAIN + "sizpay?token=" + create.Token };
    }

    case "RIALIT": {
      const count = await CountRialit();
      const create = await new Rialit().CreatePayment({ amount, order_id: count + 1, user_id: telegramId });
      if (!create || create.status != 1) return { ok: false, error: "gateway_error" };
      await CreateRialit({ chat_id: telegramId, amount, trans_id: create.token, payment });
      return { ok: true, kind: "redirect", url: "https://api.rialit.org/api/v1/redirect/" + create.token };
    }

    case "NOWPEYMENT": {
      const setting = await SelectSetting();
      if (!setting.nowpayments_enabled) return { ok: false, error: "gateway_disabled" };
      const usdAmount = ToUsd(amount, setting.nowpayments_usd_rate);
      const nowpay = new Nowpeyment(setting.nowpayments_api_key);
      const create = await nowpay.createPeyment(usdAmount, setting.nowpayments_pay_currency || "trx");
      if (!create || !create.pay_address || !create.pay_amount) return { ok: false, error: "gateway_error" };
      const rowId = await CreateNowpeyment({
        chat_id: telegramId,
        amount,
        count: create.pay_amount,
        price_count: usdAmount,
        pay_address: create.pay_address,
        payment_id: String(create.payment_id),
        pay_currency: create.pay_currency,
        idServise: payment,
      });
      return {
        ok: true,
        kind: "crypto",
        topup_id: rowId,
        pay_address: create.pay_address,
        pay_amount: create.pay_amount,
        pay_currency: (create.pay_currency || "").toUpperCase(),
      };
    }

    default:
      return { ok: false, error: "unknown_gateway" };
  }
};

export { getEnabledGateways, validateAmount, createGatewayCharge, MIN_AMOUNT, MAX_AMOUNT, PURCHASE_CAPABLE, NumberFormat };
