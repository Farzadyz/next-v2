import { Op } from "sequelize";
import Users from "../../model/users.js";
import { UpdateUser } from "../../controllers/Users.js";
import { CreateBlock, DestoryBlock, SelectBlock } from "../../controllers/Block.js";
import { SelectALLServiseUser } from "../../controllers/Servise.js";
import { selectAllInbound, UpdateInbound, DestoryInbound, selectInbound, CreataInbound } from "../../controllers/Inbound.js";
import { CreataInboundSanaeiNew } from "../../controllers/InboundSanaeiNew.js";
import Sanae from "../../api/sanae.js";
import SanaeiNew from "../../api/sanaei_new.js";
import { PANEL_TYPES } from "../../utils/panelTypes.js";
import { SelectAllResellers, CountResellers, SelectReseller } from "../../controllers/Reseller.js";
import { CountResellerSales, SumResellerSales } from "../../controllers/ResellerSale.js";
import {
  RESELLER_FEATURE_GROUPS,
  RESELLER_PERMISSION_DEFS,
  RESELLER_ADMIN_GROUPS,
  RESELLER_ADMIN_PERMISSION_DEFS,
  parseResellerPermissions,
  parseResellerAdminPermissions,
  RESELLER_PERMISSION_KEYS,
  RESELLER_ADMIN_PERMISSION_KEYS,
} from "../../utils/resellerPermissions.js";
import { SelectAllPaygService, CountPaygService, SelectPaygService } from "../../controllers/PaygService.js";
import { SelectPaygCostLogs, CountPaygCostLogs, SumPaygCostLogsByType } from "../../controllers/PaygCostLog.js";
import { SelectSetting, UpdateSetting } from "../../controllers/Setting.js";
import { SelectAllTickets, SelectTicket, ReplyTicket, CloseTicket } from "../../controllers/WebappTicket.js";
import { bot } from "../../bot/index.js";

// ============================================================================
// Everything the Main Admin's Mini App dashboard needs. Every route that
// reaches this module is already behind webapp/auth.js's requireAdmin - this
// file does not re-check admin identity, it assumes the caller is allowed and
// focuses on doing the actual work, reusing the SAME controllers/model layer
// the Telegram-side admin panel already uses (no parallel business logic).
// ============================================================================

// -------------------------------------------------------------- servers ----

const listServers = async () => {
  const rows = await selectAllInbound();
  return rows.map((row) => ({
    id: row.id,
    location: row.location,
    host: row.host,
    domain: row.damoin,
    panel: row.panel,
    type: row.type,
    port: row.port,
    price: row.price,
    status: row.status,
  }));
};

// mirrors app/bot/panel/sessions/inbound.js (old) and inbound_sanaei_new.js (new) -
// same fields, same login-to-verify-credentials step, same port-range format
const createServer = async ({ panel, domain, username, password, location, host, internal, tunel, port, type, price }) => {
  if (!/^\d+,\d+$/.test(String(port || ""))) return { ok: false, error: "invalid_port_range" };
  if (!["normal", "economic"].includes(type)) return { ok: false, error: "invalid_type" };

  const usePort = String(port).split(",")[0];
  if (panel === PANEL_TYPES.SANAEI_NEW) {
    const api = new SanaeiNew(domain);
    const session = await api.Login(username, password).catch(() => null);
    if (!session) return { ok: false, error: "login_failed" };
    const id = await CreataInboundSanaeiNew({ location, internal, usePort, port, tunel, host, type, damoin: domain, username, password, session, price: price || null });
    return { ok: true, id };
  }
  const api = new Sanae(domain);
  const session = await api.Login(username, password).catch(() => null);
  if (!session) return { ok: false, error: "login_failed" };
  const id = await CreataInbound({ location, internal, usePort, port, tunel, host, type, damoin: domain, username, password, session, price: price || null });
  return { ok: true, id };
};

const updateServer = async (id, changes) => {
  const allowed = ["location", "host", "price", "status", "type"];
  const object = Object.fromEntries(Object.entries(changes).filter(([key]) => allowed.includes(key)));
  if (!Object.keys(object).length) return { ok: false, error: "nothing_to_update" };
  await UpdateInbound({ id }, object);
  return { ok: true };
};

const deleteServer = async (id) => {
  const server = await selectInbound({ id });
  if (!server) return { ok: false, error: "not_found" };
  await DestoryInbound({ id });
  return { ok: true };
};

// ---------------------------------------------------------------- users ----

const searchUsers = async (query, limit = 20) => {
  const q = String(query || "").trim();
  if (!q) return [];
  const where = /^\d+$/.test(q) ? { id: q } : { phone: { [Op.like]: `%${q}%` } };
  const rows = await Users.findAll({ where, limit });
  const results = [];
  for (const row of rows) {
    results.push({ id: String(row.id), phone: row.phone, price: row.price, agent: row.agent, blocked: Boolean(await SelectBlock({ id: row.id })) });
  }
  return results;
};

const adjustUserBalance = async (id, delta) => {
  const user = await Users.findByPk(id);
  if (!user) return { ok: false, error: "not_found" };
  const newBalance = Number(user.price) + Number(delta);
  if (newBalance < 0) return { ok: false, error: "negative_balance" };
  await UpdateUser({ id }, { price: newBalance });
  return { ok: true, balance: newBalance };
};

const setUserBlocked = async (id, blocked) => {
  const user = await Users.findByPk(id);
  if (!user) return { ok: false, error: "not_found" };
  if (blocked) await CreateBlock({ id }).catch(() => {});
  else await DestoryBlock({ id });
  return { ok: true };
};

const userServices = (id) => SelectALLServiseUser({ telegram_id: id, offset: 0, limit: 200 });

// -------------------------------------------------------------- resellers --

const listResellers = async () => {
  const rows = await SelectAllResellers({ offset: 0, limit: 500 });
  const results = [];
  for (const row of rows) {
    const sales = await CountResellerSales({ reseller_id: row.id });
    const total = await SumResellerSales({ reseller_id: row.id });
    results.push({
      id: row.id,
      username: row.bot_username,
      owner_id: String(row.owner_id),
      status: row.status,
      deploy_status: row.deploy_status,
      sales,
      total_sales: total,
    });
  }
  return results;
};

const resellerPermissionsView = async () => {
  const setting = await SelectSetting();
  return {
    features: { groups: RESELLER_FEATURE_GROUPS, defs: RESELLER_PERMISSION_DEFS, values: parseResellerPermissions(setting.reseller_permissions) },
    admin: { groups: RESELLER_ADMIN_GROUPS, defs: RESELLER_ADMIN_PERMISSION_DEFS, values: parseResellerAdminPermissions(setting.reseller_admin_permissions) },
  };
};

const saveResellerFeatures = async (values) => {
  const setting = await SelectSetting();
  let stored = {};
  try {
    stored = JSON.parse(setting.reseller_permissions || "{}");
  } catch (error) {
    stored = {};
  }
  for (const key of Object.keys(values)) if (RESELLER_PERMISSION_KEYS.includes(key)) stored[key] = Boolean(values[key]);
  await UpdateSetting({ reseller_permissions: JSON.stringify(stored) });
  return { ok: true };
};

const saveResellerAdminPermissions = async (values) => {
  const setting = await SelectSetting();
  let stored = parseResellerAdminPermissions(setting.reseller_admin_permissions);
  for (const key of Object.keys(values)) if (RESELLER_ADMIN_PERMISSION_KEYS.includes(key)) stored[key] = Boolean(values[key]);
  await UpdateSetting({ reseller_admin_permissions: JSON.stringify(stored) });
  return { ok: true };
};

// ------------------------------------------------------------------ payg ---

const listPayg = async (page = 0, pageSize = 20) => {
  const total = await CountPaygService();
  const rows = await SelectAllPaygService({ offset: page * pageSize, limit: pageSize });
  return {
    total,
    items: rows.map((row) => ({ id: row.id, service_id: row.service_id, telegram_id: String(row.telegram_id), suspended: Boolean(row.suspended_at) })),
  };
};

const paygCostLog = async (paygId, page = 0, pageSize = 20) => {
  const item = await SelectPaygService({ id: paygId });
  if (!item) return { ok: false, error: "not_found" };
  const total = await CountPaygCostLogs({ payg_service_id: item.id });
  const rows = await SelectPaygCostLogs({ payg_service_id: item.id, offset: page * pageSize, limit: pageSize });
  const sums = await SumPaygCostLogsByType({ payg_service_id: item.id });
  return { ok: true, total, sums, entries: rows };
};

// -------------------------------------------------------------- settings ---

// only the fields a Mini App settings screen may safely expose/edit are
// whitelisted here - this is intentionally narrower than raw Setting.update
const SETTINGS_FIELDS = [
  "id_card",
  "free",
  "first_payment",
  "reseller_min_balance",
  "reseller_setup_fee",
  "refund_enabled",
  "refund_hours",
  "nowpayments_enabled",
  "nowpayments_usd_rate",
  "default_pay",
  "default_pay_card",
];

const getSettings = async () => {
  const setting = await SelectSetting();
  const view = Object.fromEntries(SETTINGS_FIELDS.map((key) => [key, setting[key]]));
  view.pay = JSON.parse(setting.pay || "[]");
  return view;
};

const updateSettings = async (changes) => {
  const object = Object.fromEntries(Object.entries(changes).filter(([key]) => SETTINGS_FIELDS.includes(key)));
  if (Array.isArray(changes.pay)) object.pay = JSON.stringify(changes.pay);
  if (!Object.keys(object).length) return { ok: false, error: "nothing_to_update" };
  await UpdateSetting(object);
  return { ok: true };
};

// -------------------------------------------------------------- tickets ----

const listTickets = (status) => SelectAllTickets(status ? { status } : {});

const replyTicket = async (id, reply) => {
  const ticket = await SelectTicket({ id });
  if (!ticket) return { ok: false, error: "not_found" };
  await ReplyTicket({ id }, reply);
  bot.telegram.sendMessage(ticket.telegram_id, `📩 پاسخ تیکت #${ticket.id} - ${ticket.subject}\n\n${reply}`).catch(() => {});
  return { ok: true };
};

const closeTicket = async (id) => {
  await CloseTicket({ id });
  return { ok: true };
};

export {
  listServers,
  createServer,
  updateServer,
  deleteServer,
  searchUsers,
  adjustUserBalance,
  setUserBlocked,
  userServices,
  listResellers,
  resellerPermissionsView,
  saveResellerFeatures,
  saveResellerAdminPermissions,
  listPayg,
  paygCostLog,
  getSettings,
  updateSettings,
  listTickets,
  replyTicket,
  closeTicket,
};
