import { selectUser, UpdateUser } from "../../controllers/Users.js";
import { SelectALLServiseUser } from "../../controllers/Servise.js";
import ServiseModel from "../../bot/model/servise.js";
import { SelectPaygService } from "../../controllers/PaygService.js";
import { CountPaygCostLogs, SumPaygCostLogsByType } from "../../controllers/PaygCostLog.js";
import PaygService from "../../model/paygservice.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { CreateReseller, DeleteReseller, SelectResellerByOwner, SelectResellerByToken } from "../../controllers/Reseller.js";
import { validateBotToken, deployAndLaunch, destroyReseller } from "../../bot/reseller/ResellerManager.js";
import { CreateTicket, SelectTicketsByUser } from "../../controllers/WebappTicket.js";
import Card from "../../model/card.js";
import Paystar from "../../model/paystar.js";
import Zarinpal from "../../model/zarinpal.js";
import Zibal from "../../model/zibal.js";
import Novinpay from "../../model/novinpay.js";
import Polam from "../../model/polam.js";
import TabaPay from "../../model/tabapay.js";
import Sizepay from "../../model/sizepay.js";
import Zirgozar from "../../model/zirgozar.js";
import Terapay from "../../model/terapay.js";
import Rialit from "../../model/rialit.js";
import AtlasPay from "../../model/atlaspay.js";
import Nowpeyment from "../../model/nowpeyment.js";
import { i18nL } from "../../bot/index.js";

// ============================================================================
// Everything a REGULAR user's Mini App view needs. Every function here trusts
// req.telegramUser.id (verified by webapp/auth.js) as the acting user and never
// takes a telegram id from the request body/query - a user can only ever act on
// their own wallet/services/tickets, which is what keeps this half of the app
// safe without needing its own copy of admin-style access checks.
// ============================================================================

// i18n shim: the bot's Servise class formats its texts through `i18n.t(key, vars)`
// bound to a request's language; outside of a chat update we bind the same
// locale strings (i18nL) to the user's saved language so the Mini App shows
// byte-for-byte the same wording the bot itself would.
const i18nFor = (language) => ({ t: (key, vars) => i18nL.t(language || "fa", key, vars) });

const profile = async (telegramId) => {
  const user = await selectUser({ id: telegramId });
  return user;
};

const wallet = async (telegramId) => {
  const user = await profile(telegramId);
  return { balance: user ? Number(user.price) || 0 : 0 };
};

// Every gateway keeps its own top-up table (see app/model/*.js); a row with
// `payment: null` is a wallet top-up (as opposed to a plan purchase, which
// sets `payment` to the linked order id) - the same distinction the gateway
// callback routes themselves use (see routes/zarinpal.js etc).
const GATEWAY_SOURCES = [
  { model: Card, gateway: "CARD", manual: true },
  { model: Paystar, gateway: "PAYSTAR" },
  { model: Zarinpal, gateway: "ZARINPAL" },
  { model: Zibal, gateway: "ZIBAL" },
  { model: Novinpay, gateway: "NOVINPAL" },
  { model: Polam, gateway: "POLAM" },
  { model: TabaPay, gateway: "TABAPAY" },
  { model: Sizepay, gateway: "SIZAPAY" },
  { model: Zirgozar, gateway: "ZIRGOZAR" },
  { model: Terapay, gateway: "TERAPAY" },
  { model: Rialit, gateway: "RIALIT" },
  { model: AtlasPay, gateway: "ATLASPAY" },
  { model: Nowpeyment, gateway: "NOWPEYMENT" },
];

const transactions = async (telegramId, limit = 50) => {
  const rows = [];
  for (const source of GATEWAY_SOURCES) {
    const where = source.manual ? { chat_id: telegramId, payment: null } : { chat_id: telegramId, payment: null };
    const items = await source.model.findAll({ where, order: [["id", "DESC"]], limit }).catch(() => []);
    for (const item of items) {
      rows.push({
        id: `${source.gateway}-${item.id}`,
        gateway: source.gateway,
        amount: Number(item.amount) || 0,
        status: source.manual ? (item.status ? "paid" : "pending") : item.status ? "paid" : "pending",
        manual_review: Boolean(source.manual),
        at: item.updatedAt || item.createdAt,
      });
    }
  }
  rows.sort((a, b) => new Date(b.at) - new Date(a.at));
  return rows.slice(0, limit);
};

// Standard (non-PAYG) services, rendered through the SAME class the bot itself
// uses for "My Services" - so usage/remaining/status/config-links here are
// guaranteed to match exactly what the customer sees inside the chat.
const standardServices = async (telegramId, language) => {
  const rows = await SelectALLServiseUser({ telegram_id: telegramId, offset: 0, limit: 200 });
  const servises = new ServiseModel();
  const i18n = i18nFor(language);
  const results = [];
  for (const row of rows) {
    const info = await servises.SelectServise({ id: row.id, i18n }).catch(() => null);
    if (!info) continue;
    results.push({
      id: row.id,
      kind: "standard",
      name: row.name,
      panel: row.panel,
      status: info.status,
      used_traffic: info.used_traffic,
      remaining: info.remaining,
      expire: info.expire,
      links: { internal: info.internal || null, tunel: info.tunel || null, subscription_url: info.subscription_url || null },
    });
  }
  return results;
};

// PAYG services: usage/remaining come live from the panel (same class), while
// the cost breakdown comes from the cost-deduction log (see PaygCostLog).
const paygServices = async (telegramId, language) => {
  const rows = await PaygService.findAll({ where: { telegram_id: telegramId }, order: [["id", "DESC"]] });
  const servises = new ServiseModel();
  const i18n = i18nFor(language);
  const results = [];
  for (const row of rows) {
    const info = await servises.SelectServise({ id: row.service_id, i18n }).catch(() => null);
    if (!info) continue;
    const sums = await SumPaygCostLogsByType({ payg_service_id: row.id });
    results.push({
      id: row.service_id,
      payg_id: row.id,
      kind: "payg",
      panel: info.panel,
      status: row.suspended_at ? "⛔️ تعلیق‌شده" : info.status,
      used_traffic: info.used_traffic,
      remaining: info.remaining,
      links: { internal: info.internal || null, tunel: info.tunel || null, subscription_url: info.subscription_url || null },
      total_cost: sums.reduce((sum, item) => sum + item.total, 0),
      cost_entries: await CountPaygCostLogs({ payg_service_id: row.id }),
    });
  }
  return results;
};

const services = async (telegramId, language) => {
  const [standard, payg] = await Promise.all([standardServices(telegramId, language), paygServices(telegramId, language)]);
  return [...standard, ...payg];
};

// mirrors the exact bot flow in app/bot/sessions/reseller.js (min balance +
// setup fee are deducted the same way, and refunded on the same failure path)
const requestReseller = async (telegramId, botToken) => {
  const token = String(botToken || "").trim();
  if (!token) return { ok: false, error: "token_required" };

  const existingOwn = await SelectResellerByOwner({ owner_id: telegramId }).catch(() => null);
  if (existingOwn) return { ok: false, error: "already_have_reseller" };

  const existing = await SelectResellerByToken({ bot_token: token });
  if (existing) return { ok: false, error: "token_taken" };

  const setting = await SelectSetting();
  const user = await selectUser({ id: telegramId });
  const fee = Number(setting.reseller_setup_fee || 0);
  const minBalance = Number(setting.reseller_min_balance || 0);
  if (!user || Number(user.price) < minBalance + fee) return { ok: false, error: "insufficient_balance", required: minBalance + fee };

  const { valid, username } = await validateBotToken(token);
  if (!valid) return { ok: false, error: "token_invalid" };

  if (fee > 0) await UpdateUser({ id: telegramId }, { price: user.price - fee });
  const reseller = await CreateReseller({ owner_id: telegramId, bot_token: token, bot_username: username });
  try {
    await deployAndLaunch(reseller);
  } catch (error) {
    if (fee > 0) {
      const fresh = await selectUser({ id: telegramId });
      await UpdateUser({ id: telegramId }, { price: fresh.price + fee });
    }
    await destroyReseller(reseller.id).catch(() => {});
    await DeleteReseller({ id: reseller.id }).catch(() => {});
    return { ok: false, error: "deploy_failed" };
  }
  return { ok: true, username, fee };
};

const resellerStatus = async (telegramId) => {
  const reseller = await SelectResellerByOwner({ owner_id: telegramId }).catch(() => null);
  if (!reseller) return null;
  return { id: reseller.id, username: reseller.bot_username, status: reseller.status, deploy_status: reseller.deploy_status };
};

const createTicket = async (telegramId, { subject, message }) => {
  if (!subject || !message) return { ok: false, error: "invalid" };
  const id = await CreateTicket({ telegram_id: telegramId, subject: String(subject).slice(0, 255), message: String(message).slice(0, 4000) });
  return { ok: true, id };
};

const listTickets = (telegramId) => SelectTicketsByUser({ telegram_id: telegramId });

export { profile, wallet, transactions, services, requestReseller, resellerStatus, createTicket, listTickets };
