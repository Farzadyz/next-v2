// ============================================================================
// Everything needed to buy a new config, renew an existing one, request a
// free test config, buy a Pay-As-You-Go service, and top up the wallet -
// from the Mini App. Every function here re-implements the matching bot flow
// (see app/bot/actions/buyeshterak.js, TamdidEshterak.js, payg.js, price.js,
// pay.js) call for call, minus the Telegraf ctx/i18n/menu plumbing, so the
// numbers a user sees in the Mini App are always identical to what the bot
// itself would have shown for the same action.
//
// Like userApi.js, every function here trusts `telegramId` resolved from the
// verified initData (see webapp/auth.js) as the acting user - it is never
// taken from the request body.
// ============================================================================

import { selectAllPelanLocation, selectPelan } from "../../controllers/Pelan.js";
import { selectAllInboundType, selectInbound, selectFirstInbound } from "../../controllers/Inbound.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { UpdateUser, selectUser } from "../../controllers/Users.js";
import { CreatePeyment, SelectPeyment, UpdatePeyment } from "../../controllers/Peyment.js";
import { CreateAlert, SelectAlert, UpdateAlert } from "../../controllers/Alert.js";
import { CreatePaygService } from "../../controllers/PaygService.js";
import { CreateFree } from "../../controllers/Free.js";
import { SelectCard } from "../../controllers/Card.js";
import { SelectNowpeyment, UpdateNowpeyment } from "../../controllers/Nowpeyment.js";
import { SelectGift, UpdateGift } from "../../controllers/Gift.js";
import { sumUserReferralEarnings } from "../../controllers/Free.js";
import Servise from "../../bot/model/servise.js";
import { NumberFormat } from "../../bot/utils/utils.js";
import { bot, i18nL } from "../../bot/index.js";
import { Markup } from "telegraf";
import Nowpeyment from "../../pay/nowpeyment.js";
import { getEnabledGateways, createGatewayCharge, validateAmount, MIN_AMOUNT, MAX_AMOUNT } from "./paymentGateways.js";

// ---------------------------------------------------------------------------
// shared helpers
// ---------------------------------------------------------------------------

// mirrors the agent (reseller-tier user) discount applied in buyeshterak.js /
// TamdidEshterak.js: only "normal" plans/inbounds qualify, discount is a flat
// percent below 100,000 and a (usually larger) percent above it.
const applyAgentDiscount = (user, price, planType, inboundType = "normal") => {
  if (!user.agent || planType !== "normal" || inboundType !== "normal") return { price, discounted: null };
  const { darsad, number } = JSON.parse(user.agent_price || "{}");
  const discounted = price - (price * (price > 100000 ? darsad : number)) / 100;
  return { price: discounted, discounted: discounted !== price ? discounted : null };
};

const sendBuyLog = async ({ type, telegramId, ctxUser, idEshterak, pelan, price, day, traficc }) => {
  const { log_buy } = await SelectSetting();
  if (!log_buy) return;
  bot.telegram
    .sendMessage(
      log_buy,
      i18nL.t("fa", "ESHTERAK_BUY.NEW_BUY", {
        type,
        id: telegramId,
        name: ctxUser?.first_name || "-",
        username: ctxUser?.username || "-",
        idEshterak,
        pelan,
        price,
        day,
        traficc,
        gift: "",
      }),
      { parse_mode: "html" }
    )
    .catch(() => {});
};

// ---------------------------------------------------------------------------
// browsing: what can be bought right now
// ---------------------------------------------------------------------------

const purchaseMeta = async (telegramId) => {
  const setting = await SelectSetting();
  const showpelan = JSON.parse(setting.showpelan || "[]").filter((item) => item.value == true);
  const user = await selectUser({ id: telegramId });
  const featureKeys = new Set(showpelan.map((item) => item.text));
  return {
    single: featureKeys.has("CHOESE"),
    multi: featureKeys.has("CHOESE"),
    economic: featureKeys.has("ECONOMIC"),
    custom: featureKeys.has("CUSTOMIZE") || featureKeys.has("SELECTCUSTOMIZE"),
    free: featureKeys.has("FREE") && !user?.free,
    payg_multi: Boolean(setting.payg_enabled_multi),
    payg_single: Boolean(setting.payg_enabled_single),
    payg_base_amount: Number(setting.payg_base_amount || 0),
    first_payment_bonus: Boolean(setting.first_payment) && !user?.first_payment,
  };
};

// connection: "single" | "multi"   type: "normal" | "economic"
const listPlans = async (connection, type = "normal") => {
  const rows = await selectAllPelanLocation({ connection, type });
  return rows.map((row) => ({
    id: row.id,
    name: row.name,
    price: row.price,
    traficc: row.traficc,
    time: row.time,
    panel: row.panel,
    connection: row.connection,
    type: row.type,
  }));
};

// servers a "single location" plan/custom-plan can be deployed on
const listLocations = async (type = "normal") => {
  const rows = await selectAllInboundType(type);
  return rows.map((row) => ({ id: row.id, location: row.location, price: row.price || 0 }));
};

const customOptions = async () => {
  const setting = await SelectSetting();
  const { traficcV, traficcP, timeV, timeP } = JSON.parse(setting.customize || "{}");
  return { traficcV, traficcP, timeV, timeP };
};

// ---------------------------------------------------------------------------
// checkout: create a pending Peyment (order) the user can then pay for -
// mirrors BuyEshterak.CHOOSE + BuyEshterak.SERVISE (fixed single-location
// plans), BuyEshterak.MZCHOOSE (multi-location plans, no server to pick) and
// BuyEshterak.CUSTUMIZETRAFICC + SERVISE (custom day/traffic plans).
// ---------------------------------------------------------------------------

const buildQuote = async ({ telegramId, location, types, panel, price, name, time, traficc, idPlan = null, connection, planType }) => {
  const selectinbounds = location ? await selectInbound({ id: location }) : null;
  let finalPrice = price;
  let vipFee = 0;
  if (selectinbounds?.price) {
    vipFee = selectinbounds.price;
    finalPrice = price + vipFee;
  }

  const user = await selectUser({ id: telegramId });
  const { discounted } = applyAgentDiscount(user, finalPrice, planType, selectinbounds?.type);

  const id = await CreatePeyment({
    location: location ?? "0",
    types,
    price: discounted ?? finalPrice,
    name,
    day: time,
    traficc,
    telegram_id: telegramId,
    idPlan,
    panel,
    connection: connection || "single",
  });

  return {
    payment_id: id,
    price: discounted ?? finalPrice,
    original_price: finalPrice !== (discounted ?? finalPrice) ? finalPrice : null,
    display_price: NumberFormat(discounted ?? finalPrice),
    name,
    day: time,
    traficc,
    location_label: selectinbounds?.location || "مولتی لوکیشن",
    vip_fee: vipFee,
  };
};

// source: "plan" (single-location fixed plan) | "multi" (multi-location fixed plan) | "custom"
const purchaseQuote = async (telegramId, { source, pelanId, locationId, day, traficc } = {}) => {
  if (source === "plan") {
    if (!pelanId || !locationId) return { ok: false, error: "invalid_request" };
    const pelan = await selectPelan({ id: pelanId });
    if (!pelan) return { ok: false, error: "plan_not_found" };
    const quote = await buildQuote({
      telegramId,
      location: locationId,
      types: "select",
      panel: pelan.panel,
      price: pelan.price,
      name: pelan.name,
      time: pelan.time,
      traficc: pelan.traficc,
      idPlan: pelan.id,
      connection: pelan.connection,
      planType: pelan.type,
    });
    return { ok: true, quote };
  }

  if (source === "multi") {
    if (!pelanId) return { ok: false, error: "invalid_request" };
    const pelan = await selectPelan({ id: pelanId });
    if (!pelan) return { ok: false, error: "plan_not_found" };
    const quote = await buildQuote({
      telegramId,
      location: "0",
      types: "select",
      panel: pelan.panel,
      price: pelan.price,
      name: pelan.name,
      time: pelan.time,
      traficc: pelan.traficc,
      idPlan: pelan.id,
      connection: pelan.connection,
      planType: pelan.type,
    });
    return { ok: true, quote };
  }

  if (source === "custom") {
    if (!locationId || !day || !traficc) return { ok: false, error: "invalid_request" };
    const setting = await SelectSetting();
    const { traficcP, timeP } = JSON.parse(setting.customize || "{}");
    const price = Number(traficc) * traficcP + Number(day) * timeP;
    const quote = await buildQuote({
      telegramId,
      location: locationId,
      types: "select-sefareshi",
      panel: "sanae",
      price,
      name: "انتخابی ، سفارشی",
      time: day,
      traficc,
      connection: "single",
      planType: undefined,
    });
    return { ok: true, quote };
  }

  return { ok: false, error: "invalid_source" };
};

// mirrors BuyEshterak.PELAN_FREE
const purchaseFree = async (telegramId) => {
  const user = await selectUser({ id: telegramId });
  if (user?.free) return { ok: false, error: "already_used" };
  await UpdateUser({ id: telegramId }, { free: true });

  const setting = await SelectSetting();
  const { id: loid } = await selectFirstInbound();
  const Servises = new Servise();
  const { result, id } = await Servises.createServise({
    location: loid,
    id: telegramId,
    traficc: setting.free,
    day: 1,
    name: "🎁 اشتراک تست",
    free: true,
    defaultname: true,
    types2: "free",
    panel: "sanae",
  });
  if (!result) {
    await UpdateUser({ id: telegramId }, { free: false });
    return { ok: false, error: "create_failed" };
  }
  return { ok: true, service_id: id };
};

// ---------------------------------------------------------------------------
// PAYG - mirrors app/bot/actions/payg.js exactly (charge the fixed base fee
// now, remaining wallet balance keeps being metered as the service is used)
// ---------------------------------------------------------------------------

const calcPaygInitial = ({ setting, remainingBalance, panel }) => {
  if (setting.payg_initial_mode === "auto") {
    const dailyRate = Number((panel === "wiguard" ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0);
    const dataRate = Number((panel === "wiguard" ? setting.payg_data_rate_multi : setting.payg_data_rate_single) || 0);
    const traficc = dataRate > 0 ? Math.max(1, Math.floor(remainingBalance / dataRate)) : 1;
    const day = dailyRate > 0 ? Math.max(1, Math.floor(remainingBalance / dailyRate)) : 1;
    return { traficc, day };
  }
  return {
    traficc: Math.max(1, Number(setting.payg_initial_traffic || 1)),
    day: Math.max(1, Number(setting.payg_initial_days || 1)),
  };
};

const purchasePayg = async (telegramId, { mode, locationId } = {}) => {
  const setting = await SelectSetting();
  if (mode === "single" && !setting.payg_enabled_single) return { ok: false, error: "not_enabled" };
  if (mode === "multi" && !setting.payg_enabled_multi) return { ok: false, error: "not_enabled" };
  if (mode === "single" && !locationId) return { ok: false, error: "location_required" };

  const fee = Number(setting.payg_base_amount || 0);
  if (fee <= 0) return { ok: false, error: "not_configured" };

  const user = await selectUser({ id: telegramId });
  if (!user || user.price < fee) return { ok: false, error: "insufficient_balance", required: fee };

  const remainingBalance = user.price - fee;
  await UpdateUser({ id: telegramId }, { price: remainingBalance });

  const panel = mode === "multi" ? "wiguard" : "sanae";
  const location = mode === "multi" ? "payg" : locationId;
  const { traficc, day } = calcPaygInitial({ setting, remainingBalance, panel });

  const Servises = new Servise();
  const { result, id } = await Servises.createServise({
    id: telegramId,
    traficc,
    day,
    name: "⚡️ اشتراک اشتراکی (PAYG)",
    defaultname: true,
    idPlan: null,
    free: false,
    location,
    types2: "payg",
    panel,
  });

  if (!result) {
    const fresh = await selectUser({ id: telegramId });
    await UpdateUser({ id: telegramId }, { price: fresh.price + fee });
    return { ok: false, error: "create_failed" };
  }

  await CreatePaygService({ service_id: id, telegram_id: telegramId, initial_traffic: traficc, initial_days: day });
  return { ok: true, service_id: id, fee, traficc, day };
};

// ---------------------------------------------------------------------------
// renewal - mirrors TamdidEshterak.TAMDID_ESHTERAK (quote) and always forces
// past the "already active" warning, matching what pressing the bot's own
// "renew anyway" button does.
// ---------------------------------------------------------------------------

const renewQuote = async (telegramId, serviceId) => {
  const servises = new Servise();
  const i18n = { t: (key, vars) => i18nL.t("fa", key, vars) };
  const status = await servises.StatusTamdid({ id: serviceId, i18n });
  if (!status || status.price == null || isNaN(status.price)) return { ok: false, error: "not_renewable" };

  const { price, traficc, time, location, types, panel, type } = status;
  const user = await selectUser({ id: telegramId });
  const { price: finalPrice, discounted } = applyAgentDiscount(user, price, type);

  const id = await CreatePeyment({
    location,
    types,
    idServise: serviceId,
    price: discounted ?? finalPrice,
    name: "تمدید",
    day: time,
    traficc,
    telegram_id: telegramId,
    panel,
  });

  return {
    ok: true,
    quote: {
      payment_id: id,
      price: discounted ?? finalPrice,
      original_price: finalPrice !== (discounted ?? finalPrice) ? finalPrice : null,
      display_price: NumberFormat(discounted ?? finalPrice),
      day: time,
      traficc,
      already_active: status.status,
    },
  };
};

// ---------------------------------------------------------------------------
// paying for a pending Peyment - either from the wallet (mirrors
// BuyEshterak.PEYMENT for a new purchase and TamdidEshterak.FAINAL_TAMDID for
// a renewal, auto-detected from idServise) or via a redirect/crypto gateway
// (mirrors BuyEshterak.PEYDARGAH - renewals never went through a gateway in
// the bot either, so that stays wallet-only here too).
// ---------------------------------------------------------------------------

const payWithWallet = async (telegramId, paymentId, ctxUser) => {
  const order = await SelectPeyment({ id: paymentId });
  if (!order) return { ok: false, error: "not_found" };
  if (order.telegram_id != telegramId) return { ok: false, error: "forbidden" };
  if (order.status) return { ok: false, error: "already_paid" };

  const user = await selectUser({ id: telegramId });
  if (user.price < order.price) return { ok: false, error: "insufficient_balance", required: order.price };

  if (order.idServise) {
    // renewal
    const servises = new Servise();
    const result = await servises.Tamdid({ id: order.idServise, day: order.day });
    if (!result) return { ok: false, error: "renew_failed" };
    await UpdateUser({ id: telegramId }, { price: user.price - order.price });
    await UpdatePeyment({ id: paymentId }, { status: true });

    const alert = await SelectAlert({ primaryId: order.idServise });
    if (alert) await UpdateAlert({ primaryId: order.idServise }, { alertValue: false, alertDate: false });
    else await CreateAlert({ primaryId: order.idServise });

    await sendBuyLog({
      type: "تمدید",
      telegramId,
      ctxUser,
      idEshterak: order.idServise,
      pelan: order.name,
      price: order.price,
      day: order.day,
      traficc: order.traficc,
    });
    return { ok: true, renewed: true, service_id: order.idServise };
  }

  // new purchase
  const Servises = new Servise();
  const { result, id } = await Servises.createServise({
    id: telegramId,
    traficc: order.traficc,
    day: order.day,
    name: order.name,
    idPlan: order.idPlan,
    defaultname: order.defaultname,
    location: order.location,
    types2: order.types,
    panel: order.panel,
    price: order.price,
  });
  if (!result) return { ok: false, error: "create_failed" };

  await UpdatePeyment({ id: paymentId }, { status: true });
  await UpdateUser({ id: telegramId }, { price: user.price - order.price, first_payment: true });
  await CreateAlert({ primaryId: id });
  await sendBuyLog({
    type: "خرید",
    telegramId,
    ctxUser,
    idEshterak: id,
    pelan: order.name,
    price: order.price,
    day: order.day,
    traficc: order.traficc,
  });
  return { ok: true, renewed: false, service_id: id };
};

// redeems a discount code against a pending (unpaid) purchase order - mirrors
// app/bot/sessions/gift.js exactly: one code per order, one redemption per
// user per code, agents can't use them, and it only ever applies to a fresh
// purchase (renewals never exposed this button in the bot either).
const applyCoupon = async (telegramId, paymentId, code) => {
  if (!code) return { ok: false, error: "invalid_request" };

  const order = await SelectPeyment({ id: paymentId });
  if (!order) return { ok: false, error: "not_found" };
  if (order.telegram_id != telegramId) return { ok: false, error: "forbidden" };
  if (order.status) return { ok: false, error: "already_paid" };
  if (order.idServise) return { ok: false, error: "coupon_not_supported" };
  if (JSON.parse(order.gift || "false")) return { ok: false, error: "coupon_already_applied" };

  const user = await selectUser({ id: telegramId });
  if (user.agent) return { ok: false, error: "coupon_agent_blocked" };

  const gift = await SelectGift({ code });
  if (!gift || JSON.parse(gift.used).length >= gift.limit) return { ok: false, error: "coupon_invalid" };

  const used = JSON.parse(gift.used);
  if (used.includes(telegramId) || used.includes(String(telegramId))) return { ok: false, error: "coupon_already_used" };
  used.push(telegramId);
  await UpdateGift({ code }, { used: JSON.stringify(used) });

  let price = order.price;
  let giftLabel;
  if (String(gift.gift).includes("%")) {
    const percentage = parseFloat(gift.gift) / 100;
    price -= price * percentage;
    giftLabel = gift.gift;
  } else {
    price -= Number(gift.gift);
    giftLabel = NumberFormat(gift.gift) + " تومان";
  }
  price = Math.max(0, Math.round(price));

  await UpdatePeyment({ id: paymentId }, { price, gift: JSON.stringify({ code: gift.code, gift: giftLabel }) });

  return {
    ok: true,
    quote: {
      payment_id: paymentId,
      price,
      original_price: order.price,
      display_price: NumberFormat(price),
      name: order.name,
      day: order.day,
      traficc: order.traficc,
      coupon: giftLabel,
    },
  };
};

// ---------------------------------------------------------------------------
// referral program - invite bonus (fixed, on signup) + ongoing top-up
// percentage (see CommendMiddleware.js and checkCryptoTopup below); mirrors
// what the bot shows for a user's own referral link/earnings.
// ---------------------------------------------------------------------------

const referralInfo = async (telegramId) => {
  const [user, earned] = await Promise.all([selectUser({ id: telegramId }), sumUserReferralEarnings(telegramId)]);
  const setting = await SelectSetting();
  const { start, charge } = JSON.parse(setting.invite || "{}");
  const botUsername = process.env.BOTNAME;
  return {
    link: botUsername ? `https://t.me/${botUsername}?start=ref_${telegramId}` : null,
    member: user?.member || 0,
    earned,
    signup_bonus: Number(start || 0),
    charge_percent: Number(charge || 0),
  };
};

const payWithGateway = async (telegramId, paymentId, gateway) => {
  const order = await SelectPeyment({ id: paymentId });
  if (!order) return { ok: false, error: "not_found" };
  if (order.telegram_id != telegramId) return { ok: false, error: "forbidden" };
  if (order.status) return { ok: false, error: "already_paid" };
  if (order.idServise) return { ok: false, error: "renewal_wallet_only" };

  return createGatewayCharge({ gateway, amount: order.price, telegramId, payment: paymentId });
};

// ---------------------------------------------------------------------------
// wallet top-up
// ---------------------------------------------------------------------------

const walletGateways = async () => {
  const gateways = await getEnabledGateways();
  return { gateways, min: MIN_AMOUNT, max: MAX_AMOUNT };
};

// same list, minus CARD (manual bank transfer has no way to link back to a
// specific purchase order - see PURCHASE_CAPABLE in paymentGateways.js)
const purchaseGateways = async () => {
  const gateways = await getEnabledGateways({ forPurchase: true });
  return { gateways };
};

const walletTopup = async (telegramId, { amount, gateway } = {}) => {
  const amountError = validateAmount(amount);
  if (amountError) return { ok: false, error: amountError };
  return createGatewayCharge({ gateway, amount, telegramId, payment: null });
};

// user uploaded their bank-transfer receipt photo (base64) for a CARD top-up
// - forwards it to the admin review chat, mirrors sessions/price.js SEND_PHOTO
const walletTopupCardReceipt = async (telegramId, topupId, imageBase64) => {
  const row = await SelectCard({ id: topupId, chat_id: telegramId });
  if (!row) return { ok: false, error: "not_found" };
  if (row.status) return { ok: false, error: "already_reviewed" };
  if (!imageBase64) return { ok: false, error: "image_required" };

  const setting = await SelectSetting();
  const buffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
  await bot.telegram.sendPhoto(
    setting.id_card,
    { source: buffer },
    {
      caption: i18nL.t("fa", "PAY.CARD.SEND_ADMIN", { amount: NumberFormat(row.amount), id: telegramId }),
      ...Markup.inlineKeyboard([
        Markup.button.callback(i18nL.t("fa", "PAY.CARD.MENU.ACCEPT"), `ACCEPTRESID_${row.id}`),
        Markup.button.callback(i18nL.t("fa", "PAY.CARD.MENU.APPROVE"), "APPROVERESID_" + row.id),
      ]),
    }
  );
  return { ok: true };
};

// polls a NOWPAYMENTS crypto invoice and settles it exactly like
// app/bot/actions/pay.js NOWCRYPTOCHECK does - works for both a wallet
// top-up (idServise null) and a purchase/renewal invoice (idServise set)
const checkCryptoTopup = async (telegramId, rowId, ctxUser) => {
  const check = await SelectNowpeyment({ id: rowId, chat_id: telegramId });
  if (!check) return { ok: false, error: "not_found" };
  if (check.deposit) return { ok: false, error: "already_done" };

  const setting = await SelectSetting();
  const nowpay = new Nowpeyment(setting.nowpayments_api_key);
  const status = await nowpay.PaymentStatus(check.payment_id);
  const paid = status && ["finished", "confirmed", "partially_paid"].includes(status.payment_status);
  if (!paid) return { ok: false, error: "pending" };

  await UpdateNowpeyment(check.id, { status: true, deposit: true });

  if (check.idServise) {
    await UpdatePeyment({ id: check.idServise }, { status: true });
    const order = await SelectPeyment({ id: check.idServise });
    const Servises = new Servise();
    const { result, id } = await Servises.createServise({
      id: telegramId,
      traficc: order.traficc,
      day: order.day,
      name: order.name,
      idPlan: order.idPlan,
      defaultname: order.defaultname,
      location: order.location,
      types2: order.types,
      panel: order.panel,
      price: order.price,
    });
    if (!result) return { ok: false, error: "create_failed" };
    await UpdateUser({ id: telegramId }, { first_payment: true });
    await CreateAlert({ primaryId: id });
    await sendBuyLog({
      type: "خرید",
      telegramId,
      ctxUser,
      idEshterak: id,
      pelan: order.name,
      price: order.price,
      day: order.day,
      traficc: order.traficc,
    });
    return { ok: true, purchased: true, service_id: id };
  }

  // wallet top-up
  const user = await selectUser({ id: telegramId });
  await UpdateUser({ id: telegramId }, { price: user.price + Number(check.amount), first_payment: true });
  if (user.inviter) {
    const { invite } = await SelectSetting();
    const { charge } = JSON.parse(invite);
    const percentageAmount = (charge / 100) * Number(check.amount);
    const inviter = await selectUser({ id: user.inviter });
    await UpdateUser({ id: user.inviter }, { price: inviter.price + percentageAmount });
    await CreateFree({ chat_id: user.inviter, amount: percentageAmount, type: "charge" });
    bot.telegram.sendMessage(user.inviter, i18nL.t(inviter.language, "PRICE.SEND_INVITE", { percentageAmount }), { parse_mode: "html" }).catch(() => {});
  }
  return { ok: true, purchased: false, credited: Number(check.amount) };
};

export {
  purchaseMeta,
  listPlans,
  listLocations,
  customOptions,
  purchaseQuote,
  purchaseFree,
  purchasePayg,
  renewQuote,
  applyCoupon,
  referralInfo,
  payWithWallet,
  payWithGateway,
  purchaseGateways,
  walletGateways,
  walletTopup,
  walletTopupCardReceipt,
  checkCryptoTopup,
};
