// ============================================================================
// Full "service management" surface for the Mini App - everything a user can
// do to an existing service from the bot's inline keyboard (see
// app/bot/buttons/ButtonManager.js InfoMyestErakkeyboard), re-implemented
// call for call against the same model/controllers the bot itself uses:
//   - toggle temporary connection status  -> mirrors UtilsEshterak.CHANGESTATUS
//   - revoke/regenerate connection link   -> mirrors UtilsEshterak.VERIFYCHANGEPASESHTERAK
//   - delete service                      -> mirrors UtilsEshterak.VERIFYDELETEESHTERAK
//   - upgrade data volume                 -> mirrors UpgradeEshterak.UPGERATE/ERTEGA
//   - cancel + refund (inside the window) -> mirrors RefundEshterak.js
//   - transfer to another user            -> mirrors UtilsEshterak.REDIRECT + sessions/redireact.js
//
// Like userApi.js / shopApi.js, every function here trusts `telegramId`
// resolved from verified initData as the acting user; the target service is
// always re-loaded and its ownership re-checked server-side before any
// mutation, so a user can never act on a service that isn't theirs.
// ============================================================================

import { SelectServise, UpdateServise } from "../../controllers/Servise.js";
import { SelectSetting } from "../../controllers/Setting.js";
import { selectUser, UpdateUser } from "../../controllers/Users.js";
import { CreateFree } from "../../controllers/Free.js";
import { selectAllUpgrade, selectUpgrade } from "../../controllers/Upgrade.js";
import { CreateAlert, SelectAlert, UpdateAlert } from "../../controllers/Alert.js";
import Servise from "../../bot/model/servise.js";
import { bot, i18nL } from "../../bot/index.js";

const i18nFor = (language) => ({ t: (key, vars) => i18nL.t(language || "fa", key, vars) });

// loads a service row and makes sure it belongs to the acting user - every
// mutation below starts from this, never from an id the client can spoof
const ownedService = async (telegramId, serviceId) => {
  const row = await SelectServise({ id: serviceId });
  if (!row || row.telegram_id != telegramId) return null;
  return row;
};

// mirrors the inline agent-discount math in UpgradeEshterak.js (kept local /
// separate from shopApi.js's applyAgentDiscount since the upgrade flow never
// restricts itself to "normal" plans the way a fresh purchase/renewal does)
const applyAgentUpgradePrice = (user, price) => {
  if (!user?.agent) return price;
  const { darsad, number } = JSON.parse(user.agent_price || "{}");
  const discounted = price - (price * (price > 100000 ? darsad : number)) / 100;
  return Number.isFinite(discounted) ? discounted : price;
};

const linkItems = (info) => {
  const items = [];
  if (info.internal) items.push({ label: "لینک داخلی", link: info.internal });
  if (info.tunel) items.push({ label: "لینک مستقیم", link: info.tunel });
  if (info.subscription_url) items.push({ label: "لینک هوشمند", link: info.subscription_url });
  return items;
};

// ---------------------------------------------------------------------------
// links
// ---------------------------------------------------------------------------

const getServiceLinks = async (telegramId, serviceId, language) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const servises = new Servise();
  const info = await servises.SelectServise({ id: serviceId, i18n: i18nFor(language) });
  if (!info || info.status === false) return { ok: false, error: "not_found" };
  return { ok: true, items: linkItems(info) };
};

// ---------------------------------------------------------------------------
// toggle temporary connection status - mirrors CHANGESTATUS
// ---------------------------------------------------------------------------

const toggleStatus = async (telegramId, serviceId, language) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const servises = new Servise();
  const changed = await servises.ChangeStatus({ id: serviceId });
  if (!changed) return { ok: false, error: "not_found" };
  const info = await servises.SelectServise({ id: serviceId, i18n: i18nFor(language) });
  return { ok: true, status_api: info?.status_api ?? null };
};

// ---------------------------------------------------------------------------
// revoke / regenerate the connection link - mirrors VERIFYCHANGEPASESHTERAK
// ---------------------------------------------------------------------------

const revokeLink = async (telegramId, serviceId, language) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const servises = new Servise();
  await servises.Revokelink({ id: serviceId });
  return getServiceLinks(telegramId, serviceId, language);
};

// ---------------------------------------------------------------------------
// delete - mirrors VERIFYDELETEESHTERAK
// ---------------------------------------------------------------------------

const deleteService = async (telegramId, serviceId) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const servises = new Servise();
  await servises.DeleteServise({ id: serviceId });
  return { ok: true };
};

// ---------------------------------------------------------------------------
// upgrade data volume - mirrors UpgradeEshterak.UPGERATE (eligibility + list)
// and .ERTEGA (the purchase itself)
// ---------------------------------------------------------------------------

const upgradeOverview = async (telegramId, serviceId) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const servises = new Servise();
  const alertInfo = await servises.SelectServiseAlert({ id: serviceId });
  if (!alertInfo) return { ok: false, error: "not_found" };

  const usedPercent = alertInfo.traffic > 0 ? (alertInfo.used_traffic * 100) / alertInfo.traffic : 0;
  const eligible = usedPercent >= 80;

  const user = await selectUser({ id: telegramId });
  const rows = await selectAllUpgrade();
  const items = rows.map((u) => {
    const price = applyAgentUpgradePrice(user, Number(u.price));
    return { id: u.id, traficc: u.traficc, price, original_price: price !== Number(u.price) ? Number(u.price) : null };
  });

  return { ok: true, eligible, used_percent: Math.min(100, Math.round(usedPercent)), items };
};

const purchaseUpgrade = async (telegramId, serviceId, upgradeId) => {
  if (!upgradeId) return { ok: false, error: "invalid_request" };
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };

  const upgrade = await selectUpgrade({ id: upgradeId });
  if (!upgrade) return { ok: false, error: "not_found" };

  const servises = new Servise();
  const alertInfo = await servises.SelectServiseAlert({ id: serviceId });
  if (!alertInfo) return { ok: false, error: "not_found" };
  const usedPercent = alertInfo.traffic > 0 ? (alertInfo.used_traffic * 100) / alertInfo.traffic : 0;
  if (usedPercent < 80) return { ok: false, error: "not_eligible" };

  const user = await selectUser({ id: telegramId });
  const price = applyAgentUpgradePrice(user, Number(upgrade.price));
  if (Number(user.price) < price) return { ok: false, error: "insufficient_balance", required: price };

  const result = await servises.upgradeServise({ id: serviceId, traficc: upgrade.traficc, idUpgarade: upgrade.id });
  if (!result) return { ok: false, error: "upgrade_failed" };

  await UpdateUser({ id: telegramId }, { price: Number(user.price) - price });

  const alert = await SelectAlert({ primaryId: serviceId });
  if (alert) await UpdateAlert({ primaryId: serviceId }, { alertValue: false });
  else await CreateAlert({ primaryId: serviceId });

  return { ok: true, traficc: upgrade.traficc, price };
};

// ---------------------------------------------------------------------------
// cancel + refund (inside the admin-configured window) - mirrors
// RefundEshterak.js's checkEligibility + REFUNDESHTERAK/VERIFYREFUNDESHTERAK
// ---------------------------------------------------------------------------

const checkRefundEligibility = async (row) => {
  const setting = await SelectSetting();
  if (!setting.refund_enabled) return { ok: false, error: "disabled" };
  if (!row.price || row.price <= 0 || row.free || row.refunded_at) return { ok: false, error: "not_eligible" };
  const hours = Number(setting.refund_hours || 0);
  const hoursPassed = (Date.now() - new Date(row.createdAt).getTime()) / 3600000;
  if (hoursPassed > hours) return { ok: false, error: "expired", hours };
  return { ok: true, hours };
};

const refundOverview = async (telegramId, serviceId) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const check = await checkRefundEligibility(row);
  if (!check.ok) return check;
  return { ok: true, price: row.price, hours: check.hours };
};

const refundService = async (telegramId, serviceId) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };
  const check = await checkRefundEligibility(row);
  if (!check.ok) return check;

  const servises = new Servise();
  await servises.DeleteServise({ id: serviceId });

  const user = await selectUser({ id: telegramId });
  if (user) {
    await UpdateUser({ id: telegramId }, { price: Number(user.price) + Number(row.price) });
    await CreateFree({ chat_id: telegramId, amount: row.price, type: "refund" });
  }
  return { ok: true, price: row.price };
};

// ---------------------------------------------------------------------------
// transfer to another Telegram user - mirrors UtilsEshterak.REDIRECT +
// sessions/redireact.js exactly, including the status toggle it performs
// right after the transfer
// ---------------------------------------------------------------------------

const transferService = async (telegramId, serviceId, targetId) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };

  const target = String(targetId || "").trim();
  if (!target || isNaN(target)) return { ok: false, error: "invalid_request" };
  if (String(target) === String(telegramId)) return { ok: false, error: "invalid_request" };

  const targetUser = await selectUser({ id: target });
  if (!targetUser) return { ok: false, error: "target_not_found" };

  await UpdateServise({ id: serviceId }, { telegram_id: target });
  bot.telegram
    .sendMessage(target, i18nL.t("fa", "MY_ESHTERAK.REDIRECT.SEND", { ids: serviceId }), { parse_mode: "html" })
    .catch(() => {});

  const servises = new Servise();
  await servises.ChangeStatus({ id: serviceId });

  return { ok: true };
};

// ---------------------------------------------------------------------------
// one-call overview for the Mini App's "manage" modal
// ---------------------------------------------------------------------------

const manageOverview = async (telegramId, serviceId, language) => {
  const row = await ownedService(telegramId, serviceId);
  if (!row) return { ok: false, error: "not_found" };

  const servises = new Servise();
  const info = await servises.SelectServise({ id: serviceId, i18n: i18nFor(language) });
  if (!info || info.status === false) return { ok: false, error: "not_found" };

  const [refund, upgrade] = await Promise.all([refundOverview(telegramId, serviceId), upgradeOverview(telegramId, serviceId)]);

  return {
    ok: true,
    status_api: info.status_api,
    panel: info.panel,
    links: linkItems(info),
    refund: refund.ok ? { eligible: true, price: refund.price, hours: refund.hours } : { eligible: false, error: refund.error },
    upgrade: upgrade.ok
      ? { eligible: upgrade.eligible, used_percent: upgrade.used_percent, items: upgrade.items }
      : { eligible: false, items: [] },
  };
};

export {
  manageOverview,
  getServiceLinks,
  toggleStatus,
  revokeLink,
  deleteService,
  upgradeOverview,
  purchaseUpgrade,
  refundOverview,
  refundService,
  transferService,
};
