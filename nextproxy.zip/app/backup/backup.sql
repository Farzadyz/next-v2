/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: alerts
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `alerts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `primaryId` int NOT NULL,
  `alertDate` tinyint(1) DEFAULT '0',
  `alertValue` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: blocks
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `blocks` (
  `id` bigint NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: bots
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `bots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `price` int NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: cards
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `cards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: frees
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `frees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: gifts
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `gifts` (
  `code` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `gift` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `limit` int NOT NULL,
  `used` text COLLATE utf8mb4_persian_ci,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: inbound_mzs
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `inbound_mzs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(25) COLLATE utf8mb4_persian_ci NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  `count` int DEFAULT '0',
  `tag` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `protocol` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `network` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `tls` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `port` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: inbounds
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `inbounds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `damoin` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `host` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `internal` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `tunel` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `port` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `usePort` int NOT NULL,
  `price` int DEFAULT NULL,
  `session` text COLLATE utf8mb4_persian_ci NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  `type` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL DEFAULT 'normal',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: novinpays
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `novinpays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: nowpeyments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `nowpeyments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `count` decimal(10, 2) NOT NULL,
  `price_count` int NOT NULL,
  `price_desposid` decimal(10, 1) DEFAULT '0.0',
  `pay_address` text COLLATE utf8mb4_persian_ci NOT NULL,
  `payment_id` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `deposit` tinyint(1) DEFAULT '0',
  `idServise` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: numbers
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `numbers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phonenumber` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: pelans
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `pelans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `price` int NOT NULL,
  `traficc` double NOT NULL,
  `time` int NOT NULL,
  `panel` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL DEFAULT 'normal',
  `connection` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: peyments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `peyments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `types` varchar(32) COLLATE utf8mb4_persian_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `defaultname` tinyint(1) DEFAULT '1',
  `price` int NOT NULL,
  `priceTamdid` int NOT NULL,
  `day` int NOT NULL,
  `traficc` double NOT NULL,
  `idPlan` int DEFAULT NULL,
  `idServise` int DEFAULT NULL,
  `telegram_id` bigint NOT NULL,
  `gift` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `alert_gift` tinyint(1) DEFAULT '0',
  `panel` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: peystars
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `peystars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint DEFAULT NULL,
  `bot` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `amount` int NOT NULL,
  `ref_num` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: polams
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `polams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: rialits
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `rialits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `callback` tinyint(1) DEFAULT '0',
  `closed` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 3 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sendAll_bots
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sendAll_bots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `step` varchar(20) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_persian_ci,
  `chat` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `user` int DEFAULT '0',
  `type` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT 'ALL',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: servises
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `servises` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '1',
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `types` varchar(32) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `id_pelan` int DEFAULT NULL,
  `telegram_id` bigint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `defaultname` tinyint(1) DEFAULT '1',
  `username` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `data_limit` bigint DEFAULT NULL,
  `traficc` double NOT NULL,
  `time` int NOT NULL,
  `upgerade` int DEFAULT NULL,
  `free` tinyint(1) DEFAULT '0',
  `panel` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: settings
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_card` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL DEFAULT '2126513979',
  `log_buy` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL DEFAULT '2126513979',
  `gift` int NOT NULL DEFAULT '0',
  `free` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL DEFAULT '0.1465',
  `invite` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT '{"start":500,"charge":5}',
  `subscribe` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT '{"priceT":5000,"maxT":100,"minT":5,"priceD":5000,"maxD":100,"minD":5}',
  `inbound` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT '[{"text":"GAMING","price":1000},{"text":"WEB","price":1000},{"text":"HYBRID","price":2000}]',
  `protocol` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT '[{"name":"vmess_tcp","value":true},{"name":"vmess_ws","value":true},{"name":"vless_tcp","value":true},{"name":"vless_crpc","value":true}]',
  `showpelan` text COLLATE utf8mb4_persian_ci,
  `customize` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT '{"traficcV":[5,10,15,20,35,40,50],"traficcP":10000,"timeV":[5,10,15,20,35,40,50,365],"timeP":5000}',
  `pay` text COLLATE utf8mb4_persian_ci,
  `default_pay` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `first_payment` tinyint(1) DEFAULT '1',
  `pin` text COLLATE utf8mb4_persian_ci,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: sizepays
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `sizepays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: tabapays
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `tabapays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: telegraf-sessions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `telegraf-sessions` (
  `key` varchar(32) NOT NULL,
  `session` text,
  PRIMARY KEY (`key`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: terapays
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `terapays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: upgrades
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `upgrades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `price` int NOT NULL,
  `traficc` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: users
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint NOT NULL,
  `ids` bigint NOT NULL AUTO_INCREMENT,
  `language` varchar(2) COLLATE utf8mb4_persian_ci DEFAULT 'fa',
  `free` tinyint(1) DEFAULT '0',
  `agent` tinyint(1) DEFAULT '0',
  `agent_price` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `price` int DEFAULT '0',
  `inviter` bigint DEFAULT NULL,
  `member` int DEFAULT '0',
  `phone` varchar(25) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `last_Message` datetime DEFAULT '2026-06-02 08:01:49',
  `status` tinyint(1) DEFAULT '1',
  `first_payment` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ids` (`ids`)
) ENGINE = InnoDB AUTO_INCREMENT = 2 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: vendas
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `vendas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `vprescode` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: zarinpals
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `zarinpals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `authority` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: zibals
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `zibals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: zirgozars
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `zirgozars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `chat_id` bigint NOT NULL,
  `amount` int NOT NULL,
  `trans_id` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `payment` int DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_persian_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: alerts
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: blocks
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: bots
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: cards
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: frees
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: gifts
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: inbound_mzs
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: inbounds
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: novinpays
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: nowpeyments
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: numbers
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: pelans
# ------------------------------------------------------------

INSERT INTO
  `pelans` (
    `id`,
    `name`,
    `price`,
    `traficc`,
    `time`,
    `panel`,
    `type`,
    `connection`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    '۶ گیگ - ۲ کاربره - ۱۵۰ هزارتومان',
    150000,
    6,
    31,
    'wiguard',
    'normal',
    'multi',
    '2026-06-02 08:29:58',
    '2026-06-02 08:29:58'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: peyments
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: peystars
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: polams
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: rialits
# ------------------------------------------------------------

INSERT INTO
  `rialits` (
    `id`,
    `chat_id`,
    `amount`,
    `trans_id`,
    `payment`,
    `status`,
    `callback`,
    `closed`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    2126513979,
    50000,
    'iB2Owz5rzsKCYP7MhHbJuikjp2GI4ZPR',
    NULL,
    0,
    0,
    0,
    '2026-06-02 08:44:47',
    '2026-06-02 08:44:47'
  );
INSERT INTO
  `rialits` (
    `id`,
    `chat_id`,
    `amount`,
    `trans_id`,
    `payment`,
    `status`,
    `callback`,
    `closed`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2,
    2126513979,
    50000,
    'nOBnf5M0hKGJNMFtzYcp7XXnbztb2HIJ',
    NULL,
    0,
    0,
    0,
    '2026-06-02 08:45:08',
    '2026-06-02 08:45:08'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sendAll_bots
# ------------------------------------------------------------

INSERT INTO
  `sendAll_bots` (
    `id`,
    `step`,
    `text`,
    `chat`,
    `user`,
    `type`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    NULL,
    NULL,
    NULL,
    0,
    'ALL',
    '2026-06-02 04:31:06',
    '2026-06-02 04:31:06'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: servises
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: settings
# ------------------------------------------------------------

INSERT INTO
  `settings` (
    `id`,
    `id_card`,
    `log_buy`,
    `gift`,
    `free`,
    `invite`,
    `subscribe`,
    `inbound`,
    `protocol`,
    `showpelan`,
    `customize`,
    `pay`,
    `default_pay`,
    `first_payment`,
    `pin`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    1,
    '2126513979',
    '2126513979',
    0,
    '0.1465',
    '{\"start\":500,\"charge\":5}',
    '{\"priceT\":5000,\"maxT\":100,\"minT\":5,\"priceD\":5000,\"maxD\":100,\"minD\":5}',
    '[{\"text\":\"GAMING\",\"price\":1000},{\"text\":\"WEB\",\"price\":1000},{\"text\":\"HYBRID\",\"price\":2000}]',
    '[{\"name\":\"vmess_tcp\",\"value\":true},{\"name\":\"vmess_ws\",\"value\":true},{\"name\":\"vless_tcp\",\"value\":true},{\"name\":\"vless_crpc\",\"value\":true}]',
    '[{\"text\":\"CHOESE\",\"callback\":\"PELAN_CHOESE\",\"value\":true},{\"text\":\"CUSTOMIZE\",\"callback\":\"PELAN_CUSTOMIZE\",\"value\":true},{\"text\":\"SELECTCUSTOMIZE\",\"callback\":\"PELAN_SELECTCUSTOMIZE\",\"value\":true},{\"text\":\"FREE\",\"callback\":\"PELAN_FREE\",\"value\":true},{\"text\":\"ECONOMIC\",\"callback\":\"PELAN_ECONOMIC\",\"value\":true}]',
    '{\"traficcV\":[5,10,15,20,35,40,50],\"traficcP\":10000,\"timeV\":[5,10,15,20,35,40,50,365],\"timeP\":5000}',
    '[{\"text\":\"PAYSTAR\",\"value\":true},{\"text\":\"CARD\",\"value\":true},{\"text\":\"NOWPEYMENT\",\"value\":true},{\"text\":\"ZARINPAL\",\"value\":false},{\"text\":\"VENDA\",\"value\":false},{\"text\":\"ZIBAL\",\"value\":false},{\"text\":\"NOVINPAL\",\"value\":false},{\"text\":\"POLAM\",\"value\":false},{\"text\":\"TABAPAY\",\"value\":false},{\"text\":\"RIALIT\",\"value\":true}]',
    NULL,
    1,
    NULL,
    '2026-06-02 04:31:06',
    '2026-06-02 04:32:54'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: sizepays
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: tabapays
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: telegraf-sessions
# ------------------------------------------------------------

INSERT INTO
  `telegraf-sessions` (`key`, `session`)
VALUES
  (
    '2126513979:2126513979',
    '{\"__language_code\":\"fa\"}'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: terapays
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: upgrades
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: users
# ------------------------------------------------------------

INSERT INTO
  `users` (
    `id`,
    `ids`,
    `language`,
    `free`,
    `agent`,
    `agent_price`,
    `price`,
    `inviter`,
    `member`,
    `phone`,
    `last_Message`,
    `status`,
    `first_payment`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    2126513979,
    1,
    'fa',
    0,
    0,
    NULL,
    0,
    NULL,
    0,
    NULL,
    '2026-06-02 04:31:49',
    1,
    0,
    '2026-06-02 04:31:59',
    '2026-06-02 04:31:59'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: vendas
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: zarinpals
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: zibals
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: zirgozars
# ------------------------------------------------------------


/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
