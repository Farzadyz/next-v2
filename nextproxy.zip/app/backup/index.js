import mysqldump from "mysqldump";

const CreateBackUp = async () => {
  const USER_DATA = process.env.USER_DATA;
  const NAME_DATA = process.env.NAME_DATA;
  const PASSWORD_DATA = process.env.PASSWORD_DATA;

  await mysqldump({
    connection: {
      host: "localhost",
      user: NAME_DATA,
      password: PASSWORD_DATA,
      database: USER_DATA,
    },
    dumpToFile: "app/backup/backup.sql",
  })
    .then(() => {
      console.log("Backup created!");
    })
    .catch((err) => {
      return false;
    });
};

export default CreateBackUp;
