import axios from "axios";

class Zibal {
  constructor() {
    this.merchant = process.env.ZIBAL_MARCHAND;
    // ساخت axios instance با تنظیمات پیش‌فرض
    this.http = axios.create({
      baseURL: "https://gateway.zibal.ir/v1/",
    });
  }

  async CreatePeyment({ amount }) {
    try {
      const response = await this.http.post("request", {
        merchant: this.merchant,
        amount: amount * 10,
        callbackUrl: process.env.URL_DOMAIN + "zibal",
      });
      return response.data;
    } catch (error) {
      const err = error.response?.data || error.message;
      throw err;
    }
  }

  async VerifayPeyment(trackId) {
    try {
      const response = await this.http.post("verify", {
        merchant: this.merchant,
        trackId,
      });

      return response.data;
    } catch (error) {
      const err = error.response?.data || error.message;
      throw err;
    }
  }
}

export default Zibal;
