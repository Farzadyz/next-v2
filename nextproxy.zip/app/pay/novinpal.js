import axios from "axios";
import FormData from "form-data";

class NovinPay {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://api.novinpal.ir/invoice",
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    this.api_key = process.env.NOVIN_PAY;
  }

  // create payment
  async CreatePayment({ amount, order_id }) {
    const formData = new FormData();
    formData.append("api_key", this.api_key);
    formData.append("amount", amount * 10);
    formData.append("return_url", `${process.env.URL_DOMAIN}novinpay`);
    formData.append("order_id", order_id);

    try {
      const response = await this.axios.post("/request", formData, {
        headers: formData.getHeaders(), // هدرهای درست برای form-data
      });

      return response.data;
    } catch (error) {
      return false;
    }
  }

  // verify payment
  async VerifyPayment({ ref_id }) {
    const formData = new FormData();
    formData.append("api_key", this.api_key);
    formData.append("ref_id", ref_id);

    try {
      const response = await this.axios.post("/verify", formData, {
        headers: formData.getHeaders(),
      });
      return response.data;
    } catch (error) {
      return false;
    }
  }
}

export default NovinPay;
