import axios from "axios";
import { handleRandom } from "../bot/utils/utils.js";

class Aranex {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://api.aranex.net",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
  }

  // check prices
  async CheckPrices({ type }) {
    try {
      const response = await this.axios.get("/prices?type=" + type);
      return response.data;
    } catch (error) {
      return false;
    }
  }

  // create peyment
  async CreatePayment({ count }) {
    const id = await handleRandom(15);
    return {
      id,
      address: `https://site.aranex.net/web/buy?count=${count}&wallet=${process.env.WALLET_TRON}&type=trx&network=trc20&id=${id}`,
    };
  }

  // verify peyment
  async VerifyPayment({ id }) {
    try {
      const response = await this.axios.get(`/payment?id=${id}`);
      return response.data;
    } catch (error) {
      return false;
    }
  }
}

export default Aranex;
