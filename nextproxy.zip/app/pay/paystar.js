import axios from "axios";
import crypto from "crypto";

class Paystar {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://core.paystar.ir/api/pardakht",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.PAYSTAR}`,
      },
    });
  }

  // create peyment
  async CreatePayment({ amount, order_id, type = "validate" }) {
    const amountNumber = Number(amount) * 10;
    const newAmount = amountNumber.toString();
    const callback = `${process.env.URL_DOMAIN}peystar/${type}`;
    const sign_data = `${newAmount}#${order_id}#${callback}`;
    const sign = crypto.createHmac("sha512", process.env.SIGNSTAR).update(sign_data).digest("hex");
    const bodyParams = {
      amount: newAmount,
      order_id,
      callback,
      sign,
      callback_method: 1,
    };
    try {
      const response = await this.axios.post("/create", bodyParams);
      return response.data;
    } catch (error) {
      return false;
    }
  }

  // verify peyment
  async VerifyPayment({ amount, ref_num, card_number, tracking_code }) {
    const amountNumber = Number(amount) * 10;
    const newAmount = amountNumber.toString();
    const sign_data = `${newAmount}#${ref_num}#${card_number}#${tracking_code}`;
    const sign = crypto.createHmac("sha512", process.env.SIGNSTAR).update(sign_data).digest("hex");
    const bodyParams = {
      amount: newAmount,
      ref_num,
      sign,
    };
    try {
      const response = await this.axios.post("/verify", bodyParams);
      return response.data;
    } catch (error) {
      return false;
    }
  }
}

export default Paystar;
