import axios from "axios";

class Venda {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://ipg.vandar.io/api",
      headers: {
        "Content-Type": "application/json",
      },
    });
    this.pin = process.env.PIN_VENDA;
  }

  // create peyment
  async CreatePayment({ price }) {
    const res = await this.axios
      .post("/v4/send", {
        api_key: this.pin,
        amount: price * 10,
        callback_url: `${process.env.URL_DOMAIN}venda/validate`,
        description: `خرید - ${price}`,
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        return false;
      });
    return res;
  }

  // verify peyment
  async VerifyPayment({ token }) {
    const res = await this.axios
      .post("/v4/verify", {
        api_key: this.pin,
        token,
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        return false;
      });
    return res;
  }
}

export default Venda;
