import axios from "axios";

class AtlasPay {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://api.atlaspay.space/api/v1",
      headers: {
        "X-API-Key": process.env.ATLASPAY_KEY,
        "Content-Type": "application/json",
      },
    });
  }

  // create order - returns customerStartLink for the telegram mini app
  async CreatePayment({ amount, order_id, user_id }) {
    const res = await this.axios
      .post("/orders", {
        merchantOrderRef: String(order_id),
        baseAmountToman: Number(amount),
        customerTelegramId: user_id ? Number(user_id) : undefined,
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        return false;
      });
    return res;
  }

  // check order status - used for polling since atlaspay has no redirect callback
  async VerifyPayment({ orderId }) {
    const res = await this.axios
      .get(`/orders/${orderId}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        return false;
      });
    return res;
  }
}

export default AtlasPay;
