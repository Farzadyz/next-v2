import axios from "axios";
import crypto from "crypto";

class TetraPay {
  constructor() {
    this.apiKey = process.env.HOOSHPAY_APIKEY; // کلید دسترسی
    this.apiSecret = process.env.HOOSHPAY_SECRET; // کلید امضا برای اعتبارسنجی کال‌بک
    this.http = axios.create({
      baseURL: "https://hooshpay.xyz/api/v1/",
      headers: {
        "X-API-KEY": this.apiKey,
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * ایجاد فاکتور جدید
   * @param {Object} data
   * @param {string} data.hashId - شناسه یکتا سفارش (order_id)
   * @param {number} data.amount - مبلغ فاکتور (به تومان)
   */
  async createOrder({ hashId, amount }) {
    try {
      const response = await this.http.post("invoices", {
        amount,
        order_id: hashId,
        fee_mode: "buyer",
        callback_url: process.env.URL_DOMAIN + "terapay",
        return_url: process.env.URL_DOMAIN + "pendingpay",
      });

      return response.data;
    } catch (error) {
      console.error("HooshPay createOrder error:", error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * بررسی وضعیت تراکنش
   * @param {Object} data
   * @param {string} data.uid - شناسه یکتای فاکتور
   */
  async verifyPayment({ uid }) {
    try {
      const response = await this.http.post(`invoices/${uid}/verify`);

      return response.data;
    } catch (error) {
      console.error("HooshPay verifyPayment error:", error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * اعتبارسنجی امضای کال‌بک (X-HooshPay-Signature)
   * @param {Object} payload - بدنه‌ی JSON کال‌بک
   * @param {string} signature - مقدار هدر X-HooshPay-Signature
   */
  verifySignature(payload, signature) {
    if (!signature || !this.apiSecret) return false;
    try {
      const sorted = Object.keys(payload)
        .sort()
        .reduce((acc, key) => ((acc[key] = payload[key]), acc), {});
      const body = JSON.stringify(sorted);
      const expected = crypto.createHmac("sha256", this.apiSecret).update(body).digest("hex");
      return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
    } catch (error) {
      return false;
    }
  }
}

export default TetraPay;
