import axios from "axios";

class Rialit {
  constructor() {
    this.apiKey = process.env.RIALIT_KEY; // کلید دسترسی
    this.http = axios.create({
      baseURL: "https://api.rialit.org/api/v1",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.RIALIT_KEY}`,
      },
    });
  }

  // create payment
  // مبلغ به تومان ارسال می‌شود
  async CreatePayment({ amount, order_id, user_id }) {
    try {
      const response = await this.http.post("/send", {
        amount: Number(amount),
        order_id: String(order_id),
        user_id: Number(user_id),
        callback_url: `${process.env.URL_DOMAIN}rialit`,
      });
      return response.data;
    } catch (error) {
      console.error("Rialit CreatePayment error:", error.response?.data || error.message);
      return false;
    }
  }

  // verify payment
  async VerifyPayment({ token }) {
    try {
      const response = await this.http.post(`/verify/${token}`);
      return response.data;
    } catch (error) {
      console.error("Rialit VerifyPayment error:", error.response?.data || error.message);
      return false;
    }
  }
}

export default Rialit;
