import axios from "axios";

class ZarinPal {
  constructor() {
    this.apiKey = process.env.TONPAYS_APIKEY; // کلید دسترسی
    this.http = axios.create({
      baseURL: "https://tonpays.online/api/v1",
      headers: {
        "X-API-Key": this.apiKey,
        "Content-Type": "application/json",
      },
    });
  }

  // create peyment
  async CreatePayment({ amount, order_id, callback_url }) {
    const result = await this.http
      .post("/invoices/create", {
        amount: Number(amount),
        order_id: String(order_id),
        callback_url,
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("TonPays CreatePayment error:", error.response?.data || error.message);
        return false;
      });
    return result;
  }

  // verify peyment (استعلام وضعیت فاکتور)
  async VerifyPayment({ Authority }) {
    const result = await this.http
      .get(`/invoices/check/${Authority}`)
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        console.error("TonPays VerifyPayment error:", error.response?.data || error.message);
        return false;
      });
    return result;
  }
}

export default ZarinPal;
