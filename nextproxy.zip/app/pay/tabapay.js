import axios from "axios";

class TabaPay {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://api.tabapay.ir/v1",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.TABAPAY}`,
      },
    });
  }

  // create peyment
  async CreatePeyment({ amount }) {
    const result = await this.axios
      .post("/create", {
        amount: amount * 10, // Required - In Rials
        callbackURL: `${process.env.URL_DOMAIN_ROOT}/tabapay.php`, // The URL Where User will be Redirected to After Payment
        // mobile, // Optional - User's Card Numbers will Show inf Dropdown in Shaparak Page if you Send User's Mobile
        // cardNumber: allowedCards, // Optional - Any Transaction with a Card Number which is not Present in this Array will be Unsuccessful
      })
      .then((response) => {
        // Redirect User to Payment URL after Creating Transaction
        // res.redirect is for Express Framework
        // Store response.trackId Somewhere too
        return response.data;
      })
      .catch((err) => {
        return err;
      });
    return result;
  }

  // Verifay Peyment
  async VerifayPeyment({ amount, token }) {
    const result = await this.axios
      .post("/verify", {
        token,
        amount: amount * 10, // Required - In Rials
      })
      .then((response) => {
        return response.data;
      })
      .catch((err) => {
        return err;
      });
    return result;
  }
}

export default TabaPay;
