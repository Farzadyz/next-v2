import NowPaymentsApi from "@nowpaymentsio/nowpayments-api-js";

class Nowpeyment {
  constructor(apiKey) {
    this.npApi = new NowPaymentsApi({ apiKey: apiKey || process.env.NOWPEYMENT }); // your api key
  }

  // price: مبلغ به دلار (price_amount) که باید محاسبه و پاس داده شود
  // payCurrency: ارزی که کاربر با آن پرداخت میکند (مثال : usdttrc20 ، trx ، usdtbsc)
  async createPeyment(price, payCurrency = "trx") {
    try {
      const result = await this.npApi.createPayment({
        price_amount: price,
        price_currency: "usd",
        pay_currency: payCurrency,
        fixed_rate: true,
        is_fee_paid_by_user: true,
      });
      return result;
    } catch (error) {
      console.log(error);
    }
  }

  async PaymentStatus(payment_id) {
    try {
      const result = await this.npApi.getPaymentStatus({
        payment_id,
      });
      return result;
    } catch (error) {
      console.log(error);
    }
  }
}

// تبدیل مبلغ تومان به دلار طبق نرخ تنظیم شده در پنل - اگر نرخ صفر باشد مبلغ بدون تبدیل برگردانده میشود
const ToUsd = (amountToman, usdRate) => {
  if (!usdRate || Number(usdRate) <= 0) return Number(amountToman);
  const usd = Number(amountToman) / Number(usdRate);
  return Math.round(usd * 100) / 100;
};

export default Nowpeyment;
export { ToUsd };
