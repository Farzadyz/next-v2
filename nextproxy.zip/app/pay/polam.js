import axios from "axios";

class Polam {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://polam.io/invoice",
      headers: {
        "Content-Type": "application/json",
      },
    });
    this.api_key = process.env.POLAM;
  }

  // create peyment
  async CreatePayment({ amount }) {
    const res = await this.axios
      .post("/request", {
        api_key: this.api_key,
        amount,
        return_url: `${process.env.URL_DOMAIN}polam`,
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        return false;
      });
    return res;
  }

  // verify peyment
  async VerifyPayment({ invoice_key }) {
    const res = await this.axios
      .post("/check/" + invoice_key, {
        api_key: this.pin,
      })
      .then((response) => {
        return response.data;
      })
      .catch((error) => {
        return false;
      });
    return res;
  }
}

export default Polam;
