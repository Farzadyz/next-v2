import axios from "axios";

class SizePay {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://rt.sizpay.ir/api/PaymentSimple",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "User-Agent": "Sizpay Rest Api v1",
      },
    });

    this.key = process.env.SIZEPAY_KEY; // کلید درگاه
    this.returnUrl = `${process.env.URL_DOMAIN}sizpay`; // آدرس بازگشت
  }

  // ساخت توکن پرداخت
  async createPayment({ amount, orderId = Date.now(), extraInfo = "خرید" }) {
    try {
      const response = await this.axios.post("/GetTokenSimple", {
        sizPayKey: this.key,
        ReturnURL: this.returnUrl,
        Amount: amount, // به ریال
        OrderID: orderId,
        InvoiceNo: "",
        DocDate: "",
        ExtraInf: extraInfo,
      });

      return response.data;
    } catch (err) {
      return { error: err.message };
    }
  }

  // تایید پرداخت
  async verifyPayment({ token, amount }) {
    try {
      const response = await this.axios.post("/ConfirmSimple", {
        sizPayKey: this.key,
        Token: token,
        amount: amount,
      });

      return response.data;
    } catch (err) {
      return { error: err.message };
    }
  }
}

export default SizePay;
