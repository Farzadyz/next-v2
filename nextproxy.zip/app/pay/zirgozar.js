import axios from "axios";

class Zirgozar {
  constructor() {
    this.key = process.env.ZIRGOZAR_KEY; // کلید دسترسی
    this.http = axios.create({
      baseURL: "https://dgpaneltr.sbs/zirgozar/api/",
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * ایجاد لینک پرداخت
   * @param {Object} data
   * @param {string} data.amount - مبلغ فاکتور (تومان)
   * @param {string} data.callback_url - آدرس بازگشت
   * @param {string} [data.mobile] - شماره موبایل (اختیاری)
   * @param {string} [data.order_id] - شناسه سفارش (اختیاری)
   */
  async createPaymentLink({ amount }) {
    try {
      const response = await this.http.post("index.php", {
        key: this.key,
        action: "web_pay",
        amount,
        callback_url: process.env.URL_DOMAIN + "zirgozar",
      });

      return response.data;
    } catch (error) {
      console.error("Zirgozar createPaymentLink error:", error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * بررسی وضعیت پرداخت
   * @param {string} token - توکن پرداخت
   */
  async checkPaymentStatus(token) {
    try {
      const response = await this.http.post("index.php", {
        key: this.key,
        action: "web_pay_status",
        token,
      });

      return response.data;
    } catch (error) {
      console.error("Zirgozar checkPaymentStatus error:", error.response?.data || error.message);
      throw error;
    }
  }
}

export default Zirgozar;
