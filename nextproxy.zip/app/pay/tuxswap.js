import axios from "axios";

class TuxSwap {
  constructor() {
    this.axios = axios.create({
      baseURL: "https://payikc.tuxweb.ir/api/v1.0",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    });
    this.token = process.env.TOKEN_TUXWAP;
  }

  // create peyment
  async CreatePayment({ wallet, amount }) {
    try {
      const response = await this.axios.post("/createInvoice", {
        wallet,
        amount,
        currency: "trx",
        token: this.token,
      });
      return response.data;
    } catch (error) {
      return false;
    }
  }

  // verify peyment
  async VerifyPayment({ transction }) {
    try {
      const response = await this.axios.post("/checkInvoice", {
        transction,
        token: this.token,
      });
      return response.data;
    } catch (error) {
      return false;
    }
  }
}

export default TuxSwap;
