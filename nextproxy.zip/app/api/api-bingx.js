import CryptoJS from "crypto-js";
import axios from "axios";

class BingX {
  constructor() {
    this.API_KEY = "S5QiCCPxux605WfA8WAiZiSKvJfXxCG73bAe91g0ISRsTKillWlMgLt3ZDItY03RcZwK6kHAEbnAP1z7Paw";
    this.API_SECRET = "j3r0krpJ8tJrGmaUSOisp1oBltIlalxo22dQNIpYIutpA4h19G4r9Oo5H3cvU3DjvVtlPLIpPhKyWXuMzyw";
    this.HOST = "open-api.bingx.com";
  }

  // create sunged
  getParameters(API, timestamp, urlEncode) {
    let parameters = "";
    for (const key in API.payload) {
      if (urlEncode) {
        parameters += key + "=" + encodeURIComponent(API.payload[key]) + "&";
      } else {
        parameters += key + "=" + API.payload[key] + "&";
      }
    }
    if (parameters) {
      parameters = parameters.substring(0, parameters.length - 1);
      parameters = parameters + "&timestamp=" + timestamp;
    } else {
      parameters = "timestamp=" + timestamp;
    }
    return parameters;
  }

  // get price
  async getPrice(symbol) {
    const API = {
      uri: "/openApi/swap/v2/quote/price",
      method: "GET",
      payload: {
        symbol: symbol,
      },
      protocol: "https",
    };
    const timestamp = new Date().getTime();
    const sign = CryptoJS.enc.Hex.stringify(CryptoJS.HmacSHA256(this.getParameters(API, timestamp), this.API_SECRET));
    const url =
      "https://" + this.HOST + "/openApi/swap/v2/quote/price" + "?" + this.getParameters(API, timestamp, true) + "&signature=" + sign;

    const config = {
      method: "GET",
      url: url,
      headers: {
        "X-BX-APIKEY": this.API_KEY,
      },
      transformResponse: (resp) => {
        return resp;
      },
    };
    const resp = await axios(config);
    return JSON.parse(resp.data);
  }

  //  widthdraw
  async Widthdraw(coin, address, amount) {
    const API = {
      uri: "/openApi/wallets/v1/capital/withdraw/apply",
      method: "POST",
      payload: {
        coin,
        address,
        addressTag: "",
        amount,
        walletType: 1,
      },
      protocol: "https",
    };
    const timestamp = new Date().getTime();
    const sign = CryptoJS.enc.Hex.stringify(CryptoJS.HmacSHA256(this.getParameters(API, timestamp), this.API_SECRET));
    const url =
      "https://" +
      this.HOST +
      "/openApi/wallets/v1/capital/withdraw/apply" +
      "?" +
      this.getParameters(API, timestamp, true) +
      "&signature=" +
      sign;
    const config = {
      method: "POST",
      url: url,
      headers: {
        "X-BX-APIKEY": this.API_KEY,
      },
      transformResponse: (resp) => {
        return resp;
      },
    };
    const resp = await axios(config);
    return JSON.parse(resp.data);
  }
}

export default BingX;
