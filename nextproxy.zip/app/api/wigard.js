import axios from "axios";

class Wigard {
  constructor() {
    this.axios = axios.create({
      baseURL: process.env.URL_GARD,
      headers: {
        accept: "application/json",
        "X-API-Key": process.env.KEY_GARD,
        "User-Agent": "curl/7.79.1",
      },
    });
  }

  // add user
  async addUser({ username, limit_expire, limit_usage }) {
    const data = {
      username,
      limit_usage,
      limit_expire,
      service_ids: [1],
    };

    return this.axios
      .post("/api/subscriptions", [data])
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // get user
  async getUser({ username }) {
    return this.axios
      .get("/api/subscriptions/" + username)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // add all user
  async getAllUser() {
    return this.axios
      .get("/api/services")
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        console.log(err);

        return false;
      });
  }

  // modify user
  async modifyUser({ username, data }) {
    return this.axios
      .put("/api/user/" + username, data)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // reset user
  async resetUser({ username }) {
    return this.axios
      .post(`/api/user/${username}/reset/`, {
        username,
      })
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // delete user
  async DeleteUser({ username }) {
    return this.axios
      .delete("/api/user/" + username)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // revoke sub
  async revokeSub({ username }) {
    return this.axios
      .post("/api/user/" + username + "/revoke_sub")
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // get inbounds
  async getInbounds({ tag }) {
    const result = await this.axios
      .get("/api/inbounds")
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });

    // find tag
    const allData = Object.values(result).flat();
    const foundItem = allData.find((item) => item.tag === tag); // جستجو بر اساس تگ
    if (foundItem) {
      return foundItem;
    } else {
      return false;
    }
  }
}

export default Wigard;
