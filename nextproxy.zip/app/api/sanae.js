import axios from "axios";
import qs from "qs";
import cookie from "cookie";

class Sanae {
  constructor(baseURL, Cookie = null, Xui = "sanae") {
    // ساخت هدرها به صورت داینامیک
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    };

    // اگر Cookie موجود بود، اضافه می‌کنیم
    if (Cookie) {
      headers["Cookie"] = `${Xui == "sanae" ? "3x-ui" : "x-ui"}=${Cookie}`;
    }

    this.client = axios.create({
      baseURL,
      headers,
    });
    this.xui = Xui;
  }

  // login
  async Login(username, password) {
    const data = {
      username,
      password,
    };

    try {
      const response = await this.client.post("/login", data);
      // چک کنید که آیا کوکی "session" وجود دارد
      if (response.headers["set-cookie"]) {
        const cookies = response.headers["set-cookie"].map(cookie.parse);
        // یافتن کوکی با نام "session"
        if (this.xui == "sanae") {
          const longestCookie = cookies.reduce((prev, current) => (current["3x-ui"].length > prev["3x-ui"].length ? current : prev));

          if (longestCookie) {
            // مقدار کوکی "session" را برگردانید
            const sessionValue = longestCookie["3x-ui"];
            return sessionValue;
          }
        } else {
          const sessionCookie = cookies.find((c) => c["x-ui"]);
          if (sessionCookie) {
            // مقدار کوکی "session" را برگردانید
            const sessionValue = sessionCookie["x-ui"];
            return sessionValue;
          }
        }
      }
      // اگر کوکی "session" یافت نشد
      return null;
    } catch (error) {
      console.error("Error during login:", error.message);
      throw error;
    }
  }

  //  add clinet
  async addClinet({ data_limit, expire, email, sub, inbound, uuid, password }) {
    const data = {
      id: inbound,
      settings: JSON.stringify({
        clients: [
          {
            id: uuid,
            password,
            email,
            alterId: 0,
            limitIp: 2,
            totalGB: data_limit,
            expiryTime: expire,
            enable: true,
            tgId: "",
            subId: sub,
          },
        ],
      }),
    };

    const postData = qs.stringify(data);

    const res = await this.client
      .post("/panel/api/inbounds/addClient", postData)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    if (!res || !res.success) return false;

    return true;
  }

  //  add clinet
  async findClinet({ email }) {
    const res = await this.client
      .get("/panel/api/inbounds/getClientTraffics/" + email)
      .then((res) => {
        return res.data.obj;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  // update clinet
  async updateClinet(datas) {
    const { uuid, inboundId, total, expiryTime, email } = datas;
    const data = {
      id: inboundId,
      settings: JSON.stringify({
        clients: [
          {
            id: uuid,
            email,
            limitIp: 2,
            totalGB: total,
            expiryTime,
            enable: true,
          },
        ],
      }),
    };

    const postData = qs.stringify(data);

    const res = await this.client
      .post("/panel/api/inbounds/updateClient/" + uuid, postData)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    if (!res) return false;
  }

  // update clinet
  async revokeLink(datas) {
    const { uuid, id, inboundId, total, expiryTime, email, enable } = datas;
    const data = {
      id: inboundId,
      settings: JSON.stringify({
        clients: [
          {
            id: uuid,
            email,
            limitIp: 2,
            totalGB: total,
            expiryTime,
            enable,
          },
        ],
      }),
    };

    const postData = qs.stringify(data);

    const res = await this.client
      .post("/panel/api/inbounds/updateClient/" + id, postData)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    if (!res) return false;
  }

  //  delete clinet
  async deleteClinet({ inboundId, uuid }) {
    const res = await this.client
      .post(`/panel/api/inbounds/${inboundId}/delClient/` + uuid)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  //  reset clinet
  async resetClinet({ inboundId, email }) {
    const res = await this.client
      .post(`/panel/api/inbounds/${inboundId}/resetClientTraffic/` + email)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  // get inbound
  async getInbound({ inboundId }) {
    const res = await this.client
      .get(`/panel/api/inbounds/get/` + inboundId)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  async addInbound({ name, port, maxport, uuid, email, data_limit, expire, header }) {
    let currentPort = port;

    while (currentPort <= maxport) {
      const data = {
        enable: true,
        remark: name,
        listen: "",
        port: currentPort,
        protocol: "vless",
        expiryTime: 0,
        total: data_limit,
        expiryTime: expire,
        settings: JSON.stringify({
          clients: [
            {
              id: uuid,
              email,
              alterId: 0,
              limitIp: 2,
              totalGB: data_limit,
              expiryTime: expire,
              enable: true,
              tgId: "",
              subId: email,
            },
          ],
          decryption: "none",
          fallbacks: [],
        }),
        streamSettings: JSON.stringify({
          network: "ws",
          security: "none",
          externalProxy: [],
          wsSettings: {
            acceptProxyProtocol: false,
            path: "/",
            headers: {
              Host: header,
            },
          },
        }),
        sniffing: JSON.stringify({
          enabled: true,
          destOverride: ["http", "tls"],
        }),
      };

      const postData = qs.stringify(data);

      const res = await this.client
        .post("/panel/api/inbounds/add", postData)
        .then((res) => {
          console.error(res.data);
          return res.data;
        })
        .catch((err) => {
          console.error(err.response);
          return { success: false };
        });
      if (res.success) {
        return { success: true, port: currentPort };
      } else {
        if (res?.msg?.includes("Port already exists")) {
          currentPort++; // افزایش شماره پورت
        } else {
          return { success: false }; // اگر پاسخی غیر از خطای مرتبط با پورت دریافت شد
        }
      }
    }

    return { success: false }; // اگر همه پورت‌ها امتحان شدند و همچنان خطای مربوط به پورت دریافت نشد
  }

  //  reset unbound
  async resetInbound({ inboundId }) {
    const res = await this.client
      .post(`/panel/api/inbounds/resetAllClientTraffics/` + inboundId)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  // update inbound
  async updateInbound(data) {
    const res = await this.client
      .post("/panel/api/inbounds/update/" + data.id, data)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  //  delete iunbound
  async deleteInbound({ inboundId }) {
    const res = await this.client
      .post(`/panel/api/inbounds/del/` + inboundId)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }

  // get inbound
  async getInbounds() {
    const res = await this.client
      .get(`/panel/api/inbounds/list`)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
    return res;
  }
}

export default Sanae;
