import axios from "axios";

/*
 * Sanaei (3x-ui) NEW versions API client.
 *
 * Fully isolated from app/api/sanae.js (<= 2.6.6). Differences handled here:
 *  - login is JSON ({ username, password, twoFactorCode? }) and answers { success, msg }
 *  - every request body is JSON (settings / streamSettings / sniffing are nested objects)
 *  - unsafe requests made with a cookie session need the X-CSRF-Token header (GET /csrf-token)
 *  - clients are first-class entities: /panel/api/clients/* (add / get / update / del / traffic / resetTraffic)
 *
 * The session value returned by Login() is a ready-to-send Cookie header string ("name=value; ...").
 */

const parseJson = (value, fallback = null) => {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value !== "string") return value;
  try {
    return JSON.parse(value);
  } catch (error) {
    return fallback;
  }
};

const isObject = (value) => value !== null && typeof value === "object";

// "3x-ui=abc; Path=/; HttpOnly" -> "3x-ui=abc" (keeps the longest value per cookie name)
const cookieHeaderFromSetCookie = (setCookie) => {
  if (!setCookie) return null;
  const list = Array.isArray(setCookie) ? setCookie : [setCookie];
  const cookies = new Map();
  for (const raw of list) {
    const pair = String(raw).split(";")[0].trim();
    const index = pair.indexOf("=");
    if (index < 1) continue;
    const name = pair.slice(0, index);
    const value = pair.slice(index + 1);
    if (!value) continue;
    if (!cookies.has(name) || value.length > cookies.get(name).length) cookies.set(name, value);
  }
  if (cookies.size < 1) return null;
  return [...cookies.entries()].map(([name, value]) => `${name}=${value}`).join("; ");
};

const looksLikeLoginPage = (data) => typeof data === "string" && /<html|<!doctype|name=["']?password/i.test(data);

const isPortConflict = (msg = "") => /port/i.test(msg) && /(exist|in use|already|conflict|collid|occupied|used)/i.test(msg);

class SanaeiNew {
  /**
   * @param {string} baseURL panel address (protocol + host + port + web base path)
   * @param {string|null} session cookie header string returned by Login()
   * @param {object} options { username, password, onSession, timeout } - when username/password are given
   *                          an expired session is renewed automatically (and reported through onSession)
   */
  constructor(baseURL, session = null, options = {}) {
    this.baseURL = String(baseURL || "")
      .trim()
      .replace(/\/+$/, "");
    this.session = session || null;
    this.username = options.username || null;
    this.password = options.password || null;
    this.onSession = typeof options.onSession === "function" ? options.onSession : null;
    // undefined = not fetched yet, null = not available on this panel, string = token
    this.csrf = undefined;
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: options.timeout ?? 30000,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });
  }

  /*
  @ auth
  */

  // login - returns the session (Cookie header string) or null
  // some panels enforce CSRF on /login itself: an anonymous session cookie + matching
  // X-CSRF-Token are required on the login POST, not just on requests made after logging in.
  async Login(username = this.username, password = this.password, twoFactorCode = null) {
    try {
      // 1) visit the base page to receive an anonymous session cookie
      const preflight = await this.client.get("/", { validateStatus: () => true });
      const anonymousCookie = cookieHeaderFromSetCookie(preflight.headers["set-cookie"]);

      // 2) fetch the CSRF token tied to that anonymous session (best-effort - older panels
      // without this requirement simply won't set a cookie here, and we proceed without one)
      let csrfToken = null;
      if (anonymousCookie) {
        try {
          const csrfRes = await this.client.get("/csrf-token", { headers: { Cookie: anonymousCookie } });
          csrfToken = typeof csrfRes.data?.obj === "string" ? csrfRes.data.obj : null;
        } catch (error) {
          csrfToken = null;
        }
      }

      // 3) POST /login carrying the anonymous cookie + CSRF token
      const headers = {};
      if (anonymousCookie) headers.Cookie = anonymousCookie;
      if (csrfToken) headers["X-CSRF-Token"] = csrfToken;

      const body = { username, password };
      if (twoFactorCode) body.twoFactorCode = twoFactorCode;
      const response = await this.client.post("/login", body, { headers });
      if (!isObject(response.data) || response.data.success !== true) return null;
      // the login response sets a fresh, authenticated cookie - fall back to the anonymous
      // one only if the panel didn't rotate it (older panels without this CSRF requirement)
      return cookieHeaderFromSetCookie(response.headers["set-cookie"]) || anonymousCookie;
    } catch (error) {
      console.error("Error during login (sanaei_new):", error.message);
      return null;
    }
  }

  async _relogin() {
    if (!this.username || !this.password) return false;
    const session = await this.Login(this.username, this.password);
    if (!session) return false;
    this.session = session;
    this.csrf = undefined;
    if (this.onSession) {
      try {
        await this.onSession(session);
      } catch (error) {
        console.error("Error saving renewed session (sanaei_new):", error.message);
      }
    }
    return true;
  }

  async _getCsrf() {
    if (this.csrf !== undefined) return this.csrf;
    try {
      const response = await this.client.get("/csrf-token", { headers: this.session ? { Cookie: this.session } : {} });
      const token = response.data?.obj;
      this.csrf = typeof token === "string" && token ? token : null;
    } catch (error) {
      this.csrf = null;
    }
    return this.csrf;
  }

  /*
  @ transport
  */

  // returns { ok, status, data } and never throws
  async _call(method, url, { data, params } = {}, attempt = 0) {
    const unsafe = method !== "GET";
    const headers = {};
    if (this.session) headers.Cookie = this.session;
    if (unsafe) {
      const csrf = await this._getCsrf();
      if (csrf) headers["X-CSRF-Token"] = csrf;
    }

    try {
      const response = await this.client.request({ method, url, data, params, headers });
      // an expired session is answered with the login page
      if (looksLikeLoginPage(response.data)) {
        if (attempt < 2 && (await this._relogin())) return this._call(method, url, { data, params }, attempt + 1);
        return { ok: false, status: 401, data: null };
      }
      const body = response.data;
      return { ok: !isObject(body) || body.success !== false, status: response.status, data: body };
    } catch (error) {
      const status = error.response?.status ?? 0;
      const body = error.response?.data;
      const notJson = !isObject(body);
      // expired / missing session
      if ((status === 401 || (status === 404 && notJson)) && attempt < 2) {
        if (await this._relogin()) return this._call(method, url, { data, params }, attempt + 1);
      }
      // csrf rejected: first refresh the token, then renew the session
      if (status === 403 && unsafe && attempt < 2) {
        this.csrf = undefined;
        if (attempt === 1 && !(await this._relogin())) return { ok: false, status, data: isObject(body) ? body : null };
        return this._call(method, url, { data, params }, attempt + 1);
      }
      return { ok: false, status, data: isObject(body) ? body : null };
    }
  }

  /*
  @ inbounds
  */

  // settings / streamSettings / sniffing are nested objects in new versions (strings on old ones)
  _normalizeInbound(inbound) {
    if (!isObject(inbound)) return inbound;
    return {
      ...inbound,
      settings: parseJson(inbound.settings, {}),
      streamSettings: parseJson(inbound.streamSettings, {}),
      sniffing: parseJson(inbound.sniffing, {}),
    };
  }

  // list of inbounds or false
  async getInbounds() {
    const res = await this._call("GET", "/panel/api/inbounds/list");
    if (!res.ok || !Array.isArray(res.data?.obj)) return false;
    return res.data.obj.map((item) => this._normalizeInbound(item));
  }

  // inbound object or false
  async getInbound({ inboundId }) {
    const res = await this._call("GET", `/panel/api/inbounds/get/${encodeURIComponent(inboundId)}`);
    if (!res.ok || !isObject(res.data?.obj)) return false;
    return this._normalizeInbound(res.data.obj);
  }

  // creates an empty (client-less) vless/ws inbound; walks the port range while the port is taken
  async addInbound({ name, port, maxport, header }) {
    let currentPort = Number(port);
    const lastPort = Number(maxport);

    while (currentPort <= lastPort) {
      const body = {
        enable: true,
        remark: name,
        listen: "",
        port: currentPort,
        protocol: "vless",
        // limits are enforced per client (first-class clients), the inbound itself stays unlimited
        expiryTime: 0,
        total: 0,
        settings: {
          clients: [],
          decryption: "none",
          fallbacks: [],
        },
        streamSettings: {
          network: "ws",
          security: "none",
          externalProxy: [],
          wsSettings: {
            acceptProxyProtocol: false,
            path: "/",
            host: header,
            headers: {
              Host: header,
            },
          },
        },
        sniffing: {
          enabled: true,
          destOverride: ["http", "tls"],
        },
      };

      const res = await this._call("POST", "/panel/api/inbounds/add", { data: body });
      if (res.ok) {
        let id = res.data?.obj?.id ?? null;
        // older answers may not return the created inbound - look it up
        if (!id) {
          const list = await this.getInbounds();
          const found = Array.isArray(list) ? list.find((item) => Number(item.port) === currentPort && item.remark === name) : null;
          id = found?.id ?? null;
        }
        return { success: true, port: currentPort, id };
      }
      if (isPortConflict(res.data?.msg)) {
        currentPort++;
      } else {
        return { success: false };
      }
    }

    return { success: false };
  }

  // full replace of an inbound (same body shape as add) - returns boolean
  async updateInbound(inbound) {
    const { clientStats, ...body } = inbound;
    const res = await this._call("POST", `/panel/api/inbounds/update/${encodeURIComponent(inbound.id)}`, { data: body });
    return res.ok;
  }

  async setInboundEnable({ inboundId, enable }) {
    const res = await this._call("POST", `/panel/api/inbounds/setEnable/${encodeURIComponent(inboundId)}`, { data: { enable: !!enable } });
    return res.ok;
  }

  async deleteInbound({ inboundId }) {
    const res = await this._call("POST", `/panel/api/inbounds/del/${encodeURIComponent(inboundId)}`);
    return res.ok;
  }

  /*
  @ clients (first-class entities)
  */

  _normalizeClient(client) {
    if (!isObject(client)) return null;
    return {
      ...client,
      // responses expose the uuid as `uuid` (record id is numeric) - requests use `id` for the uuid
      uuid: client.uuid || (typeof client.id === "string" ? client.id : ""),
      inboundIds: Array.isArray(client.inboundIds) ? client.inboundIds : [],
    };
  }

  // client (with attached inboundIds) or null
  async getClient({ email }) {
    const res = await this._call("GET", `/panel/api/clients/get/${encodeURIComponent(email)}`);
    if (!res.ok || !isObject(res.data?.obj)) return null;
    return this._normalizeClient(res.data.obj);
  }

  // traffic counters { up, down, total, expiryTime, enable, inboundId, ... } or null
  async getClientTraffic({ email }) {
    const res = await this._call("GET", `/panel/api/clients/traffic/${encodeURIComponent(email)}`);
    if (!res.ok || !isObject(res.data?.obj)) return null;
    return res.data.obj;
  }

  // finds a client by e-mail or uuid (used to register an existing link)
  async findClient({ term }) {
    const res = await this._call("GET", "/panel/api/clients/list/paged", { params: { search: term, pageSize: 20 } });
    const items = res.ok && Array.isArray(res.data?.obj?.items) ? res.data.obj.items : [];
    for (const item of items) {
      const full = await this.getClient({ email: item.email });
      if (full && (full.email === term || full.uuid === term)) return full;
    }
    return null;
  }

  // builds the full client body for update (the panel replaces the row, it does not patch)
  buildClientPayload(current = {}, patch = {}, uuid = null) {
    const {
      inboundIds,
      traffic,
      externalConfigIds,
      externalLinks,
      createdAt,
      updatedAt,
      uuid: currentUuid,
      id: currentId,
      ...rest
    } = current;
    return {
      ...rest,
      ...patch,
      id: patch.id || currentUuid || (typeof currentId === "string" ? currentId : "") || uuid,
    };
  }

  // creates a client and attaches it to the inbound
  async addClient({ inboundId, client }) {
    const res = await this._call("POST", "/panel/api/clients/add", { data: { client, inboundIds: [Number(inboundId)] } });
    return res.ok;
  }

  async updateClient({ email, client }) {
    const res = await this._call("POST", `/panel/api/clients/update/${encodeURIComponent(email)}`, { data: client });
    return res.ok;
  }

  async deleteClient({ email, keepTraffic = false }) {
    const res = await this._call("POST", `/panel/api/clients/del/${encodeURIComponent(email)}`, { params: { keepTraffic: keepTraffic ? 1 : 0 } });
    return res.ok;
  }

  // zeroes up/down counters (also re-enables the client)
  async resetClientTraffic({ email }) {
    const res = await this._call("POST", `/panel/api/clients/resetTraffic/${encodeURIComponent(email)}`);
    return res.ok;
  }
}

export { parseJson, cookieHeaderFromSetCookie };
export default SanaeiNew;
