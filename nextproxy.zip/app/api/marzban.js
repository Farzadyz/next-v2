import axios from "axios";

class Marzban {
  constructor() {
    this.axios = axios.create({
      baseURL: process.env.URL_API_MZ,
    });
    this.axios.defaults.headers["Authorization"] = "Bearer " + process.env.TOKEN_API_MZ;
    this.axios.defaults.headers.common["Accept"] = "application/json";
    this.axios.defaults.headers.post["Content-Type"] = "application/json";
  }

  // generate uuid
  generateuuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
      var r = (Math.random() * 16) | 0,
        v = c == "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  handleRandom(length) {
    const charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    let password = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
      password += charset.charAt(Math.floor(Math.random() * n));
    }
    return password;
  }

  // add user
  async addUser({ username, expire, data_limit, types }) {
    const data = {
      username,
      data_limit,
      expire,
      proxies: {},
      inbounds: types,
    };
    if ("vmess" in types) {
      if (!data.proxies.vmess) {
        data.proxies.vmess = {};
      }
      data.proxies.vmess.id = await this.generateuuid();
    }

    if ("vless" in types) {
      if (!data.proxies.vless) {
        data.proxies.vless = {};
      }
    }

    if ("shadowsocks" in types) {
      if (!data.proxies.shadowsocks) {
        data.proxies.shadowsocks = {
          password: await this.handleRandom(15),
          method: "chacha20-ietf-poly1305",
        };
      }
    }

    if ("trojan" in types) {
      if (!data.proxies.trojan) {
        data.proxies.trojan = {
          password: await this.handleRandom(15),
        };
      }
    }

    return this.axios
      .post("/api/user", data)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // add user
  async getUser({ username }) {
    return this.axios
      .get("/api/user/" + username)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // modify user
  async modifyUser({ username, data }) {
    return this.axios
      .put("/api/user/" + username, data)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // reset user
  async resetUser({ username }) {
    return this.axios
      .post(`/api/user/${username}/reset/`, {
        username,
      })
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // delete user
  async DeleteUser({ username }) {
    return this.axios
      .delete("/api/user/" + username)
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // revoke sub
  async revokeSub({ username }) {
    return this.axios
      .post("/api/user/" + username + "/revoke_sub")
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });
  }

  // get inbounds
  async getInbounds({ tag }) {
    const result = await this.axios
      .get("/api/inbounds")
      .then((res) => {
        return res.data;
      })
      .catch((err) => {
        return false;
      });

    // find tag
    const allData = Object.values(result).flat();
    const foundItem = allData.find((item) => item.tag === tag); // جستجو بر اساس تگ
    if (foundItem) {
      return foundItem;
    } else {
      return false;
    }
  }
}

export default Marzban;
