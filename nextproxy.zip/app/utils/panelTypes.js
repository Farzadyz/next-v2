// Panel type identifiers stored in `inbounds.panel` (server) and `servises.panel` (service).
const PANEL_TYPES = {
  // Sanaei (3x-ui) <= 2.6.6  (legacy integration - untouched)
  SANAEI_OLD: "sanae",
  // Sanaei (3x-ui) new versions (JSON API, first-class clients, Bearer/cookie auth)
  SANAEI_NEW: "sanaei_new",
};

const isSanaeiFamily = (panel) => panel === PANEL_TYPES.SANAEI_OLD || panel === PANEL_TYPES.SANAEI_NEW;

export { PANEL_TYPES, isSanaeiFamily };
