import momentJalali from "moment-jalaali";
import moment from "moment-timezone";
import { SelectPaygService } from "../controllers/PaygService.js";
import { SelectServise } from "../controllers/Servise.js";
import { SelectSetting } from "../controllers/Setting.js";
import { selectUser } from "../controllers/Users.js";
import { selectInbound } from "../controllers/Inbound.js";
import { CreatePaygCostLog } from "../controllers/PaygCostLog.js";
import { bot } from "../bot/index.js";

// ============================================================================
// Side effects of a NEW Pay As You Go purchase (called by CreatePaygService, so
// every purchase path - bot menu and reseller API - is covered):
//   1) the creation fee is written to the cost-deduction log of the config
//   2) a direct message with the user + service details is sent to the bot admins
// Never blocks or breaks the purchase - failures are only logged.
// ============================================================================

const fmt = (value) => Math.round(Number(value) || 0).toLocaleString("en-US");

const escapeHtml = (value) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

const adminIds = () => {
  try {
    const list = JSON.parse(process.env.ADMIN || "[]");
    return [...new Set((Array.isArray(list) ? list : [list]).map((id) => String(id)).filter(Boolean))];
  } catch (error) {
    return [];
  }
};

const jalaliNow = () => {
  const tehran = moment.tz("Asia/Tehran").format("YYYY-MM-DD HH:mm:ss");
  return momentJalali(tehran, "YYYY-MM-DD HH:mm:ss").format("jYYYY/jMM/jDD HH:mm:ss");
};

const onPaygPurchased = async (paygId) => {
  const payg = await SelectPaygService({ id: paygId });
  if (!payg) return;
  const [setting, servise, user] = await Promise.all([
    SelectSetting(),
    SelectServise({ id: payg.service_id }),
    selectUser({ id: payg.telegram_id }),
  ]);
  const fee = Number(setting?.payg_base_amount || 0);

  // ---- ۱) ثبت هزینه ایجاد در لاگ کسر هزینه‌های این سرویس
  const logTask = CreatePaygCostLog({
    payg_service_id: payg.id,
    type: "creation",
    amount: fee,
    requested: fee,
    traffic_bytes: 0,
    balance_after: user ? Number(user.price) : null,
  });

  // ---- ۲) پیام مستقیم به ادمین‌ها
  const notifyTask = (async () => {
    const admins = adminIds();
    if (!admins.length) return;

    let chat = null;
    try {
      chat = await bot.telegram.getChat(payg.telegram_id);
    } catch (error) {
      chat = null;
    }
    const fullName = [chat?.first_name, chat?.last_name].filter(Boolean).join(" ") || "-";

    const isMulti = servise?.panel === "wiguard";
    const dailyRate = Math.round(Number((isMulti ? setting?.payg_daily_rate_multi : setting?.payg_daily_rate_single) || 0));
    const dataRate = Number((isMulti ? setting?.payg_data_rate_multi : setting?.payg_data_rate_single) || 0);

    let location = "-";
    if (servise && !isMulti) {
      const inbound = await selectInbound({ id: servise.location }).catch(() => null);
      location = inbound?.location || String(servise.location);
    }

    const text =
      "⚡️ <b>خرید جدید سرویس PAYG</b>\n\n" +
      "👤 <b>اطلاعات کاربر</b>\n" +
      `• نام : ${escapeHtml(fullName)}\n` +
      `• یوزرنیم : ${chat?.username ? "@" + escapeHtml(chat.username) : "-"}\n` +
      `• آیدی عددی : <code>${payg.telegram_id}</code>\n` +
      `• شماره تماس : ${escapeHtml(user?.phone || "-")}\n` +
      `• موجودی کیف پول : ${user ? fmt(user.price) : "-"} تومان\n\n` +
      "📦 <b>اطلاعات سرویس</b>\n" +
      `• آیدی سرویس : <code>${payg.service_id}</code>\n` +
      `• شناسه PAYG : <code>${payg.id}</code>\n` +
      `• نوع : ${isMulti ? "مولتی لوکیشن" : "تک لوکیشن"}\n` +
      `• لوکیشن : ${escapeHtml(location)}\n` +
      `• نام کاربری پنل : <code>${escapeHtml(servise?.username || "-")}</code>\n` +
      `• حجم اولیه : ${payg.initial_traffic} گیگابایت\n` +
      `• مدت اولیه : ${payg.initial_days} روز\n\n` +
      "💰 <b>هزینه‌ها</b>\n" +
      `• هزینه ایجاد (کسر شده) : ${fmt(fee)} تومان\n` +
      `• نرخ روزانه : ${fmt(dailyRate)} تومان\n` +
      `• نرخ هر گیگابایت : ${fmt(dataRate)} تومان\n\n` +
      `🕒 ${jalaliNow()}`;

    await Promise.allSettled(admins.map((id) => bot.telegram.sendMessage(id, text, { parse_mode: "HTML" })));
  })();

  const results = await Promise.allSettled([logTask, notifyTask]);
  for (const result of results) {
    if (result.status === "rejected") console.error("PAYG purchase hook error:", result.reason?.message || result.reason);
  }
};

export { onPaygPurchased };
