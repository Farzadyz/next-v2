import { Sequelize } from "sequelize";
import dotenv from "dotenv";
dotenv.config();

const USER_DATA = process.env.USER_DATA;
const NAME_DATA = process.env.NAME_DATA;
const PASSWORD_DATA = process.env.PASSWORD_DATA;

const sequelize = new Sequelize(USER_DATA, NAME_DATA, PASSWORD_DATA, {
  dialect: "mysql",
  host: "localhost",
  define: {
    charset: "utf8mb4",
    collate: "utf8mb4_persian_ci",
  },
});

export default sequelize;
