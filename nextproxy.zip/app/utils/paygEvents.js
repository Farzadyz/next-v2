import { SelectSetting } from "../controllers/Setting.js";
import { selectUser } from "../controllers/Users.js";
import { selectInbound } from "../controllers/Inbound.js";
import { SelectServise as SelectServiseRow } from "../controllers/Servise.js";
import { CreatePaygCostLog } from "../controllers/PaygCostLog.js";
import { bot } from "../bot/index.js";

const money = (value) => Number(value || 0).toLocaleString("en-US");

// نام قابل نمایش نوع پنل سرویس
const panelTitle = (panel) => {
  if (panel === "wiguard") return "مولتی لوکیشن";
  if (panel === "sanaei_new") return "تک لوکیشن (Sanaei جدید)";
  return "تک لوکیشن";
};

const escapeHtml = (text) => String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// اطلاعات کاربر تلگرام (نام / یوزرنیم) - اگر ربات به چت دسترسی نداشته باشد فقط آیدی نمایش داده می‌شود
const telegramProfile = async (id) => {
  try {
    const chat = await bot.telegram.getChat(id);
    return {
      name: [chat.first_name, chat.last_name].filter(Boolean).join(" ") || "-",
      username: chat.username ? "@" + chat.username : "-",
    };
  } catch (error) {
    return { name: "-", username: "-" };
  }
};

// بلافاصله بعد از ساخته شدن هر سرویس PAYG (ربات اصلی یا ربات نمایندگی) صدا زده می‌شود:
//   ۱) هزینه ایجاد سرویس در دفتر کسر هزینه ثبت می‌شود
//   ۲) پیام مستقیم با جزئیات کاربر و سرویس برای همه ادمین‌های ربات ارسال می‌شود
const OnPaygServiceCreated = async (row) => {
  const setting = await SelectSetting();
  const fee = Number(setting.payg_base_amount || 0);
  const payer = await selectUser({ id: row.telegram_id });

  // ۱) ثبت هزینه ایجاد
  if (fee > 0) {
    try {
      await CreatePaygCostLog({
        payg_service_id: row.id,
        service_id: row.service_id,
        telegram_id: row.telegram_id,
        type: "initial",
        amount: fee,
        balance_after: payer ? Number(payer.price) : null,
        note: "هزینه ایجاد سرویس",
      });
    } catch (error) {
      console.error("PaygCostLog initial error:", error.message);
    }
  }

  // ۲) اطلاع به ادمین
  let admins = [];
  try {
    admins = JSON.parse(process.env.ADMIN || "[]");
  } catch (error) {
    admins = [];
  }
  if (!Array.isArray(admins) || !admins.length) return;

  const servise = await SelectServiseRow({ id: row.service_id });
  // خریدار واقعی سرویس؛ در ربات نمایندگی با صاحب کیف پول (نماینده) فرق دارد
  const buyerId = servise?.telegram_id ?? row.telegram_id;
  const profile = await telegramProfile(buyerId);
  let location = "مولتی لوکیشن";
  if (servise && servise.panel !== "wiguard") {
    const inbound = await selectInbound({ id: servise.location }).catch(() => null);
    location = inbound?.location || String(servise.location);
  }
  const isMulti = servise?.panel === "wiguard";
  const dailyRate = Number((isMulti ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0);
  const dataRate = Number((isMulti ? setting.payg_data_rate_multi : setting.payg_data_rate_single) || 0);

  const walletLine =
    String(row.telegram_id) !== String(buyerId)
      ? `• کیف پول کسرشونده (نماینده) : <code>${row.telegram_id}</code>\n`
      : "";
  const text =
    `⚡️ <b>#خرید_PAYG</b>\n\n` +
    `<pre>👤 اطلاعات کاربر :</pre>\n` +
    `<b>• آیدی عددی :</b> <code>${buyerId}</code>\n` +
    `<b>• نام :</b> ${escapeHtml(profile.name)}\n` +
    `<b>• یوزرنیم :</b> ${escapeHtml(profile.username)}\n` +
    walletLine +
    `<b>• موجودی کیف پول بعد از خرید :</b> ${money(payer?.price)} تومان\n\n` +
    `<pre>⚙️ جزئیات سرویس :</pre>\n` +
    `<b>• شناسه سرویس :</b> ${row.service_id}\n` +
    `<b>• شناسه PAYG :</b> ${row.id}\n` +
    `<b>• نوع :</b> ${panelTitle(servise?.panel)}\n` +
    `<b>• لوکیشن :</b> ${escapeHtml(location)}\n` +
    `<b>• حجم اولیه :</b> ${row.initial_traffic} گیگ\n` +
    `<b>• روز اولیه :</b> ${row.initial_days} روز\n` +
    `<b>• هزینه ایجاد :</b> ${money(fee)} تومان\n` +
    `<b>• نرخ روزانه :</b> ${money(dailyRate)} تومان\n` +
    `<b>• نرخ هر گیگ مصرف :</b> ${money(dataRate)} تومان`;

  const extra = {
    parse_mode: "html",
    reply_markup: {
      inline_keyboard: [
        [{ text: "⚡️ مدیریت سرویس", callback_data: "PAYGVIEW_" + row.id }],
        [{ text: "🧾 لاگ کسر هزینه", callback_data: "PAYGCOST_" + row.id + "_0" }],
      ],
    },
  };
  for (const admin of admins) {
    bot.telegram.sendMessage(admin, text, extra).catch((error) => console.error("PAYG admin notify error:", admin, error.message));
  }
};

export { OnPaygServiceCreated };
