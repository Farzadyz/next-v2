import sequelize from "./database.js";
import {
  SelectPaygService,
  SelectSuspendedPaygServiceByUser,
  UpdatePaygService,
} from "../controllers/PaygService.js";
import { SelectServise as SelectServiseRow } from "../controllers/Servise.js";
import { SelectSetting } from "../controllers/Setting.js";
import { selectUser } from "../controllers/Users.js";
import Servise from "../bot/model/servise.js";
import { bot, i18nL } from "../bot/index.js";

// ============================================================================
// Auto-reactivation of suspended PAYG configs right after a wallet top-up.
//
// A single hook on the users table watches every write to the wallet (`price`),
// so ALL top-up paths are covered (every payment gateway callback, card-to-card
// approval, admin balance increase, invite rewards, reseller credit top-ups...).
// As soon as the balance is enough (>= the daily fee, at least 1) the config is
//   1) enabled on the panel with an explicit enable request (verified on the panel)
//   2) reactivated in the database (suspension cleared, daily cycle restarted)
//   3) announced to the user
// The 30s PaygDelete cron shares reactivatePaygService() and stays as a safety
// net (e.g. panel temporarily unreachable) - the two can never run it twice.
// ============================================================================

// payg ids that are being reactivated right now (cron + hook never overlap)
const inFlight = new Set();

// حداقل موجودی لازم برای فعال‌سازی = هزینه روزانه (پیش‌پرداخت) و حداقل مثبت بودن موجودی
const neededBalance = ({ setting, panel }) => {
  const isMulti = panel === "wiguard";
  const dailyRate = Math.round(Number((isMulti ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0));
  return Math.max(1, dailyRate);
};

// budgets (optional Map telegram_id -> remaining wallet) stops several suspended configs of ONE user
// from being reactivated with money that only covers one of them
// result: "reactivated" | "panel_failed" | "insufficient" | "busy" | "skipped"
const reactivatePaygService = async ({ item, servises, setting, budgets }) => {
  if (inFlight.has(item.id)) return "busy";
  inFlight.add(item.id);
  try {
    const fresh = await SelectPaygService({ id: item.id });
    if (!fresh || !fresh.suspended_at) return "skipped";
    const local = await SelectServiseRow({ id: fresh.service_id });
    if (!local) return "skipped";
    const user = await selectUser({ id: fresh.telegram_id });
    if (!user) return "skipped";

    const key = String(fresh.telegram_id);
    const balance = budgets && budgets.has(key) ? budgets.get(key) : Number(user.price) || 0;
    const needed = neededBalance({ setting, panel: local.panel });
    if (balance < needed) return "insufficient";

    // فعال‌سازی فقط بعد از تایید پنل
    const enabled = await servises.SetStatus({ id: fresh.service_id, enable: true });
    if (!enabled) return "panel_failed";

    await UpdatePaygService({ id: fresh.id }, { suspended_at: null, warned: false, daily_billed_at: null });
    if (budgets) budgets.set(key, balance - needed);
    bot.telegram.sendMessage(fresh.telegram_id, i18nL.t("fa", "PAYG.REACTIVATED", { id: fresh.service_id }), { parse_mode: "html" }).catch(() => {});
    return "reactivated";
  } finally {
    inFlight.delete(item.id);
  }
};

const reactivatePaygForUser = async (telegramId) => {
  const suspended = await SelectSuspendedPaygServiceByUser({ telegram_id: telegramId });
  if (!suspended.length) return;
  const setting = await SelectSetting();
  const servises = new Servise();
  const budgets = new Map();
  for (const item of suspended) {
    try {
      await reactivatePaygService({ item, servises, setting, budgets });
    } catch (error) {
      console.error("PAYG reactivation error for service", item.service_id, error.message);
    }
  }
};

// one run per user at a time; top-ups that arrive meanwhile trigger exactly one more run
const running = new Set();
const dirty = new Set();

const schedulePaygReactivation = (telegramId) => {
  const key = String(telegramId);
  if (running.has(key)) {
    dirty.add(key);
    return;
  }
  running.add(key);
  (async () => {
    try {
      do {
        dirty.delete(key);
        await reactivatePaygForUser(key);
      } while (dirty.has(key));
    } catch (error) {
      console.error("PAYG recharge reactivation error:", error.message);
    } finally {
      running.delete(key);
    }
  })();
};

const installPaygRechargeHook = () => {
  sequelize.addHook("afterBulkUpdate", "paygRechargeReactivate", (options) => {
    try {
      if (options?.model?.name !== "users") return;
      const attributes = options.attributes;
      // کیف پول تغییری نکرده
      if (attributes && !("price" in attributes)) return;
      // کسر لحظه‌ای صورتحساب (literal "price - n") هیچ‌وقت موجودی را بیشتر نمی‌کند
      const price = attributes?.price;
      if (price && typeof price === "object" && /price\s*-/.test(String(price.val ?? ""))) return;
      const id = options.where?.id;
      if (id === undefined || id === null || typeof id === "object") return;
      // بدون await - نباید کالبک درگاه/تایید پرداخت را کند کند
      schedulePaygReactivation(id);
    } catch (error) {
      console.error("PAYG recharge hook error:", error.message);
    }
  });
};

export { installPaygRechargeHook, reactivatePaygService, reactivatePaygForUser, schedulePaygReactivation };
