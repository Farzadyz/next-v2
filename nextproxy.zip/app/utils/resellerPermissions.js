// ============================================================================
// Master permission matrices for reseller bots.
//
// TWO independent matrices are managed by the Main Admin (inline keyboards in
// the main bot's admin panel -> "Manage resellers" control hub):
//
//   1) FEATURES  (setting.reseller_permissions)
//      Every customer-facing capability of the main bot: plans, PAYG, checkout,
//      menus, per-service buttons, automation and payment gateways.
//      -> served to the reseller instance as `permissions`
//
//   2) ADMIN PERMISSIONS  (setting.reseller_admin_permissions)
//      Every admin-panel menu / setting a Reseller Admin may open inside the
//      reseller bot's own /panel. One key per main-bot admin menu button.
//      -> served to the reseller instance as `admin_permissions`
//
// Both are delivered to every isolated reseller instance through the
// Intermediary REST API (GET /reseller-api/v1/bootstrap | /permissions) and
// each reseller bot rebuilds its menus, buttons and admin panel from them:
//   - hide/deny a menu whose `allow_*` feature key is false
//   - hide/deny an admin-panel button whose `admin_*` key is false
//     (`admin_panel_access` = false locks the whole /panel)
//
// NOTE: the isolated reseller instance code lives in `reseller-template/`
// (RESELLER_TEMPLATE_DIR) and must read `admin_permissions` from the API
// payload to hide/deny the matching admin-panel menus on its side.
//
// The legacy `allow_panel_*` keys are still emitted inside `permissions`
// (derived from the admin matrix, see LEGACY_PANEL_PERMISSION_MAP) so already
// deployed reseller instances and the main API keep working unchanged.
// ============================================================================

// Payment gateway types a reseller may configure/use LOCALLY (own merchant
// codes / API keys, money goes straight to the reseller).
const PAY_GATEWAYS = [
  { key: "PAYSTAR", label: "💰 مستقیم (پی‌استار)", default: true },
  { key: "CARD", label: "💳 کارت به کارت", default: true },
  { key: "ZARINPAL", label: "⭐️ زرین پال", default: true },
  { key: "ZIBAL", label: "🧩 زیبال", default: true },
  { key: "NOVINPAL", label: "👑 نوین‌پال", default: false },
  { key: "POLAM", label: "💥 پلام", default: false },
  { key: "TABAPAY", label: "🧬 تاباپی", default: false },
  { key: "SIZAPAY", label: "⭐️ سیزپی", default: false },
  { key: "ZIRGOZAR", label: "🔗 درگاه ریالی مستقیم (زیرگذر)", default: false },
  { key: "TERAPAY", label: "💳 کارت به کارت خودکار (ترا‌پی)", default: false },
  { key: "RIALIT", label: "🏦 درگاه ریالیت", default: false },
  { key: "ATLASPAY", label: "🔅 اطلس‌پی", default: false },
  { key: "NOWPEYMENT", label: "💵 درگاه ارز مجازی (NowPayments)", default: false },
];

// kept for import compatibility with older code
const CRYPTO_GATEWAY = null;

// ----------------------------------------------------------------- FEATURES

const RESELLER_FEATURE_GROUPS = [
  { key: "plans", title: "📦 خرید و پلن‌ها" },
  { key: "payg", title: "⚡️ Pay As You Go" },
  { key: "checkout", title: "💸 روش‌های پرداخت مشتری" },
  { key: "other", title: "⚙️ سایر امکانات" },
  { key: "menus", title: "📋 منوهای اصلی ربات" },
  { key: "actions", title: "🔘 دکمه‌های مدیریت سرویس" },
  { key: "auto", title: "🤖 اتوماسیون و اعلان‌ها" },
  { key: "pay", title: "💳 درگاه‌های پرداخت اختصاصی" },
];

const CORE_PERMISSIONS = [
  // plans
  { key: "allow_buy_service", label: "🛒 خرید اشتراک (منوی خرید)", group: "plans", default: true },
  { key: "allow_choose_plan", label: "○ پلن انتخابی (پلن‌های آماده)", group: "plans", default: true },
  { key: "allow_multi_location", label: "🌍 پلن‌های مولتی لوکیشن", group: "plans", default: true },
  { key: "allow_single_location", label: "📍 پلن‌های تک لوکیشن", group: "plans", default: true },
  { key: "allow_economic_plan", label: "💰 پلن‌های اقتصادی", group: "plans", default: true },
  { key: "allow_custom_plan", label: "🎛 پلن سفارشی (انتخاب حجم/روز)", group: "plans", default: false },
  { key: "allow_select_custom_plan", label: "▫️ پلن انتخابی، سفارشی", group: "plans", default: false },
  { key: "allow_server_choice", label: "🖥 انتخاب لوکیشن توسط مشتری", group: "plans", default: true },
  { key: "allow_set_name", label: "📝 تنظیم نام اشتراک قبل از پرداخت", group: "plans", default: true },
  // payg
  { key: "allow_payg_multi", label: "⚡️ Pay As You Go (مولتی لوکیشن)", group: "payg", default: false },
  { key: "allow_payg_single", label: "⚡️ Pay As You Go (تک لوکیشن)", group: "payg", default: false },
  // checkout
  { key: "allow_wallet_pay", label: "💸 پرداخت با کیف پول", group: "checkout", default: true },
  { key: "allow_gateway_pay", label: "💰 پرداخت با درگاه", group: "checkout", default: true },
  { key: "allow_agent_discount", label: "🏵 قیمت ویژه نمایندگان (Agent)", group: "checkout", default: false },
  // other
  { key: "allow_test_service", label: "🎁 سرویس تست رایگان", group: "other", default: true },
  { key: "allow_gift", label: "🎟 کد تخفیف", group: "other", default: false },
  { key: "allow_renew", label: "♻️ تمدید سرویس", group: "other", default: true },
  { key: "allow_invite_reward", label: "🎉 پاداش دعوت (هدیه شروع و درصد شارژ)", group: "other", default: false },
  // customer main menu buttons
  { key: "allow_my_service", label: "💎 اشتراک های من", group: "menus", default: true },
  { key: "allow_account", label: "👤 اطلاعات حساب", group: "menus", default: true },
  { key: "allow_support", label: "👥 پشتیبانی", group: "menus", default: true },
  { key: "allow_price_list", label: "💰 لیست قیمت‌ها", group: "menus", default: true },
  { key: "allow_charge_account", label: "💳 شارژ حساب (کیف پول مشتری)", group: "menus", default: true },
  { key: "allow_free_proxy", label: "💌 اشتراک رایگان (لینک دعوت)", group: "menus", default: false },
  { key: "allow_get_agent", label: "🔑 دریافت نمایندگی", group: "menus", default: false },
  { key: "allow_question", label: "❓ سوالات متداول", group: "menus", default: true },
  { key: "allow_reseller_bot", label: "🤖 ربات نمایندگی", group: "menus", default: false },
  { key: "allow_website", label: "🌐 سایت", group: "menus", default: false },
  // per-service buttons
  { key: "allow_action_qr", label: "🔖 دکمه QR Code", group: "actions", default: true },
  { key: "allow_action_refresh", label: "📊 دکمه بروزرسانی اطلاعات", group: "actions", default: true },
  { key: "allow_action_revoke", label: "🔐 دکمه تغییر لینک/پسوورد", group: "actions", default: true },
  { key: "allow_action_status", label: "🔌 دکمه وضعیت اتصال موقت", group: "actions", default: true },
  { key: "allow_action_delete", label: "❌ دکمه حذف سرویس", group: "actions", default: false },
  { key: "allow_action_upgrade", label: "🪜 دکمه ارتقا حجم اشتراک", group: "actions", default: false },
  { key: "allow_action_redirect", label: "♋️ دکمه منتقل کردن سرویس", group: "actions", default: false },
  { key: "allow_action_refund", label: "↩️ دکمه لغو و مرجوعی", group: "actions", default: false },
  { key: "allow_action_search", label: "🔎 جستجوی اشتراک (اینلاین)", group: "actions", default: true },
  { key: "allow_connect_guides", label: "📲 راهنمای اتصال (اندروید/iOS/ویندوز)", group: "actions", default: true },
  // automation & notifications
  { key: "allow_expiry_alert", label: "🔔 هشدار نزدیک شدن به پایان حجم/زمان", group: "auto", default: true },
  { key: "allow_gift_alert", label: "🎁 پیام تخفیف فاکتورهای پرداخت‌نشده", group: "auto", default: false },
  { key: "allow_last_message", label: "🥹 پیام یادآوری کاربران غیرفعال", group: "auto", default: false },
  { key: "allow_auto_delete", label: "🗑 حذف خودکار سرویس‌های منقضی", group: "auto", default: false },
  { key: "allow_test_expire", label: "⏱ غیرفعال‌سازی خودکار سرویس تست", group: "auto", default: true },
  { key: "allow_join_lock", label: "📢 قفل عضویت اجباری در کانال", group: "auto", default: false },
  { key: "allow_backup", label: "💾 بک‌آپ خودکار دیتابیس", group: "auto", default: false },
];

const PAY_PERMISSIONS = PAY_GATEWAYS.map((gateway) => ({
  key: `allow_pay_${gateway.key}`,
  label: gateway.label,
  group: "pay",
  default: gateway.default,
}));

const RESELLER_PERMISSION_DEFS = [...CORE_PERMISSIONS, ...PAY_PERMISSIONS];
const RESELLER_PERMISSION_KEYS = RESELLER_PERMISSION_DEFS.map((def) => def.key);

const RESELLER_PERMISSION_GROUP_TITLES = Object.fromEntries(RESELLER_FEATURE_GROUPS.map((group) => [group.key, group.title]));

const DEFAULT_RESELLER_PERMISSIONS = Object.fromEntries(RESELLER_PERMISSION_DEFS.map((def) => [def.key, def.default]));

// ------------------------------------------------------- ADMIN PERMISSIONS

const RESELLER_ADMIN_GROUPS = [
  { key: "general", title: "📊 دسترسی کلی و آمار" },
  { key: "users", title: "👥 مدیریت کاربران" },
  { key: "agents", title: "🏵 مدیریت نمایندگان" },
  { key: "plans", title: "💠 محصولات و پلن‌ها" },
  { key: "servers", title: "🖥 سرورها و پنل‌ها" },
  { key: "payg", title: "⚡️ Pay As You Go" },
  { key: "gateways", title: "🏦 درگاه‌ها و پرداخت" },
  { key: "marketing", title: "🎁 تخفیف و بازاریابی" },
  { key: "broadcast", title: "📢 ارتباط با کاربران" },
  { key: "system", title: "🛠 تنظیمات ربات" },
  { key: "resellers", title: "🤝 مدیریت نمایندگی‌ها" },
];

// One key per main-bot admin menu button (PANEL.MENU_PANEL.*) plus the
// reseller-only sections (recharge / pricing / own gateway keys).
const RESELLER_ADMIN_PERMISSION_DEFS = [
  // general & stats
  { key: "admin_panel_access", label: "🔓 ورود به پنل ادمین (کلید اصلی)", group: "general", default: true },
  { key: "admin_stats", label: "📊 آمار", group: "general", default: true },
  { key: "admin_sell_month", label: "💰 فروش ماهانه (PDF / Excel)", group: "general", default: true },
  { key: "admin_sell_card", label: "🏷 گردش حساب ماهانه", group: "general", default: true },
  { key: "admin_log_buy", label: "👥 تنظیم گزارشات", group: "general", default: false },
  // users
  { key: "admin_check_account", label: "♨️ چک کردن حساب", group: "users", default: true },
  { key: "admin_check_service", label: "🚸 چک کردن سرویس", group: "users", default: true },
  { key: "admin_disable_all", label: "💤 قطع تمامی سرویس‌های کاربر", group: "users", default: false },
  { key: "admin_enable_all", label: "☑️ وصل تمامی سرویس‌های کاربر", group: "users", default: false },
  { key: "admin_block", label: "🪓 بلاک", group: "users", default: true },
  { key: "admin_unblock", label: "🕳 آن‌بلاک", group: "users", default: true },
  { key: "admin_add_balance", label: "💰 افزایش موجودی کاربر", group: "users", default: false },
  // agents
  { key: "admin_add_agent", label: "♻️ افزودن نمایندگی", group: "agents", default: false },
  { key: "admin_delete_agent", label: "🏵 حذف نمایندگی", group: "agents", default: false },
  { key: "admin_list_agent", label: "📜 لیست نماینده‌ها", group: "agents", default: false },
  { key: "admin_add_balance_agent", label: "💷 افزایش موجودی نمایندگان", group: "agents", default: false },
  // plans
  { key: "admin_pricing", label: "💲 قیمت‌گذاری پلن‌ها", group: "plans", default: true },
  { key: "admin_add_plan", label: "💠 اضافه کردن محصول", group: "plans", default: false },
  { key: "admin_delete_plan", label: "❌ حذف محصول", group: "plans", default: false },
  { key: "admin_edit_plan", label: "✏️ ویرایش محصول", group: "plans", default: false },
  { key: "admin_show_plans", label: "🧬 نمایش پلن", group: "plans", default: false },
  { key: "admin_custom_plan", label: "❓ تنظیمات پلن سفارشی", group: "plans", default: false },
  { key: "admin_custom_select_plan", label: "❔ تنظیمات پلن (سفارشی، انتخابی)", group: "plans", default: false },
  { key: "admin_add_upgrade", label: "🪜 اضافه کردن بسته ارتقا", group: "plans", default: false },
  { key: "admin_delete_upgrade", label: "✖️ حذف بسته ارتقا", group: "plans", default: false },
  { key: "admin_protocol", label: "🔗 تنظیم پروتکل", group: "plans", default: false },
  { key: "admin_free_traffic", label: "🆓 تنظیم حجم رایگان", group: "plans", default: false },
  // servers
  { key: "admin_add_panel", label: "➕ اضافه کردن پنل", group: "servers", default: false },
  { key: "admin_list_panel", label: "📜 لیست پنل (سرورهای در دسترس)", group: "servers", default: true },
  { key: "admin_set_price_inbound", label: "🎟 تنظیم قیمت inbound", group: "servers", default: false },
  { key: "admin_add_panel_mz", label: "➕ اضافه کردن پنل مرزبان", group: "servers", default: false },
  { key: "admin_list_panel_mz", label: "📜 لیست پنل مرزبان", group: "servers", default: false },
  { key: "admin_sabt_link", label: "⭐️ ثبت لینک", group: "servers", default: false },
  // payg
  { key: "admin_config_payg", label: "⚡️ تنظیمات پرداخت به ازای مصرف", group: "payg", default: false },
  { key: "admin_manage_payg", label: "📊 مدیریت سرویس‌های PAYG", group: "payg", default: false },
  // gateways & payments
  { key: "admin_recharge", label: "🔋 شارژ حساب نزد ربات اصلی", group: "gateways", default: true },
  { key: "admin_gateways", label: "🏦 تنظیم درگاه‌های پرداخت اختصاصی", group: "gateways", default: true },
  { key: "admin_show_pay", label: "💰 نمایش / فعال‌سازی درگاه‌ها", group: "gateways", default: true },
  { key: "admin_switch_gateway", label: "💢 سوییچ درگاه", group: "gateways", default: true },
  { key: "admin_switch_gateway_card", label: "💳 سوییچ درگاه کارت به کارت", group: "gateways", default: false },
  { key: "admin_first_payment", label: "📊 تغییر وضعیت اولین پرداخت", group: "gateways", default: false },
  { key: "admin_config_nowpayments", label: "💎 تنظیمات NowPayments", group: "gateways", default: false },
  { key: "admin_id_card", label: "💴 تنظیم دریافت رسید", group: "gateways", default: true },
  // marketing
  { key: "admin_gift_add", label: "🎁 اضافه کردن کد تخفیف", group: "marketing", default: false },
  { key: "admin_gift_delete", label: "✖️ حذف کد تخفیف", group: "marketing", default: false },
  { key: "admin_gift_invite", label: "🎉 سود زیرمجموعه", group: "marketing", default: false },
  { key: "admin_gift_start", label: "💌 تنظیم هدیه شروع", group: "marketing", default: false },
  // broadcast
  { key: "admin_message_all", label: "✉️ پیام همگانی", group: "broadcast", default: true },
  { key: "admin_forward_all", label: "📪 فوروارد همگانی", group: "broadcast", default: true },
  { key: "admin_pin", label: "📌 پین پیام در ربات", group: "broadcast", default: false },
  // system
  { key: "admin_manage_texts", label: "📝 مدیریت متن‌ها و دکمه‌ها", group: "system", default: true },
  { key: "admin_config_refund", label: "↩️ تنظیمات مرجوعی", group: "system", default: false },
  // resellers
  { key: "admin_manage_resellers", label: "🤝 مدیریت نمایندگی‌ها", group: "resellers", default: false },
  { key: "admin_reseller_balance", label: "💰 حداقل موجودی نمایندگی", group: "resellers", default: false },
  { key: "admin_reseller_fee", label: "💵 هزینه راه‌اندازی نمایندگی", group: "resellers", default: false },
];

const RESELLER_ADMIN_PERMISSION_KEYS = RESELLER_ADMIN_PERMISSION_DEFS.map((def) => def.key);

const DEFAULT_RESELLER_ADMIN_PERMISSIONS = Object.fromEntries(RESELLER_ADMIN_PERMISSION_DEFS.map((def) => [def.key, def.default]));

// Old coarse "panel section" switches (features matrix) -> granular admin keys.
const LEGACY_PANEL_PERMISSION_MAP = {
  allow_panel_recharge: ["admin_recharge"],
  allow_panel_pricing: ["admin_pricing"],
  allow_panel_gateways: ["admin_gateways"],
  allow_panel_gifts: ["admin_gift_add", "admin_gift_delete"],
  allow_panel_broadcast: ["admin_message_all", "admin_forward_all"],
  allow_panel_texts: ["admin_manage_texts"],
  allow_panel_stats: ["admin_stats"],
};

// ----------------------------------------------------------------- parsing

const safeParse = (raw) => {
  try {
    const parsed = JSON.parse(raw || "{}");
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (error) {
    return {};
  }
};

// Parses the stored JSON blob, drops unknown/legacy keys and backfills every
// missing key with its default so an old row never yields `undefined`.
const parseResellerPermissions = (raw) => {
  const parsed = safeParse(raw);
  const result = {};
  for (const key of RESELLER_PERMISSION_KEYS) {
    result[key] = key in parsed ? Boolean(parsed[key]) : DEFAULT_RESELLER_PERMISSIONS[key];
  }
  return result;
};

// Same for the reseller-admin matrix.
const parseResellerAdminPermissions = (raw) => {
  const parsed = safeParse(raw);
  const result = {};
  for (const key of RESELLER_ADMIN_PERMISSION_KEYS) {
    result[key] = key in parsed ? Boolean(parsed[key]) : DEFAULT_RESELLER_ADMIN_PERMISSIONS[key];
  }
  return result;
};

// One-time seed used by the migration: carries the values the main admin had
// already chosen for the old `allow_panel_*` switches over to the new matrix.
const seedAdminPermissionsFromLegacy = (legacyRaw) => {
  const legacy = safeParse(legacyRaw);
  const result = { ...DEFAULT_RESELLER_ADMIN_PERMISSIONS };
  for (const [legacyKey, adminKeys] of Object.entries(LEGACY_PANEL_PERMISSION_MAP)) {
    if (!(legacyKey in legacy)) continue;
    for (const adminKey of adminKeys) result[adminKey] = Boolean(legacy[legacyKey]);
  }
  return result;
};

// Adds the legacy `allow_panel_*` keys (derived from the admin matrix) to the
// feature matrix that is served to reseller instances.
const withLegacyPanelKeys = (features, adminPermissions) => {
  const result = { ...features };
  for (const [legacyKey, adminKeys] of Object.entries(LEGACY_PANEL_PERMISSION_MAP)) {
    result[legacyKey] = Boolean(adminPermissions.admin_panel_access) && adminKeys.some((key) => adminPermissions[key]);
  }
  return result;
};

export {
  PAY_GATEWAYS,
  CRYPTO_GATEWAY,
  CORE_PERMISSIONS,
  PAY_PERMISSIONS,
  RESELLER_FEATURE_GROUPS,
  RESELLER_PERMISSION_DEFS,
  RESELLER_PERMISSION_KEYS,
  RESELLER_PERMISSION_GROUP_TITLES,
  DEFAULT_RESELLER_PERMISSIONS,
  RESELLER_ADMIN_GROUPS,
  RESELLER_ADMIN_PERMISSION_DEFS,
  RESELLER_ADMIN_PERMISSION_KEYS,
  DEFAULT_RESELLER_ADMIN_PERMISSIONS,
  LEGACY_PANEL_PERMISSION_MAP,
  parseResellerPermissions,
  parseResellerAdminPermissions,
  seedAdminPermissionsFromLegacy,
  withLegacyPanelKeys,
};
