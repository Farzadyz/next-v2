import { SelectSuspendedPaygServiceByUser, UpdatePaygService } from "../controllers/PaygService.js";
import { SelectSetting } from "../controllers/Setting.js";
import { selectUser } from "../controllers/Users.js";
import { SelectServise as SelectServiseRow } from "../controllers/Servise.js";
import Servise from "../bot/model/servise.js";
import { bot, i18nL } from "../bot/index.js";

// حداقل موجودی لازم برای فعال‌سازی مجدد = هزینه روزانه (پیش‌پرداخت روز جدید) و حداقل مثبت بودن موجودی
const neededToReactivate = (setting, panel) => {
  const isMulti = panel === "wiguard";
  const dailyRate = Math.round(Number((isMulti ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0));
  return Math.max(1, dailyRate);
};

// جلوگیری از اجرای همزمان (هوک شارژ + کرون پشتیبان) برای یک کیف پول
const locks = new Set();

// سرویس‌های PAYG تعلیق‌شده‌ی این کیف پول را - اگر موجودی جدید کافی باشد - همین لحظه دوباره فعال می‌کند:
//   ۱) درخواست صریح فعال‌سازی (enable=true) به پنل + بروزرسانی وضعیت در دیتابیس ربات (Servise.SetStatus، تاییدشده)
//   ۲) پاک شدن وضعیت تعلیق سرویس PAYG (چرخه هزینه روزانه ریست می‌شود تا هزینه روز جدید از قبل کسر شود)
// اگر پنل فعال‌سازی را تایید نکند سرویس تعلیق‌شده می‌ماند و در اجرای بعدی (کرون ۳۰ ثانیه‌ای) دوباره تلاش می‌شود.
// خروجی: تعداد سرویس‌های فعال‌شده
const ReactivatePaygForUser = async ({ telegram_id }) => {
  const key = String(telegram_id);
  if (locks.has(key)) return 0;
  locks.add(key);
  try {
    const suspended = await SelectSuspendedPaygServiceByUser({ telegram_id });
    if (!suspended.length) return 0;
    const user = await selectUser({ id: telegram_id });
    if (!user) return 0;
    const setting = await SelectSetting();
    const servises = new Servise();

    // موجودی بین چند سرویس یک کاربر تقسیم می‌شود (هر سرویس فعال‌شده هزینه روز اولش را رزرو می‌کند)
    let available = Number(user.price) || 0;
    let count = 0;
    for (const item of suspended) {
      const local = await SelectServiseRow({ id: item.service_id });
      if (!local) continue;
      const needed = neededToReactivate(setting, local.panel);
      if (available < needed) continue;

      const enabled = await servises.SetStatus({ id: item.service_id, enable: true });
      if (!enabled) {
        console.error("PaygReactivate: panel did not confirm re-enable of service", item.service_id, "- retrying later");
        continue;
      }
      await UpdatePaygService({ id: item.id }, { suspended_at: null, warned: false, daily_billed_at: null });
      available -= needed;
      count++;
      bot.telegram
        .sendMessage(item.telegram_id, i18nL.t("fa", "PAYG.REACTIVATED", { id: item.service_id }), { parse_mode: "html" })
        .catch(() => {});
    }
    return count;
  } finally {
    locks.delete(key);
  }
};

export { ReactivatePaygForUser, neededToReactivate };
