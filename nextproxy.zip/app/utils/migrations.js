import { DATE, STRING, TEXT } from "sequelize";
import sequelize from "./database.js";
import PaygService from "../model/paygservice.js";
import Setting from "../model/setting.js";
import PaygCostLog from "../model/paygcostlog.js";
import "../model/webapp_ticket.js"; // registers the table with sequelize before sync()
import { PANEL_TYPES } from "./panelTypes.js";
import { seedAdminPermissionsFromLegacy } from "./resellerPermissions.js";

// adds a column only when it does not exist yet (sequelize.sync() never alters existing tables)
const ensureColumn = async (table, column, definition) => {
  const queryInterface = sequelize.getQueryInterface();
  const description = await queryInterface.describeTable(table);
  if (!description[column]) {
    await queryInterface.addColumn(table, column, definition);
  }
};

// adds every column of a model that is missing in an ALREADY EXISTING table (sequelize.sync() never alters existing tables)
const ensureModelColumns = async (Model) => {
  const queryInterface = sequelize.getQueryInterface();
  const table = Model.getTableName();
  const description = await queryInterface.describeTable(table);
  for (const [name, attribute] of Object.entries(Model.rawAttributes)) {
    if (description[name]) continue;
    // timestamps are added nullable so rows that already exist never break the ALTER
    const definition =
      name === "createdAt" || name === "updatedAt"
        ? { type: DATE, allowNull: true }
        : { type: attribute.type, allowNull: attribute.allowNull, defaultValue: attribute.defaultValue };
    await queryInterface.addColumn(table, name, definition);
  }
};

const RunMigrations = async () => {
  try {
    // start of the last prepaid PAYG day (upfront daily fee)
    await ensureColumn(PaygService.getTableName(), "daily_billed_at", { type: DATE, allowNull: true, defaultValue: null });
  } catch (error) {
    console.log("migration skipped:", error.message);
  }
  try {
    // panel type of every server (existing servers keep working as the legacy Sanaei type)
    await ensureColumn("inbounds", "panel", {
      type: STRING(32),
      allowNull: false,
      defaultValue: PANEL_TYPES.SANAEI_OLD,
    });
  } catch (error) {
    // table may not exist yet on a fresh install - sequelize.sync() creates it with the column
    console.log("migration skipped:", error.message);
  }
  try {
    // PAYG cost-deduction log: a payg_cost_logs table created earlier with fewer columns gets the missing ones added
    await ensureModelColumns(PaygCostLog);
  } catch (error) {
    // table may not exist yet on a fresh install - sequelize.sync() creates it with all columns
    console.log("migration skipped:", error.message);
  }
  try {
    // reseller permission matrices (features + granular admin-panel permissions).
    // Added nullable (MySQL TEXT cannot carry a DEFAULT) - a NULL value simply means "use the defaults".
    const settingTable = Setting.getTableName();
    await ensureColumn(settingTable, "reseller_permissions", { type: TEXT, allowNull: true });
    await ensureColumn(settingTable, "reseller_admin_permissions", { type: TEXT, allowNull: true });
    // one-time seed: keep whatever the main admin had chosen for the old allow_panel_* switches
    const row = await Setting.findOne({ where: { id: 1 }, attributes: ["id", "reseller_permissions", "reseller_admin_permissions"] });
    if (row && !row.reseller_admin_permissions) {
      await Setting.update(
        { reseller_admin_permissions: JSON.stringify(seedAdminPermissionsFromLegacy(row.reseller_permissions)) },
        { where: { id: 1 } }
      );
    }
  } catch (error) {
    // table may not exist yet on a fresh install - sequelize.sync() creates it with the columns
    console.log("migration skipped:", error.message);
  }
};

export default RunMigrations;
