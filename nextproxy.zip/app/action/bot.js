import { SelectBot, UpdateBot } from "../controllers/Bot.js";
import { CountPeystar, CreatePeystar } from "../controllers/Paystar.js";
import Paystar from "../pay/paystar.js";

const Bots = {
  // get data
  GETDATA: async ({ res, username }) => {
    try {
      const product = await SelectBot({ username });
      if (!product) return res.json({ result: false });
      return res.json({ result: true, data: product });
    } catch (error) {
      return res.json({ result: false });
    }
  },
  // update price data
  UPDATEPRICE: async ({ res, username, price }) => {
    try {
      await UpdateBot({ username, price });
      return res.json({ result: true });
    } catch (error) {
      return res.json({ result: false });
    }
  },
  // Create peyment
  CREATEPEYMENT: async ({ res, username, chat_id, amount }) => {
    try {
      const count = await CountPeystar();
      const vendas = new Paystar();
      const create = await vendas.CreatePayment({ amount, order_id: count + 1, type: "pricenmd" });
      if (!create || create.status != 1) return res.json({ result: false });
      // create pay for payment in database
      await CreatePeystar({
        chat_id,
        bot: username,
        amount,
        ref_num: create.data.ref_num,
      });
      return res.json({ result: true, pay: "https://core.paystar.ir/api/pardakht/payment?token=" + create.data.token });
    } catch (error) {
      return res.json({ result: false });
    }
  },
};

export default Bots;
