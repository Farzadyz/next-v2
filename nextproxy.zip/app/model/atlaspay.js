import { BIGINT, BOOLEAN, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const AtlasPay = sequelize.define("atlaspay", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: BIGINT, allowNull: false },
  amount: { type: INTEGER, allowNull: false },
  order_id: { type: STRING(255), allowNull: false },
  tracking_code: { type: STRING(255), allowNull: true },
  payment: { type: INTEGER, allowNull: true },
  status: { type: BOOLEAN, defaultValue: false },
  // پرداخت با کسری واریز تایید شده یا در وضعیت نهایی ناموفق/منقضی رسیده - کرون دیگر verify نمی‌کند
  closed: { type: BOOLEAN, defaultValue: false },
});

export default AtlasPay;
