import { BIGINT, BOOLEAN, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Venda = sequelize.define("venda", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: BIGINT, allowNull: false },
  amount: { type: INTEGER, allowNull: false },
  vprescode: { type: STRING(255), allowNull: false },
  payment: { type: INTEGER, allowNull: true },
  status: { type: BOOLEAN, defaultValue: false },
});

export default Venda;
