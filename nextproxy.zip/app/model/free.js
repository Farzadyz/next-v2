import { BIGINT, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Free = sequelize.define("free", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: BIGINT, allowNull: false },
  amount: { type: INTEGER, allowNull: false },
  type: { type: STRING, allowNull: false },
});

export default Free;
