import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Zibal = sequelize.define("zibal", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: DataTypes.BIGINT, allowNull: false },
  amount: { type: DataTypes.INTEGER, allowNull: false },
  trans_id: { type: DataTypes.STRING(50), allowNull: false },
  payment: { type: DataTypes.INTEGER, allowNull: true },
  status: { type: DataTypes.BOOLEAN, defaultValue: false },
});

export default Zibal;
