import { BIGINT, BOOLEAN, DATE, DOUBLE, INTEGER, STRING, UUID } from "sequelize";
import sequelize from "../utils/database.js";

const Servise = sequelize.define("servise", {
  id: {
    type: INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  status: {
    type: BOOLEAN,
    defaultValue: true,
  },
  uuid: { type: UUID, allowNull: false },
  location: { type: STRING, allowNull: false },
  types: { type: STRING(32), allowNull: true },
  id_pelan: {
    type: INTEGER,
    allowNull: true,
  },
  telegram_id: {
    type: BIGINT,
    allowNull: false,
  },
  name: {
    type: STRING(255),
    allowNull: false,
  },
  defaultname: {
    type: BOOLEAN,
    defaultValue: true,
  },
  username: {
    type: STRING(255),
    allowNull: false,
  },
  data_limit: {
    type: BIGINT,
    allowNull: true,
  },
  traficc: {
    type: DOUBLE,
    allowNull: false,
  },
  time: {
    type: INTEGER,
    allowNull: false,
  },
  upgerade: {
    type: INTEGER,
    allowNull: true,
  },
  free: {
    type: BOOLEAN,
    defaultValue: false,
  },
  panel: {
    type: STRING,
    allowNull: false,
  },
  // مبلغی که برای این سرویس در لحظه خرید پرداخت شده (جهت سیستم لغو و مرجوعی) - 0 یعنی قابل مرجوعی نیست
  price: {
    type: INTEGER,
    allowNull: true,
    defaultValue: 0,
  },
  // زمان مرجوعی سرویس (در صورت null یعنی هنوز مرجوع نشده)
  refunded_at: {
    type: DATE,
    allowNull: true,
  },
});

export default Servise;
