import { INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Upgrade = sequelize.define("upgrade", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: { type: STRING(255), allowNull: false },
  price: { type: INTEGER, allowNull: false },
  traficc: { type: INTEGER, allowNull: false },
});

export default Upgrade;
