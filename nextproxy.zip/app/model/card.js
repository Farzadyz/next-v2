import { BIGINT, BOOLEAN, INTEGER } from "sequelize";

import sequelize from "../utils/database.js";

const Card = sequelize.define("card", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: BIGINT, allowNull: false },
  amount: { type: INTEGER, allowNull: false },
  status: { type: BOOLEAN, defaultValue: false },
});

export default Card;
