import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Gifts = sequelize.define("gifts", {
  code: { primaryKey: true, type: DataTypes.STRING, allowNull: false },
  gift: { type: DataTypes.STRING(255), allowNull: false },
  limit: { type: DataTypes.INTEGER, allowNull: false },
  used: { type: DataTypes.TEXT, defaultValue: JSON.stringify([]) },
});

export default Gifts;
