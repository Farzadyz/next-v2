import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Sendall = sequelize.define("sendAll_bot", {
  id: {
    type: DataTypes.INTEGER(11),
    primaryKey: true,
    allowNull: false,
    autoIncrement: true,
  },
  step: { type: DataTypes.STRING(20), defaultValue: null },
  text: { type: DataTypes.TEXT, defaultValue: null },
  chat: { type: DataTypes.STRING(100), defaultValue: null },
  user: { type: DataTypes.INTEGER, defaultValue: 0 },
  type: { type: DataTypes.STRING, defaultValue: "ALL" },
});

export default Sendall;
