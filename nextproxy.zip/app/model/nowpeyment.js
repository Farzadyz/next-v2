import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Nowpeyment = sequelize.define("nowpeyments", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: DataTypes.BIGINT, allowNull: false },
  amount: { type: DataTypes.INTEGER, allowNull: false },
  count: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  price_count: { type: DataTypes.INTEGER, allowNull: false },
  price_desposid: { type: DataTypes.DECIMAL(10, 1), defaultValue: 0 },
  pay_address: { type: DataTypes.TEXT, allowNull: false },
  payment_id: { type: DataTypes.STRING(255), allowNull: false },
  status: { type: DataTypes.BOOLEAN, defaultValue: false },
  deposit: { type: DataTypes.BOOLEAN, defaultValue: false },
  idServise: { type: DataTypes.INTEGER, allowNull: true },
  pay_currency: { type: DataTypes.STRING(32), allowNull: true },
});

export default Nowpeyment;
