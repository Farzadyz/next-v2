import { BIGINT, BOOLEAN, DATE, DOUBLE, INTEGER } from "sequelize";

import sequelize from "../utils/database.js";

// وضعیت مصرف و صورتحساب هر سرویس Pay As You Go - جدا از جدول servise چون این سرویس‌ها
// نرخ مصرف پیوسته و متفاوتی با پلن‌های ثابت دارند و باید جداگانه توسط کرون رصد شوند
const PaygService = sequelize.define("payg_service", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  service_id: { type: INTEGER, allowNull: false },
  telegram_id: { type: BIGINT, allowNull: false },
  // حجم و روزهای اولیه‌ای که در لحظه ساخت به سرویس اختصاص داده شد (ثابت یا محاسبه‌شده خودکار)
  initial_traffic: { type: DOUBLE, allowNull: true, defaultValue: 0 },
  initial_days: { type: INTEGER, allowNull: true, defaultValue: 0 },
  // آخرین مقدار مصرف (بایت) که در دور قبلی کرون خونده و صورتحساب شده
  last_traffic_bytes: { type: DOUBLE, allowNull: false, defaultValue: 0 },
  last_billed_at: { type: DATE, allowNull: true },
  // ابتدای آخرین روزی که هزینه ثابت روزانه‌اش از قبل (پیش‌پرداخت) کسر شده - null یعنی هزینه روز بعدی باید همین الان کسر شود
  daily_billed_at: { type: DATE, allowNull: true, defaultValue: null },
  // زمانی که به دلیل اتمام موجودی، سرویس تعلیق شد - مبنای قانون حذف بعد از ۱۲ ساعت
  suspended_at: { type: DATE, allowNull: true, defaultValue: null },
  // جلوگیری از ارسال چندباره پیام هشدار کمبود موجودی
  warned: { type: BOOLEAN, defaultValue: false },
});

export default PaygService;
