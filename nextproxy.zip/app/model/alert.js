import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Alert = sequelize.define("alert", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  primaryId: { type: DataTypes.INTEGER, allowNull: false },
  alertDate: { type: DataTypes.BOOLEAN, defaultValue: false },
  alertValue: { type: DataTypes.BOOLEAN, defaultValue: false },
});

export default Alert;
