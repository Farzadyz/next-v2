import { INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Bot = sequelize.define("bot", {
  id: {
    type: INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  username: { type: STRING(50), allowNull: false },
  price: { type: INTEGER, allowNull: false, defaultValue: 0 },
});

export default Bot;
