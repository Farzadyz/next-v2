import { BOOLEAN, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const InboundMz = sequelize.define("inbound_mz", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  type: { type: STRING(25), allowNull: false },
  status: { type: BOOLEAN, defaultValue: true },
  count: { type: INTEGER, defaultValue: 0 },
  tag: { type: STRING(255), allowNull: false },
  protocol: { type: STRING(255), allowNull: false },
  network: { type: STRING(255), allowNull: false },
  tls: { type: STRING(255), allowNull: false },
  port: { type: INTEGER, allowNull: false },
});

export default InboundMz;
