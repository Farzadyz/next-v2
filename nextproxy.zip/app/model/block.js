import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Block = sequelize.define("block", {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    allowNull: false,
  },
});

export default Block;
