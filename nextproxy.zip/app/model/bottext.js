import { INTEGER, STRING, TEXT } from "sequelize";
import sequelize from "../utils/database.js";

// Stores admin-edited overrides for texts/buttons that are normally
// resolved through locales/fa.yaml via ctx.i18n.t(text_key).
const BotText = sequelize.define("bot_text", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  text_key: {
    type: STRING(191),
    allowNull: false,
    unique: true,
  },
  value: {
    type: TEXT,
    allowNull: false,
  },
});

export default BotText;
