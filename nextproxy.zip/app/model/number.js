import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Number = sequelize.define("number", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  phonenumber: { type: DataTypes.STRING(50), allowNull: false },
});

export default Number;
