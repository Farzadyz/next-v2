import { BIGINT, BOOLEAN, DOUBLE, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Peyment = sequelize.define("peyment", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  location: { type: STRING, allowNull: false },
  types: { type: STRING(32), allowNull: false },
  name: { type: STRING(255), allowNull: false },
  defaultname: {
    type: BOOLEAN,
    defaultValue: true,
  },
  price: { type: INTEGER, allowNull: false },
  priceTamdid: { type: INTEGER, allowNull: false },
  day: { type: INTEGER(5), allowNull: false },
  traficc: { type: DOUBLE, allowNull: false },
  idPlan: { type: INTEGER, allowNull: true },
  idServise: { type: INTEGER, allowNull: true },
  telegram_id: { type: BIGINT, allowNull: false },
  gift: { type: STRING(255), defaultValue: false },
  status: { type: BOOLEAN, defaultValue: false },
  alert_gift: { type: BOOLEAN, defaultValue: false },
  panel: {
    type: STRING,
    allowNull: false,
  },
  connection: { type: STRING, allowNull: false },
});

export default Peyment;
