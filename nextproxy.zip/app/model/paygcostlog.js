import { DOUBLE, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

// تاریخچه دقیق تک‌تک کسرهای هزینه هر سرویس Pay As You Go (برای نمایش در پنل مدیریت)
//  - creation : هزینه ایجاد سرویس (در لحظه خرید)
//  - daily    : هزینه ثابت روزانه (پیش‌پرداخت هر روز)
//  - data     : هزینه مصرف داده (کسرهای پشت‌سرهم نزدیک به هم در یک ردیف جمع می‌شوند، جمع مبلغ و حجم دقیق می‌ماند)
const PaygCostLog = sequelize.define("payg_cost_log", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  payg_service_id: { type: INTEGER, allowNull: false },
  type: { type: STRING(16), allowNull: false },
  // مبلغی که واقعا از کیف پول کسر شد
  amount: { type: INTEGER, allowNull: false, defaultValue: 0 },
  // مبلغی که باید کسر می‌شد (در صورت کمبود موجودی کمتر از این مقدار کسر می‌شود)
  requested: { type: INTEGER, allowNull: false, defaultValue: 0 },
  // حجم صورتحساب‌شده (بایت) - فقط برای هزینه مصرف داده
  traffic_bytes: { type: DOUBLE, allowNull: false, defaultValue: 0 },
  // موجودی کیف پول بعد از این کسر
  balance_after: { type: INTEGER, allowNull: true },
});

export default PaygCostLog;
