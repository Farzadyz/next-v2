import { BIGINT, DATE, INTEGER, STRING, TEXT } from "sequelize";
import sequelize from "../utils/database.js";

// One row per reseller bot. Every reseller runs as its OWN isolated instance
// (own code folder, own database, own OS process) and can only reach the main
// bot through the Intermediary REST API using the api key issued at deploy time
// (only its SHA-256 hash is kept here).
const Reseller = sequelize.define("reseller", {
  id: { type: INTEGER, autoIncrement: true, primaryKey: true },
  // telegram id of the main-bot user who owns this reseller bot; that user's
  // wallet balance IS the reseller's "Credit Balance" with the main bot.
  owner_id: { type: BIGINT, allowNull: false },
  bot_token: { type: STRING(255), allowNull: false, unique: true },
  bot_username: { type: STRING(255), allowNull: true },
  // active | suspended
  status: { type: STRING(20), allowNull: false, defaultValue: "active" },
  api_key_hash: { type: STRING(64), allowNull: true },
  hook_secret: { type: STRING(64), allowNull: true },
  // local port of the isolated instance (callbacks + instant-sync hook)
  port: { type: INTEGER, allowNull: true },
  // physical folder of the isolated instance
  dir: { type: STRING(512), allowNull: true },
  // pending | deploying | running | stopped | failed
  deploy_status: { type: STRING(20), allowNull: false, defaultValue: "pending" },
  last_error: { type: TEXT, allowNull: true },
  last_seen_at: { type: DATE, allowNull: true },
});

export default Reseller;
