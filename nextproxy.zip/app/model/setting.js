import { BOOLEAN, INTEGER, STRING, TEXT } from "sequelize";
import sequelize from "../utils/database.js";
import { DEFAULT_RESELLER_PERMISSIONS } from "../utils/resellerPermissions.js";

const Setting = sequelize.define("setting", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  id_card: {
    type: STRING,
    allowNull: false,
    defaultValue: 2126513979,
  },
  log_buy: {
    type: STRING,
    allowNull: false,
    defaultValue: 2126513979,
  },
  gift: {
    type: INTEGER,
    allowNull: false,
    defaultValue: 0,
  },
  free: {
    type: STRING(255),
    allowNull: false,
    defaultValue: 0.1465,
  },
  invite: {
    type: STRING(255),
    defaultValue: JSON.stringify({
      start: 500,
      charge: 5,
    }),
  },
  subscribe: {
    type: STRING(255),
    defaultValue: JSON.stringify({
      priceT: 5000,
      maxT: 100,
      minT: 5,
      priceD: 5000,
      maxD: 100,
      minD: 5,
    }),
  },
  inbound: {
    type: STRING(255),
    defaultValue: JSON.stringify([
      { text: "GAMING", price: 1000 },
      { text: "WEB", price: 1000 },
      { text: "HYBRID", price: 2000 },
    ]),
  },
  protocol: {
    type: STRING(255),
    defaultValue: JSON.stringify([
      { name: "vmess_tcp", value: true },
      { name: "vmess_ws", value: true },
      { name: "vless_tcp", value: true },
      { name: "vless_crpc", value: true },
    ]),
  },
  showpelan: {
    type: TEXT,
    defaultValue: JSON.stringify([
      { text: "CHOESE", callback: "PELAN_CHOESE", value: true },
      { text: "CUSTOMIZE", callback: "PELAN_CUSTOMIZE", value: true },
      {
        text: "SELECTCUSTOMIZE",
        callback: "PELAN_SELECTCUSTOMIZE",
        value: true,
      },
      { text: "FREE", callback: "PELAN_FREE", value: true },
      { text: "ECONOMIC", callback: "PELAN_ECONOMIC", value: true },
    ]),
  },
  customize: {
    type: STRING(255),
    defaultValue: JSON.stringify({
      traficcV: [5, 10, 15, 20, 35, 40, 50],
      traficcP: 10000,
      timeV: [5, 10, 15, 20, 35, 40, 50, 365],
      timeP: 5000,
    }),
  },
  pay: {
    type: TEXT,
    defaultValue: JSON.stringify([
      { text: "PAYSTAR", value: true },
      { text: "CARD", value: true },
      { text: "NOWPEYMENT", value: true },
      { text: "ZARINPAL", value: false },
      { text: "ATLASPAY", value: false },
      { text: "ZIBAL", value: false },
      { text: "NOVINPAL", value: false },
      { text: "POLAM", value: false },
      { text: "TERAPAY", value: false },
      { text: "TABAPAY", value: false },
      { text: "RIALIT", value: false },
    ]),
  },
  default_pay: {
    type: STRING(255),
    allowNull: true,
  },
  default_pay_card: {
    type: STRING(255),
    allowNull: true,
    defaultValue: "TERAPAY",
  },
  // Pay As You Go
  payg_base_amount: { type: INTEGER, allowNull: true, defaultValue: 0 },
  payg_daily_rate_multi: { type: INTEGER, allowNull: true, defaultValue: 0 },
  payg_data_rate_multi: { type: INTEGER, allowNull: true, defaultValue: 0 },
  payg_daily_rate_single: { type: INTEGER, allowNull: true, defaultValue: 0 },
  payg_data_rate_single: { type: INTEGER, allowNull: true, defaultValue: 0 },
  payg_enabled_multi: { type: BOOLEAN, defaultValue: false },
  payg_enabled_single: { type: BOOLEAN, defaultValue: false },
  // fixed | auto - نحوه تعیین حجم/روز اولیه سرویس در لحظه ساخت
  payg_initial_mode: { type: STRING(32), allowNull: true, defaultValue: "fixed" },
  payg_initial_traffic: { type: INTEGER, allowNull: true, defaultValue: 10 },
  payg_initial_days: { type: INTEGER, allowNull: true, defaultValue: 3 },
  first_payment: {
    type: BOOLEAN,
    defaultValue: true,
  },
  pin: {
    type: TEXT,
    allowNull: true,
  },
  // NowPayments (crypto payment gateway)
  nowpayments_enabled: { type: BOOLEAN, defaultValue: false },
  nowpayments_api_key: { type: STRING(255), allowNull: true },
  nowpayments_ipn_secret: { type: STRING(255), allowNull: true },
  nowpayments_pay_currency: { type: STRING(32), allowNull: true, defaultValue: "usdttrc20" },
  // چند تومان معادل 1 دلار است - در صورت صفر بودن ، مبلغ بدون تبدیل مستقیم بعنوان دلار ارسال میشود
  nowpayments_usd_rate: { type: INTEGER, allowNull: true, defaultValue: 0 },
  // Service cancellation & refund
  refund_enabled: { type: BOOLEAN, defaultValue: false },
  refund_hours: { type: INTEGER, allowNull: true, defaultValue: 2 },
  // Reseller Bot feature
  reseller_min_balance: { type: INTEGER, allowNull: false, defaultValue: 500000 },
  reseller_setup_fee: { type: INTEGER, allowNull: false, defaultValue: 200000 },
  // full granular feature-permission matrix for reseller bots - see
  // app/utils/resellerPermissions.js for the canonical list of keys
  reseller_permissions: {
    type: TEXT,
    allowNull: false,
    defaultValue: JSON.stringify(DEFAULT_RESELLER_PERMISSIONS),
  },
  // granular admin-panel permission matrix for Reseller Admins (which admin
  // menus/settings a reseller may open inside its own /panel). NULL = defaults.
  reseller_admin_permissions: {
    type: TEXT,
    allowNull: true,
  },
});

export default Setting;
