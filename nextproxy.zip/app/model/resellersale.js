import { BIGINT, DOUBLE, INTEGER, STRING } from "sequelize";
import sequelize from "../utils/database.js";

// One row per config operation a reseller bot performed through the API.
// `cost` is what was debited from the reseller's credit balance.
const ResellerSale = sequelize.define("reseller_sale", {
  id: { type: INTEGER, autoIncrement: true, primaryKey: true },
  reseller_id: { type: INTEGER, allowNull: false },
  // telegram id of the customer inside the reseller's own bot
  customer_id: { type: BIGINT, allowNull: false },
  pelan_id: { type: INTEGER, allowNull: true },
  cost: { type: INTEGER, allowNull: false },
  display_price: { type: INTEGER, allowNull: true },
  servise_id: { type: STRING(64), allowNull: true },
  // plan | custom | payg | free | renew
  kind: { type: STRING(16), allowNull: false, defaultValue: "plan" },
  // idempotency key sent by the reseller bot (a retry never charges twice)
  request_id: { type: STRING(64), allowNull: true },
  days: { type: INTEGER, allowNull: true },
  traffic: { type: DOUBLE, allowNull: true },
  server_id: { type: STRING(32), allowNull: true },
});

export default ResellerSale;
