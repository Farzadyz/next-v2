import { DOUBLE, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Pelan = sequelize.define("pelan", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: { type: STRING(255), allowNull: false },
  price: { type: INTEGER, allowNull: false },
  traficc: { type: DOUBLE, allowNull: false },
  time: { type: INTEGER, allowNull: false },
  panel: { type: STRING, allowNull: false },
  type: { type: STRING, allowNull: false, defaultValue: "normal" },
  connection: { type: STRING, allowNull: false },
});

export default Pelan;
