import { DOUBLE, INTEGER } from "sequelize";

import sequelize from "../utils/database.js";

// اسنپ‌شات ساعتی از مصرف هر سرویس PAYG - برای رسم نمودار مصرف در پنل مدیریت
const PaygUsageLog = sequelize.define("payg_usage_log", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  payg_service_id: { type: INTEGER, allowNull: false },
  used_traffic_bytes: { type: DOUBLE, allowNull: false, defaultValue: 0 },
  cost: { type: INTEGER, allowNull: false, defaultValue: 0 },
});

export default PaygUsageLog;
