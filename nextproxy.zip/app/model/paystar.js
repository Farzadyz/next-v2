import { BIGINT, BOOLEAN, INTEGER, STRING } from "sequelize";

import sequelize from "../utils/database.js";

const Peystar = sequelize.define("peystar", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: BIGINT, allowNull: true },
  bot: { type: STRING, allowNull: true },
  amount: { type: INTEGER, allowNull: false },
  ref_num: { type: STRING(255), allowNull: false },
  payment: { type: INTEGER, allowNull: true },
  status: { type: BOOLEAN, defaultValue: false },
});

export default Peystar;
