import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Rialit = sequelize.define("rialit", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: DataTypes.BIGINT, allowNull: false },
  amount: { type: DataTypes.INTEGER, allowNull: false },
  trans_id: { type: DataTypes.STRING(100), allowNull: false },
  payment: { type: DataTypes.INTEGER, allowNull: true },
  status: { type: DataTypes.BOOLEAN, defaultValue: false },
  // کاربر از درگاه برگشت (callback آمد) — کرون فقط همین‌ها را verify می‌کند
  callback: { type: DataTypes.BOOLEAN, defaultValue: false },
  // به وضعیت نهایی ناموفق/منقضی رسید — دیگر verify نمی‌شود
  closed: { type: DataTypes.BOOLEAN, defaultValue: false },
});

export default Rialit;
