import { BIGINT, BOOLEAN, DATE, INTEGER, STRING } from "sequelize";
import sequelize from "../utils/database.js";
import moment from "moment";

const Users = sequelize.define("users", {
  id: {
    type: BIGINT,
    primaryKey: true, // مثل قبل کلید اصلی
  },
  ids: {
    type: BIGINT,
    autoIncrement: true, // خودکار افزایش یابد
    unique: true, // تکراری نباشد
  },
  language: { type: STRING(2), defaultValue: "fa" },
  free: {
    type: BOOLEAN,
    defaultValue: false,
  },
  agent: {
    type: BOOLEAN,
    defaultValue: false,
  },
  agent_price: {
    type: STRING(255),
    defaultValue: null,
  },
  price: {
    type: INTEGER,
    defaultValue: 0,
  },
  inviter: {
    type: BIGINT,
    allowNull: true,
  },
  member: {
    type: INTEGER,
    defaultValue: 0,
  },
  phone: {
    type: STRING(25),
    allowNull: true,
  },
  last_Message: {
    type: DATE,
    defaultValue: moment().format("YYYY-MM-DD HH:mm:ss"),
  },
  status: {
    type: BOOLEAN,
    defaultValue: true,
  },
  first_payment: {
    type: BOOLEAN,
    defaultValue: false,
  },
});

// ---------------------------------------------------------------------------
// شارژ کیف پول -> فعال‌سازی مجدد خودکار سرویس‌های PAYG تعلیق‌شده
// همه مسیرهای شارژ (درگاه‌ها، کارت به کارت، ادمین، مرجوعی، هدیه ...) موجودی را با UpdateUser
// (Users.update) عوض می‌کنند؛ این هوک بلافاصله بعد از هر تغییر موجودی، اگر آن کاربر سرویس PAYG
// تعلیق‌شده داشته باشد و موجودی جدید کافی باشد، آن را در دیتابیس و روی پنل دوباره فعال می‌کند.
// کسرهای خود کرون صورتحساب (price - N) نادیده گرفته می‌شوند.
// ---------------------------------------------------------------------------
const pendingReactivation = new Set();

Users.addHook("afterBulkUpdate", (options) => {
  try {
    const attributes = options.attributes || {};
    if (!("price" in attributes)) return;
    const value = attributes.price;
    if (value && typeof value === "object" && typeof value.val === "string" && /^\s*price\s*-/.test(value.val)) return;
    const id = options.where && options.where.id;
    if (id === undefined || id === null || typeof id === "object") return;
    const key = String(id);
    if (pendingReactivation.has(key)) return;
    pendingReactivation.add(key);
    setImmediate(async () => {
      pendingReactivation.delete(key);
      try {
        const { ReactivatePaygForUser } = await import("../utils/paygReactivate.js");
        await ReactivatePaygForUser({ telegram_id: key });
      } catch (error) {
        console.error("PAYG reactivation after recharge error:", error.message);
      }
    });
  } catch (error) {
    console.error("Users afterBulkUpdate hook error:", error.message);
  }
});

export default Users;
