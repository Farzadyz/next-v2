import { BOOLEAN, INTEGER, STRING, TEXT } from "sequelize";

import sequelize from "../utils/database.js";

const Inbound = sequelize.define("inbound", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  damoin: { type: STRING(255), allowNull: false },
  username: { type: STRING(255), allowNull: false },
  password: { type: STRING(255), allowNull: false },
  host: { type: STRING(255), allowNull: false },
  location: { type: STRING(255), allowNull: false },
  internal: { type: STRING(255), allowNull: false },
  tunel: { type: STRING(255), allowNull: false },
  port: { type: STRING(255), allowNull: false },
  usePort: { type: INTEGER, allowNull: false },
  price: { type: INTEGER, allowNull: true },
  session: { type: TEXT, allowNull: false },
  status: { type: BOOLEAN, defaultValue: true },
  type: { type: STRING, allowNull: false, defaultValue: "normal" },
  // panel type of the server: "sanae" (Sanaei <= 2.6.6) | "sanaei_new" (Sanaei new versions)
  panel: { type: STRING(32), allowNull: false, defaultValue: "sanae" },
});

export default Inbound;
