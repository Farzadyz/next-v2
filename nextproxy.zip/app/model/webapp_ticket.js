import { BIGINT, INTEGER, STRING, TEXT } from "sequelize";
import sequelize from "../utils/database.js";

// Lightweight support ticket for the Mini App. This is a NEW, additive table -
// it does not replace or touch the bot's existing free-text support-forward
// flow (bot/actions/support.js), which keeps working exactly as before.
const WebappTicket = sequelize.define("webapp_ticket", {
  id: { type: INTEGER, autoIncrement: true, primaryKey: true },
  telegram_id: { type: BIGINT, allowNull: false },
  subject: { type: STRING(255), allowNull: false },
  message: { type: TEXT, allowNull: false },
  // open | answered | closed
  status: { type: STRING(16), allowNull: false, defaultValue: "open" },
  reply: { type: TEXT, allowNull: true },
});

export default WebappTicket;
