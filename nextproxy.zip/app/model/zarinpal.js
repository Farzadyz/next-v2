import { DataTypes } from "sequelize";

import sequelize from "../utils/database.js";

const Zarinpal = sequelize.define("zarinpal", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  chat_id: { type: DataTypes.BIGINT, allowNull: false },
  amount: { type: DataTypes.INTEGER, allowNull: false },
  authority: { type: DataTypes.STRING(255), allowNull: false },
  payment: { type: DataTypes.INTEGER, allowNull: true },
  status: { type: DataTypes.BOOLEAN, defaultValue: false },
});

export default Zarinpal;
