import { INTEGER, STRING, TEXT } from "sequelize";
import sequelize from "../utils/database.js";

const Proxies = sequelize.define(
  "proxies",
  {
    id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: { type: INTEGER, allowNull: false },
    type: { type: STRING, allowNull: false },
    settings: {
      type: TEXT,
      allowNull: false,
      get() {
        return JSON.parse(this.getDataValue("settings"));
      },
      set(value) {
        this.setDataValue("settings", JSON.stringify(value));
      },
    },
  },
  {
    freezeTableName: true,
    timestamps: false,
  }
);

export default Proxies;
