import { bot, i18nL } from "../bot/index.js";
import Servise from "../bot/model/servise.js";
import { CreateAlert } from "../controllers/Alert.js";
import { SelectHoursPeystar } from "../controllers/Paystar.js";
import { SelectPeyment } from "../controllers/Peyment.js";

const Payment = async () => {
  const all = await SelectHoursPeystar();
  for (const result of all) {
    const { location, types, price, idPlan, traficc, day, name, gift, defaultname } = await SelectPeyment({ id: result.payment });
    // create api servise
    const Servises = new Servise();
    const { result: results, id } = await Servises.createServise({
      id: result.chat_id,
      traficc,
      day,
      name,
      idPlan,
      defaultname,
      location,
      types2: types,
      price,
    });
    // error to create
    if (!results) {
      bot.telegram.sendMessage(2126513979, i18nL.t("fa", "ESHTERAK_BUY.ERROR_TO_CREATED"));
      return false;
    }
    bot.telegram.sendMessage(result.chat_id, i18nL.t("fa", "ESHTERAK_BUY.SECCEFULY_PLAN", { id }), {
      parse_mode: "html",
    });
    // insert to alert
    CreateAlert({ primaryId: id });
  }
};

Payment();
