import { updateFirstPaymentFlag } from "../controllers/Users.js";

const FirstPayemnt = async () => {
  console.log("running ...");

  await updateFirstPaymentFlag();
  console.log("end ...");
};

FirstPayemnt();
