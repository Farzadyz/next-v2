import { getServicesByDateRange } from "../controllers/Servise.js";
import Servise from "../bot/model/servise.js";

/**
 * Main function to process Services based on IDs and date range
 * @param {Array<number>} ids - List of IDs for filtering
 * @param {{ startDate: string, endDate: string }} dateRange - Date range for filtering services
 */
export const processInboundsAndServices = async (ids, dateRange) => {
  try {
    // Fetch Services by date range and location ids
    const serviceResult = await getServicesByDateRange(dateRange.startDate, dateRange.endDate, ids);
    if (!serviceResult.success) {
      throw new Error("Failed to fetch services");
    }
    const services = serviceResult.data;

    const Servises = new Servise();

    // Loop through all services and create new entries
    for (const service of services) {
      await Servises.createServise({
        id: service.telegram_id,
        traficc: service.traficc,
        day: service.time,
        name: service.name,
        idPlan: service.id_pelan,
        uuids: service.uuid,
        username: service.username,
        defaultname: service.defaultname,
        location: service.location,
        types2: service.types,
        panel: "sanae",
      });
      // TODO: Add more processing logic here if needed
    }

    return {
      success: true,
      message: "Processing completed successfully.",
    };
  } catch (error) {
    console.error("Error in processInboundsAndServices:", error);
    return {
      success: false,
      message: "An error occurred during processing.",
    };
  }
};

// === Main entrypoint ===

// Read parameters from command line: node index.js 2025-07-08 2025-07-12 1,2,3
const startDate = process.argv[2];
const endDate = process.argv[3];
const idsInput = process.argv[4];

const ids = idsInput ? idsInput.split(",").map((id) => parseInt(id, 10)) : [];

(async () => {
  if (!startDate || !endDate || ids.length === 0) {
    console.error("Usage: node app/script/createService.js <startDate> <endDate> <comma_separated_ids>");
    process.exit(1);
  }

  const result = await processInboundsAndServices(ids, { startDate, endDate });
  console.log(result);
})();
