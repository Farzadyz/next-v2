import moment from "moment";
import Servise from "../bot/model/servise.js";
import { bot, i18nL } from "../bot/index.js";
import { SelectALLServise } from "../controllers/Servise.js";

const AutoDelete = async () => {
  const accounts = await SelectALLServise();
  const servies = new Servise();
  accounts.map(async (item) => {
    const account = await servies.SelectServiseAutoDelete(item);
    if (account && !account.status) {
      const today = moment();
      // تاریخ مورد نظر
      const targetDate = moment(item.updatedAt);
      const diffInDays = targetDate.diff(today, "days");
      if (diffInDays <= -9) {
        bot.telegram.sendMessage(item.telegram_id, i18nL.t("fa", "AUTODELETE", { id: item.id, name: item.username }), {
          parse_mode: "html",
        });
        servies.DeleteServise({ id: item.id, username: item.username });
      }
    }
  });
};

export default AutoDelete;
