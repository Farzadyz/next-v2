import moment from "moment";
import { bot, i18nL } from "../bot/index.js";
import { UpdateUser, selectLastMessage } from "../controllers/Users.js";

const Last_Message = async () => {
  const allMessage = await selectLastMessage();
  allMessage.map(async (item) => {
    try {
      await bot.telegram.sendMessage(543434, i18nL.t("fa", "LAST_MESSAGE"));
      // update last message
      UpdateUser({ id: item.id }, { last_Message: moment().format("YYYY-MM-DD HH:mm:ss") });
    } catch (error) {
      if (
        error.response.description == "Forbidden: bot was blocked by the user" ||
        error.response.description == "Bad Request: chat not found"
      ) {
        await UpdateUser({ id: item.id }, { status: false });
      }
    }
  });
};

export default Last_Message;
