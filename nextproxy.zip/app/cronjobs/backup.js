import ftp from "basic-ftp";
import CreateBackUp from "../backup/index.js";

// اطلاعات FTP
const ftpConfig = {
  host: process.env.FTP_HOST,
  port: process.env.FTP_PORT,
  user: process.env.FTP_USER,
  password: process.env.FTP_PASSWORD,
};

// تابع برای مدیریت نسخه‌های بکاپ
const manageBackupVersions = async (ftpClient) => {
  try {
    // لیست فایل‌های موجود در پوشه بکاپ در FTP
    const list = await ftpClient.list("backups/backup-bot");
    const backups = list
      .filter((file) => file.name.startsWith(`backup_`) && file.isFile)
      .map((file) => ({ name: file.name, time: new Date(file.modifiedAt) }));

    // مرتب‌سازی فایل‌ها به ترتیب تاریخ، از قدیم به جدید
    backups.sort((a, b) => a.time.getTime() - b.time.getTime());

    // حذف فایل‌های اضافی (بیش از 3 نسخه)
    if (backups.length > 3) {
      for (let i = 0; i < backups.length - 3; i++) {
        await ftpClient.remove(`backups/backup-bot/${backups[i].name}`);
      }
    }
  } catch (error) {}
};

// تابع برای آپلود فایل به FTP با نام تصادفی
const uploadToFTP = async (filePath) => {
  const client = new ftp.Client(60000);
  client.ftp.verbose = false;

  try {
    await client.access(ftpConfig);

    // مدیریت نسخه‌های بکاپ
    await manageBackupVersions(client);

    // تولید نام تصادفی برای بکاپ
    const randomName = `backup_${Date.now()}.sql`;

    // آپلود فایل
    await client.uploadFrom(filePath, `/backups/backup-bot/${randomName}`);
  } catch (error) {
    console.error("خطا در آپلود بکاپ:", error);
  } finally {
    client.close();
  }
};

// تابع برای گرفتن بکاپ و آپلود آن
const backupDatabase = async () => {
  try {
    await CreateBackUp();
    const backupFilePath = `app/backup/backup.sql`;
    await uploadToFTP(backupFilePath);
  } catch (error) {
    console.error("خطا در فرآیند بکاپ گیری:", error);
  }
};

// اجرای بکاپ
export default backupDatabase;
