import moment from "moment";
import { DeleteAlert, SelectAllAlert, UpdateAlert } from "../controllers/Alert.js";
import { Buttons } from "../bot/buttons/ButtonManager.js";
import Servise from "../bot/model/servise.js";
import { bot, i18nL } from "../bot/index.js";

const Alert = async () => {
  const accounts = await SelectAllAlert();
  const newDays = moment().add({ days: 3 }).format("YYYY-MM-DD HH:mm:ss");
  const servies = new Servise();
  accounts.map(async (item) => {
    if (item.alertDate && item.alertValue) {
      await DeleteAlert({ id: item.id });
    } else {
      const account = await servies.SelectServiseAlert({ id: item.primaryId });
      // error
      if (account == "error-get") return false;
      if (!account) return DeleteAlert({ id: item.id });
      const date = moment.unix(account.expire).format("YYYY-MM-DD HH:mm:ss");

      if (date > moment().format("YYYY-MM-DD HH:mm:ss") && account.used_traffic >= 0) {
        // alert date
        if (newDays >= date && !item.alertDate) {
          const button = new Buttons();
          bot.telegram.sendMessage(account.belongs, i18nL.t("fa", "ALERT.DATE", { id: account.id, name: account.name }), {
            parse_mode: "html",
            ...button.TamdidinlineKeyboardOne(account.id, false),
          });
          await UpdateAlert({ id: item.id }, { alertDate: true });
        }
        // alert value
        if ((account.used_traffic * 100) / account.traffic >= 85 && !item.alertValue) {
          const button = new Buttons();
          bot.telegram.sendMessage(account.belongs, i18nL.t("fa", "ALERT.VALUE", { id: account.id, name: account.name }), {
            parse_mode: "html",
            ...button.TamdidinlineKeyboardOne(account.id, false),
          });
          await UpdateAlert({ id: item.id }, { alertValue: true });
        }
      } else {
        await DeleteAlert({ id: item.id });
      }
    }
  });
};

export default Alert;
