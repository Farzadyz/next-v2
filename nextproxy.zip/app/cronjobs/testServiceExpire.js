import moment from "moment";
import { SelectAllFreeActiveSanae } from "../controllers/Servise.js";
import { SelectAllFreeActiveSanaeiNew } from "../controllers/ServiseSanaeiNew.js";
import Servise from "../bot/model/servise.js";
import { bot, i18nL } from "../bot/index.js";

// باگ قبلی: وقتی سرویس تست (رایگان) روی x-ui منقضی می‌شد، فقط یک پیام غیرفعال شدن به کاربر
// نمایش داده می‌شد (STATUS_OFF صرفا یک برچسب نمایشی بر اساس محاسبه تاریخ بود) اما هیچ‌وقت واقعا
// از طریق API پنل غیرفعال (enable:false) نمی‌شد و کانکشن همچنان روی سرور فعال باقی می‌ماند.
// این کرون هر ۱۰ دقیقه سرویس‌های تست فعال را بررسی می‌کند و در صورت اتمام زمان یا حجم،
// واقعا از طریق ChangeStatus (که برای پنل sanae مستقیما client.enable=false را در x-ui ست می‌کند)
// کانفیگ را غیرفعال می‌کند و سپس به کاربر اطلاع می‌دهد.
const TestServiceExpire = async () => {
  // sanae (<= 2.6.6) + sanaei_new (new versions)
  const actives = [...(await SelectAllFreeActiveSanae()), ...(await SelectAllFreeActiveSanaeiNew())];
  const servises = new Servise();

  for (const item of actives) {
    try {
      const account = await servises.SelectServiseAlert({ id: item.id });
      if (!account || account == "error-get") continue;

      // توجه: expire برگشتی از SelectServiseAlertSanae روی x-ui به میلی‌ثانیه است (نه یونیکس‌ثانیه)
      const expired = moment(account.expire).isBefore(moment());
      const trafficDone = account.traffic > 0 && account.used_traffic >= account.traffic;

      if (expired || trafficDone) {
        // واقعا کانفیگ را در x-ui غیرفعال می‌کنیم (status محلی هم آپدیت می‌شود)
        await servises.ChangeStatus({ id: item.id });
        bot.telegram.sendMessage(item.telegram_id, i18nL.t("fa", "TEST_SERVICE_SUSPENDED", { id: item.id }), {
          parse_mode: "html",
        });
      }
    } catch (error) {
      console.error("TestServiceExpire cron error for service", item.id, error.message);
    }
  }
};

export default TestServiceExpire;
