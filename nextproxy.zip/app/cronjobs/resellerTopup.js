import { SelectReseller } from "../controllers/Reseller.js";
import { SelectPendingResellerTopups, SelectUnnotifiedPaidTopups, UpdateResellerTopup } from "../controllers/ResellerTopup.js";
import { syncTopupStatus } from "../reseller-api/services/topupGateways.js";
import { getBalance } from "../reseller-api/services/credit.js";
import { notifyReseller } from "../bot/reseller/ResellerManager.js";

let running = false;

// Every minute: settle pending reseller top-up invoices (the main bot's gateway
// callbacks have already credited the wallet) and push a signed "credit" event
// so the reseller bot refreshes its balance and tells the owner instantly.
const ResellerTopupCron = async () => {
  if (running) return;
  running = true;
  try {
    for (const row of await SelectPendingResellerTopups()) {
      await syncTopupStatus(row);
    }
    for (const row of await SelectUnnotifiedPaidTopups()) {
      const reseller = await SelectReseller({ id: row.reseller_id });
      if (!reseller) continue;
      const delivered = await notifyReseller(reseller, "credit", {
        topup_id: row.id,
        amount: row.amount,
        balance: await getBalance(reseller),
      });
      if (delivered) await UpdateResellerTopup({ id: row.id }, { notified: true });
    }
  } catch (error) {
    console.error("[reseller-topup cron]", error?.message || error);
  } finally {
    running = false;
  }
};

export default ResellerTopupCron;
