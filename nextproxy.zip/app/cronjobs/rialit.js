import moment from "moment";
import { SelectPendingRialit, UpdateRialit } from "../controllers/Rialit.js";
import Rialit from "../pay/rialit.js";
import ProcessRialit from "../pay/rialitProcess.js";

// هر ۵ دقیقه: رکوردهای در انتظار (کاربر برگشته ولی هنوز تایید نشده) را verify می‌کند
// طبق داک ریالیت، اندپوینت verify ممکن است سر callback هنوز تایید نکند (409)
// و فقط status == 3 به‌معنای پرداخت موفق است.
const RialitVerify = async () => {
  const pendings = await SelectPendingRialit();
  if (!pendings || pendings.length < 1) return;

  const rialit = new Rialit();

  for (const item of pendings) {
    try {
      const verify = await rialit.VerifyPayment({ token: item.trans_id });

      if (verify && verify.status == 3) {
        // پرداخت موفق — پردازش نهایی (شارژ/ساخت سرویس/پورسانت)
        await ProcessRialit({ result: item, verify });
        continue;
      }

      // وضعیت نهایی ناموفق یا منقضی — دیگر verify نشود
      if (verify && (verify.status == 4 || verify.status == 5)) {
        await UpdateRialit({ id: item.id }, { closed: true });
        continue;
      }

      // در غیر این صورت (409/خطای موقت) در انتظار می‌ماند و دفعه بعد دوباره تلاش می‌شود
      // ولی اگر بیش از ۲ ساعت گذشته باشد، برای جلوگیری از تلاش بی‌پایان بسته می‌شود
      const ageMinutes = moment().diff(moment(item.createdAt), "minutes");
      if (ageMinutes > 120) {
        await UpdateRialit({ id: item.id }, { closed: true });
      }
    } catch (error) {
      console.error("RialitVerify cron error for token", item.trans_id, error.message);
    }
  }
};

export default RialitVerify;
