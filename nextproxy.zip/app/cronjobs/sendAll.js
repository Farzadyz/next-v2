import { bot, i18nL } from "../bot/index.js";
import { SelectSendall, UpdateSendall } from "../controllers/SendAll.js";
import { countUser, selectUserForAll } from "../controllers/Users.js";

const SendAll = async () => {
  const sendall = await SelectSendall();
  if (sendall.step == "none") return true;
  const alluser = await countUser();
  const users = await selectUserForAll({ limit: 100, offset: sendall?.user, type: sendall.type });
  const admins = JSON.parse(process.env.ADMIN);
  for (const user of users) {
    console.log(user.id);
  }
  if (sendall && sendall.step == "send") {
    for (const user of users) {
      try {
        await bot.telegram.sendMessage(user.id, sendall.text);
        await new Promise((r) => setTimeout(r, 50)); // کنترل فشار روی CPU و API
      } catch (error) {
        console.log(error);
      }
    }

    if (sendall.user + 100 >= alluser) {
      await UpdateSendall({ step: "none", user: 0 });
      return bot.telegram.sendMessage(JSON.parse(admins[0]), i18nL.t("fa", "PANEL.MESSAGE_ALL.SECCEFULY_SEND_ALL"));
    }
    await UpdateSendall({ user: sendall.user + 100 });
  } else if (sendall && sendall.step == "forward") {
    for (const user of users) {
      try {
        await bot.telegram.forwardMessage(user.id, sendall.chat, sendall.text);
        await new Promise((r) => setTimeout(r, 50)); // کنترل فشار روی CPU و API
      } catch (error) {
        console.log("forward all error:", user.id, error.message);
      }
    }
    if (sendall.user + 100 >= alluser) {
      await UpdateSendall({ step: "none", user: 0 });
      return bot.telegram.sendMessage(JSON.parse(admins[0]), i18nL.t("fa", "PANEL.FORWARD_ALL.SECCEFULY_FORWARD_ALL"));
    }
    await UpdateSendall({ user: sendall.user + 100 });
  }
};

export default SendAll;
