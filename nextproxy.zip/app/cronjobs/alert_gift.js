import { Buttons } from "../bot/buttons/ButtonManager.js";
import { bot, i18nL } from "../bot/index.js";
import { NumberFormat } from "../bot/utils/utils.js";
import { selectPelan } from "../controllers/Pelan.js";
import { SelectRecentPendingPeyments, UpdatePeyment } from "../controllers/Peyment.js";

const SendGiftAlert = async () => {
  try {
    const peyments = await SelectRecentPendingPeyments();
    const button = new Buttons();

    for (const pay of peyments) {
      try {
        var name = "";
        if (pay.idPlan) {
          var { name } = await selectPelan({ id: pay.idPlan });
        }
        const newPrice = Math.round(pay.price * 0.95); // ۵٪ تخفیف
        // ارسال پیام به کاربر
        await bot.telegram.sendMessage(
          pay.telegram_id, // اگر ستون user_id داری، اینجا بذار pay.user_id
          i18nL.t("fa", "ESHTERAK_BUY.ALERT_GIFT", { name, price: NumberFormat(pay.price), price_gift: NumberFormat(newPrice) }),
          {
            ...button.buyPriceGift(pay.id),
          }
        );

        // به‌روزرسانی وضعیت alert_gift
        await UpdatePeyment({ id: pay.id }, { alert_gift: true, price: newPrice });

        console.log(`✅ پیام برای کاربر ${pay.id} ارسال شد و alert_gift آپدیت شد`);
      } catch (err) {
        console.error(`❌ خطا در ارسال پیام برای ${pay.id}:`, err.message);
      }
    }
  } catch (err) {
    console.error("❌ خطا در دریافت پرداخت‌ها:", err.message);
  }
};

export default SendGiftAlert;
