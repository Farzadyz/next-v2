import Sanae from "../api/sanae.js";
import SanaeiNew from "../api/sanaei_new.js";
import { UpdateInbound, selectAllInbound } from "../controllers/Inbound.js";
import { PANEL_TYPES } from "../utils/panelTypes.js";

const timeout = (ms) => new Promise((_, reject) => setTimeout(() => reject(new Error("Request Timeout")), ms));

const Session = async () => {
  const selectAllinbound = await selectAllInbound();

  for (const item of selectAllinbound) {
    // sanaei new versions
    const apisanae = item.panel == PANEL_TYPES.SANAEI_NEW ? new SanaeiNew(item.damoin) : new Sanae(item.damoin);
    try {
      const result = await Promise.race([
        apisanae.Login(item.username, item.password),
        timeout(10000), // 10 ثانیه
      ]);

      // اگر موفق بود، به‌روزرسانی انجام شود
      if (result) {
        await UpdateInbound({ id: item.id }, { session: result });
      }
    } catch (error) {
      console.log(`Error for item ${item.id}:`, error.message);
    }
  }
};

export default Session;
