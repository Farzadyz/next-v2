import moment from "moment";
import { SelectSuspendedPaygService, DeletePaygServiceRow } from "../controllers/PaygService.js";
import { SelectSetting } from "../controllers/Setting.js";
import { selectUser } from "../controllers/Users.js";
import { SelectServise as SelectServiseRow } from "../controllers/Servise.js";
import Servise from "../bot/model/servise.js";
import { bot, i18nL } from "../bot/index.js";
import { reactivatePaygService } from "../utils/paygRecharge.js";

let running = false;

// این کرون هر ۳۰ ثانیه سرویس‌های تعلیق‌شده PAYG را بررسی می‌کند:
// - فعال‌سازی مجدد بعد از شارژ کیف پول همان لحظه‌ی شارژ توسط هوک utils/paygRecharge.js انجام می‌شود؛
//   این کرون شبکه ایمنی آن است (مثلا اگر پنل لحظه شارژ در دسترس نبود): اگر موجودی برای پیش‌پرداخت هزینه روزانه
//   (و مثبت بودن موجودی) کافی باشد، سرویس با درخواست صریح فعال‌سازی (enable=true) روی پنل و تایید آن دوباره فعال می‌شود
//   (چرخه هزینه روزانه ریست می‌شود تا هزینه روز جدید همان لحظه از قبل کسر شود)
// - اگر ۱۲ ساعت از لحظه تعلیق گذشته و هنوز شارژ نشده، سرویس برای همیشه حذف می‌شود
const PaygDelete = async () => {
  if (running) return;
  running = true;
  try {
    const suspended = await SelectSuspendedPaygService();
    if (!suspended.length) return;
    const setting = await SelectSetting();
    const servises = new Servise();
    // موجودی باقیمانده هر کاربر - چند سرویس تعلیق‌شده یک کاربر با پولی که فقط یکی را پوشش می‌دهد فعال نمی‌شوند
    const budgets = new Map();

    for (const item of suspended) {
      try {
        const user = await selectUser({ id: item.telegram_id });
        if (!user) continue;

        const localServise = await SelectServiseRow({ id: item.service_id });
        if (!localServise) {
          // سرویس اصلی دیگر وجود ندارد
          await DeletePaygServiceRow({ id: item.id });
          continue;
        }

        // شارژ شده - فعال‌سازی دوباره (فقط بعد از تایید پنل)
        const result = await reactivatePaygService({ item, servises, setting, budgets });
        if (result !== "insufficient") continue;

        // هنوز شارژ نشده - بررسی مهلت ۱۲ ساعته
        const hoursSuspended = moment().diff(moment(item.suspended_at), "hours", true);
        if (hoursSuspended >= 12) {
          await servises.DeleteServise({ id: item.service_id });
          await DeletePaygServiceRow({ id: item.id });
          bot.telegram
            .sendMessage(item.telegram_id, i18nL.t("fa", "PAYG.DELETED", { id: item.service_id }), {
              parse_mode: "html",
            })
            .catch(() => {});
        }
      } catch (error) {
        console.error("PaygDelete cron error for service", item.service_id, error.message);
      }
    }
  } catch (error) {
    console.error("PaygDelete cron error:", error.message);
  } finally {
    running = false;
  }
};

export default PaygDelete;
