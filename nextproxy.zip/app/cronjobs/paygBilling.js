import { SelectActivePaygService, SelectServisesByIds, UpdatePaygService } from "../controllers/PaygService.js";
import { CreatePaygUsageLog, SelectPaygUsageLogs } from "../controllers/PaygUsageLog.js";
import { CreatePaygCostLog } from "../controllers/PaygCostLog.js";
import { SelectSetting } from "../controllers/Setting.js";
import { selectUser } from "../controllers/Users.js";
import { DeductUserBalance, selectUsersByIds } from "../controllers/PaygWallet.js";
import { selectInbound, UpdateInbound } from "../controllers/Inbound.js";
import Servise from "../bot/model/servise.js";
import Sanae from "../api/sanae.js";
import { PANEL_TYPES } from "../utils/panelTypes.js";
import { bot, i18nL } from "../bot/index.js";

// ============================================================================================
// صورتحساب PAYG - حلقه لحظه‌ای (هر ۵ ثانیه از index.js اجرا می‌شود؛ آمار ترافیک خود x-ui هر ~۱۰ ثانیه تازه می‌شود)
//
//  ۱) هزینه ثابت روزانه: در «ابتدای هر روز سرویس» (لحظه اولین اجرا بعد از ساخت و بعد هر ۲۴ ساعت) از قبل کسر می‌شود.
//  ۲) هزینه مصرف داده: به محض اینکه x-ui مصرف جدیدی گزارش کند، دقیقاً همان مقدار از کیف پول کسر می‌شود.
//     کیف پول عدد صحیح است، پس فقط «تومان کامل» کسر می‌شود و کسر اعشاری روی بایت‌های صورتحساب‌نشده می‌ماند
//     (last_traffic_bytes فقط به اندازه بایت‌های صورتحساب‌شده جلو می‌رود) تا هیچ مصرفی گرد و گم نشود.
//  ۳) کم بودن موجودی (هنگام کسر روزانه یا مصرف): سرویس همان لحظه تعلیق می‌شود - وضعیت در دیتابیس ربات و
//     درخواست صریح غیرفعال‌سازی (enable=false) به پنل x-ui ارسال و از روی پنل بازخوانی/تایید می‌شود.
//     اگر پنل جواب ندهد، تعلیق هر ۵ ثانیه تکرار می‌شود تا واقعاً اعمال شود.
// ============================================================================================

const DAY_MS = 86400000;
const HOUR_MS = 3600000;
const BYTES_PER_GB = 1073741824;
// تا این تعداد سرویس روی یک سرور: مصرف تک‌تک (درخواست کوچک)، بیشتر از آن: یک درخواست لیست برای کل سرور
const PER_USER_LIMIT = 8;
const CONCURRENCY = 10;
const MAX_CATCHUP_DAYS = 400;
const LOGIN_COOLDOWN_MS = 60000;

let running = false;
// اسنپ‌شات ساعتی مصرف برای نمودار پنل مدیریت: payg id -> { at, cost }
const usageLogState = new Map();
// جلوگیری از لاگین مکرر روی پنل‌های قدیمی: inbound id -> زمان آخرین تلاش
const loginCooldown = new Map();

const runChunks = async (list, size, worker) => {
  for (let index = 0; index < list.length; index += size) {
    await Promise.all(list.slice(index, index + size).map(worker));
  }
};

// نرخ روزانه/مصرف مخصوص نوع پلن - wiguard = مولتی لوکیشن، بقیه = تک لوکیشن
const ratesOf = (setting, panel) => {
  const isMulti = panel === "wiguard";
  const dailyRate = Math.round(Number((isMulti ? setting.payg_daily_rate_multi : setting.payg_daily_rate_single) || 0));
  const dataRate = Number((isMulti ? setting.payg_data_rate_multi : setting.payg_data_rate_single) || 0);
  return { dailyRate, dataRate };
};

/*
@ خواندن مصرف (بایت) از پنل‌ها
*/

// sanae (<= 2.6.6)
const readLegacyUsage = async (inbound, emails) => {
  const read = async (api) => {
    const usage = new Map();
    if (emails.length <= PER_USER_LIMIT) {
      for (const email of emails) {
        const client = await api.findClinet({ email });
        if (client && typeof client === "object") usage.set(email, (Number(client.up) || 0) + (Number(client.down) || 0));
      }
      return usage.size ? usage : null;
    }
    const res = await api.getInbounds();
    if (!res || !Array.isArray(res.obj)) return null;
    for (const item of res.obj) {
      for (const client of item.clientStats || []) usage.set(client.email, (Number(client.up) || 0) + (Number(client.down) || 0));
    }
    return usage;
  };

  const usage = await read(new Sanae(inbound.damoin, inbound.session));
  if (usage) return usage;
  // نشست منقضی شده؟ (حداکثر دقیقه‌ای یک بار برای هر سرور تجدید می‌شود)
  const last = loginCooldown.get(inbound.id) || 0;
  if (Date.now() - last < LOGIN_COOLDOWN_MS) return null;
  loginCooldown.set(inbound.id, Date.now());
  try {
    const session = await new Sanae(inbound.damoin).Login(inbound.username, inbound.password);
    if (!session) return null;
    await UpdateInbound({ id: inbound.id }, { session });
    return await read(new Sanae(inbound.damoin, session));
  } catch (error) {
    return null;
  }
};

// sanaei_new (new versions) - نشست منقضی به‌صورت خودکار توسط کلاس API تجدید می‌شود
const readNewUsage = async (servises, inbound, emails) => {
  const api = servises.sanaeiNew.api(inbound);
  const usage = new Map();
  if (emails.length <= PER_USER_LIMIT) {
    for (const email of emails) {
      const traffic = await api.getClientTraffic({ email });
      if (traffic) usage.set(email, (Number(traffic.up) || 0) + (Number(traffic.down) || 0));
    }
    return usage.size ? usage : null;
  }
  const list = await api.getInbounds();
  if (!Array.isArray(list)) return null;
  for (const item of list) {
    for (const client of item.clientStats || []) usage.set(client.email, (Number(client.up) || 0) + (Number(client.down) || 0));
  }
  return usage;
};

// payg id -> مصرف کل (بایت)
const collectUsage = async (rows, servises) => {
  const result = new Map();
  const groups = new Map();
  const generic = [];

  for (const row of rows) {
    const panel = row.local.panel;
    if (panel === "sanae" || panel === PANEL_TYPES.SANAEI_NEW) {
      const key = `${panel}:${row.local.location}`;
      if (!groups.has(key)) groups.set(key, { panel, location: row.local.location, rows: [] });
      groups.get(key).rows.push(row);
    } else {
      generic.push(row);
    }
  }

  // یک سرور = یک گروه (سرورها موازی)
  await Promise.all(
    [...groups.values()].map(async (group) => {
      try {
        const inbound = await selectInbound({ id: group.location });
        if (!inbound) return;
        const emails = group.rows.map((row) => row.local.username);
        const usage =
          group.panel === PANEL_TYPES.SANAEI_NEW ? await readNewUsage(servises, inbound, emails) : await readLegacyUsage(inbound, emails);
        if (!usage) return;
        for (const row of group.rows) {
          if (usage.has(row.local.username)) result.set(row.item.id, usage.get(row.local.username));
        }
      } catch (error) {
        console.error("PaygBilling usage error for server", group.location, error.message);
      }
    })
  );

  // wiguard / marzban: تک‌تک
  await runChunks(generic, CONCURRENCY, async (row) => {
    try {
      const account = await servises.SelectServiseAlert({ id: row.item.service_id });
      if (account && account !== "error-get") result.set(row.item.id, Number(account.used_traffic) || 0);
    } catch (error) {
      console.error("PaygBilling usage error for service", row.item.service_id, error.message);
    }
  });

  return result;
};

/*
@ تعلیق
*/

// وضعیت دیتابیس + درخواست صریح غیرفعال‌سازی به پنل (تایید‌شده). در صورت شکست، با تاخیر افزایشی دوباره تلاش می‌شود
const suspendFailures = new Map(); // payg id -> { count, retryAt }

const suspend = async ({ item, servises, now }) => {
  const failure = suspendFailures.get(item.id);
  if (failure && now < failure.retryAt) return false;

  const disabled = await servises.SetStatus({ id: item.service_id, enable: false });
  if (!disabled) {
    const count = (failure?.count || 0) + 1;
    const delay = Math.min(30000 * 2 ** (count - 1), 30 * 60000); // 30s -> 30min max
    suspendFailures.set(item.id, { count, retryAt: now + delay });
    console.error("PaygBilling: panel did not confirm suspension of service", item.service_id, `(attempt ${count}, next retry in ${delay / 1000}s)`);
    return false;
  }
  suspendFailures.delete(item.id);
  await UpdatePaygService({ id: item.id }, { suspended_at: new Date(now) });
  usageLogState.delete(item.id);
  bot.telegram
    .sendMessage(item.telegram_id, i18nL.t("fa", "PAYG.SUSPENDED", { id: item.service_id }), { parse_mode: "html" })
    .catch(() => {});
  return true;
};

/*
@ اسنپ‌شات ساعتی مصرف (نمودار مدیریت)
*/

const logUsage = async (item, used, charged, now) => {
  let state = usageLogState.get(item.id);
  if (!state) {
    const logs = await SelectPaygUsageLogs({ payg_service_id: item.id, limit: 1 });
    const last = logs[logs.length - 1];
    state = { at: new Date(last ? last.createdAt : item.createdAt).getTime(), cost: 0 };
    usageLogState.set(item.id, state);
  }
  state.cost += charged;
  if (now - state.at >= HOUR_MS) {
    await CreatePaygUsageLog({ payg_service_id: item.id, used_traffic_bytes: used, cost: Math.round(state.cost) });
    state.at = now;
    state.cost = 0;
  }
};

/*
@ لاگ دقیق کسر هزینه‌ها (نمایش در پنل مدیریت) - خطا در ثبت لاگ هرگز صورتحساب را مختل نمی‌کند
*/

const logCost = async (payload) => {
  try {
    await CreatePaygCostLog(payload);
  } catch (error) {
    console.error("PaygBilling cost log error:", error.message);
  }
};

/*
@ صورتحساب یک سرویس
*/

const processService = async ({ row, used, snapshot, setting, servises, now }) => {
  const { item } = row;
  const { dailyRate, dataRate } = ratesOf(setting, row.local.panel);
  const baseAmount = Number(setting.payg_base_amount || 0);
  let balance = snapshot ? Number(snapshot.price) || 0 : null;
  let exhausted = false;
  let charged = 0;

  // ---- ۱) هزینه ثابت روزانه - از قبل و در ابتدای هر روز
  if (dailyRate > 0) {
    const dailyAt = item.daily_billed_at ? new Date(item.daily_billed_at).getTime() : null;
    const dueList = [];
    if (dailyAt === null) {
      // روز اول (یا اولین اجرا بعد از فعال‌سازی) - همین الان
      dueList.push(now);
    } else {
      let next = dailyAt + DAY_MS;
      while (next <= now && dueList.length < MAX_CATCHUP_DAYS) {
        dueList.push(next);
        next += DAY_MS;
      }
    }
    for (const at of dueList) {
      const res = await DeductUserBalance({ id: item.telegram_id, amount: dailyRate });
      balance = res.balance;
      if (res.deducted < dailyRate) {
        // موجودی برای پیش‌پرداخت روز جدید کافی نیست
        exhausted = true;
        break;
      }
      charged += res.deducted;
      // بلافاصله ثبت می‌شود تا هیچ روزی دو بار کسر نشود
      await UpdatePaygService({ id: item.id }, { daily_billed_at: new Date(at), last_billed_at: new Date(now) });
      await logCost({ payg_service_id: item.id, type: "daily", amount: res.deducted, requested: dailyRate, balance_after: res.balance });
    }
  }

  // ---- ۲) هزینه مصرف داده - لحظه‌ای
  if (!exhausted && used !== undefined) {
    const last = Number(item.last_traffic_bytes) || 0;
    const perByte = dataRate / BYTES_PER_GB;
    let newLast = last;
    if (used < last) {
      // شمارنده پنل ریست شده (تمدید / بازسازی) - مبنا دوباره تنظیم می‌شود
      newLast = used;
    } else if (used > last) {
      if (perByte > 0) {
        const whole = Math.floor((used - last) * perByte);
        if (whole >= 1) {
          const res = await DeductUserBalance({ id: item.telegram_id, amount: whole, partial: true });
          balance = res.balance;
          charged += res.deducted;
          if (res.deducted > 0) {
            await logCost({
              payg_service_id: item.id,
              type: "data",
              amount: res.deducted,
              requested: whole,
              traffic_bytes: res.deducted / perByte,
              balance_after: res.balance,
            });
          }
          if (res.deducted >= whole) {
            // فقط بایت‌های صورتحساب‌شده جلو می‌روند؛ باقی‌مانده اعشاری برای دور بعد می‌ماند
            newLast = Math.min(used, last + whole / perByte);
          } else {
            // موجودی تمام شد - مصرف بدون پوشش دیگر قابل وصول نیست
            newLast = used;
            exhausted = true;
          }
        }
      } else {
        // نرخ داده صفر است
        newLast = used;
      }
    }
    if (newLast !== last) {
      const update = { last_traffic_bytes: newLast };
      if (charged > 0) update.last_billed_at = new Date(now);
      await UpdatePaygService({ id: item.id }, update);
    }
  }

  // ---- ۳) صفر شدن موجودی (فقط وقتی سرویس واقعاً هزینه‌ای دارد)
  if (!exhausted && (dailyRate > 0 || dataRate > 0) && balance !== null && balance <= 0) {
    const fresh = await selectUser({ id: item.telegram_id });
    if (!fresh || Number(fresh.price) <= 0) exhausted = true;
    else balance = Number(fresh.price);
  }

  if (used !== undefined) await logUsage(item, used, charged, now);

  // ---- ۴) تعلیق فوری
  if (exhausted) {
    await suspend({ item, servises, now });
    return;
  }

  // ---- ۵) هشدار کمبود موجودی (فقط یک بار تا وقتی شارژ نشده)
  if (balance !== null) {
    if (balance > 0 && balance <= baseAmount * 0.2 && !item.warned) {
      bot.telegram
        .sendMessage(item.telegram_id, i18nL.t("fa", "PAYG.WARNING_LOW_BALANCE", { id: item.service_id }), { parse_mode: "html" })
        .catch(() => {});
      await UpdatePaygService({ id: item.id }, { warned: true });
    } else if (item.warned && balance > baseAmount * 0.2) {
      // موجودی دوباره کافی شد - پرچم هشدار ریست می‌شود
      await UpdatePaygService({ id: item.id }, { warned: false });
    }
  }
};

const tick = async () => {
  const actives = await SelectActivePaygService();
  if (!actives.length) {
    usageLogState.clear();
    return;
  }
  const setting = await SelectSetting();
  const servises = new Servise();

  const locals = await SelectServisesByIds([...new Set(actives.map((item) => item.service_id))]);
  const localMap = new Map(locals.map((local) => [String(local.id), local]));
  const rows = actives.map((item) => ({ item, local: localMap.get(String(item.service_id)) })).filter((row) => row.local);

  const users = await selectUsersByIds([...new Set(rows.map((row) => row.item.telegram_id))]);
  const userMap = new Map(users.map((user) => [String(user.id), user]));

  const usage = await collectUsage(rows, servises);
  const now = Date.now();

  await runChunks(rows, CONCURRENCY, async (row) => {
    try {
      await processService({
        row,
        used: usage.get(row.item.id),
        snapshot: userMap.get(String(row.item.telegram_id)),
        setting,
        servises,
        now,
      });
    } catch (error) {
      console.error("PaygBilling error for service", row.item.service_id, error.message);
    }
  });

  // پاکسازی اسنپ‌شات سرویس‌های حذف/تعلیق‌شده
  const alive = new Set(actives.map((item) => item.id));
  for (const key of usageLogState.keys()) {
    if (!alive.has(key)) usageLogState.delete(key);
  }
};

// هر اجرا فقط وقتی شروع می‌شود که اجرای قبلی تمام شده باشد (جلوگیری از کسر دوباره)
const PaygBilling = async () => {
  if (running) return;
  running = true;
  try {
    await tick();
  } catch (error) {
    console.error("PaygBilling cron error:", error.message);
  } finally {
    running = false;
  }
};

export default PaygBilling;
