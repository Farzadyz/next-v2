import moment from "moment";
import { SelectPendingAtlasPay, UpdateAtlasPay } from "../controllers/AtlasPay.js";
import AtlasPay from "../pay/atlaspay.js";
import ProcessAtlasPay from "../pay/atlaspayProcess.js";

// هر دقیقه: سفارش‌های در انتظار اطلس‌پی را استعلام می‌کند
// طبق داک اطلس‌پی، اتصال از نوع کارت‌به‌کارت داخل مینی‌اپ تلگرام است و callback مستقیم به سرور ما وجود ندارد
// بنابراین Polling روی GET /orders/{id} تنها راه اتصاله (دقیقا طبق نمونه‌ی پیاده‌سازی رسمی)
const AtlasPayVerify = async () => {
  const pendings = await SelectPendingAtlasPay();
  if (!pendings || pendings.length < 1) return;

  const atlaspay = new AtlasPay();
  const successStatuses = ["confirmed", "settled"];
  const deadStatuses = ["rejected", "expired", "cancelled"];

  for (const item of pendings) {
    try {
      const verify = await atlaspay.VerifyPayment({ orderId: item.order_id });
      if (!verify) continue;

      if (successStatuses.includes(verify.status)) {
        // پرداخت موفق - پردازش نهایی (شارژ/ساخت سرویس/پورسانت)
        await ProcessAtlasPay({ result: item, verify });
        continue;
      }

      if (deadStatuses.includes(verify.status)) {
        await UpdateAtlasPay({ id: item.id }, { closed: true });
        continue;
      }

      // در غیر این صورت هنوز در انتظار واریزه - مهلت پرداخت طبق داک ۲۰ دقیقه‌ست
      const ageMinutes = moment().diff(moment(item.createdAt), "minutes");
      if (ageMinutes > 25) {
        await UpdateAtlasPay({ id: item.id }, { closed: true });
      }
    } catch (error) {
      console.error("AtlasPayVerify cron error for order", item.order_id, error.message);
    }
  }
};

export default AtlasPayVerify;
