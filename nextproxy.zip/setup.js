import { CreateSendall } from "./app/controllers/SendAll.js";
import { CreateSetting } from "./app/controllers/Setting.js";
import Sendall from "./app/model/sendAll.js";
import Setting from "./app/model/setting.js";

const Create = async () => {
  const SetupDB = async () => {
    await Sendall.sync({ force: true }).catch();
    await Setting.sync({ force: true }).catch();
  };

  const Setup = async () => {
    await CreateSetting();
    await CreateSendall();
  };
  console.log("instaling ...");
  await SetupDB();
  await Setup();
  console.log("install sauccfuly!");
};
Create();
