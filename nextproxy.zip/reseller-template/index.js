import cfg from "./app/config.js";
import { initDb } from "./app/models.js";
import { loadTexts } from "./app/texts.js";
import buildBot from "./app/bot/index.js";
import startServer from "./app/server.js";
import { setBot, retryPending } from "./app/fulfillment.js";
import { Api } from "./app/mainApi.js";
import { Payment } from "./app/models.js";
import { verifyPayment } from "./app/gateways.js";
import { settlePayment } from "./app/fulfillment.js";

// ============================================================================
// Isolated reseller bot instance: own code, own SQLite database, own process.
// The only link to the main bot is the Intermediary REST API (app/mainApi.js).
// ============================================================================

const main = async () => {
  await initDb();
  await loadTexts();

  const bot = buildBot();
  setBot(bot);
  startServer();

  // safety net next to the instant hook: refresh the main-bot snapshot regularly
  setInterval(() => Api.getBootstrap({ force: true }).catch(() => {}), 60 * 1000);
  // deliver paid orders that are still waiting (low credit / temporary API error)
  setInterval(() => retryPending().catch((error) => console.error("[retry]", error?.message || error)), 60 * 1000);
  // re-verify recent online payments whose callback never arrived
  setInterval(async () => {
    const since = new Date(Date.now() - 2 * 60 * 60 * 1000);
    const pending = await Payment.findAll({ where: { status: "pending" } });
    for (const payment of pending) {
      if (new Date(payment.createdAt) < since) continue;
      if (await verifyPayment(payment, {})) await settlePayment(payment.id);
    }
  }, 2 * 60 * 1000);

  await bot.launch();
};

main().catch((error) => {
  console.error(error);
  process.exit(1);
});

const shutdown = () => process.exit(0);
process.once("SIGINT", shutdown);
process.once("SIGTERM", shutdown);
