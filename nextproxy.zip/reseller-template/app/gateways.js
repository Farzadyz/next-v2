import axios from "axios";
import crypto from "crypto";
import cfg from "./config.js";
import { Gateway, Payment } from "./models.js";
import { parseJson } from "./util.js";

// ============================================================================
// The reseller's OWN payment gateways. Merchant codes / API keys are entered
// in this bot's local admin panel and stored only in this instance's database:
// customers pay the reseller directly, the main bot never sees this money.
// ============================================================================

const callback = (name) => `${cfg.publicUrl}/pay/${name}`;
const rial = (toman) => Math.round(toman) * 10;

const ADAPTERS = {
  ZARINPAL: {
    label: "⭐️ زرین پال",
    fields: [{ key: "merchant", label: "مرچنت کد (Merchant ID)" }],
    callbackRef: (q) => q.Authority,
    callbackOk: (q) => q.Status === "OK",
    request: async ({ amount, config, order }) => {
      const { data } = await axios.post("https://payment.zarinpal.com/pg/v4/payment/request.json", {
        merchant_id: config.merchant,
        amount: rial(amount),
        callback_url: callback("zarinpal"),
        description: `Order #${order.id}`,
      });
      const authority = data?.data?.authority;
      if (data?.data?.code !== 100 || !authority) return null;
      return { ref: authority, url: `https://payment.zarinpal.com/pg/StartPay/${authority}` };
    },
    verify: async ({ payment, config }) => {
      const { data } = await axios.post("https://payment.zarinpal.com/pg/v4/payment/verify.json", {
        merchant_id: config.merchant,
        amount: rial(payment.amount),
        authority: payment.ref,
      });
      return [100, 101].includes(data?.data?.code);
    },
  },
  ZIBAL: {
    label: "🧩 زیبال",
    fields: [{ key: "merchant", label: "مرچنت کد (Merchant)" }],
    callbackRef: (q) => q.trackId,
    callbackOk: (q) => String(q.success) === "1",
    request: async ({ amount, config, order }) => {
      const { data } = await axios.post("https://gateway.zibal.ir/v1/request", {
        merchant: config.merchant,
        amount: rial(amount),
        callbackUrl: callback("zibal"),
        orderId: String(order.id),
      });
      if (data?.result !== 100) return null;
      return { ref: String(data.trackId), url: `https://gateway.zibal.ir/start/${data.trackId}` };
    },
    verify: async ({ payment, config }) => {
      const { data } = await axios.post("https://gateway.zibal.ir/v1/verify", { merchant: config.merchant, trackId: payment.ref });
      return [100, 201].includes(data?.result);
    },
  },
  PAYSTAR: {
    label: "💰 مستقیم (پی‌استار)",
    fields: [
      { key: "gateway_id", label: "شناسه درگاه (Gateway ID)" },
      { key: "sign_key", label: "کلید امضا (Sign Key)" },
    ],
    callbackRef: (q) => q.ref_num,
    callbackOk: (q) => Boolean(q.tracking_code && q.card_number),
    request: async ({ amount, config, order }) => {
      const value = String(rial(amount));
      const orderId = `${order.id}${Date.now() % 100000}`;
      const url = callback("paystar");
      const sign = crypto.createHmac("sha512", config.sign_key).update(`${value}#${orderId}#${url}`).digest("hex");
      const { data } = await axios.post(
        "https://core.paystar.ir/api/pardakht/create",
        { amount: value, order_id: orderId, callback: url, sign, callback_method: 1 },
        { headers: { Authorization: `Bearer ${config.gateway_id}` } }
      );
      if (data?.status !== 1) return null;
      return { ref: data.data.ref_num, url: `https://core.paystar.ir/api/pardakht/payment?token=${data.data.token}` };
    },
    verify: async ({ payment, config, query }) => {
      const value = String(rial(payment.amount));
      const sign = crypto
        .createHmac("sha512", config.sign_key)
        .update(`${value}#${payment.ref}#${query.card_number}#${query.tracking_code}`)
        .digest("hex");
      const { data } = await axios.post(
        "https://core.paystar.ir/api/pardakht/verify",
        { amount: value, ref_num: payment.ref, sign },
        { headers: { Authorization: `Bearer ${config.gateway_id}` } }
      );
      return data?.status === 1;
    },
  },
  // manual: customer sends a receipt photo, the reseller approves it in the bot
  CARD: {
    label: "💳 کارت به کارت",
    fields: [
      { key: "card_number", label: "شماره کارت" },
      { key: "card_owner", label: "نام صاحب کارت" },
    ],
    manual: true,
    request: async () => ({ ref: "card-" + crypto.randomBytes(6).toString("hex"), url: null }),
  },
};

const getConfig = async (key) => {
  const row = await Gateway.findByPk(key);
  return { enabled: Boolean(row?.enabled), config: parseJson(row?.config, {}) };
};

const saveConfig = async (key, patch) => {
  const current = await getConfig(key);
  await Gateway.upsert({ key, enabled: patch.enabled ?? current.enabled, config: JSON.stringify({ ...current.config, ...(patch.config || {}) }) });
};

const isConfigured = (key, config) => ADAPTERS[key].fields.every((field) => Boolean(config[field.key]));

// gateways the customer may actually use: permitted by the main admin's matrix,
// switched on by the reseller and completely configured.
// allow_gateway_pay = online gateways as a group (card-to-card is a separate switch: allow_pay_CARD)
const availableGateways = async (permissions) => {
  const result = [];
  for (const [key, adapter] of Object.entries(ADAPTERS)) {
    if (!permissions[`allow_pay_${key}`]) continue;
    if (!adapter.manual && permissions.allow_gateway_pay === false) continue;
    const { enabled, config } = await getConfig(key);
    if (enabled && isConfigured(key, config)) result.push({ key, label: adapter.label, manual: Boolean(adapter.manual) });
  }
  return result;
};

const startPayment = async (order, key) => {
  const adapter = ADAPTERS[key];
  const { config } = await getConfig(key);
  if (!adapter || !isConfigured(key, config)) return null;
  let created;
  try {
    created = await adapter.request({ amount: order.amount, config, order });
  } catch (error) {
    console.error(`[gateway ${key}]`, error?.message || error);
    return null;
  }
  if (!created) return null;
  const payment = await Payment.create({ order_id: order.id, gateway: key, ref: created.ref, amount: order.amount });
  return { payment, url: created.url, manual: Boolean(adapter.manual), config };
};

// verifies one payment with the gateway (callback or periodic re-check)
const verifyPayment = async (payment, query = {}) => {
  const adapter = ADAPTERS[payment.gateway];
  if (!adapter || adapter.manual) return false;
  const { config } = await getConfig(payment.gateway);
  try {
    return await adapter.verify({ payment, config, query });
  } catch (error) {
    return false;
  }
};

export { ADAPTERS, getConfig, saveConfig, isConfigured, availableGateways, startPayment, verifyPayment };
