import { Setting } from "./models.js";

// Same wording as the main bot, editable by the reseller from the local panel.
const MENU = {
  BUY: "🛒 خرید اشتراک",
  MY: "💎 اشتراک های من",
  ACCOUNT: "👤 اطلاعات حساب",
  PRICE: "💰 لیست قیمت‌ها",
  SUPPORT: "👥 پشتیبانی",
  AGENT: "🔑 دریافت نمایندگی",
  FAQ: "❓ سوالات متداول",
  BACK: "🔙 بازگشت",
};

const DEFAULTS = {
  WELCOME: "✋ سلام ${name} عزیز به ربات ${bot} خوش اومدی.\n\nبرای شروع از منوی زیر استفاده کنید.",
  SUPPORT_ASK: "✍️ لطفا پیام خود را برای پشتیبانی ارسال کنید:",
  SUPPORT_SENT: "✅ پیام شما برای پشتیبانی ارسال شد.",
  AGENT: "🔑 برای دریافت نمایندگی با پشتیبانی در ارتباط باشید.",
  FAQ: "❓ سوالات متداول هنوز توسط مدیریت تنظیم نشده است.",
  DISABLED: "⛔️ این ربات در حال حاضر غیرفعال است.",
  RESTRICTED: "⛔️ این امکان در دسترس نیست.",
  UNAVAILABLE: "⚠️ سرویس‌دهی موقتا در دسترس نیست، لطفا کمی بعد دوباره تلاش کنید.",
};

const overrides = new Map();

const loadTexts = async () => {
  for (const row of await Setting.findAll()) if (row.key.startsWith("text:")) overrides.set(row.key.slice(5), row.value);
};

// an empty value restores the built-in default text
const setText = async (key, value) => {
  if (!value) {
    await Setting.destroy({ where: { key: "text:" + key } });
    overrides.delete(key);
    return;
  }
  await Setting.upsert({ key: "text:" + key, value });
  overrides.set(key, value);
};

const t = (key, vars = {}) => {
  const template = overrides.get(key) ?? DEFAULTS[key] ?? key;
  return template.replace(/\$\{(\w+)\}/g, (_, name) => vars[name] ?? "");
};

const EDITABLE_TEXTS = [
  { key: "WELCOME", label: "پیام خوش‌آمدگویی (/start)" },
  { key: "SUPPORT_ASK", label: "متن درخواست پیام پشتیبانی" },
  { key: "AGENT", label: "متن دریافت نمایندگی" },
  { key: "FAQ", label: "متن سوالات متداول" },
];

export { MENU, DEFAULTS, loadTexts, setText, t, EDITABLE_TEXTS };
