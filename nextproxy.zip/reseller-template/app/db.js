import fs from "fs";
import path from "path";
import { Sequelize } from "sequelize";
import cfg from "./config.js";

// This instance's OWN database: a private SQLite file inside its own folder.
fs.mkdirSync(path.dirname(cfg.dbFile), { recursive: true });
const sequelize = new Sequelize({ dialect: "sqlite", storage: cfg.dbFile, logging: false });

export default sequelize;
