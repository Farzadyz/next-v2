import crypto from "crypto";

// ============================================================================
// Permission helpers. The main admin controls two matrices from the main bot:
//   boot.permissions        customer-facing features   (allow_*)
//   boot.admin_permissions  this bot's admin panel      (admin_*, admin_panel_access = master key)
// Both arrive live with every snapshot from the main bot (Intermediary API).
// ============================================================================

// main bots that still send only the old coarse switches: admin key -> old key
const LEGACY_PANEL_KEY = {
  admin_recharge: "allow_panel_recharge",
  admin_pricing: "allow_panel_pricing",
  admin_gateways: "allow_panel_gateways",
  admin_show_pay: "allow_panel_gateways",
  admin_id_card: "allow_panel_gateways",
  admin_gift_add: "allow_panel_gifts",
  admin_gift_delete: "allow_panel_gifts",
  admin_message_all: "allow_panel_broadcast",
  admin_forward_all: "allow_panel_broadcast",
  admin_manage_texts: "allow_panel_texts",
  admin_stats: "allow_panel_stats",
  admin_list_panel: null, // was always visible
};

// customer feature switch
const can = (boot, key) => Boolean(boot?.permissions?.[key]);

// is the admin panel open at all (master key)?
const panelOpen = (boot) => {
  const admin = boot?.admin_permissions;
  return admin && typeof admin === "object" ? admin.admin_panel_access !== false : true;
};

// admin panel switch - true only when the panel is open AND the key is allowed
const adminCan = (boot, key) => {
  if (!boot || !panelOpen(boot)) return false;
  const admin = boot.admin_permissions;
  if (admin && typeof admin === "object") return admin[key] === true;
  if (!(key in LEGACY_PANEL_KEY)) return false;
  const legacy = LEGACY_PANEL_KEY[key];
  return legacy === null ? true : Boolean(boot.permissions?.[legacy]);
};

// any of several admin keys
const adminCanAny = (boot, keys) => (Array.isArray(keys) ? keys : [keys]).some((key) => adminCan(boot, key));

// fingerprint of everything that changes the menus/buttons a chat should see
const permSignature = (boot) =>
  crypto
    .createHash("sha1")
    .update(JSON.stringify([boot?.reseller?.status, boot?.permissions, boot?.admin_permissions]))
    .digest("hex")
    .slice(0, 10);

// remembers which reply keyboard a chat currently has ("main" | "panel") so it can be refreshed
const markKeyboard = (ctx, kind) => {
  ctx.session.kb = kind;
  ctx.state.kbSent = true;
};

export { can, panelOpen, adminCan, adminCanAny, permSignature, markKeyboard };
