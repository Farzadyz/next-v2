import crypto from "crypto";
import express from "express";
import cfg from "./config.js";
import { Api } from "./mainApi.js";
import { Payment } from "./models.js";
import { verifyPayment, ADAPTERS } from "./gateways.js";
import { settlePayment, notifyOwner, retryPending } from "./fulfillment.js";
import { NumberFormat } from "./util.js";

// Local HTTP server (127.0.0.1 only):
//   POST /internal/sync  signed push from the main bot (instant refresh / credit)
//   GET  /pay/<gateway>  callback of this reseller's own payment gateways
// The main web server only passes the public /r/<id>/pay/* callbacks through.

const page = (ok, message) =>
  `<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:Tahoma,sans-serif;text-align:center;padding:48px"><h2>${
    ok ? "✅" : "❌"
  } ${message}</h2><p>می‌توانید به ربات تلگرام بازگردید.</p></body></html>`;

const startServer = () => {
  const app = express();
  app.use(express.json({ verify: (req, res, buffer) => (req.rawBody = buffer) }));

  app.post("/internal/sync", async (req, res) => {
    const signature = String(req.headers["x-signature"] || "");
    const expected = crypto.createHmac("sha256", cfg.hookSecret).update(req.rawBody || "").digest("hex");
    const valid = signature.length === expected.length && crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
    if (!valid || Math.abs(Date.now() - Number(req.body?.ts)) > 5 * 60 * 1000) return res.status(401).json({ ok: false });

    // servers / plans / permissions / credit changed on the main bot -> refetch now
    Api.invalidate();
    Api.getBootstrap({ force: true }).catch(() => {});
    if (req.body.event === "credit") {
      const { amount, balance } = req.body.payload || {};
      notifyOwner(`✅ اعتبار شما نزد ربات اصلی ${NumberFormat(amount)} تومان شارژ شد.\n💳 موجودی فعلی: ${NumberFormat(balance)} تومان`);
      retryPending().catch(() => {});
    }
    return res.json({ ok: true });
  });

  app.get("/pay/:gateway", async (req, res) => {
    const key = String(req.params.gateway).toUpperCase();
    const adapter = ADAPTERS[key];
    if (!adapter || adapter.manual) return res.status(404).send(page(false, "درگاه نامعتبر است"));
    const ref = adapter.callbackRef(req.query);
    if (!ref || !adapter.callbackOk(req.query)) return res.status(400).send(page(false, "پرداخت ناموفق بود"));
    const payment = await Payment.findOne({ where: { gateway: key, ref: String(ref), status: "pending" } });
    if (!payment) return res.status(404).send(page(false, "تراکنش یافت نشد یا قبلا پردازش شده است"));
    if (!(await verifyPayment(payment, req.query))) return res.status(402).send(page(false, "پرداخت تایید نشد"));
    await settlePayment(payment.id);
    return res.send(page(true, "پرداخت با موفقیت انجام شد"));
  });

  app.get("/health", (req, res) => res.json({ ok: true }));
  app.listen(cfg.port, "127.0.0.1", () => console.log(`[reseller ${cfg.resellerId}] local server on ${cfg.port}`));
};

export default startServer;
