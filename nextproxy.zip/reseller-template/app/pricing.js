import { Price, getSetting } from "./models.js";

// Prices are the RESELLER's business: the main bot only ever sees its own
// cost. Customer price = reseller's per-plan price, or cost + default margin.

const roundUp = (value) => Math.ceil(value / 500) * 500;

const margin = async () => Number((await getSetting("margin_percent", "30")) || 0);

const withMargin = async (cost) => roundUp(cost * (1 + (await margin()) / 100));

const serverExtra = (boot, serverId) => Number(boot.servers.find((server) => server.id === Number(serverId))?.extra_price || 0);

// what the main bot charges this reseller (credit) for an order
const mainCost = (boot, order) => {
  const extra = order.server_id ? serverExtra(boot, order.server_id) : 0;
  // a renewal is priced like the original purchase (plan or custom)
  const kind = order.kind === "renew" ? (order.plan_id ? "plan" : "custom") : order.kind;
  switch (kind) {
    case "plan": {
      const plan = boot.plans.find((item) => item.id === Number(order.plan_id));
      return plan ? plan.price + (plan.panel === "sanae" ? extra : 0) : 0;
    }
    case "custom":
      return Math.round(order.days * boot.custom.price_per_day + order.traffic * boot.custom.price_per_gb) + extra;
    case "payg":
      return boot.payg.base_amount;
    default:
      return 0;
  }
};

// what the customer pays the reseller for an order
const sellPrice = async (boot, order) => {
  if (order.kind === "free") return 0;
  if (order.kind === "plan" || (order.kind === "renew" && order.plan_id)) {
    const own = await Price.findByPk(Number(order.plan_id));
    const extra = order.server_id ? serverExtra(boot, order.server_id) : 0;
    if (own) return own.price + extra;
  }
  return withMargin(mainCost(boot, order));
};

const applyGift = (amount, gift) => Math.max(0, roundUp(amount - (amount * gift.percent) / 100));

export { mainCost, sellPrice, applyGift, withMargin };
