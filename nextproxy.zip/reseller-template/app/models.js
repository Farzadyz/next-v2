import { BIGINT, BOOLEAN, DOUBLE, INTEGER, STRING, TEXT } from "sequelize";
import sequelize from "./db.js";

// ---- key/value settings (margin, card number, welcome text, faq ...) ----
const Setting = sequelize.define("setting", { key: { type: STRING(64), primaryKey: true }, value: { type: TEXT } }, { timestamps: false });

const Customer = sequelize.define("customer", {
  id: { type: BIGINT, primaryKey: true },
  username: { type: STRING(255) },
  blocked: { type: BOOLEAN, defaultValue: false },
});

// reseller's own selling price per main-bot plan id
const Price = sequelize.define("price", { plan_id: { type: INTEGER, primaryKey: true }, price: { type: INTEGER, allowNull: false } }, { timestamps: false });

// reseller's OWN payment gateways (own merchant codes / api keys)
const Gateway = sequelize.define("gateway", {
  key: { type: STRING(32), primaryKey: true },
  enabled: { type: BOOLEAN, defaultValue: false },
  config: { type: TEXT, defaultValue: "{}" },
}, { timestamps: false });

// what a customer wants to buy / renew; amount = what the customer pays the reseller
const Order = sequelize.define("order", {
  id: { type: INTEGER, autoIncrement: true, primaryKey: true },
  request_id: { type: STRING(64), allowNull: false, unique: true },
  customer_id: { type: BIGINT, allowNull: false },
  // plan | custom | payg | free | renew
  kind: { type: STRING(16), allowNull: false },
  plan_id: { type: INTEGER },
  server_id: { type: INTEGER },
  connection: { type: STRING(16) },
  traffic: { type: DOUBLE },
  days: { type: INTEGER },
  service_id: { type: INTEGER },
  amount: { type: INTEGER, defaultValue: 0 },
  gift_code: { type: STRING(64) },
  // new | paid | fulfilled | failed
  status: { type: STRING(16), defaultValue: "new" },
  attempts: { type: INTEGER, defaultValue: 0 },
  error: { type: STRING(255) },
  owner_warned: { type: BOOLEAN, defaultValue: false },
});

// a customer -> reseller payment made through one of the reseller's gateways
const Payment = sequelize.define("payment", {
  id: { type: INTEGER, autoIncrement: true, primaryKey: true },
  order_id: { type: INTEGER, allowNull: false },
  gateway: { type: STRING(32), allowNull: false },
  ref: { type: STRING(255), allowNull: false },
  amount: { type: INTEGER, allowNull: false },
  // pending | paid | rejected
  status: { type: STRING(16), defaultValue: "pending" },
});

const Gift = sequelize.define("gift", {
  code: { type: STRING(64), primaryKey: true },
  percent: { type: INTEGER, allowNull: false },
  limit: { type: INTEGER, defaultValue: 1 },
  used: { type: TEXT, defaultValue: "[]" },
}, { timestamps: false });

// configs sold to a customer (only ids - all real data stays on the main bot)
const ServiceRef = sequelize.define("service_ref", {
  service_id: { type: INTEGER, primaryKey: true },
  customer_id: { type: BIGINT, allowNull: false },
  name: { type: STRING(255) },
  kind: { type: STRING(16) },
  plan_id: { type: INTEGER },
  traffic: { type: DOUBLE },
  days: { type: INTEGER },
  server_id: { type: INTEGER },
});

const Session = sequelize.define("session", { key: { type: STRING(64), primaryKey: true }, value: { type: TEXT } }, { timestamps: false });

const initDb = () => sequelize.sync();

// ---- setting helpers (tiny in-memory cache, DB is the source of truth) ----
const cache = new Map();
const getSetting = async (key, fallback = null) => {
  if (!cache.has(key)) cache.set(key, (await Setting.findByPk(key))?.value ?? null);
  return cache.get(key) ?? fallback;
};
const setSetting = async (key, value) => {
  await Setting.upsert({ key, value: String(value) });
  cache.set(key, String(value));
};

export { sequelize, Setting, Customer, Price, Gateway, Order, Payment, Gift, ServiceRef, Session, initDb, getSetting, setSetting };
