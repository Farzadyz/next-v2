import dotenv from "dotenv";
import path from "path";
dotenv.config();

const need = (name) => {
  const value = process.env[name];
  if (!value) {
    console.error(`Missing ${name} in .env`);
    process.exit(1);
  }
  return value;
};

// Everything this instance knows about the outside world. There is deliberately
// no database credential for the main bot here - only the REST API key.
const cfg = {
  token: need("BOT_TOKEN"),
  resellerId: Number(need("RESELLER_ID")),
  ownerId: Number(need("OWNER_ID")),
  apiUrl: need("MAIN_API_URL").replace(/\/$/, ""),
  apiKey: need("MAIN_API_KEY"),
  hookSecret: need("HOOK_SECRET"),
  port: Number(process.env.PORT || 4100),
  publicUrl: (process.env.PUBLIC_URL || "").replace(/\/$/, ""),
  dbFile: path.resolve(process.env.DB_FILE || "./data/reseller.sqlite"),
};

export default cfg;
