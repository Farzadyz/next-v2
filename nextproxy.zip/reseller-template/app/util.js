const NumberFormat = (number) => new Intl.NumberFormat("en-US").format(Math.round(Number(number) || 0));

const esc = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const chunk = (array, size) => Array.from({ length: Math.ceil(array.length / size) }, (_, i) => array.slice(i * size, i * size + size));

const random = (length = 16) => {
  const charset = "abcdefghijklmnopqrstuvwxyz0123456789";
  let value = "";
  for (let i = 0; i < length; i++) value += charset[Math.floor(Math.random() * charset.length)];
  return value;
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const parseJson = (raw, fallback) => {
  try {
    return JSON.parse(raw) ?? fallback;
  } catch (error) {
    return fallback;
  }
};

export { NumberFormat, esc, chunk, random, sleep, parseJson };
