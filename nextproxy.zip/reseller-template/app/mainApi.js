import axios from "axios";
import cfg from "./config.js";

// ============================================================================
// Client of the main bot's Intermediary REST API - the ONLY channel to the main
// bot. Servers, plans, prices, permissions and the credit balance are never
// stored locally: they are fetched here (short cache + instant invalidation
// through the signed /internal/sync hook).
// ============================================================================

const http = axios.create({
  baseURL: `${cfg.apiUrl}/reseller-api/v1`,
  timeout: 20000,
  headers: { Authorization: `Bearer ${cfg.apiKey}`, "X-Reseller-Id": String(cfg.resellerId) },
});

class MainApiError extends Error {
  constructor(code, message, details = {}, status = 0) {
    super(message);
    this.code = code;
    this.details = details;
    this.status = status;
  }
}

const call = async (method, url, data) => {
  try {
    const response = await http.request({ method, url, data: method === "get" ? undefined : data, params: method === "get" ? data : undefined });
    return response.data.data;
  } catch (error) {
    const body = error.response?.data?.error;
    throw new MainApiError(body?.code || "unreachable", body?.message || error.message, body || {}, error.response?.status || 0);
  }
};

const TTL_MS = 8000;
let snapshot = null;
let fetchedAt = 0;
let pending = null;

// full catalog: reseller status, credit, permissions, servers, plans, pricing rules
const getBootstrap = async ({ force = false } = {}) => {
  if (!force && snapshot && Date.now() - fetchedAt < TTL_MS) return snapshot;
  if (!pending) {
    pending = call("get", "/bootstrap")
      .then((data) => {
        snapshot = data;
        fetchedAt = Date.now();
        return data;
      })
      .finally(() => {
        pending = null;
      });
  }
  try {
    return await pending;
  } catch (error) {
    if (snapshot) return snapshot; // main bot briefly unreachable -> last known state
    throw error;
  }
};

// called by the signed hook the moment the main bot changes anything
const invalidate = () => {
  fetchedAt = 0;
};

const Api = {
  getBootstrap,
  invalidate,
  balance: () => call("get", "/credit"),
  createTopup: (amount, gateway) => call("post", "/credit/topups", { amount, gateway }),
  listTopups: () => call("get", "/credit/topups"),
  getTopup: (id) => call("get", `/credit/topups/${id}`),
  stats: () => call("get", "/stats"),
  createService: (body) => call("post", "/services", body),
  serviceInfo: (id, customerId) => call("get", `/services/${id}`, { customer_id: customerId }),
  renew: (id, body) => call("post", `/services/${id}/renew`, body),
  toggleStatus: (id, customerId) => call("post", `/services/${id}/status`, { customer_id: customerId }),
  revoke: (id, customerId) => call("post", `/services/${id}/revoke`, { customer_id: customerId }),
  remove: (id, customerId) => call("delete", `/services/${id}`, { customer_id: customerId }),
};

export { Api, MainApiError };
