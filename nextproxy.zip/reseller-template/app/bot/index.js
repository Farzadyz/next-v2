import { Telegraf, session } from "telegraf";
import cfg from "../config.js";
import { Api } from "../mainApi.js";
import { Customer, Session } from "../models.js";
import { t } from "../texts.js";
import { parseJson } from "../util.js";
import { registerCustomer, handleCustomerText, mainMenu } from "./customer.js";
import { registerAdmin, handleAdminText, panelKeyboard } from "./admin.js";
import { permSignature, panelOpen, markKeyboard } from "../access.js";

// sessions live in this instance's own database
const store = {
  get: async (key) => parseJson((await Session.findByPk(key))?.value, undefined),
  set: async (key, value) => {
    await Session.upsert({ key, value: JSON.stringify(value) });
  },
  delete: async (key) => {
    await Session.destroy({ where: { key } });
  },
};

const buildBot = () => {
  const bot = new Telegraf(cfg.token);
  bot.catch((error, ctx) => console.error(`[bot] ${ctx.updateType}:`, error));

  bot.use(session({ store, defaultSession: () => ({}) }));

  // per-update context: customer row + the LIVE snapshot fetched from the main bot
  bot.use(async (ctx, next) => {
    if (!ctx.from || ctx.chat?.type !== "private") return;
    const [customer] = await Customer.findOrCreate({ where: { id: ctx.from.id }, defaults: { username: ctx.from.username || null } });
    if (customer.blocked && ctx.from.id !== cfg.ownerId) return;
    try {
      ctx.state.boot = await Api.getBootstrap();
    } catch (error) {
      ctx.state.boot = null;
    }
    const boot = ctx.state.boot;
    const signature = boot ? permSignature(boot) : null;
    const seen = ctx.session.permSig;
    await next();
    if (!signature) return;
    ctx.session.permSig = signature;
    // the main admin changed this bot's permissions since this chat last saw its keyboard:
    // reply keyboards can only be replaced by sending a message, so refresh it on the next interaction
    if (seen && seen !== signature && ctx.message?.text && !ctx.state.kbSent) {
      const isOwner = ctx.from.id === cfg.ownerId;
      const inPanel = isOwner && ctx.session.kb === "panel" && panelOpen(boot);
      markKeyboard(ctx, inPanel ? "panel" : "main");
      await ctx.reply("🔄 منوی ربات به‌روزرسانی شد.", inPanel ? panelKeyboard(boot) : mainMenu(boot, isOwner)).catch(() => {});
    }
  });

  // registered first: menu buttons / commands always win over a pending text state
  registerAdmin(bot);
  registerCustomer(bot);

  bot.on("text", async (ctx) => {
    const state = ctx.session.state;
    if (!state) return ctx.state.boot?.reseller.status === "active" ? undefined : ctx.reply(t("DISABLED"));
    return state.startsWith("adm:") ? handleAdminText(ctx) : handleCustomerText(ctx);
  });

  return bot;
};

export default buildBot;
