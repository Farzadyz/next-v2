import { Markup } from "telegraf";
import cfg from "../config.js";
import { Api } from "../mainApi.js";
import { Customer, Order, Payment, Price, Gift, ServiceRef, getSetting, setSetting } from "../models.js";
import { mainMenu } from "./customer.js";
import { setText, EDITABLE_TEXTS, DEFAULTS } from "../texts.js";
import { NumberFormat, esc, chunk, sleep, parseJson } from "../util.js";
import { mainCost, sellPrice } from "../pricing.js";
import { ADAPTERS, getConfig, saveConfig, isConfigured } from "../gateways.js";
import { settlePayment, send, infoText } from "../fulfillment.js";
import { adminCan, adminCanAny, panelOpen, markKeyboard } from "../access.js";

// ============================================================================
// The reseller's LOCAL admin panel (/panel). Everything here edits this
// instance's own database - except the credit balance / recharge section,
// which talks to the main bot through the REST API.
//
// Every section, button and text action is gated by the "Reseller Admin
// Permissions" matrix (boot.admin_permissions) that the main admin controls
// from the main bot - it is re-read live on every interaction, so a change on
// the main bot takes effect immediately (admin_panel_access = master key).
// ============================================================================

// customer-side switches this bot acts on (shown read-only to the reseller)
const PERM_LABELS = {
  allow_buy_service: "🛒 خرید اشتراک",
  allow_choose_plan: "○ پلن انتخابی (پلن‌های آماده)",
  allow_multi_location: "🌍 پلن مولتی لوکیشن",
  allow_single_location: "📍 پلن تک لوکیشن",
  allow_economic_plan: "💰 پلن اقتصادی",
  allow_custom_plan: "🎛 پلن سفارشی",
  allow_select_custom_plan: "▫️ پلن انتخابی، سفارشی",
  allow_server_choice: "🖥 انتخاب لوکیشن",
  allow_payg_multi: "⚡️ PAYG مولتی",
  allow_payg_single: "⚡️ PAYG تک",
  allow_gateway_pay: "💰 پرداخت با درگاه آنلاین",
  allow_test_service: "🎁 سرویس تست",
  allow_gift: "🎟 کد تخفیف",
  allow_renew: "♻️ تمدید",
  allow_my_service: "💎 اشتراک های من",
  allow_account: "👤 اطلاعات حساب",
  allow_support: "👥 پشتیبانی",
  allow_price_list: "💰 لیست قیمت",
  allow_get_agent: "🔑 دریافت نمایندگی",
  allow_question: "❓ سوالات متداول",
  allow_action_qr: "🔖 QR Code",
  allow_action_refresh: "📊 بروزرسانی",
  allow_action_revoke: "🔐 تغییر لینک",
  allow_action_status: "🔌 اتصال موقت",
  allow_action_delete: "❌ حذف سرویس",
  allow_pay_PAYSTAR: "💰 پی‌استار",
  allow_pay_CARD: "💳 کارت به کارت",
  allow_pay_ZARINPAL: "⭐️ زرین پال",
  allow_pay_ZIBAL: "🧩 زیبال",
};

// admin-panel switches this bot acts on
const ADMIN_LABELS = {
  admin_recharge: "🔋 شارژ اعتبار",
  admin_stats: "📊 آمار فروش",
  admin_sell_month: "📅 فروش ماهانه",
  admin_sell_card: "💳 گردش حساب ماهانه",
  admin_log_buy: "📝 چت گزارش فروش",
  admin_pricing: "💲 قیمت‌گذاری",
  admin_gateways: "🏦 اطلاعات درگاه‌های آنلاین",
  admin_show_pay: "💰 فعال/غیرفعال کردن درگاه‌ها",
  admin_id_card: "💴 اطلاعات کارت به کارت",
  admin_gift_add: "🎁 ساخت کد تخفیف",
  admin_gift_delete: "✖️ حذف کد تخفیف",
  admin_message_all: "✉️ پیام همگانی",
  admin_forward_all: "📪 فوروارد همگانی",
  admin_manage_texts: "📝 متن‌ها",
  admin_check_account: "♨️ چک کردن حساب کاربر",
  admin_check_service: "🚸 چک کردن سرویس",
  admin_block: "🪓 بلاک کاربر",
  admin_unblock: "🕳 آن‌بلاک کاربر",
  admin_list_panel: "🖥 لیست سرورها",
};

const B = {
  CREDIT: "💳 اعتبار و شارژ",
  PRICING: "💲 قیمت‌گذاری",
  GATEWAYS: "🏦 درگاه‌های پرداخت",
  GIFTS: "🎟 کدهای تخفیف",
  BROADCAST: "📢 ارسال همگانی",
  TEXTS: "📝 متن‌ها",
  STATS: "📊 آمار فروش",
  USERS: "👥 مدیریت کاربران",
  FEATURES: "🔐 امکانات فعال",
  SERVERS: "🖥 سرورها",
  HOME: "🏠 منوی اصلی",
};

const STATS_KEYS = ["admin_stats", "admin_sell_month", "admin_sell_card", "admin_log_buy"];
const GATEWAY_KEYS = ["admin_gateways", "admin_show_pay", "admin_id_card"];
const BROADCAST_KEYS = ["admin_message_all", "admin_forward_all"];
const USER_KEYS = ["admin_check_account", "admin_check_service", "admin_block", "admin_unblock"];
const GIFT_KEYS = ["admin_gift_add", "admin_gift_delete"];

// only the sections the main admin allows are on the keyboard
const panelKeyboard = (boot) => {
  const items = [
    [adminCan(boot, "admin_recharge"), B.CREDIT],
    [adminCanAny(boot, STATS_KEYS), B.STATS],
    [adminCan(boot, "admin_pricing"), B.PRICING],
    [adminCanAny(boot, GATEWAY_KEYS), B.GATEWAYS],
    [adminCanAny(boot, GIFT_KEYS) && boot.permissions.allow_gift, B.GIFTS],
    [adminCanAny(boot, BROADCAST_KEYS), B.BROADCAST],
    [adminCan(boot, "admin_manage_texts"), B.TEXTS],
    [adminCanAny(boot, USER_KEYS), B.USERS],
    [true, B.FEATURES],
    [adminCan(boot, "admin_list_panel"), B.SERVERS],
    [true, B.HOME],
  ]
    .filter(([allowed]) => allowed)
    .map(([, label]) => label);
  return Markup.keyboard(chunk(items, 2)).resize();
};

// owner-only, no panel permission needed (store operations such as card-to-card approvals)
const ownerOnly = async (ctx) => {
  if (ctx.callbackQuery) await ctx.answerCbQuery().catch(() => {});
  if (ctx.from.id !== cfg.ownerId) return null;
  const boot = ctx.state.boot;
  if (!boot) {
    await ctx.reply("⚠️ ارتباط با ربات اصلی برقرار نیست، کمی بعد تلاش کنید.");
    return null;
  }
  return boot;
};

// owner-only + the main admin's matrix must allow the panel and (at least one of) the given admin permissions.
// A denied section refreshes the reply keyboard so the stale button disappears.
const owner = async (ctx, keys) => {
  const boot = await ownerOnly(ctx);
  if (!boot) return null;
  if (!panelOpen(boot)) {
    markKeyboard(ctx, "main");
    await ctx.reply("⛔️ دسترسی به پنل مدیریت توسط مدیریت اصلی غیرفعال شده است.", mainMenu(boot, true));
    return null;
  }
  if (keys && !adminCanAny(boot, keys)) {
    markKeyboard(ctx, "panel");
    await ctx.reply("⛔️ این بخش توسط مدیریت اصلی غیرفعال شده است.", panelKeyboard(boot));
    return null;
  }
  return boot;
};

const apiError = (ctx, error) => ctx.reply(`⚠️ ${error.code === "insufficient_credit" ? "اعتبار کافی نیست" : error.message || "خطا در ارتباط با ربات اصلی"}`);

const showPanel = async (ctx) => {
  ctx.session.state = null;
  const boot = await owner(ctx);
  if (!boot) return;
  markKeyboard(ctx, "panel");
  await ctx.reply("🔧 پنل مدیریت نمایندگی", panelKeyboard(boot));
};

// ----------------------------------------------------------- credit --------

const showCredit = async (ctx) => {
  const boot = await owner(ctx, "admin_recharge");
  if (!boot) return;
  const fresh = await Api.getBootstrap({ force: true }).catch(() => boot);
  await ctx.replyWithHTML(
    `💳 <b>اعتبار شما نزد ربات اصلی</b>\n\n💰 موجودی: <b>${NumberFormat(fresh.credit.balance)}</b> تومان\n\n⚠️ هزینه ساخت و تمدید هر سرویس از همین اعتبار کسر می‌شود.`,
    Markup.inlineKeyboard([[Markup.button.callback("🔋 شارژ حساب", "TU:new"), Markup.button.callback("📜 تاریخچه شارژ", "TU:hist")]])
  );
};

const topupStatus = { pending: "⏳ در انتظار پرداخت", paid: "✅ پرداخت شده", expired: "⌛️ منقضی" };

const registerCredit = (bot) => {
  bot.action("TU:new", async (ctx) => {
    const boot = await owner(ctx, "admin_recharge");
    if (!boot) return;
    ctx.session.state = "adm:topup";
    await ctx.reply(`✍️ مبلغ شارژ را به تومان ارسال کنید (بین ${NumberFormat(boot.topup.min)} تا ${NumberFormat(boot.topup.max)}):`);
  });

  bot.action(/^TU:g:(\d+):(\w+)$/, async (ctx) => {
    const boot = await owner(ctx, "admin_recharge");
    if (!boot) return;
    try {
      const invoice = await Api.createTopup(Number(ctx.match[1]), ctx.match[2]);
      let text = `🧾 <b>فاکتور شارژ اعتبار</b>\n\n💰 مبلغ: ${NumberFormat(invoice.amount)} تومان\n🏦 درگاه: ${invoice.gateway_label}\n\nℹ️ این پرداخت از درگاه‌های ربات اصلی انجام می‌شود.`;
      const rows = [];
      if (invoice.extra?.pay_address) {
        text += `\n\n💎 مبلغ: <code>${invoice.extra.pay_amount}</code> ${invoice.extra.pay_currency}\n📥 آدرس واریز:\n<code>${esc(invoice.extra.pay_address)}</code>`;
      }
      if (invoice.pay_url) rows.push([Markup.button.url("💳 پرداخت", invoice.pay_url)]);
      rows.push([Markup.button.callback("♻️ بررسی پرداخت", "TU:c:" + invoice.id)]);
      await ctx.replyWithHTML(text, Markup.inlineKeyboard(rows));
    } catch (error) {
      await apiError(ctx, error);
    }
  });

  bot.action(/^TU:c:(\d+)$/, async (ctx) => {
    if (!(await owner(ctx, "admin_recharge"))) return;
    try {
      const invoice = await Api.getTopup(ctx.match[1]);
      await ctx.reply(
        invoice.status === "paid"
          ? `✅ پرداخت تایید شد.\n💳 موجودی فعلی: ${NumberFormat(invoice.balance)} تومان`
          : `${topupStatus[invoice.status] || invoice.status}\nدر صورت پرداخت چند دقیقه صبر کرده و دوباره بررسی کنید.`
      );
    } catch (error) {
      await apiError(ctx, error);
    }
  });

  bot.action("TU:hist", async (ctx) => {
    if (!(await owner(ctx, "admin_recharge"))) return;
    try {
      const { items } = await Api.listTopups();
      await ctx.reply(items.length ? items.map((item) => `#${item.id} | ${NumberFormat(item.amount)} تومان | ${topupStatus[item.status] || item.status}`).join("\n") : "📭 هنوز شارژی انجام نشده است.");
    } catch (error) {
      await apiError(ctx, error);
    }
  });
};

// ---------------------------------------------------------- pricing --------

const showPricing = async (ctx) => {
  const boot = await owner(ctx, "admin_pricing");
  if (!boot) return;
  const rows = [];
  for (const plan of boot.plans) {
    const sell = await sellPrice(boot, { kind: "plan", plan_id: plan.id });
    rows.push([Markup.button.callback(`${plan.name} | هزینه شما: ${NumberFormat(mainCost(boot, { kind: "plan", plan_id: plan.id }))} | فروش: ${NumberFormat(sell)}`, "PR:" + plan.id)]);
  }
  rows.push([Markup.button.callback(`📈 درصد سود پیش‌فرض: ${await getSetting("margin_percent", "30")}٪`, "PR:m")]);
  await ctx.reply("👇 برای تغییر قیمت فروش یک پلن روی آن بزنید (پلن‌ها و هزینه‌ها به صورت زنده از ربات اصلی می‌آیند):", Markup.inlineKeyboard(rows));
};

// ---------------------------------------------------------- gateways -------

// online gateways need "admin_gateways" for their credentials, card-to-card needs "admin_id_card"
const editKey = (gatewayKey) => (ADAPTERS[gatewayKey].manual ? "admin_id_card" : "admin_gateways");

const gatewayList = async (ctx, edit) => {
  const boot = await owner(ctx, GATEWAY_KEYS);
  if (!boot) return;
  const rows = [];
  for (const [key, adapter] of Object.entries(ADAPTERS)) {
    if (!boot.permissions[`allow_pay_${key}`]) continue;
    const { enabled, config } = await getConfig(key);
    rows.push([Markup.button.callback(`${enabled && isConfigured(key, config) ? "✅" : "❌"} ${adapter.label}`, "GW:" + key)]);
  }
  const text = rows.length ? "🏦 درگاه‌های پرداخت شما (مبلغ مستقیما به حساب خودتان واریز می‌شود):" : "⛔️ هیچ درگاهی توسط مدیریت اصلی برای شما مجاز نشده است.";
  return edit ? ctx.editMessageText(text, Markup.inlineKeyboard(rows)).catch(() => {}) : ctx.reply(text, Markup.inlineKeyboard(rows));
};

const registerGateways = (bot) => {
  bot.action(/^GW:([A-Z]+)$/, async (ctx) => {
    const boot = await owner(ctx, GATEWAY_KEYS);
    const key = ctx.match[1];
    if (!boot || !ADAPTERS[key] || !boot.permissions[`allow_pay_${key}`]) return;
    const { enabled, config } = await getConfig(key);
    const fields = ADAPTERS[key].fields.map((field) => `${config[field.key] ? "✅" : "❌"} ${field.label}`).join("\n");
    const rows = [];
    if (adminCan(boot, "admin_show_pay")) rows.push([Markup.button.callback(enabled ? "🔴 غیرفعال کردن" : "🟢 فعال کردن", "GW:t:" + key)]);
    if (adminCan(boot, editKey(key))) rows.push([Markup.button.callback("✏️ ثبت / ویرایش اطلاعات درگاه", "GW:e:" + key)]);
    rows.push([Markup.button.callback("🔙 بازگشت", "GW:list")]);
    await ctx.editMessageText(`${ADAPTERS[key].label}\n\nوضعیت: ${enabled ? "🟢 فعال" : "🔴 غیرفعال"}\n\n${fields}`, Markup.inlineKeyboard(rows));
  });
  bot.action("GW:list", (ctx) => gatewayList(ctx, true));
  bot.action(/^GW:t:([A-Z]+)$/, async (ctx) => {
    const boot = await owner(ctx, "admin_show_pay");
    const key = ctx.match[1];
    if (!boot || !ADAPTERS[key] || !boot.permissions[`allow_pay_${key}`]) return;
    const { enabled, config } = await getConfig(key);
    if (!enabled && !isConfigured(key, config)) return ctx.reply("⚠️ ابتدا اطلاعات درگاه را کامل ثبت کنید.");
    await saveConfig(key, { enabled: !enabled });
    await ctx.reply(!enabled ? "🟢 درگاه فعال شد." : "🔴 درگاه غیرفعال شد.");
  });
  bot.action(/^GW:e:([A-Z]+)$/, async (ctx) => {
    const key = ctx.match[1];
    const boot = await owner(ctx, ADAPTERS[key] ? editKey(key) : GATEWAY_KEYS);
    if (!boot || !ADAPTERS[key] || !boot.permissions[`allow_pay_${key}`]) return;
    ctx.session.state = `adm:gw:${key}:0`;
    await ctx.reply(`✍️ ${ADAPTERS[key].fields[0].label} را ارسال کنید:`);
  });
};

// ----------------------------------------------------------- gifts ---------

const showGifts = async (ctx) => {
  const boot = await owner(ctx, GIFT_KEYS);
  if (!boot || !boot.permissions.allow_gift) return;
  const canDelete = adminCan(boot, "admin_gift_delete");
  const gifts = await Gift.findAll();
  const rows = gifts.map((gift) => [
    Markup.button.callback(`${canDelete ? "🗑 " : ""}${gift.code} (${gift.percent}٪ | ${parseJson(gift.used, []).length}/${gift.limit})`, canDelete ? "GF:d:" + gift.code : "GF:i"),
  ]);
  if (adminCan(boot, "admin_gift_add")) rows.push([Markup.button.callback("➕ ساخت کد تخفیف", "GF:new")]);
  await ctx.reply(canDelete ? "🎟 کدهای تخفیف شما (برای حذف روی کد بزنید):" : "🎟 کدهای تخفیف شما:", Markup.inlineKeyboard(rows));
};

// ----------------------------------------------------------- stats ---------

const persianMonth = new Intl.DateTimeFormat("fa-IR-u-nu-latn", { year: "numeric", month: "2-digit" });
const monthKey = (date) => {
  const parts = Object.fromEntries(persianMonth.formatToParts(new Date(date)).map((part) => [part.type, part.value]));
  return `${parts.year}/${parts.month}`;
};

// last 12 months, newest first. source: "all" (delivered orders) | "card" (paid card-to-card payments)
const monthlyReport = async (source) => {
  const entries =
    source === "card"
      ? (await Payment.findAll({ where: { gateway: "CARD", status: "paid" } })).map((payment) => ({ at: payment.updatedAt, amount: payment.amount }))
      : (await Order.findAll({ where: { status: "fulfilled" } })).filter((order) => order.amount > 0).map((order) => ({ at: order.updatedAt, amount: order.amount }));
  const months = new Map();
  for (const entry of entries) {
    const key = monthKey(entry.at);
    const current = months.get(key) || { count: 0, sum: 0 };
    current.count += 1;
    current.sum += entry.amount;
    months.set(key, current);
  }
  const list = [...months.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 12);
  const title = source === "card" ? "💳 <b>گردش حساب ماهانه (کارت به کارت)</b>" : "📅 <b>فروش ماهانه</b>";
  if (!list.length) return `${title}\n\nهنوز موردی ثبت نشده است.`;
  const total = list.reduce((sum, [, value]) => sum + value.sum, 0);
  return `${title}\n\n${list.map(([key, value]) => `📆 ${key} → ${value.count} مورد | ${NumberFormat(value.sum)} تومان`).join("\n")}\n\n💵 مجموع: ${NumberFormat(total)} تومان`;
};

const showStats = async (ctx) => {
  const boot = await owner(ctx, STATS_KEYS);
  if (!boot) return;
  const rows = [];
  if (adminCan(boot, "admin_sell_month")) rows.push([Markup.button.callback("📅 فروش ماهانه", "ST:m")]);
  if (adminCan(boot, "admin_sell_card")) rows.push([Markup.button.callback("💳 گردش حساب ماهانه (کارت به کارت)", "ST:c")]);
  if (adminCan(boot, "admin_log_buy")) rows.push([Markup.button.callback("📝 تنظیم چت گزارش فروش", "ST:l")]);
  const extra = rows.length ? Markup.inlineKeyboard(rows) : {};
  if (!adminCan(boot, "admin_stats")) return ctx.reply("📊 گزارش‌های فروش:", extra);
  const delivered = await Order.findAll({ where: { status: "fulfilled" } });
  const revenue = delivered.reduce((sum, order) => sum + order.amount, 0);
  let api = { operations: 0, spent: 0 };
  try {
    api = await Api.stats();
  } catch (error) {}
  const day = new Date();
  day.setHours(0, 0, 0, 0);
  const today = delivered.filter((order) => new Date(order.updatedAt) >= day);
  await ctx.replyWithHTML(
    `📊 <b>آمار فروش</b>\n\n👥 مشتریان: ${await Customer.count()}\n🛍 سفارش‌های تحویل‌شده: ${delivered.length}\n📅 امروز: ${today.length} سفارش / ${NumberFormat(today.reduce((s, o) => s + o.amount, 0))} تومان\n💵 مجموع دریافتی از مشتریان: ${NumberFormat(revenue)} تومان\n💳 مجموع کسر از اعتبار (ربات اصلی): ${NumberFormat(api.spent)} تومان\n📈 سود تقریبی: ${NumberFormat(revenue - api.spent)} تومان\n\n💰 اعتبار فعلی: ${NumberFormat(boot.credit.balance)} تومان`,
    extra
  );
};

// ----------------------------------------------------------- users ---------

const showUsers = async (ctx) => {
  const boot = await owner(ctx, USER_KEYS);
  if (!boot) return;
  const rows = [];
  if (adminCan(boot, "admin_check_account")) rows.push([Markup.button.callback("♨️ چک کردن حساب", "US:acc")]);
  if (adminCan(boot, "admin_check_service")) rows.push([Markup.button.callback("🚸 چک کردن سرویس", "US:svc")]);
  if (adminCan(boot, "admin_block")) rows.push([Markup.button.callback("🪓 بلاک کاربر", "US:blk")]);
  if (adminCan(boot, "admin_unblock")) rows.push([Markup.button.callback("🕳 آن‌بلاک کاربر", "US:unb")]);
  await ctx.reply("👥 مدیریت کاربران:", Markup.inlineKeyboard(rows));
};

const registerUsers = (bot) => {
  const ask = (data, key, state, prompt) =>
    bot.action(data, async (ctx) => {
      if (!(await owner(ctx, key))) return;
      ctx.session.state = state;
      await ctx.reply(prompt);
    });
  ask("US:acc", "admin_check_account", "adm:acc", "✍️ آیدی عددی کاربر را ارسال کنید:");
  ask("US:svc", "admin_check_service", "adm:svc", "✍️ آیدی سرویس را ارسال کنید:");
  ask("US:blk", "admin_block", "adm:blk", "✍️ آیدی عددی کاربری که می‌خواهید بلاک شود را ارسال کنید:");
  ask("US:unb", "admin_unblock", "adm:unb", "✍️ آیدی عددی کاربری که می‌خواهید آن‌بلاک شود را ارسال کنید:");
};

// ----------------------------------------------------------- misc views ----

const showFeatures = async (ctx) => {
  const boot = await owner(ctx);
  if (!boot) return;
  const lines = Object.entries(PERM_LABELS).map(([key, label]) => `${boot.permissions[key] ? "✅" : "❌"} ${label}`);
  await ctx.reply(`🔐 امکانات فعال برای فروشگاه شما (فقط توسط مدیریت اصلی قابل تغییر است و همین لحظه اعمال می‌شود):\n\n${lines.join("\n")}`);
  if (boot.admin_permissions) {
    const adminLines = Object.entries(ADMIN_LABELS).map(([key, label]) => `${adminCan(boot, key) ? "✅" : "❌"} ${label}`);
    await ctx.reply(`🛡 دسترسی‌های پنل مدیریت شما (توسط مدیریت اصلی تعیین می‌شود):\n\n${adminLines.join("\n")}`);
  }
};

const showServers = async (ctx) => {
  const boot = await owner(ctx, "admin_list_panel");
  if (!boot) return;
  const lines = boot.servers.map((server) => `• ${esc(server.name)}${server.extra_price ? ` ⭐️ (+${NumberFormat(server.extra_price)} تومان)` : ""}`);
  await ctx.replyWithHTML(`🖥 <b>سرورهای در دسترس</b> (${boot.servers.length})\n\n${lines.join("\n") || "—"}\n\nℹ️ این فهرست زنده از ربات اصلی دریافت می‌شود و هر تغییری همان لحظه اعمال می‌شود.`);
};

const showTexts = async (ctx) => {
  if (!(await owner(ctx, "admin_manage_texts"))) return;
  await ctx.reply("📝 کدام متن را می‌خواهید ویرایش کنید؟", Markup.inlineKeyboard(EDITABLE_TEXTS.map((item) => [Markup.button.callback(item.label, "TX:" + item.key)])));
};

const startBroadcast = async (ctx) => {
  const boot = await owner(ctx, BROADCAST_KEYS);
  if (!boot) return;
  const rows = [];
  if (adminCan(boot, "admin_message_all")) rows.push([Markup.button.callback("✉️ پیام همگانی", "BC:m")]);
  if (adminCan(boot, "admin_forward_all")) rows.push([Markup.button.callback("📪 فوروارد همگانی", "BC:f")]);
  await ctx.reply("📢 نوع ارسال را انتخاب کنید:", Markup.inlineKeyboard(rows));
};

// ------------------------------------------------------- registration ------

const registerAdmin = (bot) => {
  bot.command("panel", showPanel);
  bot.hears("🛠 پنل مدیریت", showPanel);
  bot.hears(B.HOME, async (ctx) => {
    ctx.session.state = null;
    if (ctx.state.boot) {
      markKeyboard(ctx, "main");
      await ctx.reply("🏠", mainMenu(ctx.state.boot, ctx.from.id === cfg.ownerId));
    }
  });

  const section = (label, handler) =>
    bot.hears(label, async (ctx) => {
      ctx.session.state = null;
      return handler(ctx);
    });
  section(B.CREDIT, showCredit);
  section(B.PRICING, showPricing);
  section(B.GATEWAYS, (ctx) => gatewayList(ctx, false));
  section(B.GIFTS, showGifts);
  section(B.BROADCAST, startBroadcast);
  section(B.TEXTS, showTexts);
  section(B.STATS, showStats);
  section(B.USERS, showUsers);
  section(B.FEATURES, showFeatures);
  section(B.SERVERS, showServers);

  registerCredit(bot);
  registerGateways(bot);
  registerUsers(bot);

  bot.action(/^PR:(\d+)$/, async (ctx) => {
    if (!(await owner(ctx, "admin_pricing"))) return;
    ctx.session.state = "adm:price:" + ctx.match[1];
    await ctx.reply("✏️ قیمت فروش جدید (تومان) را ارسال کنید. برای بازگشت به قیمت خودکار عدد 0 بفرستید:");
  });
  bot.action("PR:m", async (ctx) => {
    if (!(await owner(ctx, "admin_pricing"))) return;
    ctx.session.state = "adm:margin";
    await ctx.reply("✏️ درصد سود پیش‌فرض را ارسال کنید (مثلا 30):");
  });

  bot.action("ST:m", async (ctx) => {
    if (!(await owner(ctx, "admin_sell_month"))) return;
    await ctx.replyWithHTML(await monthlyReport("all"));
  });
  bot.action("ST:c", async (ctx) => {
    if (!(await owner(ctx, "admin_sell_card"))) return;
    await ctx.replyWithHTML(await monthlyReport("card"));
  });
  bot.action("ST:l", async (ctx) => {
    if (!(await owner(ctx, "admin_log_buy"))) return;
    ctx.session.state = "adm:logchat";
    const current = await getSetting("log_chat");
    await ctx.reply(`✍️ آیدی عددی چت/کانال/گروه گزارش فروش را ارسال کنید (ربات باید در آن عضو باشد). برای غیرفعال کردن یک "-" بفرستید.${current ? `\n\nمقدار فعلی: ${current}` : ""}`);
  });

  bot.action("GF:i", (ctx) => ctx.answerCbQuery().catch(() => {}));
  bot.action("GF:new", async (ctx) => {
    if (!(await owner(ctx, "admin_gift_add"))) return;
    ctx.session.state = "adm:gift";
    await ctx.reply("✍️ به این صورت ارسال کنید:\nکد  درصد  تعداد‌استفاده\n\nمثال: SUMMER 20 50");
  });
  bot.action(/^GF:d:(.+)$/, async (ctx) => {
    if (!(await owner(ctx, "admin_gift_delete"))) return;
    await Gift.destroy({ where: { code: ctx.match[1] } });
    await ctx.reply("🗑 حذف شد.");
  });

  bot.action(/^TX:(\w+)$/, async (ctx) => {
    if (!(await owner(ctx, "admin_manage_texts"))) return;
    ctx.session.state = "adm:text:" + ctx.match[1];
    await ctx.reply(`✍️ متن جدید را ارسال کنید (برای بازگشت به متن پیش‌فرض یک "-" بفرستید).\n\nپیش‌فرض:\n${DEFAULTS[ctx.match[1]] || ""}`);
  });

  bot.action("BC:m", async (ctx) => {
    if (!(await owner(ctx, "admin_message_all"))) return;
    ctx.session.state = "adm:bc";
    await ctx.reply("✍️ پیام همگانی را ارسال کنید:");
  });
  bot.action("BC:f", async (ctx) => {
    if (!(await owner(ctx, "admin_forward_all"))) return;
    ctx.session.state = "adm:fw";
    await ctx.reply("✍️ پیامی را که می‌خواهید فوروارد همگانی شود ارسال کنید:");
  });

  // manual card-to-card approvals (store operation: independent of the panel permissions)
  bot.action(/^CARD:(ok|no):(\d+)$/, async (ctx) => {
    if (!(await ownerOnly(ctx))) return;
    const payment = await Payment.findByPk(Number(ctx.match[2]));
    if (!payment || payment.status !== "pending") return ctx.reply("⚠️ این پرداخت قبلا بررسی شده است.");
    if (ctx.match[1] === "ok") {
      await settlePayment(payment.id);
      return ctx.editMessageCaption("✅ تایید شد").catch(() => {});
    }
    await payment.update({ status: "rejected" });
    const order = await Order.findByPk(payment.order_id);
    if (order) await send(order.customer_id, "❌ رسید پرداخت شما تایید نشد. در صورت اشتباه با پشتیبانی در ارتباط باشید.");
    return ctx.editMessageCaption("❌ رد شد").catch(() => {});
  });

  bot.command("reply", async (ctx) => {
    if (ctx.from.id !== cfg.ownerId) return;
    const text = ctx.message.text.replace(/^\/reply(@\S+)?\s*/, "");
    const space = text.indexOf(" ");
    if (space === -1) return ctx.reply("❓ فرمت صحیح: /reply <شناسه کاربر> <متن پاسخ>");
    try {
      await ctx.telegram.sendMessage(text.slice(0, space).trim(), `📩 پاسخ پشتیبانی:\n\n${text.slice(space + 1).trim()}`);
      await ctx.reply("✅ پاسخ با موفقیت ارسال شد.");
    } catch (error) {
      await ctx.reply("❌ ارسال پاسخ ناموفق بود (احتمالا کاربر ربات را استارت نکرده است).");
    }
  });
};

// sends (copy) or forwards the owner's message to every customer
const runBroadcast = async (ctx, mode) => {
  ctx.session.state = null;
  const customers = await Customer.findAll({ where: { blocked: false } });
  await ctx.reply(`📤 ارسال به ${customers.length} کاربر شروع شد ...`);
  (async () => {
    let sent = 0;
    for (const customer of customers) {
      try {
        if (mode === "forward") await ctx.telegram.forwardMessage(customer.id, ctx.chat.id, ctx.message.message_id);
        else await ctx.telegram.copyMessage(customer.id, ctx.chat.id, ctx.message.message_id);
        sent++;
      } catch (error) {
        if (error?.response?.error_code === 403) await customer.update({ blocked: true });
      }
      await sleep(40);
    }
    ctx.telegram.sendMessage(cfg.ownerId, `✅ ارسال همگانی تمام شد: ${sent} از ${customers.length}`).catch(() => {});
  })();
};

// free-text input while an admin state is active
const handleAdminText = async (ctx) => {
  const state = ctx.session.state;
  const text = ctx.message.text.trim();
  if (ctx.from.id !== cfg.ownerId) {
    ctx.session.state = null;
    return;
  }
  const number = Number(text.replace(/[,،\s]/g, ""));

  if (state === "adm:topup") {
    const boot = await owner(ctx, "admin_recharge");
    if (!boot) return;
    if (!Number.isFinite(number) || number < boot.topup.min || number > boot.topup.max) return ctx.reply(`❌ مبلغ باید بین ${NumberFormat(boot.topup.min)} تا ${NumberFormat(boot.topup.max)} تومان باشد.`);
    ctx.session.state = null;
    if (!boot.topup.gateways.length) return ctx.reply("⚠️ در حال حاضر درگاه پرداختی در ربات اصلی فعال نیست.");
    return ctx.reply(
      `💰 مبلغ ${NumberFormat(number)} تومان\n\n👈 درگاه پرداخت را انتخاب کنید (درگاه‌های ربات اصلی):`,
      Markup.inlineKeyboard(boot.topup.gateways.map((gateway) => [Markup.button.callback(gateway.label, `TU:g:${number}:${gateway.key}`)]))
    );
  }
  if (state.startsWith("adm:price:")) {
    if (!(await owner(ctx, "admin_pricing"))) return;
    if (!Number.isFinite(number) || number < 0) return ctx.reply("❌ لطفا یک عدد معتبر ارسال کنید.");
    const planId = Number(state.split(":")[2]);
    if (number === 0) await Price.destroy({ where: { plan_id: planId } });
    else await Price.upsert({ plan_id: planId, price: Math.round(number) });
    ctx.session.state = null;
    return ctx.reply("✅ قیمت با موفقیت ذخیره شد.");
  }
  if (state === "adm:margin") {
    if (!(await owner(ctx, "admin_pricing"))) return;
    if (!Number.isFinite(number) || number < 0 || number > 1000) return ctx.reply("❌ لطفا یک عدد معتبر ارسال کنید.");
    await setSetting("margin_percent", number);
    ctx.session.state = null;
    return ctx.reply("✅ درصد سود ذخیره شد.");
  }
  if (state.startsWith("adm:gw:")) {
    const [, , key, indexRaw] = state.split(":");
    const boot = await owner(ctx, ADAPTERS[key] ? editKey(key) : GATEWAY_KEYS);
    if (!boot || !ADAPTERS[key] || !boot.permissions[`allow_pay_${key}`]) return;
    const index = Number(indexRaw);
    const fields = ADAPTERS[key].fields;
    await saveConfig(key, { config: { [fields[index].key]: text } });
    ctx.deleteMessage().catch(() => {}); // keep secrets out of the chat history
    if (index + 1 < fields.length) {
      ctx.session.state = `adm:gw:${key}:${index + 1}`;
      return ctx.reply(`✍️ ${fields[index + 1].label} را ارسال کنید:`);
    }
    ctx.session.state = null;
    return ctx.reply("✅ اطلاعات درگاه ذخیره شد. برای استفاده، درگاه را از منوی «🏦 درگاه‌های پرداخت» فعال کنید.");
  }
  if (state === "adm:gift") {
    if (!(await owner(ctx, "admin_gift_add"))) return;
    const [code, percent, limit] = text.split(/\s+/);
    if (!code || !(Number(percent) > 0 && Number(percent) <= 100) || !(Number(limit) > 0)) return ctx.reply("❌ فرمت اشتباه است. مثال: SUMMER 20 50");
    await Gift.upsert({ code, percent: Number(percent), limit: Number(limit), used: "[]" });
    ctx.session.state = null;
    return ctx.reply("✅ کد تخفیف ساخته شد.");
  }
  if (state.startsWith("adm:text:")) {
    if (!(await owner(ctx, "admin_manage_texts"))) return;
    await setText(state.split(":")[2], text === "-" ? "" : ctx.message.text);
    ctx.session.state = null;
    return ctx.reply("✅ متن ذخیره شد و همین لحظه فعال شد.");
  }
  if (state === "adm:bc") {
    if (!(await owner(ctx, "admin_message_all"))) return;
    return runBroadcast(ctx, "copy");
  }
  if (state === "adm:fw") {
    if (!(await owner(ctx, "admin_forward_all"))) return;
    return runBroadcast(ctx, "forward");
  }
  if (state === "adm:logchat") {
    if (!(await owner(ctx, "admin_log_buy"))) return;
    ctx.session.state = null;
    if (text === "-") {
      await setSetting("log_chat", "");
      return ctx.reply("✅ گزارش فروش غیرفعال شد.");
    }
    if (!/^-?\d+$/.test(text)) return ctx.reply("❌ آیدی عددی معتبر ارسال کنید.");
    await setSetting("log_chat", text);
    return ctx.reply("✅ ذخیره شد. از این پس هر فروش/تمدید در این چت گزارش می‌شود.");
  }
  if (state === "adm:acc") {
    if (!(await owner(ctx, "admin_check_account"))) return;
    ctx.session.state = null;
    const customer = Number.isFinite(number) ? await Customer.findByPk(number) : null;
    if (!customer) return ctx.reply("❌ کاربری با این آیدی پیدا نشد.");
    const orders = await Order.findAll({ where: { customer_id: customer.id, status: "fulfilled" } });
    const refs = await ServiceRef.findAll({ where: { customer_id: customer.id }, order: [["service_id", "DESC"]], limit: 15 });
    return ctx.replyWithHTML(
      `♨️ <b>اطلاعات حساب</b>\n\n🆔 آیدی: <code>${customer.id}</code>\n👤 یوزرنیم: ${customer.username ? "@" + esc(customer.username) : "-"}\n📅 عضویت: ${new Date(customer.createdAt).toLocaleDateString("fa-IR")}\n🚫 وضعیت: ${customer.blocked ? "بلاک" : "فعال"}\n🛍 سفارش‌های تحویل‌شده: ${orders.length}\n💰 مجموع پرداختی: ${NumberFormat(orders.reduce((sum, order) => sum + order.amount, 0))} تومان\n🔗 سرویس‌ها: ${refs.length ? refs.map((ref) => ref.service_id).join(", ") : "-"}`
    );
  }
  if (state === "adm:svc") {
    if (!(await owner(ctx, "admin_check_service"))) return;
    ctx.session.state = null;
    const ref = Number.isFinite(number) ? await ServiceRef.findByPk(number) : null;
    if (!ref) return ctx.reply("❌ سرویسی با این آیدی در فروشگاه شما پیدا نشد.");
    try {
      const info = await Api.serviceInfo(ref.service_id, ref.customer_id);
      return ctx.replyWithHTML(`👤 مالک سرویس: <code>${ref.customer_id}</code>\n\n${infoText(info, ref.service_id)}`);
    } catch (error) {
      return apiError(ctx, error);
    }
  }
  if (state === "adm:blk" || state === "adm:unb") {
    const block = state === "adm:blk";
    if (!(await owner(ctx, block ? "admin_block" : "admin_unblock"))) return;
    ctx.session.state = null;
    if (block && number === cfg.ownerId) return ctx.reply("❌ نمی‌توانید خودتان را بلاک کنید.");
    const customer = Number.isFinite(number) ? await Customer.findByPk(number) : null;
    if (!customer) return ctx.reply("❌ کاربری با این آیدی پیدا نشد.");
    await customer.update({ blocked: block });
    return ctx.reply(block ? "🪓 کاربر بلاک شد." : "🕳 کاربر آن‌بلاک شد.");
  }
  ctx.session.state = null;
};

export { registerAdmin, handleAdminText, panelKeyboard };
