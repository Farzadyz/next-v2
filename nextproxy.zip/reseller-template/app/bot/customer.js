import { Markup } from "telegraf";
import QRCode from "qrcode";
import cfg from "../config.js";
import { Api } from "../mainApi.js";
import { Order, Payment, ServiceRef, Gift, Customer } from "../models.js";
import { MENU, t } from "../texts.js";
import { NumberFormat, esc, chunk, random, parseJson } from "../util.js";
import { sellPrice, applyGift } from "../pricing.js";
import { availableGateways, startPayment, verifyPayment, ADAPTERS } from "../gateways.js";
import { infoText, settleOrder, settlePayment, notifyOwner } from "../fulfillment.js";
import { markKeyboard } from "../access.js";

// ============================================================================
// Customer side of the reseller bot. The menu, buttons and every action are
// rebuilt from the permission matrix / servers / plans delivered by the main bot
// on each interaction - nothing about them is stored in this database.
// ============================================================================

const mainMenu = (boot, isOwner) => {
  const p = boot.permissions;
  const rows = [];
  if (p.allow_buy_service) rows.push([MENU.BUY]);
  const row2 = [];
  if (p.allow_my_service) row2.push(MENU.MY);
  if (p.allow_account) row2.push(MENU.ACCOUNT);
  if (row2.length) rows.push(row2);
  const row3 = [];
  if (p.allow_price_list) row3.push(MENU.PRICE);
  if (p.allow_support) row3.push(MENU.SUPPORT);
  if (row3.length) rows.push(row3);
  const row4 = [];
  if (p.allow_get_agent) row4.push(MENU.AGENT);
  if (p.allow_question) row4.push(MENU.FAQ);
  if (row4.length) rows.push(row4);
  if (isOwner) rows.push(["🛠 پنل مدیریت"]);
  // a keyboard can never be empty
  if (!rows.length) rows.push(["/start"]);
  return Markup.keyboard(rows).resize();
};

// returns the fresh main-bot snapshot or replies with the reason it can't be used.
// Every given permission key must be enabled by the main admin; when one is not, the
// (stale) reply keyboard of the chat is refreshed so the disabled button disappears.
const guard = async (ctx, ...keys) => {
  const boot = ctx.state.boot;
  if (ctx.callbackQuery) await ctx.answerCbQuery().catch(() => {});
  if (!boot) {
    await ctx.reply(t("UNAVAILABLE"));
    return null;
  }
  if (boot.reseller.status !== "active") {
    await ctx.reply(t("DISABLED"));
    return null;
  }
  if (keys.some((key) => key && !boot.permissions[key])) {
    markKeyboard(ctx, "main");
    await ctx.reply(t("RESTRICTED"), mainMenu(boot, ctx.from.id === cfg.ownerId));
    return null;
  }
  return boot;
};

// may a customer buy this plan? (buy menu + plan lists + connection type + economic plans)
const planAllowed = (p, plan) =>
  Boolean(p.allow_buy_service && p.allow_choose_plan) &&
  Boolean(plan.connection === "multi" ? p.allow_multi_location : p.allow_single_location) &&
  (plan.type === "economic" ? Boolean(p.allow_economic_plan) : true);

const answer = (ctx, text, extra = {}) => (ctx.callbackQuery ? ctx.editMessageText(text, { parse_mode: "HTML", ...extra }).catch(() => ctx.reply(text, { parse_mode: "HTML", ...extra })) : ctx.reply(text, { parse_mode: "HTML", ...extra }));

const backRow = (data) => [Markup.button.callback(MENU.BACK, data)];

// the reseller bot has ONE custom-plan flow (pick days + traffic from the main bot's lists):
// it is available while either custom-plan switch is on
const customAllowed = (p) => Boolean(p.allow_buy_service && (p.allow_custom_plan || p.allow_select_custom_plan));

// ------------------------------------------------------------------ buy ---

const showBuyMenu = async (ctx) => {
  const boot = await guard(ctx, "allow_buy_service");
  if (!boot) return;
  const p = boot.permissions;
  const rows = [];
  const base = [];
  if (p.allow_choose_plan && p.allow_multi_location) base.push(Markup.button.callback("○ مولتی لوکیشن", "B:t:multi"));
  if (p.allow_choose_plan && p.allow_single_location) base.push(Markup.button.callback("● تک لوکیشن", "B:t:single"));
  if (base.length) rows.push(base);
  if (p.allow_payg_multi && boot.payg.enabled_multi) rows.push([Markup.button.callback("⚡️ پرداخت به ازای مصرف (مولتی لوکیشن)", "B:y:multi")]);
  if (p.allow_payg_single && boot.payg.enabled_single) rows.push([Markup.button.callback("⚡️ پرداخت به ازای مصرف (تک لوکیشن)", "B:y:single")]);
  if (customAllowed(p) && boot.custom.days_values.length && boot.custom.traffic_values.length) rows.push([Markup.button.callback("▫️ پلن انتخابی ، سفارشی", "B:c")]);
  if (p.allow_test_service) rows.push([Markup.button.callback("🎁 اشتراک تست", "B:f")]);
  if (p.allow_gift) rows.push([Markup.button.callback(ctx.session.gift ? "♻️ حذف کد تخفیف" : "🎁 اعمال کد تخفیف", "G:ask")]);
  if (!rows.length) return ctx.reply(t("RESTRICTED"));
  await answer(ctx, "❓ لطفا گزینه مورد نظر خود را انتخاب کنید :", Markup.inlineKeyboard(rows));
};

const showPlans = async (ctx, connection) => {
  const boot = await guard(ctx, "allow_buy_service", "allow_choose_plan", connection === "multi" ? "allow_multi_location" : "allow_single_location");
  if (!boot) return;
  const plans = boot.plans.filter((plan) => (connection === "multi" ? plan.connection === "multi" : plan.connection !== "multi") && planAllowed(boot.permissions, plan));
  if (!plans.length) return answer(ctx, "⚠️ فعلا پلنی جهت نمایش وجود ندارد!\n\nلطفا کمی بعد تلاش کنید.", Markup.inlineKeyboard([backRow("B:home")]));
  const rows = [];
  for (const plan of plans) {
    const price = await sellPrice(boot, { kind: "plan", plan_id: plan.id });
    rows.push([Markup.button.callback(`${plan.name} | ${NumberFormat(price)} تومان`, "B:p:" + plan.id)]);
  }
  rows.push(backRow("B:home"));
  await answer(ctx, "👇 لطفا پلن مورد نظر را انتخاب کنید ...", Markup.inlineKeyboard(rows));
};

// a draft is the purchase being assembled; it lives in the (per-customer) session
const needsServer = (boot, draft) => {
  if (!boot.permissions.allow_server_choice || boot.servers.length < 2) return false;
  if (draft.kind === "custom") return true;
  if (draft.kind === "payg") return draft.connection === "single";
  if (draft.kind === "plan") return boot.plans.find((plan) => plan.id === draft.plan_id)?.panel === "sanae";
  return false;
};

const nextStep = async (ctx, boot) => {
  const draft = ctx.session.draft;
  if (needsServer(boot, draft) && draft.server_id === undefined) {
    const rows = chunk(
      boot.servers.map((server) => Markup.button.callback(`${server.extra_price ? "⭐️ " : ""}${server.name}`, "SV:" + server.id)),
      2
    );
    rows.push([Markup.button.callback("🎲 انتخاب خودکار", "SV:0")]);
    return answer(ctx, "❓ لطفا لوکیشین مورد نظر خود را انتخاب کنید.\n\n⭐️ سرور های ستاره دار بدلیل ویژه بودن هزینه بیشتری در بر دارند.", Markup.inlineKeyboard(rows));
  }
  return createOrder(ctx, boot);
};

// re-checks the switches at the moment the order is created (they may have changed mid-flow)
const draftAllowed = (boot, draft) => {
  const p = boot.permissions;
  if (draft.kind === "renew") return Boolean(p.allow_renew);
  if (!p.allow_buy_service) return false;
  if (draft.kind === "plan") {
    const plan = boot.plans.find((item) => item.id === draft.plan_id);
    return Boolean(plan) && planAllowed(p, plan);
  }
  if (draft.kind === "custom") return customAllowed(p);
  if (draft.kind === "payg") return Boolean(draft.connection === "multi" ? p.allow_payg_multi : p.allow_payg_single);
  if (draft.kind === "free") return Boolean(p.allow_test_service);
  return false;
};

const createOrder = async (ctx, boot) => {
  const draft = ctx.session.draft;
  if (!draft || !draftAllowed(boot, draft)) return ctx.reply(t("RESTRICTED"));
  const fields = { kind: draft.kind, plan_id: draft.plan_id, server_id: draft.server_id || null, connection: draft.connection, traffic: draft.traffic, days: draft.days, service_id: draft.service_id };
  let amount = await sellPrice(boot, fields);
  let giftCode = null;
  if (ctx.session.gift && amount > 0) {
    const gift = await Gift.findByPk(ctx.session.gift);
    if (gift) {
      amount = applyGift(amount, gift);
      giftCode = gift.code;
    }
  }
  const order = await Order.create({ ...fields, request_id: random(24), customer_id: ctx.from.id, amount, gift_code: giftCode });
  ctx.session.draft = null;
  if (amount === 0) {
    await answer(ctx, "⏳ در حال ساخت سرویس ...");
    return settleOrder(order.id);
  }
  const gateways = await availableGateways(boot.permissions);
  if (!gateways.length) return answer(ctx, "⚠️ در حال حاضر هیچ روش پرداختی فعال نیست. لطفا با پشتیبانی در ارتباط باشید.");
  const rows = gateways.map((gateway) => [Markup.button.callback(gateway.label, `PAY:${order.id}:${gateway.key}`)]);
  await answer(
    ctx,
    `✅ فاکتور شما به قیمت <b>${NumberFormat(amount)}</b> تومان ساخته شد.\n\n<b>• شناسه فاکتور :</b> ${order.id}\n${giftCode ? `<b>• کد تخفیف :</b> ${esc(giftCode)}\n` : ""}\n👈 جهت پرداخت لطفا از یکی از گزینه های زیر استفاده کنید`,
    Markup.inlineKeyboard(rows)
  );
};

const pay = async (ctx) => {
  const boot = await guard(ctx);
  if (!boot) return;
  const [, orderId, key] = ctx.match;
  const order = await Order.findByPk(Number(orderId));
  if (!order || order.customer_id !== ctx.from.id || order.status !== "new") return ctx.reply("⚠️ این فاکتور معتبر نیست یا قبلا پرداخت شده است.");
  if (!(await availableGateways(boot.permissions)).some((gateway) => gateway.key === key)) return ctx.reply(t("RESTRICTED"));
  const started = await startPayment(order, key);
  if (!started) return ctx.reply("⚠️ خطا در ساخت لینک پرداخت، لطفا کمی بعد یا با روش دیگری تلاش کنید.");
  if (started.manual) {
    ctx.session.state = "cus:card:" + started.payment.id;
    return ctx.replyWithHTML(
      `💳 مبلغ <b>${NumberFormat(order.amount)}</b> تومان را به کارت زیر واریز کنید:\n\n<code>${esc(started.config.card_number)}</code>\n${esc(started.config.card_owner)}\n\n📷 سپس تصویر رسید پرداخت را همینجا ارسال کنید.`
    );
  }
  await ctx.replyWithHTML(
    `💸 مبلغ <b>${NumberFormat(order.amount)}</b> تومان\n\nبرای پرداخت روی دکمه زیر بزنید؛ بعد از پرداخت سرویس به صورت خودکار تحویل داده می‌شود.`,
    Markup.inlineKeyboard([[Markup.button.url("💳 پرداخت", started.url)], [Markup.button.callback("♻️ بررسی پرداخت", "CHK:" + started.payment.id)]])
  );
};

const checkPayment = async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const payment = await Payment.findByPk(Number(ctx.match[1]));
  const order = payment && (await Order.findByPk(payment.order_id));
  if (!order || order.customer_id !== ctx.from.id) return;
  if (payment.status === "paid") return ctx.reply("✅ این پرداخت قبلا تایید شده است.");
  if (ADAPTERS[payment.gateway]?.callbackOk && (await verifyPayment(payment, {}))) return settlePayment(payment.id);
  return ctx.reply("⏳ هنوز پرداخت شما تایید نشده است. در صورت پرداخت چند دقیقه صبر کرده و دوباره بررسی کنید.");
};

// -------------------------------------------------------- my services -----

const showMyServices = async (ctx) => {
  const boot = await guard(ctx, "allow_my_service");
  if (!boot) return;
  const refs = await ServiceRef.findAll({ where: { customer_id: ctx.from.id }, order: [["service_id", "DESC"]], limit: 30 });
  if (!refs.length) return answer(ctx, "⚠️ شما اشتراک فعالی ندارید ، ابتدا اشتراکی بخرید و مجدد روی این گزینه کلیک کنید.");
  const rows = refs.map((ref) => [Markup.button.callback(`💎 اشتراک #${ref.service_id}`, "S:v:" + ref.service_id)]);
  await answer(ctx, `🔗 تعداد اشتراک های شما : ${refs.length}\n⚠️ برای مشاهده هر اشتراک روی آن کلیک کنید.`, Markup.inlineKeyboard(rows));
};

const ownedRef = (ctx, id) => ServiceRef.findOne({ where: { service_id: Number(id), customer_id: ctx.from.id } });

const showService = async (ctx) => {
  const boot = await guard(ctx, "allow_my_service");
  if (!boot) return;
  const id = ctx.match[1];
  if (!(await ownedRef(ctx, id))) return ctx.reply(t("RESTRICTED"));
  let info;
  try {
    info = await Api.serviceInfo(id, ctx.from.id);
  } catch (error) {
    return answer(ctx, "⚠️ خطا در گرفتن اطلاعات لطفا مجددا تلاش کنید.", Markup.inlineKeyboard([backRow("S:list")]));
  }
  const p = boot.permissions;
  const rows = [];
  if (p.allow_action_qr) rows.push([Markup.button.callback("🔖Qr Code", "S:q:" + id)]);
  const line = [];
  if (p.allow_action_refresh) line.push(Markup.button.callback("📊 بروزرسانی اطلاعات", "S:v:" + id));
  if (p.allow_action_revoke) line.push(Markup.button.callback("🔐 تغییر لینک", "S:r:" + id));
  if (line.length) rows.push(line);
  if (p.allow_action_status && !info.is_test) rows.push([Markup.button.callback(`🔌 وضعیت اتصال موقت: ${info.connection_enabled ? "روشن" : "خاموش"}`, "S:t:" + id)]);
  if (p.allow_renew && info.renewable) rows.push([Markup.button.callback("🔋 تمدید سرویس", "S:n:" + id)]);
  if (p.allow_action_delete) rows.push([Markup.button.callback("❌ حذف سرویس", "S:d:" + id)]);
  rows.push(backRow("S:list"));
  await answer(ctx, infoText(info, id), Markup.inlineKeyboard(rows));
};

const serviceAction = (permission, run) => async (ctx) => {
  const boot = await guard(ctx, permission);
  if (!boot) return;
  const id = ctx.match[1];
  if (!(await ownedRef(ctx, id))) return ctx.reply(t("RESTRICTED"));
  try {
    await run(ctx, id);
  } catch (error) {
    await ctx.reply(error.code === "not_permitted" ? t("RESTRICTED") : "⚠️ انجام عملیات ممکن نشد، لطفا مجددا تلاش کنید.");
  }
};

const registerServiceActions = (bot) => {
  bot.action("S:list", showMyServices);
  bot.action(/^S:v:(\d+)$/, showService);
  bot.action(/^S:q:(\d+)$/, serviceAction("allow_action_qr", async (ctx, id) => {
    const info = await Api.serviceInfo(id, ctx.from.id);
    for (const link of info.links) await ctx.replyWithPhoto({ source: await QRCode.toBuffer(link.url, { errorCorrectionLevel: "H" }) }, { caption: link.label });
  }));
  bot.action(/^S:t:(\d+)$/, serviceAction("allow_action_status", async (ctx, id) => {
    await Api.toggleStatus(id, ctx.from.id);
    await showService(Object.assign(ctx, { match: [null, id] }));
  }));
  bot.action(/^S:r:(\d+)$/, serviceAction("allow_action_revoke", (ctx, id) =>
    answer(ctx, "⚠️ با تغییر لینک ، لینک قبلی شما از کار می‌افتد. آیا مطمئن هستید؟", Markup.inlineKeyboard([[Markup.button.callback("✅ بله", "S:rr:" + id)], backRow("S:v:" + id)]))
  ));
  bot.action(/^S:rr:(\d+)$/, serviceAction("allow_action_revoke", async (ctx, id) => {
    await Api.revoke(id, ctx.from.id);
    await showService(Object.assign(ctx, { match: [null, id] }));
  }));
  bot.action(/^S:d:(\d+)$/, serviceAction("allow_action_delete", (ctx, id) =>
    answer(ctx, `❓ آیا از حذف سرویس <b>${id}</b> اطمینان دارید؟`, Markup.inlineKeyboard([[Markup.button.callback("✅ بله، حذف کن", "S:dd:" + id)], backRow("S:v:" + id)]))
  ));
  bot.action(/^S:dd:(\d+)$/, serviceAction("allow_action_delete", async (ctx, id) => {
    await Api.remove(id, ctx.from.id);
    await ServiceRef.destroy({ where: { service_id: Number(id), customer_id: ctx.from.id } });
    await answer(ctx, "با موفقیت حذف شد ✅");
  }));
  bot.action(/^S:n:(\d+)$/, serviceAction("allow_renew", async (ctx, id) => {
    const ref = await ownedRef(ctx, id);
    ctx.session.draft = { kind: "renew", service_id: ref.service_id, plan_id: ref.plan_id, traffic: ref.traffic, days: ref.days, server_id: ref.server_id || undefined };
    return createOrder(ctx, ctx.state.boot);
  }));
};

// ------------------------------------------------------------ registration -

const registerCustomer = (bot) => {
  const menu = (label, handler) =>
    bot.hears(label, async (ctx) => {
      ctx.session.state = null;
      return handler(ctx);
    });

  bot.start(async (ctx) => {
    ctx.session.state = null;
    const boot = await guard(ctx);
    if (!boot) return;
    markKeyboard(ctx, "main");
    await ctx.reply(t("WELCOME", { name: ctx.from.first_name || "", bot: ctx.botInfo?.username || "" }), mainMenu(boot, ctx.from.id === cfg.ownerId));
  });

  menu(MENU.BUY, showBuyMenu);
  bot.action("B:home", showBuyMenu);
  bot.action(/^B:t:(multi|single)$/, (ctx) => showPlans(ctx, ctx.match[1]));

  bot.action(/^B:p:(\d+)$/, async (ctx) => {
    const boot = await guard(ctx, "allow_buy_service", "allow_choose_plan");
    if (!boot) return;
    const plan = boot.plans.find((item) => item.id === Number(ctx.match[1]));
    if (!plan) return ctx.reply("⚠️ این پلن دیگر در دسترس نیست.");
    if (!planAllowed(boot.permissions, plan)) return ctx.reply(t("RESTRICTED"));
    ctx.session.draft = { kind: "plan", plan_id: plan.id };
    return nextStep(ctx, boot);
  });

  bot.action("B:c", async (ctx) => {
    const boot = await guard(ctx, "allow_buy_service");
    if (!boot) return;
    if (!customAllowed(boot.permissions)) return guard(ctx, "allow_custom_plan");
    const rows = chunk(boot.custom.days_values.map((day) => Markup.button.callback(`${day} روز`, "C:d:" + day)), 3);
    rows.push(backRow("B:home"));
    return answer(ctx, "❓ تعداد #روز خود را برای پکیج خود از لیست پایین انتخاب کنید", Markup.inlineKeyboard(rows));
  });
  bot.action(/^C:d:(\d+)$/, async (ctx) => {
    const boot = await guard(ctx, "allow_buy_service");
    if (!boot) return;
    if (!customAllowed(boot.permissions)) return guard(ctx, "allow_custom_plan");
    const days = Number(ctx.match[1]);
    const rows = chunk(boot.custom.traffic_values.map((gb) => Markup.button.callback(`${gb} گیگ`, `C:t:${days}:${gb}`)), 3);
    rows.push(backRow("B:c"));
    return answer(ctx, "❓ مقدار #حجم خود را برای پکیج خود از لیست پایین انتخاب کنید", Markup.inlineKeyboard(rows));
  });
  bot.action(/^C:t:(\d+):(\d+(?:\.\d+)?)$/, async (ctx) => {
    const boot = await guard(ctx, "allow_buy_service");
    if (!boot) return;
    if (!customAllowed(boot.permissions)) return guard(ctx, "allow_custom_plan");
    ctx.session.draft = { kind: "custom", days: Number(ctx.match[1]), traffic: Number(ctx.match[2]) };
    return nextStep(ctx, boot);
  });

  bot.action(/^B:y:(multi|single)$/, async (ctx) => {
    const key = ctx.match[1] === "multi" ? "allow_payg_multi" : "allow_payg_single";
    const boot = await guard(ctx, "allow_buy_service", key);
    if (!boot) return;
    ctx.session.draft = { kind: "payg", connection: ctx.match[1] };
    return nextStep(ctx, boot);
  });

  bot.action("B:f", async (ctx) => {
    const boot = await guard(ctx, "allow_buy_service", "allow_test_service");
    if (!boot) return;
    ctx.session.draft = { kind: "free" };
    return createOrder(ctx, boot);
  });

  bot.action(/^SV:(\d+)$/, async (ctx) => {
    const boot = await guard(ctx);
    if (!boot || !ctx.session.draft) return;
    const id = Number(ctx.match[1]);
    if (id && !boot.servers.some((server) => server.id === id)) return ctx.reply("⚠️ این لوکیشن دیگر در دسترس نیست.");
    ctx.session.draft.server_id = id || null;
    return createOrder(ctx, boot);
  });

  bot.action(/^PAY:(\d+):(\w+)$/, pay);
  bot.action(/^CHK:(\d+)$/, checkPayment);

  bot.action("G:ask", async (ctx) => {
    const boot = await guard(ctx, "allow_gift");
    if (!boot) return;
    if (ctx.session.gift) {
      ctx.session.gift = null;
      return ctx.reply("♻️ کد تخفیف حذف شد.");
    }
    ctx.session.state = "cus:gift";
    return ctx.reply("✍️ لطفا کد تخفیف خود را ارسال کنید:");
  });

  registerServiceActions(bot);
  menu(MENU.MY, showMyServices);

  menu(MENU.ACCOUNT, async (ctx) => {
    const boot = await guard(ctx, "allow_account");
    if (!boot) return;
    const customer = await Customer.findByPk(ctx.from.id);
    const orders = await Order.findAll({ where: { customer_id: ctx.from.id, status: "fulfilled" } });
    const total = orders.reduce((sum, order) => sum + order.amount, 0);
    await ctx.replyWithHTML(
      `👤 شناسه کاربری: <code>${ctx.from.id}</code>\n👈 تاریخ عضویت: ${new Date(customer.createdAt).toLocaleDateString("fa-IR")}\n\n💳 تعداد اشتراک های شما: ${await ServiceRef.count({ where: { customer_id: ctx.from.id } })}\n💰 مجموع پرداختی: ${NumberFormat(total)} تومان`
    );
  });

  menu(MENU.PRICE, async (ctx) => {
    const boot = await guard(ctx, "allow_price_list");
    if (!boot) return;
    const lines = [];
    for (const plan of boot.plans) {
      if (plan.connection === "multi" ? !boot.permissions.allow_multi_location : !boot.permissions.allow_single_location) continue;
      if (plan.type === "economic" && !boot.permissions.allow_economic_plan) continue;
      lines.push(`• ${esc(plan.name)} — ${NumberFormat(await sellPrice(boot, { kind: "plan", plan_id: plan.id }))} تومان`);
    }
    await ctx.replyWithHTML(`📋 <b>لیست قیمت‌ها</b>\n\n${lines.join("\n") || "پلنی تعریف نشده است."}`);
  });

  menu(MENU.SUPPORT, async (ctx) => {
    const boot = await guard(ctx, "allow_support");
    if (!boot) return;
    ctx.session.state = "cus:support";
    await ctx.reply(t("SUPPORT_ASK"));
  });
  menu(MENU.AGENT, async (ctx) => {
    if (await guard(ctx, "allow_get_agent")) await ctx.reply(t("AGENT"));
  });
  menu(MENU.FAQ, async (ctx) => {
    if (await guard(ctx, "allow_question")) await ctx.reply(t("FAQ"));
  });

  // receipt photo for a manual (card-to-card) payment
  bot.on("photo", async (ctx, next) => {
    const state = ctx.session.state || "";
    if (!state.startsWith("cus:card:")) return next();
    const payment = await Payment.findByPk(Number(state.split(":")[2]));
    ctx.session.state = null;
    if (!payment || payment.status !== "pending") return ctx.reply("⚠️ این پرداخت معتبر نیست.");
    await ctx.telegram.sendPhoto(cfg.ownerId, ctx.message.photo.at(-1).file_id, {
      caption: `💳 رسید کارت به کارت\n👤 کاربر: ${ctx.from.id}\n💰 مبلغ: ${NumberFormat(payment.amount)} تومان\n🧾 فاکتور: #${payment.order_id}`,
      ...Markup.inlineKeyboard([[Markup.button.callback("✅ تایید", "CARD:ok:" + payment.id), Markup.button.callback("❌ رد", "CARD:no:" + payment.id)]]),
    });
    await ctx.reply("✅ رسید شما برای بررسی ارسال شد. پس از تایید، سرویس شما تحویل داده می‌شود.");
  });
};

// free-text answers while a customer state is active
const handleCustomerText = async (ctx) => {
  const state = ctx.session.state;
  const text = ctx.message.text.trim();
  if (state === "cus:gift") {
    ctx.session.state = null;
    if (!ctx.state.boot?.permissions.allow_gift) return ctx.reply(t("RESTRICTED"));
    const gift = await Gift.findByPk(text);
    const used = parseJson(gift?.used, []);
    if (!gift || used.length >= gift.limit) return ctx.reply("❌ این کد تخفیف معتبر نیست یا ظرفیت آن تکمیل شده است.");
    if (used.includes(String(ctx.from.id))) return ctx.reply("❌ شما قبلا از این کد تخفیف استفاده کرده‌اید.");
    ctx.session.gift = gift.code;
    return ctx.reply(`✅ کد تخفیف «${gift.code}» (${gift.percent}٪) با موفقیت اعمال شد و در خرید بعدی شما لحاظ می‌شود.`);
  }
  if (state === "cus:support") {
    ctx.session.state = null;
    if (!ctx.state.boot?.permissions.allow_support) return ctx.reply(t("RESTRICTED"));
    await notifyOwner(
      `📨 پیام پشتیبانی جدید از کاربر <code>${ctx.from.id}</code>${ctx.from.username ? " (@" + esc(ctx.from.username) + ")" : ""}:\n\n${esc(text)}\n\nجهت پاسخ:\n<code>/reply ${ctx.from.id} متن پاسخ شما</code>`
    );
    return ctx.reply(t("SUPPORT_SENT"));
  }
  if (state?.startsWith("cus:card:")) return ctx.reply("📷 لطفا تصویر رسید پرداخت را ارسال کنید.");
  ctx.session.state = null;
};

export { registerCustomer, handleCustomerText, mainMenu };
