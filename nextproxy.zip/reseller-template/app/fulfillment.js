import cfg from "./config.js";
import { Api, MainApiError } from "./mainApi.js";
import { Order, Payment, ServiceRef, Gift, getSetting } from "./models.js";
import { NumberFormat, esc, parseJson } from "./util.js";
import { adminCan } from "./access.js";

// Turns paid orders into configs by calling the main bot's REST API. The order's
// request_id is the API idempotency key, so retries can never charge twice.

let botRef = null;
const setBot = (bot) => {
  botRef = bot;
};

const send = (chatId, text, extra = {}) => botRef?.telegram.sendMessage(chatId, text, { parse_mode: "HTML", ...extra }).catch(() => {});
const notifyOwner = (text) => send(cfg.ownerId, text);

const infoText = (info, id) =>
  `<b>○ وضعیت </b>: ${esc(info.status)}\n<b>○ ایدی سرویس </b>: ${id}\n` +
  (info.location ? `<b>○ لوکیشن</b>: ${esc(info.location)}\n` : "") +
  `<b>○ زمان باقی مانده </b>: ${esc(info.time_left)}\n<b>○ حجم کل </b>: ${esc(info.traffic)}\n<b>○ حجم استفاده شده </b>: ${esc(info.used)}\n<b>○ حجم باقی مانده </b>: ${esc(
    info.remaining
  )}\n〰️〰️〰️〰️〰️〰️\n` +
  info.links.map((link) => `<b>${esc(link.label)}:</b>\n<code>${esc(link.url)}</code>`).join("\n") +
  "\n〰️〰️〰️〰️〰️〰️\n⚠️ با تغییر وضعیت اتصال موقت ، اشتراک شما کامل قطع یا وصل میشود.";

// sale report to the chat the reseller chose in the panel (only while the main admin allows "sales report")
const notifySale = async (order, serviceId) => {
  try {
    const chat = await getSetting("log_chat");
    if (!chat) return;
    const boot = await Api.getBootstrap().catch(() => null);
    if (!adminCan(boot, "admin_log_buy")) return;
    const kind = { plan: "پلن آماده", custom: "پلن سفارشی", payg: "PAYG", free: "تست رایگان", renew: "تمدید" }[order.kind] || order.kind;
    await send(
      chat,
      `🛒 <b>${order.kind === "renew" ? "تمدید" : "فروش جدید"}</b>\n\n👤 کاربر: <code>${order.customer_id}</code>\n📦 نوع: ${kind}\n🆔 سرویس: ${serviceId}\n💰 مبلغ: ${NumberFormat(order.amount)} تومان\n🧾 فاکتور: #${order.id}`
    );
  } catch (error) {
    console.error("[sale log]", error?.message || error);
  }
};

const sendService = async (chatId, serviceId) => {
  try {
    const info = await Api.serviceInfo(serviceId, chatId);
    await send(chatId, infoText(info, serviceId));
  } catch (error) {
    await send(chatId, `🆔 شناسه سرویس شما: <b>${serviceId}</b>\nبرای دریافت اطلاعات از «اشتراک های من» استفاده کنید.`);
  }
};

const TERMINAL = new Set(["not_permitted", "free_used", "invalid_custom", "plan_not_found", "plan_removed", "not_renewable", "reseller_suspended", "not_configured", "invalid_request"]);
const locks = new Set();

const fail = async (order, error, message) => {
  await order.update({ status: "failed", error: String(error.code || error.message).slice(0, 255) });
  await send(order.customer_id, message);
  if (order.amount > 0) {
    await notifyOwner(`❌ تحویل سفارش #${order.id} (مبلغ ${NumberFormat(order.amount)} تومان از کاربر <code>${order.customer_id}</code>) ناموفق ماند: ${esc(error.code)}\nلطفا وجه را دستی برگردانید.`);
  }
};

const handleFailure = async (order, error) => {
  const code = error instanceof MainApiError ? error.code : "unknown";
  if (code === "insufficient_credit") {
    await order.update({ error: code });
    if (!order.owner_warned) {
      await order.update({ owner_warned: true });
      await send(order.customer_id, "✅ پرداخت شما ثبت شد. سرویس شما در کوتاه‌ترین زمان تحویل داده می‌شود.");
      await notifyOwner(
        `⚠️ اعتبار شما نزد ربات اصلی برای تحویل سفارش #${order.id} کافی نیست` +
          (error.details?.required ? ` (نیاز: ${NumberFormat(error.details.required)} | موجودی: ${NumberFormat(error.details.balance)} تومان)` : "") +
          `.\nاز پنل ← «💳 اعتبار و شارژ» حساب را شارژ کنید؛ سفارش بعد از شارژ خودکار تحویل داده می‌شود.`
      );
    }
    return;
  }
  if (code === "free_used") return fail(order, error, "⚠️ شما تنها یکبار میتوانید اشتراک تست دریافت کنید.");
  if (TERMINAL.has(code) || order.attempts + 1 >= 6) {
    return fail(order, error, "❌ متاسفانه تحویل سرویس ممکن نشد. لطفا با پشتیبانی در ارتباط باشید.");
  }
  await order.update({ attempts: order.attempts + 1, error: code });
};

const fulfillOrder = async (orderId) => {
  if (locks.has(orderId)) return;
  locks.add(orderId);
  try {
    const order = await Order.findByPk(orderId);
    if (!order || order.status !== "paid") return;
    let result;
    try {
      if (order.kind === "renew") {
        result = await Api.renew(order.service_id, { request_id: order.request_id, customer_id: order.customer_id, display_price: order.amount });
      } else {
        result = await Api.createService({
          request_id: order.request_id,
          kind: order.kind,
          customer_id: order.customer_id,
          plan_id: order.plan_id,
          server_id: order.server_id,
          connection: order.connection,
          traffic: order.traffic,
          days: order.days,
          display_price: order.amount,
        });
      }
    } catch (error) {
      return await handleFailure(order, error);
    }
    await order.update({ status: "fulfilled", service_id: result.service_id, error: null });
    notifySale(order, result.service_id);
    if (order.kind === "renew") {
      await send(order.customer_id, `✅ سرویس شما با موفقیت تمدید شد.\n\n🆔 شناسه سرویس: ${result.service_id}`);
    } else {
      await ServiceRef.upsert({
        service_id: result.service_id,
        customer_id: order.customer_id,
        name: order.kind,
        kind: order.kind,
        plan_id: order.plan_id,
        traffic: order.traffic,
        days: order.days,
        server_id: order.server_id,
      });
      await send(order.customer_id, `#خرید با موفقیت انجام شد✅\n👈 برای دریافت اطلاعات و جزئیات خرید خود به قسمت اشتراک های من مراجعه کنید.\n\n<b>⚠️ ایدی این اشتراک : ${result.service_id}</b>`);
      await sendService(order.customer_id, result.service_id);
    }
  } finally {
    locks.delete(orderId);
  }
};

// consumes the gift code of an order exactly once
const consumeGift = async (order) => {
  if (!order.gift_code) return;
  const gift = await Gift.findByPk(order.gift_code);
  if (!gift) return;
  const used = parseJson(gift.used, []);
  if (!used.includes(String(order.customer_id))) await gift.update({ used: JSON.stringify([...used, String(order.customer_id)]) });
};

// marks an order as paid and starts fulfilment (idempotent)
const settleOrder = async (orderId) => {
  const [changed] = await Order.update({ status: "paid" }, { where: { id: orderId, status: "new" } });
  if (!changed) return false;
  const order = await Order.findByPk(orderId);
  await consumeGift(order);
  await fulfillOrder(orderId);
  return true;
};

// gateway/card confirmation of one payment
const settlePayment = async (paymentId) => {
  const [claimed] = await Payment.update({ status: "paid" }, { where: { id: paymentId, status: "pending" } });
  if (!claimed) return false;
  const payment = await Payment.findByPk(paymentId);
  await send((await Order.findByPk(payment.order_id))?.customer_id, "✅ پرداخت شما با موفقیت تایید شد.");
  return settleOrder(payment.order_id);
};

// retries orders that are paid but not delivered yet (e.g. credit was low)
const retryPending = async () => {
  const orders = await Order.findAll({ where: { status: "paid" }, limit: 20 });
  for (const order of orders) await fulfillOrder(order.id);
};

export { setBot, send, notifyOwner, infoText, sendService, fulfillOrder, settleOrder, settlePayment, retryPending };
