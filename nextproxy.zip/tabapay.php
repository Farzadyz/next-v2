<?php
$targetUrl = "https://pay.nextstory.ir/tabapay";

// همه پارامترهای GET و POST رو جمع می‌کنیم
$params = array_merge($_GET, $_POST);

// ساخت Query String
$query = http_build_query($params);

// ریدایرکت کاربر به مقصد
header("Location: $targetUrl?$query");
exit;
