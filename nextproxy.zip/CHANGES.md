# Mini App: user-dashboard completion + coupon codes + referral program

Overwrite these paths in your project with the matching files here:

New:
- app/webapp/controllers/paymentGateways.js
- app/webapp/controllers/shopApi.js

Modified:
- app/controllers/Free.js       (+ sumUserReferralEarnings)
- app/webapp/routes.js          (purchase/wallet/renew/coupon/referral routes)
- index.js                      (body-parser limit -> 10mb, for base64 receipt uploads)
- public/webapp/api.js          (matching client methods)
- public/webapp/components.js   (openModal/closeModal/fileToBase64 helpers)
- public/webapp/user.js         (Buy, Wallet+topup, Services+renew, Support,
                                  More/profile/tutorials/referral/reseller tabs;
                                  coupon-code box in the purchase quote screen)

No DB migration needed - every field used (Peyment.gift, Gifts, Free.type,
Users.member, Setting.invite, etc.) already exists in your schema.
