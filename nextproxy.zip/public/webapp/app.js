// ============================================================================
// Role-based bootstrap. `/webapp/api/me` is the single source of truth for
// role - the frontend NEVER decides for itself whether the caller is the
// admin; it only renders whichever dashboard the backend says to render.
// ============================================================================

(async () => {
  const loading = document.getElementById("loading");
  try {
    const me = await Api.me();
    tg?.setHeaderColor?.("#020617");
    tg?.setBackgroundColor?.("#020617");
    loading.remove();
    if (me.role === "admin") await AdminApp.mount();
    else await UserApp.mount();
  } catch (error) {
    // DIAGNOSTIC BUILD: shows exactly what failed instead of one generic message.
    const debug = [
      `window.Telegram present: ${Boolean(window.Telegram)}`,
      `Telegram.WebApp present: ${Boolean(tg)}`,
      `initData length: ${initData ? initData.length : 0}`,
      `HTTP status: ${error.status ?? "(no response - network/CORS/proxy issue)"}`,
      `error code: ${error.code ?? error.message}`,
    ].join("<br/>");
    loading.innerHTML = `<div class="text-center text-rose-400 text-sm px-6 leading-6">
      ⚠️ امکان تایید هویت شما وجود ندارد.<br/><br/>
      <div style="direction:ltr" class="text-left text-xs bg-slate-900 rounded-lg p-3 text-slate-300">${debug}</div>
    </div>`;
  }
})();
