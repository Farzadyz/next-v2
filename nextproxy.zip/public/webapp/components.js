// Tiny render helpers shared by user.js / admin.js - no framework, just template
// strings + event delegation, kept deliberately simple so any future feature
// can be added by copy-pasting an existing block rather than learning a new API.

const root = document.getElementById("root");
const tabbar = document.getElementById("tabbar");
const fa = (n) => Number(n || 0).toLocaleString("en-US");

function toast(message, kind = "info") {
  const el = document.createElement("div");
  const color = kind === "error" ? "bg-rose-600" : kind === "success" ? "bg-emerald-600" : "bg-slate-700";
  el.className = `fixed top-4 inset-x-4 z-50 ${color} text-white text-sm px-4 py-3 rounded-xl shadow-lg text-center`;
  el.textContent = message;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}

function card(inner, extra = "") {
  return `<div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 ${extra}">${inner}</div>`;
}

function button(label, { id = "", variant = "primary", full = false, disabled = false } = {}) {
  const styles = {
    primary: "bg-sky-600 hover:bg-sky-500 text-white",
    danger: "bg-rose-600 hover:bg-rose-500 text-white",
    ghost: "bg-slate-800 hover:bg-slate-700 text-slate-100",
  };
  return `<button ${id ? `id="${id}"` : ""} ${disabled ? "disabled" : ""} class="${styles[variant]} rounded-xl px-4 py-2.5 text-sm font-medium transition ${full ? "w-full" : ""} ${disabled ? "opacity-50 cursor-not-allowed" : ""}">${label}</button>`;
}

function field(label, { id, type = "text", placeholder = "", value = "" }) {
  return `<label class="block mb-3">
    <span class="text-xs text-slate-400 mb-1 block">${label}</span>
    <input id="${id}" type="${type}" value="${value}" placeholder="${placeholder}" class="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-sky-500" />
  </label>`;
}

function toggle(id, checked, label) {
  return `<label class="flex items-center justify-between gap-3 py-2.5 border-b border-slate-800 last:border-0">
    <span class="text-sm">${label}</span>
    <input type="checkbox" data-toggle="${id}" ${checked ? "checked" : ""} class="w-10 h-6 appearance-none bg-slate-700 rounded-full relative cursor-pointer checked:bg-sky-600 transition
      before:content-[''] before:absolute before:w-4 before:h-4 before:bg-white before:rounded-full before:top-1 before:left-1 before:transition checked:before:translate-x-4" />
  </label>`;
}

// Renders a set of tabs into #tabbar and wires clicking one to `onSelect`.
function renderTabs(tabs, active, onSelect) {
  tabbar.classList.remove("hidden");
  tabbar.innerHTML = `<div class="max-w-3xl mx-auto grid" style="grid-template-columns: repeat(${tabs.length}, 1fr)">
    ${tabs
      .map(
        (tab) => `<button data-tab="${tab.key}" class="flex flex-col items-center gap-0.5 py-2.5 text-xs ${tab.key === active ? "text-sky-400" : "text-slate-500"}">
        <span class="text-lg leading-none">${tab.icon}</span>${tab.label}
      </button>`
      )
      .join("")}
  </div>`;
  tabbar.querySelectorAll("[data-tab]").forEach((btn) => btn.addEventListener("click", () => onSelect(btn.dataset.tab)));
}

function showQr(text) {
  const overlay = document.createElement("div");
  overlay.className = "fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-6";
  overlay.innerHTML = `<div class="bg-white rounded-2xl p-4 flex flex-col items-center gap-3">
    <div id="qr-box"></div>
    <button id="qr-close" class="text-slate-700 text-sm font-medium">بستن</button>
  </div>`;
  document.body.appendChild(overlay);
  new QRCode(overlay.querySelector("#qr-box"), { text, width: 220, height: 220 });
  overlay.querySelector("#qr-close").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => e.target === overlay && overlay.remove());
}

// Generic bottom-sheet modal. `bodyHtml` is rendered as-is; call
// `closeModal()` (or click the backdrop / the built-in ✕) to dismiss it.
// Returns the modal's root element so callers can wire up their own
// event listeners inside it right after calling this.
function openModal(title, bodyHtml) {
  closeModal();
  const overlay = document.createElement("div");
  overlay.id = "modal-overlay";
  overlay.className = "fixed inset-0 bg-black/70 z-40 flex items-end sm:items-center justify-center";
  overlay.innerHTML = `
    <div id="modal-box" class="bg-slate-900 border border-slate-800 w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl max-h-[85vh] overflow-y-auto p-4 pb-6">
      <div class="flex items-center justify-between mb-3">
        <h3 class="font-bold text-sm">${title}</h3>
        <button id="modal-close" class="text-slate-500 text-lg leading-none px-2">✕</button>
      </div>
      <div id="modal-body">${bodyHtml}</div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener("click", (e) => e.target === overlay && closeModal());
  overlay.querySelector("#modal-close").addEventListener("click", closeModal);
  return overlay;
}

function closeModal() {
  document.getElementById("modal-overlay")?.remove();
}

// Reads a <input type=file> image and resolves a base64 data URL, downscaled
// so a phone-camera photo of a bank receipt stays well under the upload cap.
function fileToBase64(file, maxDim = 1280) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read_failed"));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = () => reject(new Error("decode_failed"));
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast("کپی شد ✅", "success");
  } catch (error) {
    toast("کپی انجام نشد", "error");
  }
}
