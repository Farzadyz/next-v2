// ============================================================================
// Main Admin dashboard: Servers, Users, Resellers (+ permission matrix), PAYG,
// Settings, and Support tickets. Every request this file makes carries the
// SAME verified initData as the user dashboard - the backend, not this file,
// is what actually enforces that only the main admin's Telegram account can
// reach any of it (see webapp/auth.js requireAdmin).
// ============================================================================

const TABS = [
  { key: "servers", icon: "🖥", label: "سرورها" },
  { key: "users", icon: "👥", label: "کاربران" },
  { key: "resellers", icon: "🤝", label: "نمایندگی" },
  { key: "payg", icon: "⚡️", label: "PAYG" },
  { key: "settings", icon: "⚙️", label: "تنظیمات" },
  { key: "tickets", icon: "💬", label: "تیکت‌ها" },
];

const AdminApp = {
  tab: "servers",

  async mount() {
    renderTabs(TABS, this.tab, (key) => {
      this.tab = key;
      this.render();
    });
    await this.render();
  },

  async render() {
    root.innerHTML = `<div class="flex justify-center py-10 text-slate-500">در حال بارگذاری ...</div>`;
    renderTabs(TABS, this.tab, (key) => {
      this.tab = key;
      this.render();
    });
    try {
      await this[`render_${this.tab}`]();
    } catch (error) {
      root.innerHTML = card(`<p class="text-rose-400 text-sm">خطا در دریافت اطلاعات.</p>`);
    }
  },

  // ------------------------------------------------------------- servers --
  async render_servers() {
    const { items } = await Api.admin.servers();
    root.innerHTML = `
      ${card(`
        <p class="text-sm font-medium mb-3">➕ افزودن سرور جدید</p>
        <label class="block mb-3">
          <span class="text-xs text-slate-400 mb-1 block">نوع پنل</span>
          <select id="srv-panel" class="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm">
            <option value="sanae">Sanaei (نسخه قدیمی، تا 2.6.6)</option>
            <option value="sanaei_new">Sanaei (نسخه‌های جدید)</option>
          </select>
        </label>
        ${field("آدرس پنل", { id: "srv-domain", placeholder: "https://panel.example.com:2053" })}
        ${field("یوزرنیم", { id: "srv-username" })}
        ${field("پسورد", { id: "srv-password", type: "password" })}
        ${field("نام لوکیشن", { id: "srv-location", placeholder: "Germany" })}
        ${field("هاست/دامین اتصال", { id: "srv-host" })}
        ${field("لینک اینترنال", { id: "srv-internal" })}
        ${field("لینک تونل", { id: "srv-tunel" })}
        ${field("رنج پورت (min,max)", { id: "srv-port", placeholder: "10000,20000" })}
        <label class="block mb-3">
          <span class="text-xs text-slate-400 mb-1 block">نوع پلن</span>
          <select id="srv-type" class="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm">
            <option value="normal">عادی</option>
            <option value="economic">اقتصادی</option>
          </select>
        </label>
        ${field("قیمت اضافه (اختیاری)", { id: "srv-price", type: "number", placeholder: "0" })}
        ${button("✅ ثبت سرور", { id: "srv-submit", full: true })}
      `)}
      <h3 class="text-sm text-slate-400 mt-5 mb-2">سرورهای موجود (${items.length})</h3>
      ${items
        .map(
          (s) => card(`
            <div class="flex items-center justify-between mb-1">
              <p class="text-sm font-medium">${s.location} <span class="text-xs text-slate-500">(${s.panel === "sanaei_new" ? "جدید" : "قدیمی"})</span></p>
              <span class="text-xs px-2 py-0.5 rounded-full ${s.status ? "bg-emerald-800 text-emerald-200" : "bg-rose-900 text-rose-200"}">${s.status ? "فعال" : "غیرفعال"}</span>
            </div>
            <p class="text-xs text-slate-500 mb-2">${s.domain} · ${s.type === "economic" ? "اقتصادی" : "عادی"} · قیمت اضافه: ${fa(s.price)} تومان</p>
            <div class="flex gap-2">
              ${button(s.status ? "⛔️ غیرفعال کردن" : "✅ فعال کردن", { id: `srv-toggle-${s.id}`, variant: "ghost" })}
              ${button("🗑 حذف", { id: `srv-delete-${s.id}`, variant: "danger" })}
            </div>
          `),
          ""
        )
        .join("")}
    `;

    document.getElementById("srv-submit").addEventListener("click", async (event) => {
      const payload = {
        panel: document.getElementById("srv-panel").value,
        domain: document.getElementById("srv-domain").value.trim(),
        username: document.getElementById("srv-username").value.trim(),
        password: document.getElementById("srv-password").value,
        location: document.getElementById("srv-location").value.trim(),
        host: document.getElementById("srv-host").value.trim(),
        internal: document.getElementById("srv-internal").value.trim(),
        tunel: document.getElementById("srv-tunel").value.trim(),
        port: document.getElementById("srv-port").value.trim(),
        type: document.getElementById("srv-type").value,
        price: Number(document.getElementById("srv-price").value || 0),
      };
      if (!payload.domain || !payload.username || !payload.password || !payload.location) return toast("همه فیلدهای ضروری را پر کنید", "error");
      event.target.disabled = true;
      event.target.textContent = "⏳ در حال اتصال به پنل ...";
      try {
        await Api.admin.createServer(payload);
        toast("سرور با موفقیت اضافه شد ✅", "success");
        this.render_servers();
      } catch (error) {
        const messages = { login_failed: "ورود به پنل ناموفق بود (یوزر/پسورد یا آدرس را بررسی کنید)", invalid_port_range: "فرمت رنج پورت باید به شکل 1000,2000 باشد", invalid_type: "نوع پلن نامعتبر است" };
        toast(messages[error.code] || "خطا در افزودن سرور", "error");
        event.target.disabled = false;
        event.target.textContent = "✅ ثبت سرور";
      }
    });
    items.forEach((s) => {
      document.getElementById(`srv-toggle-${s.id}`).addEventListener("click", async () => {
        await Api.admin.updateServer(s.id, { status: !s.status });
        this.render_servers();
      });
      document.getElementById(`srv-delete-${s.id}`).addEventListener("click", async () => {
        if (!confirm(`سرور "${s.location}" حذف شود؟`)) return;
        await Api.admin.deleteServer(s.id);
        toast("سرور حذف شد", "success");
        this.render_servers();
      });
    });
  },

  // --------------------------------------------------------------- users --
  async render_users() {
    root.innerHTML = `
      ${card(`
        <div class="flex gap-2">
          <input id="user-query" placeholder="آیدی عددی یا شماره تماس" class="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-sky-500" />
          ${button("🔍 جستجو", { id: "user-search" })}
        </div>
      `)}
      <div id="user-results" class="mt-3"></div>
    `;
    const search = async () => {
      const q = document.getElementById("user-query").value.trim();
      if (!q) return;
      const { items } = await Api.admin.searchUsers(q);
      const box = document.getElementById("user-results");
      box.innerHTML = items.length
        ? items.map((u) => this.userCard(u)).join("")
        : card(`<p class="text-sm text-slate-500 text-center">کاربری پیدا نشد.</p>`);
      items.forEach((u) => this.wireUserCard(u));
    };
    document.getElementById("user-search").addEventListener("click", search);
    document.getElementById("user-query").addEventListener("keydown", (e) => e.key === "Enter" && search());
  },

  userCard(u) {
    return card(
      `
      <div class="flex items-center justify-between mb-2">
        <p class="text-sm font-medium">🆔 ${u.id}</p>
        <span class="text-xs px-2 py-0.5 rounded-full ${u.blocked ? "bg-rose-900 text-rose-200" : "bg-emerald-800 text-emerald-200"}">${u.blocked ? "بلاک" : "فعال"}</span>
      </div>
      <p class="text-xs text-slate-500 mb-3">📞 ${u.phone || "-"} · 💰 ${fa(u.price)} تومان ${u.agent ? "· 🏵 نماینده" : ""}</p>
      <div class="flex gap-2 mb-2">
        <input id="delta-${u.id}" type="number" placeholder="مبلغ (+/-)" class="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm" />
        ${button("💰 اعمال", { id: `apply-${u.id}`, variant: "ghost" })}
      </div>
      <div class="flex gap-2">
        ${button(u.blocked ? "🕳 آن‌بلاک" : "🪓 بلاک", { id: `block-${u.id}`, variant: u.blocked ? "primary" : "danger", full: true })}
        ${button("📦 سرویس‌ها", { id: `svcs-${u.id}`, variant: "ghost", full: true })}
      </div>
      <div id="svc-box-${u.id}" class="mt-2"></div>
    `,
      "mb-3"
    );
  },

  wireUserCard(u) {
    document.getElementById(`apply-${u.id}`).addEventListener("click", async () => {
      const delta = Number(document.getElementById(`delta-${u.id}`).value || 0);
      if (!delta) return toast("مبلغ را وارد کنید", "error");
      try {
        const result = await Api.admin.adjustBalance(u.id, delta);
        toast(`موجودی جدید: ${fa(result.balance)} تومان`, "success");
        this.render_users();
      } catch (error) {
        toast(error.code === "negative_balance" ? "موجودی کافی نیست" : "خطا در اعمال تغییر", "error");
      }
    });
    document.getElementById(`block-${u.id}`).addEventListener("click", async () => {
      await Api.admin.setBlocked(u.id, !u.blocked);
      toast(!u.blocked ? "کاربر بلاک شد" : "کاربر آن‌بلاک شد", "success");
      this.render_users();
    });
    document.getElementById(`svcs-${u.id}`).addEventListener("click", async () => {
      const { items } = await Api.admin.userServices(u.id);
      document.getElementById(`svc-box-${u.id}`).innerHTML = items.length
        ? items.map((s) => `<div class="text-xs text-slate-400 border-t border-slate-800 pt-2 mt-2">#${s.id} · ${s.name} · ${s.panel}</div>`).join("")
        : `<p class="text-xs text-slate-500 mt-2">سرویسی ندارد.</p>`;
    });
  },

  // ----------------------------------------------------------- resellers --
  async render_resellers() {
    const [{ items }, permView] = await Promise.all([Api.admin.resellers(), Api.admin.resellerPermissions()]);
    root.innerHTML = `
      <h3 class="text-sm text-slate-400 mb-2">ربات‌های نمایندگی (${items.length})</h3>
      ${
        items
          .map((r) =>
            card(`
        <div class="flex items-center justify-between">
          <p class="text-sm font-medium">@${r.username || r.id}</p>
          <span class="text-xs px-2 py-0.5 rounded-full ${r.status === "active" ? "bg-emerald-800 text-emerald-200" : "bg-rose-900 text-rose-200"}">${r.status === "active" ? "فعال" : "مسدود"}</span>
        </div>
        <p class="text-xs text-slate-500 mt-1">مالک: ${r.owner_id} · فروش: ${r.sales} مورد · ${fa(r.total_sales)} تومان</p>
      `)
          )
          .join("") || card(`<p class="text-sm text-slate-500 text-center">هنوز نمایندگی ثبت نشده.</p>`)
      }

      <h3 class="text-sm text-slate-400 mt-5 mb-2">🧩 قابلیت‌های ربات نماینده</h3>
      ${this.permGroups(permView.features, "feat")}
      ${button("💾 ذخیره قابلیت‌ها", { id: "save-features", full: true })}

      <h3 class="text-sm text-slate-400 mt-6 mb-2">🛡 دسترسی‌های ادمین نماینده</h3>
      ${this.permGroups(permView.admin, "adm")}
      ${button("💾 ذخیره دسترسی‌ها", { id: "save-admin", full: true })}
    `;

    document.getElementById("save-features").addEventListener("click", () => this.savePerm("feat", permView.features.defs, Api.admin.saveResellerFeatures));
    document.getElementById("save-admin").addEventListener("click", () => this.savePerm("adm", permView.admin.defs, Api.admin.saveResellerAdminPermissions));
  },

  permGroups(view, prefix) {
    const byGroup = {};
    for (const def of view.defs) (byGroup[def.group] ||= []).push(def);
    return view.groups
      .map((group) =>
        card(`
        <p class="text-xs text-slate-400 mb-1">${group.title}</p>
        ${(byGroup[group.key] || []).map((def) => toggle(`${prefix}:${def.key}`, view.values[def.key], def.label)).join("")}
      `)
      )
      .join("");
  },

  async savePerm(prefix, defs, saveFn) {
    const values = {};
    root.querySelectorAll(`[data-toggle^="${prefix}:"]`).forEach((el) => {
      values[el.dataset.toggle.slice(prefix.length + 1)] = el.checked;
    });
    try {
      await saveFn(values);
      toast("ذخیره شد و برای همه نمایندگان اعمال شد ✅", "success");
    } catch (error) {
      toast("خطا در ذخیره‌سازی", "error");
    }
  },

  // ---------------------------------------------------------------- payg --
  async render_payg(page = 0) {
    const { items, total } = await Api.admin.payg(page);
    root.innerHTML = `
      <h3 class="text-sm text-slate-400 mb-2">سرویس‌های PAYG (${total})</h3>
      ${
        items.length
          ? items
              .map(
                (item) => card(`
              <div class="flex items-center justify-between mb-2">
                <p class="text-sm font-medium">سرویس #${item.service_id}</p>
                <span class="text-xs px-2 py-0.5 rounded-full ${item.suspended ? "bg-rose-900 text-rose-200" : "bg-emerald-800 text-emerald-200"}">${item.suspended ? "تعلیق" : "فعال"}</span>
              </div>
              <p class="text-xs text-slate-500 mb-2">کاربر: ${item.telegram_id}</p>
              ${button("🧾 لاگ کسر هزینه‌ها", { id: `payg-log-${item.id}`, variant: "ghost", full: true })}
              <div id="payg-log-box-${item.id}" class="mt-2"></div>
            `),
                ""
              )
              .join("")
          : card(`<p class="text-sm text-slate-500 text-center">سرویس PAYG ثبت نشده.</p>`)
      }
    `;
    items.forEach((item) => {
      document.getElementById(`payg-log-${item.id}`).addEventListener("click", async () => {
        const { entries, sums } = await Api.admin.paygCosts(item.id);
        const totals = { creation: 0, daily: 0, data: 0, ...Object.fromEntries(sums.map((s) => [s.type, s.total])) };
        document.getElementById(`payg-log-box-${item.id}`).innerHTML = `
          <div class="text-xs text-slate-400 border-t border-slate-800 pt-2 space-y-1">
            <p>🆕 هزینه ایجاد: ${fa(totals.creation)} تومان</p>
            <p>📅 هزینه روزانه: ${fa(totals.daily)} تومان</p>
            <p>📡 هزینه مصرف داده: ${fa(totals.data)} تومان</p>
          </div>
          ${entries
            .map((e) => `<div class="text-xs text-slate-500 border-t border-slate-800 pt-1 mt-1">${new Date(e.createdAt).toLocaleString("fa-IR")} · ${e.type} · ${fa(e.amount)} تومان</div>`)
            .join("")}
        `;
      });
    });
  },

  // ------------------------------------------------------------ settings --
  async render_settings() {
    const s = await Api.admin.settings();
    root.innerHTML = `
      ${card(`
        ${field("آیدی دریافت رسید (کارت به کارت)", { id: "set-idcard", value: s.id_card })}
        ${field("حداقل موجودی نمایندگی", { id: "set-minbal", type: "number", value: s.reseller_min_balance })}
        ${field("هزینه راه‌اندازی نمایندگی", { id: "set-fee", type: "number", value: s.reseller_setup_fee })}
        ${toggle("first_payment", s.first_payment, "پیام تخفیف اولین پرداخت")}
        ${toggle("refund_enabled", s.refund_enabled, "فعال بودن لغو و مرجوعی")}
        ${field("مهلت مرجوعی (ساعت)", { id: "set-refundh", type: "number", value: s.refund_hours })}
        ${toggle("nowpayments_enabled", s.nowpayments_enabled, "درگاه ارز دیجیتال (NowPayments)")}
      `)}
      <h3 class="text-sm text-slate-400 mt-5 mb-2">🏦 درگاه‌های پرداخت</h3>
      ${card(s.pay.map((g) => toggle(`pay:${g.text}`, g.value, g.text)).join(""))}
      ${button("💾 ذخیره تنظیمات", { id: "settings-save", full: true })}
    `;
    document.getElementById("settings-save").addEventListener("click", async () => {
      const pay = s.pay.map((g) => ({ ...g, value: root.querySelector(`[data-toggle="pay:${g.text}"]`).checked }));
      const payload = {
        id_card: document.getElementById("set-idcard").value.trim(),
        reseller_min_balance: Number(document.getElementById("set-minbal").value || 0),
        reseller_setup_fee: Number(document.getElementById("set-fee").value || 0),
        refund_hours: Number(document.getElementById("set-refundh").value || 0),
        first_payment: root.querySelector('[data-toggle="first_payment"]').checked,
        refund_enabled: root.querySelector('[data-toggle="refund_enabled"]').checked,
        nowpayments_enabled: root.querySelector('[data-toggle="nowpayments_enabled"]').checked,
        pay,
      };
      try {
        await Api.admin.updateSettings(payload);
        toast("تنظیمات ذخیره شد ✅", "success");
      } catch (error) {
        toast("خطا در ذخیره‌سازی", "error");
      }
    });
  },

  // ------------------------------------------------------------- tickets --
  async render_tickets() {
    const { items } = await Api.admin.tickets();
    root.innerHTML = items.length
      ? items
          .map(
            (t) => card(`
        <div class="flex items-center justify-between mb-1">
          <p class="text-sm font-medium">${t.subject} <span class="text-xs text-slate-500">#${t.id}</span></p>
          <span class="text-xs px-2 py-0.5 rounded-full bg-slate-800">${{ open: "🟡 باز", answered: "🟢 پاسخ داده شد", closed: "⚪️ بسته" }[t.status]}</span>
        </div>
        <p class="text-xs text-slate-500 mb-2">👤 ${t.telegram_id}</p>
        <p class="text-sm mb-3">${t.message}</p>
        ${t.reply ? `<div class="bg-slate-800 rounded-xl p-2 text-xs text-emerald-300 mb-3">📩 ${t.reply}</div>` : ""}
        ${
          t.status !== "closed"
            ? `<textarea id="reply-${t.id}" rows="2" placeholder="پاسخ ..." class="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm mb-2"></textarea>
               <div class="flex gap-2">
                 ${button("📨 ارسال پاسخ", { id: `reply-btn-${t.id}` })}
                 ${button("✅ بستن تیکت", { id: `close-btn-${t.id}`, variant: "ghost" })}
               </div>`
            : ""
        }
      `),
            ""
          )
          .join("")
      : card(`<p class="text-sm text-slate-500 text-center">تیکتی وجود ندارد.</p>`);

    items
      .filter((t) => t.status !== "closed")
      .forEach((t) => {
        document.getElementById(`reply-btn-${t.id}`).addEventListener("click", async () => {
          const reply = document.getElementById(`reply-${t.id}`).value.trim();
          if (!reply) return toast("متن پاسخ را وارد کنید", "error");
          await Api.admin.replyTicket(t.id, reply);
          toast("پاسخ ارسال شد ✅", "success");
          this.render_tickets();
        });
        document.getElementById(`close-btn-${t.id}`).addEventListener("click", async () => {
          await Api.admin.closeTicket(t.id);
          this.render_tickets();
        });
      });
  },
};
