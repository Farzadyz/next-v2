// Thin fetch wrapper: every call is authenticated with Telegram's initData,
// exactly as the backend's webapp/auth.js middleware expects it.
const tg = window.Telegram?.WebApp;
tg?.ready();
tg?.expand();

const initData = tg?.initData || "";

async function api(method, path, body) {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json", "X-Telegram-Init-Data": initData },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try {
    data = await res.json();
  } catch (error) {
    data = null;
  }
  if (!res.ok) throw Object.assign(new Error(data?.error || "request_failed"), { status: res.status, code: data?.error });
  return data;
}

const Api = {
  me: () => api("GET", "/webapp/api/me"),
  wallet: () => api("GET", "/webapp/api/wallet"),
  transactions: () => api("GET", "/webapp/api/transactions"),
  services: () => api("GET", "/webapp/api/services"),
  resellerStatus: () => api("GET", "/webapp/api/reseller"),
  requestReseller: (bot_token) => api("POST", "/webapp/api/reseller/request", { bot_token }),
  tickets: () => api("GET", "/webapp/api/tickets"),
  createTicket: (subject, message) => api("POST", "/webapp/api/tickets", { subject, message }),

  // ---------------------------------------------------------------- shop --
  purchaseMeta: () => api("GET", "/webapp/api/purchase/meta"),
  purchasePlans: (connection, type = "normal") => api("GET", `/webapp/api/purchase/plans?connection=${connection}&type=${type}`),
  purchaseLocations: (type = "normal") => api("GET", `/webapp/api/purchase/locations?type=${type}`),
  purchaseCustomOptions: () => api("GET", "/webapp/api/purchase/custom-options"),
  purchaseQuote: (payload) => api("POST", "/webapp/api/purchase/quote", payload),
  purchaseFree: () => api("POST", "/webapp/api/purchase/free"),
  purchasePayg: (payload) => api("POST", "/webapp/api/purchase/payg", payload),

  payWithWallet: (paymentId) => api("POST", `/webapp/api/payments/${paymentId}/pay-wallet`),
  payWithGateway: (paymentId, gateway) => api("POST", `/webapp/api/payments/${paymentId}/pay-gateway`, { gateway }),
  purchaseGateways: () => api("GET", "/webapp/api/purchase/gateways"),
  applyCoupon: (paymentId, code) => api("POST", `/webapp/api/payments/${paymentId}/coupon`, { code }),
  referralInfo: () => api("GET", "/webapp/api/referral"),

  renewQuote: (serviceId) => api("POST", `/webapp/api/services/${serviceId}/renew/quote`),

  // ------------------------------------------------------- service manage --
  serviceManage: (serviceId) => api("GET", `/webapp/api/services/${serviceId}/manage`),
  serviceLinks: (serviceId) => api("GET", `/webapp/api/services/${serviceId}/links`),
  toggleServiceStatus: (serviceId) => api("POST", `/webapp/api/services/${serviceId}/toggle-status`),
  revokeServiceLink: (serviceId) => api("POST", `/webapp/api/services/${serviceId}/revoke-link`),
  deleteService: (serviceId) => api("DELETE", `/webapp/api/services/${serviceId}`),
  serviceUpgrades: (serviceId) => api("GET", `/webapp/api/services/${serviceId}/upgrades`),
  purchaseUpgrade: (serviceId, upgradeId) => api("POST", `/webapp/api/services/${serviceId}/upgrade`, { upgrade_id: upgradeId }),
  serviceRefundInfo: (serviceId) => api("GET", `/webapp/api/services/${serviceId}/refund`),
  refundService: (serviceId) => api("POST", `/webapp/api/services/${serviceId}/refund`),
  transferService: (serviceId, targetId) => api("POST", `/webapp/api/services/${serviceId}/transfer`, { target_id: targetId }),

  walletGateways: () => api("GET", "/webapp/api/wallet/gateways"),
  walletTopup: (amount, gateway) => api("POST", "/webapp/api/wallet/topup", { amount, gateway }),
  walletTopupCardReceipt: (topupId, image_base64) => api("POST", `/webapp/api/wallet/topup/card/${topupId}/receipt`, { image_base64 }),
  checkCryptoTopup: (id) => api("POST", `/webapp/api/wallet/topup/crypto/${id}/check`),

  admin: {
    servers: () => api("GET", "/webapp/api/admin/servers"),
    createServer: (payload) => api("POST", "/webapp/api/admin/servers", payload),
    updateServer: (id, payload) => api("PUT", `/webapp/api/admin/servers/${id}`, payload),
    deleteServer: (id) => api("DELETE", `/webapp/api/admin/servers/${id}`),

    searchUsers: (q) => api("GET", `/webapp/api/admin/users?q=${encodeURIComponent(q)}`),
    adjustBalance: (id, delta) => api("POST", `/webapp/api/admin/users/${id}/balance`, { delta }),
    setBlocked: (id, blocked) => api("POST", `/webapp/api/admin/users/${id}/block`, { blocked }),
    userServices: (id) => api("GET", `/webapp/api/admin/users/${id}/services`),

    resellers: () => api("GET", "/webapp/api/admin/resellers"),
    resellerPermissions: () => api("GET", "/webapp/api/admin/resellers/permissions"),
    saveResellerFeatures: (values) => api("PUT", "/webapp/api/admin/resellers/permissions/features", values),
    saveResellerAdminPermissions: (values) => api("PUT", "/webapp/api/admin/resellers/permissions/admin", values),

    payg: (page = 0) => api("GET", `/webapp/api/admin/payg?page=${page}`),
    paygCosts: (id, page = 0) => api("GET", `/webapp/api/admin/payg/${id}/costs?page=${page}`),

    settings: () => api("GET", "/webapp/api/admin/settings"),
    updateSettings: (payload) => api("PUT", "/webapp/api/admin/settings", payload),

    tickets: (status) => api("GET", `/webapp/api/admin/tickets${status ? "?status=" + status : ""}`),
    replyTicket: (id, reply) => api("POST", `/webapp/api/admin/tickets/${id}/reply`, { reply }),
    closeTicket: (id) => api("POST", `/webapp/api/admin/tickets/${id}/close`),
  },
};
