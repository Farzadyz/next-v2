// ============================================================================
// Regular-user dashboard: Buy, Wallet (+ gateway top-up), Services (+ renew),
// Support, and a "More" tab (profile, connection tutorials, reseller).
// Mounted by app.js once /webapp/api/me reports role === "user".
//
// Every write-flow here (buy / renew / top-up / test config) mirrors a bot
// action 1:1 (see app/webapp/controllers/shopApi.js for the mapping) so this
// is a complete standalone replacement for the bot's text menu, not a subset
// of it.
// ============================================================================

const ERROR_MESSAGES = {
  invalid_request: "درخواست نامعتبر است.",
  plan_not_found: "پلن یافت نشد.",
  invalid_source: "درخواست نامعتبر است.",
  already_used: "شما قبلا از تست رایگان استفاده کرده‌اید.",
  create_failed: "خطا در ساخت سرویس. با پشتیبانی تماس بگیرید.",
  not_enabled: "این روش خرید غیرفعال است.",
  not_configured: "این قابلیت هنوز توسط مدیریت تنظیم نشده است.",
  location_required: "انتخاب لوکیشن الزامی است.",
  insufficient_balance: "موجودی کیف پول شما کافی نیست.",
  not_renewable: "این سرویس قابل تمدید نیست.",
  not_found: "یافت نشد.",
  forbidden: "دسترسی مجاز نیست.",
  already_paid: "این فاکتور قبلا پرداخت شده است.",
  renew_failed: "تمدید با خطا مواجه شد.",
  renewal_wallet_only: "تمدید فقط از طریق کیف پول امکان‌پذیر است.",
  gateway_error: "ساخت لینک پرداخت با خطا مواجه شد.",
  gateway_disabled: "این درگاه غیرفعال است.",
  gateway_not_supported_for_purchase: "این روش برای خرید مستقیم پشتیبانی نمی‌شود.",
  invalid_amount: "مبلغ نامعتبر است.",
  amount_out_of_range: "مبلغ باید بین ۵,۰۰۰ تا ۱,۰۰۰,۰۰۰ تومان باشد.",
  image_required: "لطفا تصویر رسید را انتخاب کنید.",
  already_reviewed: "این رسید قبلا بررسی شده است.",
  pending: "پرداخت هنوز تایید نشده؛ چند لحظه دیگر دوباره بررسی کنید.",
  already_done: "این تراکنش قبلا نهایی شده است.",
  coupon_not_supported: "کد تخفیف برای تمدید سرویس قابل استفاده نیست.",
  coupon_already_applied: "قبلا یک کد تخفیف روی این فاکتور اعمال شده است.",
  coupon_agent_blocked: "کاربران نماینده امکان استفاده از کد تخفیف را ندارند.",
  coupon_invalid: "کد تخفیف نامعتبر است یا ظرفیت آن تکمیل شده.",
  coupon_already_used: "شما قبلا از این کد تخفیف استفاده کرده‌اید.",
  not_eligible: "امکان ارتقا وجود ندارد؛ ابتدا باید حداقل ۸۰٪ از حجم سرویس مصرف شود.",
  upgrade_failed: "ارتقا با خطا مواجه شد.",
  disabled: "لغو و بازگشت وجه غیرفعال است.",
  expired: "مهلت لغو و بازگشت وجه این سرویس به پایان رسیده است.",
  target_not_found: "کاربری با این آیدی در ربات یافت نشد.",
  not_supported: "این قابلیت برای این سرویس پشتیبانی نمی‌شود.",
  server_error: "خطای سرور. لطفا دوباره تلاش کنید.",
};
const errMsg = (code) => ERROR_MESSAGES[code] || "خطایی رخ داد. لطفا دوباره تلاش کنید.";

const GATEWAY_LABELS = {
  CARD: "💳 کارت به کارت",
  PAYSTAR: "🌟 پی‌استار",
  ZARINPAL: "💠 زرین‌پال",
  ZIBAL: "🧩 زیبال",
  NOVINPAL: "👑 نوین‌پی",
  POLAM: "💥 پلام",
  TABAPAY: "🧬 تاباپی",
  SIZAPAY: "⭐️ سیزپی",
  ZIRGOZAR: "🔗 زیرگذر",
  TERAPAY: "💳 تراپی (کارت خودکار)",
  RIALIT: "🏦 ریالیت",
  NOWPEYMENT: "💵 ارز دیجیتال",
};

const UserApp = {
  tab: "buy",
  tabs: [
    { key: "buy", icon: "🛒", label: "خرید سرویس" },
    { key: "wallet", icon: "💳", label: "کیف پول" },
    { key: "services", icon: "📦", label: "سرویس‌ها" },
    { key: "support", icon: "💬", label: "پشتیبانی" },
    { key: "more", icon: "⚙️", label: "بیشتر" },
  ],

  async mount() {
    renderTabs(this.tabs, this.tab, (key) => {
      this.tab = key;
      this.render();
    });
    await this.render();
  },

  async render() {
    root.innerHTML = `<div class="flex justify-center py-10 text-slate-500">در حال بارگذاری ...</div>`;
    renderTabs(this.tabs, this.tab, (key) => {
      this.tab = key;
      this.render();
    });
    try {
      if (this.tab === "buy") await this.renderBuy();
      else if (this.tab === "wallet") await this.renderWallet();
      else if (this.tab === "services") await this.renderServices();
      else if (this.tab === "support") await this.renderSupport();
      else await this.renderMore();
    } catch (error) {
      console.error(error);
      root.innerHTML = card(`<p class="text-rose-400 text-sm">خطا در دریافت اطلاعات. لطفا دوباره تلاش کنید.</p>`);
    }
  },

  // ===================================================================
  // BUY
  // ===================================================================
  async renderBuy() {
    const meta = await Api.purchaseMeta();
    const options = [];
    if (meta.single) options.push({ key: "single", icon: "🖥", title: "تک لوکیشن", desc: "انتخاب از پلن‌های آماده روی یک سرور مشخص" });
    if (meta.multi) options.push({ key: "multi", icon: "🌍", title: "مولتی لوکیشن", desc: "یک اشتراک با دسترسی به همه سرورها" });
    if (meta.custom) options.push({ key: "custom", icon: "🎛", title: "پلن سفارشی", desc: "حجم و مدت زمان را خودتان انتخاب کنید" });
    if (meta.free) options.push({ key: "free", icon: "🎁", title: "دریافت تست رایگان", desc: "یک‌بار برای هر کاربر" });
    if (meta.payg_multi) options.push({ key: "payg_multi", icon: "⚡️", title: "پرداخت به ازای مصرف (مولتی)", desc: `شارژ اولیه ${fa(meta.payg_base_amount)} تومان` });
    if (meta.payg_single) options.push({ key: "payg_single", icon: "⚡️", title: "پرداخت به ازای مصرف (تک لوکیشن)", desc: `شارژ اولیه ${fa(meta.payg_base_amount)} تومان` });

    root.innerHTML =
      (meta.first_payment_bonus
        ? card(`<p class="text-xs text-emerald-400">🎉 برای اولین خرید خود می‌توانید همزمان با ثبت سفارش، بدون شارژ کیف پول، پرداخت کنید.</p>`, "mb-3")
        : "") +
      (options.length
        ? options
            .map(
              (o) => `
        <button data-buy="${o.key}" class="w-full text-right block bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div class="flex items-center gap-3">
            <span class="text-2xl">${o.icon}</span>
            <div class="flex-1">
              <p class="text-sm font-bold">${o.title}</p>
              <p class="text-xs text-slate-400 mt-0.5">${o.desc}</p>
            </div>
            <span class="text-slate-600">‹</span>
          </div>
        </button>`
            )
            .join('<div class="h-2"></div>')
        : card(`<p class="text-sm text-slate-500 text-center">در حال حاضر امکان خرید فعال نیست.</p>`));

    root.querySelectorAll("[data-buy]").forEach((btn) =>
      btn.addEventListener("click", () => {
        const key = btn.dataset.buy;
        if (key === "free") return this.buyFree();
        if (key === "payg_multi") return this.buyPayg("multi");
        if (key === "payg_single") return this.buyPaygSingle();
        this.buyWizard(key, meta.economic);
      })
    );
  },

  async buyFree() {
    if (!confirm("آیا مطمئن هستید که می‌خواهید سرویس تست رایگان خود را دریافت کنید؟")) return;
    try {
      const result = await Api.purchaseFree();
      toast("سرویس تست شما ساخته شد 🎉", "success");
      this.tab = "services";
      await this.mount();
    } catch (error) {
      toast(errMsg(error.code), "error");
    }
  },

  async buyPayg(mode) {
    try {
      const result = await Api.purchasePayg({ mode });
      toast(`سرویس PAYG با موفقیت ساخته شد (سرویس #${result.service_id})`, "success");
      this.tab = "services";
      await this.mount();
    } catch (error) {
      toast(errMsg(error.code), "error");
    }
  },

  async buyPaygSingle() {
    const { items } = await Api.purchaseLocations("normal");
    if (!items.length) return toast("لوکیشنی یافت نشد", "error");
    const overlay = openModal("انتخاب لوکیشن (PAYG)", this.locationListHtml(items));
    overlay.querySelectorAll("[data-loc]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        try {
          const result = await Api.purchasePayg({ mode: "single", locationId: btn.dataset.loc });
          closeModal();
          toast(`سرویس PAYG با موفقیت ساخته شد (سرویس #${result.service_id})`, "success");
          this.tab = "services";
          await this.mount();
        } catch (error) {
          toast(errMsg(error.code), "error");
        }
      })
    );
  },

  locationListHtml(items) {
    return items
      .map(
        (loc) => `
      <button data-loc="${loc.id}" class="w-full text-right flex items-center justify-between bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2 text-sm">
        <span>${loc.location}</span>
        ${loc.price ? `<span class="text-xs text-amber-400">+${fa(loc.price)} تومان</span>` : ""}
      </button>`
      )
      .join("");
  },

  // ---- fixed plan (single/multi) + custom plan wizard ------------------
  async buyWizard(kind, economicAvailable) {
    if (kind === "custom") return this.buyCustomStep1();
    const connection = kind === "multi" ? "multi" : "single";
    this.buyPlanStep({ connection, type: "normal", economicAvailable });
  },

  async buyPlanStep({ connection, type, economicAvailable }) {
    const { items } = await Api.purchasePlans(connection, type);
    const title = connection === "multi" ? "پلن مولتی لوکیشن" : type === "economic" ? "پلن تک لوکیشن (اقتصادی)" : "پلن تک لوکیشن";
    const switcher =
      connection === "single" && economicAvailable
        ? `<div class="flex gap-2 mb-3">
            ${button("عادی", { id: "switch-normal", variant: type === "normal" ? "primary" : "ghost" })}
            ${button("اقتصادی", { id: "switch-economic", variant: type === "economic" ? "primary" : "ghost" })}
          </div>`
        : "";
    const overlay = openModal(
      title,
      switcher +
        (items.length
          ? items
              .map(
                (p) => `
          <button data-plan="${p.id}" class="w-full text-right bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2">
            <div class="flex items-center justify-between">
              <span class="text-sm font-bold">${p.name}</span>
              <span class="text-sm text-sky-400">${fa(p.price)} تومان</span>
            </div>
            <div class="text-xs text-slate-400 mt-1">⏱ ${p.time} روز &nbsp; 📶 ${p.traficc} گیگ</div>
          </button>`
              )
              .join("")
          : `<p class="text-sm text-slate-500 text-center py-6">پلنی در این دسته موجود نیست.</p>`)
    );

    overlay.querySelector("#switch-normal")?.addEventListener("click", () => this.buyPlanStep({ connection, type: "normal", economicAvailable }));
    overlay.querySelector("#switch-economic")?.addEventListener("click", () => this.buyPlanStep({ connection, type: "economic", economicAvailable }));

    overlay.querySelectorAll("[data-plan]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        const pelanId = btn.dataset.plan;
        if (connection === "multi") {
          try {
            const { quote } = await Api.purchaseQuote({ source: "multi", pelanId });
            this.showQuote(quote);
          } catch (error) {
            toast(errMsg(error.code), "error");
          }
        } else {
          this.buyPlanLocationStep({ pelanId, type });
        }
      })
    );
  },

  async buyPlanLocationStep({ pelanId, type }) {
    const { items } = await Api.purchaseLocations(type);
    if (!items.length) return toast("لوکیشنی برای این پلن موجود نیست", "error");
    const overlay = openModal("انتخاب لوکیشن", this.locationListHtml(items));
    overlay.querySelectorAll("[data-loc]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        try {
          const { quote } = await Api.purchaseQuote({ source: "plan", pelanId, locationId: btn.dataset.loc });
          this.showQuote(quote);
        } catch (error) {
          toast(errMsg(error.code), "error");
        }
      })
    );
  },

  // ---- custom plan: pick traffic -> day -> location ---------------------
  async buyCustomStep1() {
    const opts = await Api.purchaseCustomOptions();
    const overlay = openModal(
      "حجم سرویس را انتخاب کنید",
      (opts.traficcV || [])
        .map((v) => `<button data-t="${v}" class="w-full text-right bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2 text-sm">${v} گیگ &nbsp; <span class="text-xs text-slate-400">(${fa(v * opts.traficcP)} تومان)</span></button>`)
        .join("")
    );
    overlay.querySelectorAll("[data-t]").forEach((btn) =>
      btn.addEventListener("click", () => this.buyCustomStep2(opts, Number(btn.dataset.t)))
    );
  },

  async buyCustomStep2(opts, traficc) {
    const overlay = openModal(
      "مدت زمان سرویس را انتخاب کنید",
      (opts.timeV || [])
        .map((v) => `<button data-d="${v}" class="w-full text-right bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2 text-sm">${v} روز &nbsp; <span class="text-xs text-slate-400">(${fa(v * opts.timeP)} تومان)</span></button>`)
        .join("")
    );
    overlay.querySelectorAll("[data-d]").forEach((btn) =>
      btn.addEventListener("click", () => this.buyCustomStep3(traficc, Number(btn.dataset.d)))
    );
  },

  async buyCustomStep3(traficc, day) {
    const { items } = await Api.purchaseLocations("normal");
    if (!items.length) return toast("لوکیشنی موجود نیست", "error");
    const overlay = openModal("انتخاب لوکیشن", this.locationListHtml(items));
    overlay.querySelectorAll("[data-loc]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        try {
          const { quote } = await Api.purchaseQuote({ source: "custom", traficc, day, locationId: btn.dataset.loc });
          this.showQuote(quote);
        } catch (error) {
          toast(errMsg(error.code), "error");
        }
      })
    );
  },

  // ---- shared: final quote + payment step (also used by renew) ---------
  async showQuote(quote, { renewal = false } = {}) {
    const overlay = openModal(
      renewal ? "تمدید سرویس" : "پیش‌فاکتور خرید",
      card(`
        ${quote.name ? `<p class="text-sm font-bold mb-1">${quote.name}</p>` : ""}
        <div class="grid grid-cols-2 gap-2 text-xs text-slate-400 my-2">
          <div>⏱ مدت: <span class="text-slate-200">${quote.day || quote.time} روز</span></div>
          <div>📶 حجم: <span class="text-slate-200">${quote.traficc} گیگ</span></div>
          ${quote.location_label ? `<div class="col-span-2">📍 لوکیشن: <span class="text-slate-200">${quote.location_label}</span></div>` : ""}
          ${quote.coupon ? `<div class="col-span-2 text-emerald-400">🎟 کد تخفیف اعمال شد: ${quote.coupon}</div>` : ""}
        </div>
        <p class="text-lg font-bold mt-2" id="quote-price">
          ${quote.original_price ? `<span class="line-through text-slate-500 text-sm ml-2">${fa(quote.original_price)}</span>` : ""}
          ${fa(quote.price)} <span class="text-xs font-normal text-slate-400">تومان</span>
        </p>
      `) +
        (renewal || quote.coupon
          ? ""
          : `<button id="coupon-toggle" class="text-xs text-sky-400 mt-2">🎟 کد تخفیف دارم</button>
             <div id="coupon-box" class="hidden mt-2 flex gap-2">
               <input id="coupon-code" placeholder="کد تخفیف" class="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm outline-none focus:border-sky-500" />
               ${button("اعمال", { id: "coupon-apply", variant: "ghost" })}
             </div>`) +
        `<div class="flex flex-col gap-2 mt-3">
          ${button("💰 پرداخت از کیف پول", { id: "pay-wallet", full: true })}
          ${renewal ? "" : button("🌐 پرداخت با درگاه", { id: "pay-gateway", full: true, variant: "ghost" })}
        </div>`
    );

    overlay.querySelector("#coupon-toggle")?.addEventListener("click", () => {
      overlay.querySelector("#coupon-box").classList.remove("hidden");
      overlay.querySelector("#coupon-toggle").classList.add("hidden");
    });
    overlay.querySelector("#coupon-apply")?.addEventListener("click", async (event) => {
      const code = overlay.querySelector("#coupon-code").value.trim();
      if (!code) return toast("کد تخفیف را وارد کنید", "error");
      event.target.disabled = true;
      try {
        const { quote: updated } = await Api.applyCoupon(quote.payment_id, code);
        toast("کد تخفیف اعمال شد ✅", "success");
        this.showQuote({ ...quote, ...updated }, { renewal });
      } catch (error) {
        toast(errMsg(error.code), "error");
        event.target.disabled = false;
      }
    });

    overlay.querySelector("#pay-wallet").addEventListener("click", async (event) => {
      event.target.disabled = true;
      try {
        const result = await Api.payWithWallet(quote.payment_id);
        closeModal();
        toast(result.renewed ? "تمدید با موفقیت انجام شد ✅" : `خرید با موفقیت انجام شد ✅ (سرویس #${result.service_id})`, "success");
        this.tab = "services";
        await this.mount();
      } catch (error) {
        toast(errMsg(error.code), "error");
        event.target.disabled = false;
      }
    });

    overlay.querySelector("#pay-gateway")?.addEventListener("click", async () => this.showGatewayPicker(quote.payment_id));
  },

  async showGatewayPicker(paymentId) {
    const { gateways } = await Api.purchaseGateways();
    if (!gateways.length) return toast("درگاهی فعال نیست", "error");
    const overlay = openModal(
      "انتخاب درگاه پرداخت",
      gateways
        .map((g) => `<button data-gw="${g.code}" class="w-full text-right bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2 text-sm">${GATEWAY_LABELS[g.code] || g.code}</button>`)
        .join("")
    );
    overlay.querySelectorAll("[data-gw]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        try {
          const result = await Api.payWithGateway(paymentId, btn.dataset.gw);
          this.handleGatewayResult(result);
        } catch (error) {
          toast(errMsg(error.code), "error");
        }
      })
    );
  },

  handleGatewayResult(result) {
    if (result.kind === "redirect") {
      closeModal();
      toast("در حال انتقال به درگاه پرداخت ...", "info");
      tg?.openLink ? tg.openLink(result.url) : window.open(result.url, "_blank");
      return;
    }
    if (result.kind === "crypto") return this.showCryptoInvoice(result);
    if (result.kind === "manual_card") return this.showCardInstructions(result);
  },

  showCryptoInvoice(result) {
    const overlay = openModal(
      "پرداخت ارز دیجیتال",
      card(`
        <p class="text-xs text-slate-400 mb-2">مبلغ زیر را به آدرس مشخص شده واریز کنید:</p>
        <p class="text-lg font-bold mb-1">${result.pay_amount} <span class="text-xs">${result.pay_currency}</span></p>
        <div class="bg-slate-800 rounded-xl p-2 text-xs break-all mb-2" style="direction:ltr">${result.pay_address}</div>
        ${button("📋 کپی آدرس", { id: "copy-addr", full: true, variant: "ghost" })}
      `) + `<div class="mt-3">${button("♻️ بررسی پرداخت", { id: "check-crypto", full: true })}</div>`
    );
    overlay.querySelector("#copy-addr").addEventListener("click", () => copyText(result.pay_address));
    overlay.querySelector("#check-crypto").addEventListener("click", async (event) => {
      event.target.disabled = true;
      event.target.textContent = "⏳ در حال بررسی ...";
      try {
        const check = await Api.checkCryptoTopup(result.topup_id);
        closeModal();
        toast(check.purchased ? "پرداخت تایید شد، سرویس شما ساخته شد ✅" : `کیف پول شما به مبلغ ${fa(check.credited)} تومان شارژ شد ✅`, "success");
        this.tab = check.purchased ? "services" : "wallet";
        await this.mount();
      } catch (error) {
        toast(errMsg(error.code), error.code === "pending" ? "info" : "error");
        event.target.disabled = false;
        event.target.textContent = "♻️ بررسی پرداخت";
      }
    });
  },

  showCardInstructions(result) {
    const overlay = openModal(
      "پرداخت کارت به کارت",
      card(`
        <p class="text-xs text-slate-400 mb-2">مبلغ زیر را به شماره کارت واریز کرده و سپس تصویر رسید را ارسال کنید:</p>
        <p class="text-lg font-bold mb-2">${fa(result.amount)} <span class="text-xs font-normal text-slate-400">تومان</span></p>
        <div class="bg-slate-800 rounded-xl p-3 text-center text-sm mb-2" style="direction:ltr">${result.card_number || "-"}</div>
        ${button("📋 کپی شماره کارت", { id: "copy-card", full: true, variant: "ghost" })}
      `) +
        `<label class="block mt-3">
          <span class="text-xs text-slate-400 mb-1 block">تصویر رسید</span>
          <input id="receipt-file" type="file" accept="image/*" capture="environment" class="w-full text-xs text-slate-300 file:ml-2 file:rounded-lg file:border-0 file:bg-slate-800 file:px-3 file:py-2 file:text-slate-100" />
        </label>
        <div class="mt-3">${button("📨 ارسال رسید", { id: "send-receipt", full: true })}</div>`
    );
    overlay.querySelector("#copy-card").addEventListener("click", () => copyText(result.card_number || ""));
    overlay.querySelector("#send-receipt").addEventListener("click", async (event) => {
      const file = overlay.querySelector("#receipt-file").files[0];
      if (!file) return toast("لطفا تصویر رسید را انتخاب کنید", "error");
      event.target.disabled = true;
      event.target.textContent = "⏳ در حال ارسال ...";
      try {
        const base64 = await fileToBase64(file);
        await Api.walletTopupCardReceipt(result.topup_id, base64);
        closeModal();
        toast("رسید ارسال شد؛ پس از تایید ادمین کیف پول شما شارژ می‌شود ✅", "success");
      } catch (error) {
        toast(errMsg(error.code), "error");
        event.target.disabled = false;
        event.target.textContent = "📨 ارسال رسید";
      }
    });
  },

  // ===================================================================
  // WALLET
  // ===================================================================
  async renderWallet() {
    const [{ balance }, { items }] = await Promise.all([Api.wallet(), Api.transactions()]);
    root.innerHTML = `
      ${card(`
        <p class="text-slate-400 text-xs mb-1">موجودی کیف پول</p>
        <p class="text-3xl font-bold">${fa(balance)} <span class="text-sm font-normal text-slate-400">تومان</span></p>
        <div class="mt-3">${button("➕ افزایش موجودی", { id: "topup-open", full: true })}</div>
      `)}
      <h3 class="text-sm text-slate-400 mt-5 mb-2">تاریخچه تراکنش‌ها</h3>
      ${
        items.length
          ? items
              .map((item) =>
                card(`
              <div class="flex items-center justify-between">
                <div>
                  <p class="text-sm font-medium">${GATEWAY_LABELS[item.gateway] || item.gateway}</p>
                  <p class="text-xs text-slate-500">${new Date(item.at).toLocaleString("fa-IR")}</p>
                </div>
                <div class="text-left">
                  <p class="text-sm font-bold">${fa(item.amount)} تومان</p>
                  <p class="text-xs ${item.status === "paid" ? "text-emerald-400" : "text-amber-400"}">${item.status === "paid" ? "✅ موفق" : "⏳ در انتظار"}</p>
                </div>
              </div>
            `)
              )
              .join("")
          : card(`<p class="text-sm text-slate-500 text-center">هنوز تراکنشی ثبت نشده است.</p>`)
      }
    `;
    document.getElementById("topup-open").addEventListener("click", () => this.openTopupModal());
  },

  async openTopupModal() {
    const { gateways, min, max } = await Api.walletGateways();
    if (!gateways.length) return toast("درگاهی برای شارژ فعال نیست", "error");
    const overlay = openModal(
      "افزایش موجودی",
      field("مبلغ (تومان)", { id: "topup-amount", type: "number", placeholder: `بین ${fa(min)} تا ${fa(max)}` }) +
        `<p class="text-xs text-slate-400 mb-2">درگاه پرداخت را انتخاب کنید:</p>` +
        gateways
          .map((g) => `<button data-gw="${g.code}" class="w-full text-right bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2 text-sm">${GATEWAY_LABELS[g.code] || g.code}</button>`)
          .join("")
    );
    overlay.querySelectorAll("[data-gw]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        const amount = Number(document.getElementById("topup-amount").value);
        if (!amount) return toast("مبلغ را وارد کنید", "error");
        btn.disabled = true;
        try {
          const result = await Api.walletTopup(amount, btn.dataset.gw);
          this.handleGatewayResult(result);
        } catch (error) {
          toast(errMsg(error.code), "error");
          btn.disabled = false;
        }
      })
    );
  },

  // ===================================================================
  // SERVICES
  // ===================================================================
  async renderServices() {
    const { items } = await Api.services();
    root.innerHTML = items.length
      ? items.map((s, index) => this.serviceCard(s, index)).join("")
      : card(`<p class="text-sm text-slate-500 text-center">هنوز سرویسی ندارید.</p>`);

    root.querySelectorAll("[data-copy]").forEach((btn) => btn.addEventListener("click", () => copyText(btn.dataset.copy)));
    root.querySelectorAll("[data-qr]").forEach((btn) => btn.addEventListener("click", () => showQr(btn.dataset.qr)));
    root.querySelectorAll("[data-renew]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        try {
          const { quote } = await Api.renewQuote(btn.dataset.renew);
          this.showQuote({ ...quote, name: "تمدید سرویس #" + btn.dataset.renew }, { renewal: true });
        } catch (error) {
          toast(errMsg(error.code), "error");
        }
      })
    );
    root.querySelectorAll("[data-manage]").forEach((btn) =>
      btn.addEventListener("click", () => this.openManageModal(btn.dataset.manage))
    );
  },

  serviceCard(s, index) {
    const link = s.links.subscription_url || s.links.tunel || s.links.internal;
    return card(
      `
      <div class="flex items-center justify-between mb-2">
        <p class="font-medium text-sm">${s.kind === "payg" ? "⚡️ " : "📦 "}${s.name || "سرویس #" + s.id}</p>
        <span class="text-xs px-2 py-0.5 rounded-full bg-slate-800">${s.status}</span>
      </div>
      <div class="grid grid-cols-2 gap-2 text-xs text-slate-400 mb-3">
        <div>مصرف‌شده: <span class="text-slate-200">${s.used_traffic}</span></div>
        <div>باقیمانده: <span class="text-slate-200">${s.remaining}</span></div>
        ${s.expire ? `<div>انقضا: <span class="text-slate-200">${s.expire}</span></div>` : ""}
        ${s.kind === "payg" ? `<div>هزینه تاکنون: <span class="text-slate-200">${fa(s.total_cost)} تومان</span></div>` : ""}
      </div>
      <div class="flex gap-2 flex-wrap">
        ${
          link
            ? `${button("📋 کپی کانفیگ", { id: `copy-${index}` }).replace("id=", `data-copy="${link.replace(/"/g, "&quot;")}" id=`)}
               ${button("🔳 QR", { id: `qr-${index}`, variant: "ghost" }).replace("id=", `data-qr="${link.replace(/"/g, "&quot;")}" id=`)}`
            : `<p class="text-xs text-slate-500">لینک کانفیگ در دسترس نیست.</p>`
        }
        ${s.kind === "standard" ? button("🔄 تمدید", { id: `renew-${index}`, variant: "ghost" }).replace("id=", `data-renew="${s.id}" id=`) : ""}
        ${button("⚙️ مدیریت", { id: `manage-${index}`, variant: "ghost" }).replace("id=", `data-manage="${s.id}" id=`)}
      </div>
    `,
      "mb-3"
    );
  },

  // -------------------------------------------------------------------
  // Service management modal - full action set mirroring the bot's own
  // inline keyboard for a service (see app/bot/buttons/ButtonManager.js
  // InfoMyestErakkeyboard / app/webapp/controllers/serviceApi.js).
  // -------------------------------------------------------------------
  async openManageModal(serviceId) {
    let data;
    try {
      data = await Api.serviceManage(serviceId);
    } catch (error) {
      return toast(errMsg(error.code), "error");
    }
    this.renderManageModal(serviceId, data);
  },

  renderManageModal(serviceId, data) {
    const linksHtml = data.links.length
      ? data.links
          .map(
            (l, i) => `
        <div class="flex items-center justify-between bg-slate-800 rounded-xl px-3 py-2 mb-2">
          <span class="text-xs">${l.label}</span>
          <div class="flex gap-2">
            <button data-copy-link="${i}" class="text-xs text-sky-400">📋 کپی</button>
            <button data-qr-link="${i}" class="text-xs text-sky-400">🔳 QR</button>
          </div>
        </div>`
          )
          .join("")
      : `<p class="text-xs text-slate-500 mb-2">لینکی یافت نشد.</p>`;

    const upgradeHtml = data.upgrade.eligible
      ? data.upgrade.items.length
        ? data.upgrade.items
            .map(
              (u) => `
          <button data-upgrade="${u.id}" class="w-full text-right bg-slate-800 hover:bg-slate-700 rounded-xl px-4 py-3 mb-2 text-sm flex items-center justify-between">
            <span>${u.traficc} گیگ</span>
            <span class="text-sky-400">${fa(u.price)} تومان</span>
          </button>`
            )
            .join("")
        : `<p class="text-xs text-slate-500">بسته ارتقایی موجود نیست.</p>`
      : `<p class="text-xs text-slate-500">امکان ارتقا وجود ندارد؛ ابتدا باید حداقل ۸۰٪ از حجم سرویس مصرف شود${
          typeof data.upgrade.used_percent === "number" ? ` (فعلا ${data.upgrade.used_percent}٪)` : ""
        }.</p>`;

    const refundHtml = data.refund.eligible
      ? button(`💸 لغو و بازگشت وجه (${fa(data.refund.price)} تومان)`, { id: "mng-refund", full: true, variant: "danger" })
      : "";

    const overlay = openModal(
      `مدیریت سرویس #${serviceId}`,
      `
      <div class="mb-4">
        <p class="text-xs text-slate-400 mb-2">🔗 لینک‌های اتصال</p>
        ${linksHtml}
        ${button("🔐 تغییر لینک اتصال (پسوورد و سکرت)", { id: "mng-revoke", full: true, variant: "ghost" })}
      </div>
      <div class="mb-4">
        <p class="text-xs text-slate-400 mb-2">وضعیت اتصال موقت</p>
        ${button(data.status_api ? "غیرفعال کردن اتصال موقت ❌" : "فعال کردن اتصال موقت ✅", { id: "mng-toggle", full: true, variant: "ghost" })}
      </div>
      <div class="mb-4">
        <p class="text-xs text-slate-400 mb-2">🪜 ارتقا حجم اشتراک</p>
        ${upgradeHtml}
      </div>
      <div class="mb-4">
        <p class="text-xs text-slate-400 mb-2">♋️ منتقل کردن سرویس به کاربر دیگر</p>
        <div class="flex gap-2">
          <input id="mng-transfer-id" placeholder="آیدی عددی کاربر مقصد" class="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm outline-none focus:border-sky-500" />
          ${button("انتقال", { id: "mng-transfer", variant: "ghost" })}
        </div>
      </div>
      ${refundHtml}
      ${button("❌ حذف سرویس", { id: "mng-delete", full: true, variant: "danger" })}
      `
    );

    overlay.querySelectorAll("[data-copy-link]").forEach((btn) =>
      btn.addEventListener("click", () => copyText(data.links[Number(btn.dataset.copyLink)].link))
    );
    overlay.querySelectorAll("[data-qr-link]").forEach((btn) =>
      btn.addEventListener("click", () => showQr(data.links[Number(btn.dataset.qrLink)].link))
    );

    overlay.querySelector("#mng-revoke").addEventListener("click", async () => {
      if (!confirm("با این کار لینک فعلی از کار می‌افتد و باید لینک جدید را مجددا وارد کنید. ادامه می‌دهید؟")) return;
      try {
        const result = await Api.revokeServiceLink(serviceId);
        toast("لینک اتصال با موفقیت تغییر کرد ✅", "success");
        this.renderManageModal(serviceId, { ...data, links: result.items });
      } catch (error) {
        toast(errMsg(error.code), "error");
      }
    });

    overlay.querySelector("#mng-toggle").addEventListener("click", async (event) => {
      event.target.disabled = true;
      try {
        const result = await Api.toggleServiceStatus(serviceId);
        toast("وضعیت اتصال موقت با موفقیت تغییر کرد ✅", "success");
        this.renderManageModal(serviceId, { ...data, status_api: result.status_api });
      } catch (error) {
        toast(errMsg(error.code), "error");
        event.target.disabled = false;
      }
    });

    overlay.querySelectorAll("[data-upgrade]").forEach((btn) =>
      btn.addEventListener("click", async () => {
        if (!confirm("آیا مطمئن هستید که می‌خواهید این بسته ارتقا را خریداری کنید؟")) return;
        try {
          await Api.purchaseUpgrade(serviceId, btn.dataset.upgrade);
          toast("ارتقا با موفقیت انجام شد ✅", "success");
          closeModal();
          this.renderServices();
        } catch (error) {
          toast(errMsg(error.code), "error");
        }
      })
    );

    overlay.querySelector("#mng-transfer").addEventListener("click", async () => {
      const targetId = document.getElementById("mng-transfer-id").value.trim();
      if (!targetId) return toast("آیدی عددی کاربر مقصد را وارد کنید", "error");
      if (
        !confirm(
          "با منتقل کردن، دسترسی شما به این سرویس به طور کل از بین می‌رود و لینک‌های اتصال قبلی نیز تعویض می‌شوند. این عمل غیرقابل بازگشت است. ادامه می‌دهید؟"
        )
      )
        return;
      try {
        await Api.transferService(serviceId, targetId);
        toast("سرویس با موفقیت منتقل شد ✅", "success");
        closeModal();
        this.renderServices();
      } catch (error) {
        toast(errMsg(error.code), "error");
      }
    });

    overlay.querySelector("#mng-refund")?.addEventListener("click", async (event) => {
      if (!confirm("آیا مطمئن هستید که می‌خواهید این سرویس را لغو و مبلغ آن را به کیف پول بازگردانید؟")) return;
      event.target.disabled = true;
      try {
        await Api.refundService(serviceId);
        toast("لغو و بازگشت وجه با موفقیت انجام شد ✅", "success");
        closeModal();
        this.renderServices();
      } catch (error) {
        toast(errMsg(error.code), "error");
        event.target.disabled = false;
      }
    });

    overlay.querySelector("#mng-delete").addEventListener("click", async (event) => {
      if (!confirm("آیا از حذف این سرویس مطمئن هستید؟ این عمل غیرقابل بازگشت است.")) return;
      event.target.disabled = true;
      try {
        await Api.deleteService(serviceId);
        toast("سرویس با موفقیت حذف شد ✅", "success");
        closeModal();
        this.renderServices();
      } catch (error) {
        toast(errMsg(error.code), "error");
        event.target.disabled = false;
      }
    });
  },

  // ===================================================================
  // SUPPORT
  // ===================================================================
  async renderSupport() {
    const { items } = await Api.tickets();
    root.innerHTML = `
      ${card(`
        ${field("موضوع", { id: "ticket-subject", placeholder: "مثلا: مشکل در اتصال" })}
        <label class="block mb-3">
          <span class="text-xs text-slate-400 mb-1 block">پیام</span>
          <textarea id="ticket-message" rows="3" class="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-sky-500"></textarea>
        </label>
        ${button("📨 ارسال تیکت", { id: "ticket-submit", full: true })}
      `)}
      <h3 class="text-sm text-slate-400 mt-5 mb-2">تیکت‌های من</h3>
      ${
        items.length
          ? items
              .map((t) =>
                card(`
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-medium">${t.subject}</p>
                <span class="text-xs px-2 py-0.5 rounded-full bg-slate-800">${{ open: "🟡 باز", answered: "🟢 پاسخ داده شد", closed: "⚪️ بسته" }[t.status]}</span>
              </div>
              <p class="text-xs text-slate-400 mb-2">${t.message}</p>
              ${t.reply ? `<div class="bg-slate-800 rounded-xl p-2 text-xs text-emerald-300">📩 ${t.reply}</div>` : ""}
            `)
              )
              .join("")
          : card(`<p class="text-sm text-slate-500 text-center">تیکتی ثبت نکرده‌اید.</p>`)
      }
    `;
    document.getElementById("ticket-submit").addEventListener("click", async (event) => {
      const subject = document.getElementById("ticket-subject").value.trim();
      const message = document.getElementById("ticket-message").value.trim();
      if (!subject || !message) return toast("موضوع و پیام را وارد کنید", "error");
      event.target.disabled = true;
      try {
        await Api.createTicket(subject, message);
        toast("تیکت ثبت شد ✅", "success");
        this.renderSupport();
      } catch (error) {
        toast("ثبت تیکت ناموفق بود", "error");
        event.target.disabled = false;
      }
    });
  },

  // ===================================================================
  // MORE: profile + connection tutorials + reseller
  // ===================================================================
  async renderMore() {
    const [{ telegram }, { balance }] = await Promise.all([Api.me(), Api.wallet()]);
    root.innerHTML = `
      ${card(`
        <p class="text-sm text-slate-400 mb-1">حساب کاربری</p>
        <p class="text-lg font-bold mb-1">${telegram.first_name || ""} ${telegram.last_name || ""}</p>
        <p class="text-xs text-slate-500">آیدی عددی: <span class="text-slate-300">${telegram.id}</span>${telegram.username ? ` &nbsp;|&nbsp; @${telegram.username}` : ""}</p>
        <p class="text-xs text-slate-500 mt-1">موجودی: <span class="text-slate-300">${fa(balance)} تومان</span></p>
      `, "mb-3")}

      ${card(`
        <p class="text-sm font-bold mb-2">📡 آموزش اتصال</p>
        <p class="text-xs text-slate-400 leading-6 mb-3">
          ۱. از تب «سرویس‌ها»، روی «کپی کانفیگ» یا «QR» سرویس مدنظر بزنید.<br/>
          ۲. یکی از اپلیکیشن‌های زیر را نصب کنید.<br/>
          ۳. لینک اشتراک (Subscription) را در اپلیکیشن وارد کرده و به‌روزرسانی (Update) بزنید، یا کد QR را اسکن کنید.<br/>
          ۴. روی دکمه اتصال بزنید و از فیلترشکن لذت ببرید 🎉
        </p>
        <div class="grid grid-cols-2 gap-2 text-xs">
          <a href="https://play.google.com/store/apps/details?id=com.v2ray.ang" target="_blank" class="bg-slate-800 rounded-xl px-3 py-2 text-center">🤖 v2rayNG (اندروید)</a>
          <a href="https://apps.apple.com/app/streisand/id6450534064" target="_blank" class="bg-slate-800 rounded-xl px-3 py-2 text-center">🍏 Streisand (آیفون)</a>
          <a href="https://apps.apple.com/app/foxray/id6448898396" target="_blank" class="bg-slate-800 rounded-xl px-3 py-2 text-center">🍏 FoXray (آیفون)</a>
          <a href="https://github.com/hiddify/hiddify-next/releases" target="_blank" class="bg-slate-800 rounded-xl px-3 py-2 text-center">💻 Hiddify (ویندوز/مک)</a>
        </div>
      `, "mb-3")}

      <div id="more-referral"></div>
      <div class="h-3"></div>
      <div id="more-reseller"></div>
    `;
    await this.renderReferralBlock(document.getElementById("more-referral"));
    await this.renderResellerBlock(document.getElementById("more-reseller"));
  },

  async renderReferralBlock(container) {
    const ref = await Api.referralInfo();
    container.innerHTML = card(`
      <p class="text-sm font-bold mb-2">🎁 دعوت از دوستان</p>
      <p class="text-xs text-slate-400 mb-3">
        با اشتراک‌گذاری لینک زیر، به ازای هر دوست جدید ${fa(ref.signup_bonus)} تومان و از هر شارژ حساب او (${fa(ref.charge_percent)}٪) به‌صورت مستمر پورسانت دریافت می‌کنید.
      </p>
      ${
        ref.link
          ? `<div class="bg-slate-800 rounded-xl p-3 text-xs break-all mb-2" style="direction:ltr">${ref.link}</div>
             ${button("📋 کپی لینک دعوت", { id: "copy-ref", full: true, variant: "ghost" })}`
          : `<p class="text-xs text-slate-500">لینک دعوت در دسترس نیست.</p>`
      }
      <div class="grid grid-cols-2 gap-2 mt-3 text-center">
        <div class="bg-slate-800 rounded-xl py-2"><p class="text-lg font-bold">${fa(ref.member)}</p><p class="text-xs text-slate-400">دعوت‌شده</p></div>
        <div class="bg-slate-800 rounded-xl py-2"><p class="text-lg font-bold">${fa(ref.earned)}</p><p class="text-xs text-slate-400">درآمد (تومان)</p></div>
      </div>
    `);
    container.querySelector("#copy-ref")?.addEventListener("click", () => copyText(ref.link));
  },

  async renderResellerBlock(container) {
    const { reseller } = await Api.resellerStatus();
    if (reseller) {
      container.innerHTML = card(`
        <p class="text-sm text-slate-400 mb-1">ربات نمایندگی شما</p>
        <p class="text-lg font-bold mb-3">@${reseller.username || "-"}</p>
        <div class="text-xs text-slate-400 space-y-1">
          <p>وضعیت: <span class="text-slate-200">${reseller.status === "active" ? "🟢 فعال" : "🔴 مسدود"}</span></p>
          <p>استقرار: <span class="text-slate-200">${reseller.deploy_status}</span></p>
        </div>
      `);
      return;
    }
    container.innerHTML = card(`
      <p class="text-sm font-bold mb-2">🤝 ربات نمایندگی</p>
      <p class="text-xs text-slate-400 mb-3">با ثبت توکن ربات خودتان، یک نسخه اختصاصی و ایزوله از ربات (نمایندگی) برای شما راه‌اندازی می‌شود. هزینه راه‌اندازی و حداقل موجودی لازم توسط مدیریت تعیین می‌شود و از کیف پول شما کسر خواهد شد.</p>
      ${field("توکن ربات (از @BotFather)", { id: "reseller-token", placeholder: "123456:AAExample-Token" })}
      ${button("🚀 ثبت درخواست", { id: "reseller-submit", full: true })}
    `);
    document.getElementById("reseller-submit").addEventListener("click", async (event) => {
      const token = document.getElementById("reseller-token").value.trim();
      if (!token) return toast("توکن را وارد کنید", "error");
      event.target.disabled = true;
      event.target.textContent = "⏳ در حال ساخت ...";
      try {
        const result = await Api.requestReseller(token);
        toast(`ربات @${result.username} با موفقیت ساخته شد ✅`, "success");
        this.renderMore();
      } catch (error) {
        const messages = {
          insufficient_balance: "موجودی کیف پول شما کافی نیست.",
          token_invalid: "توکن نامعتبر است.",
          token_taken: "این توکن قبلا استفاده شده است.",
          already_have_reseller: "شما قبلا یک ربات نمایندگی دارید.",
          deploy_failed: "راه‌اندازی با خطا مواجه شد؛ مبلغ به کیف پول بازگردانده شد.",
        };
        toast(messages[error.code] || "خطا در ثبت درخواست", "error");
        event.target.disabled = false;
        event.target.textContent = "🚀 ثبت درخواست";
      }
    });
  },
};
