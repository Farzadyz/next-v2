// lib
import express from "express";
import cron from "node-cron";
import path from "path";
import cors from "cors";
import bodyParser from "body-parser";
// utils
import sequelize from "./app/utils/database.js";
import RunMigrations from "./app/utils/migrations.js";
import { bot, startBot } from "./app/bot/index.js";
import { launchAllActiveResellers, stopAllResellerBots } from "./app/bot/reseller/ResellerManager.js";
import { installSyncHooks } from "./app/reseller-api/services/syncHooks.js";
import { installPaygRechargeHook } from "./app/utils/paygRecharge.js";
import Router from "./app/routes/index.js";
// cron
import BackUp from "./app/cronjobs/backup.js";
import Session from "./app/cronjobs/session.js";
import Alert from "./app/cronjobs/alert.js";
import SendAll from "./app/cronjobs/sendAll.js";
import SendGiftAlert from "./app/cronjobs/alert_gift.js";
import RialitVerify from "./app/cronjobs/rialit.js";
import AtlasPayVerify from "./app/cronjobs/atlaspay.js";
import PaygBilling from "./app/cronjobs/paygBilling.js";
import PaygDelete from "./app/cronjobs/paygDelete.js";
import TestServiceExpire from "./app/cronjobs/testServiceExpire.js";

const Create = async () => {
  const __dirname = path.resolve(); // برای گرفتن مسیر فعلی

  const SetupDB = () => {
    sequelize.sync().catch();
  };

  const setupServer = () => {
    const app = express();
    app.use(cors());
    // استفاده از body-parser برای JSON
    // limit افزایش یافت (نه پیش‌فرض 100kb) چون آپلود رسید کارت‌به‌کارت از
    // Mini App بصورت base64 داخل بدنه JSON ارسال می‌شود (فقط JSON از سمت
    // ربات/مینی‌اپ می‌آید، هیچ فایل باینری مستقیمی آپلود نمی‌شود)
    app.use(bodyParser.json({ limit: "10mb" }));
    // استفاده از body-parser برای x-www-form-urlencoded
    app.use(bodyParser.urlencoded({ extended: true, limit: "10mb" }));
    // تنظیم EJS به عنوان موتور قالب‌سازی
    app.set("view engine", "ejs");
    app.set("views", path.join(__dirname, "public", "views")); // تنظیم مسیر صحیح برای پوشه views

    // مسیر فایل‌های استاتیک مثل CSS و تصاویر
    app.use(express.static(path.join(__dirname, "public")));
    app.use(Router);
    app.use(async (req, res, next) => {
      const id_bot = "https://t.me/" + (await bot.telegram.getMe()).username;
      return res.redirect(id_bot);
    });
    app.listen(3100, () => {
      console.log("app listen to port 3100");
    });
  };

  const setCronJob = () => {
    cron.schedule("* * * * *", () => {
      // Alert();
      SendAll();
      BackUp();
    });

    cron.schedule("0 0 1-7 * 5", () => {
      Session();
    });
    // پیام تخفیف ۵٪ برای فاکتورهای پرداخت‌نشده، هر ۲۴ ساعت یکبار
    cron.schedule("0 0 * * *", () => {
      SendGiftAlert();
    });
    cron.schedule("*/5 * * * *", () => {
      RialitVerify();
    });
    // اطلس‌پی کال‌بک مستقیم به سرور نداره، هر دقیقه سفارش‌های در انتظار رو استعلام می‌کنیم
    cron.schedule("* * * * *", () => {
      AtlasPayVerify();
    });
    // سرویس‌های PAYG: مصرف داده لحظه‌ای (هر ۵ ثانیه) از کیف پول کسر می‌شود، هزینه روزانه در ابتدای هر روز از قبل کسر
    // می‌شود و در صورت اتمام/کمبود موجودی سرویس همان لحظه روی پنل غیرفعال (تعلیق) می‌شود
    cron.schedule("*/5 * * * * *", () => {
      PaygBilling();
    });
    // سرویس‌های PAYG تعلیق‌شده رو هر ۳۰ ثانیه بررسی می‌کنیم (فعال‌سازی مجدد بعد از شارژ یا حذف بعد از ۱۲ ساعت)
    cron.schedule("*/30 * * * * *", () => {
      PaygDelete();
    });
    // سرویس‌های تست (رایگان) منقضی‌شده روی x-ui رو هر ۱۰ دقیقه واقعا غیرفعال می‌کنیم
    cron.schedule("*/10 * * * *", () => {
      TestServiceExpire();
    });
  };

  await SetupDB();
  await RunMigrations();
  // wallet top-up (any gateway / admin / card-to-card) -> suspended PAYG configs are re-enabled instantly
  installPaygRechargeHook();
  // instant push of servers / plans / permission matrices to every running reseller bot
  await installSyncHooks().catch((error) => console.log("sync hooks skipped:", error?.message || error));
  await setupServer();
  setCronJob();

  try {
    startBot();
  } catch (error) {
    console.log(error);
  }

  try {
    await launchAllActiveResellers();
  } catch (error) {
    console.log(error);
  }
};
Create();

// Graceful shutdown - closes every bot's long-poll connection to Telegram
// before the process exits. Without this, a restart (deploy, pm2/nodemon
// restart, docker restart, etc.) kills the process while its getUpdates
// connections are still open; the next process then collides with Telegram
// (HTTP 409 Conflict) and, for reseller bots especially, that poller simply
// never recovers on its own - the bot answers once (whatever was already
// in-flight) and then goes completely silent, including things like /panel
// appearing to "not work" even though nothing is actually wrong with the
// /panel handler itself.
const shutdown = (signal) => {
  console.log(`${signal} received, shutting down gracefully...`);
  stopAllResellerBots();
  bot.stop(signal);
  process.exit(0);
};
process.once("SIGINT", () => shutdown("SIGINT"));
process.once("SIGTERM", () => shutdown("SIGTERM"));
